#ifndef WIDGETDANSONGLET_H
#define WIDGETDANSONGLET_H

#include <QWidget>
#include <QTextEdit>
#include <QHBoxLayout>
#include <QTabWidget>

#include "widgetLigne.h"
#include "editeur.h"

#include <iostream>
#include <QFileInfo>
using namespace std;

/*!
* \file WidgetDansOnglet.h
* \brief QWidget qui contient les numeros de ligne et l'editeur: tout ce qui se trouve dans l'onglet
* \author FHAL Jonathan
* \date 25.05.2009
*/

/*!
* \class WidgetDansOnglet
* \brief Classe permettant de g�rer ce qu'il y a dans l'onglet
*/

class WidgetDansOnglet : public QWidget
{
    Q_OBJECT 

    private:
        /*! \brief Contient les lignes et les signets */
        WidgetLigne *ma_widget_ligne;
        /*! \brief QTextEdit du fichier */
        Editeur * text_edit;
        /*! \brief Information sur le fichier ouvert */
        QFileInfo* info_fichier;
        bool enregistre;

    public:
        // Constructeur & Destructeur
        /*!
        *  \brief Constructeur
        *
        *  Constructeur de la classe WidgetDansOnglet
        *
        *  \param parent : parent de l'objet
        *  \param QFileInfo : Info sur le fichier
        */
       WidgetDansOnglet(QTabWidget *parent = 0, QFileInfo* = 0);

        // GETs & SETs
        /*! \return un WidgetLigne */
        WidgetLigne* getMaWidgetLigne();
        /*! \return un Editeur */
        Editeur* getTextEdit();
        /*! \brief modifie WidgetLigne */
        void setMaWidgetLigne(WidgetLigne*);
        /*! \brief modifie TextEdit */
        void setTextEdit(Editeur*);
        /*! \brief modifie les informations sur un fichier */
        void setInfoFichier(QFileInfo*);
        /*! \return QFileInfo: les informations sur un fichier  */
        QFileInfo* getInfoFichier();

        void setEnregistre(bool);
        bool getEnregistre();

        //Methodes
        void ecritDansLabelLigne();

     //public slots:
    protected :
       virtual void resizeEvent(QResizeEvent*);


};
#endif // WIDGETDANSONGLET_H
