#include "modifCompleter.h"
#include <QString>
#include <QTextEdit>
#include <QWidget>
#include <QAction>
#include <QLabel>
#include <QPalette>
#include <QColor>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QActionGroup>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QHBoxLayout>
#include <QTextStream>
#include <iostream>
#include "modifierLangage.h"
#include "mesConfigs.h"
#include "Preferences.h"
#include <QTabWidget>
#include "widgetDansOnglet.h"
#include "mainwindow.h"
using namespace std;

ModifCompleter::ModifCompleter(Completer * completer,Preferences *parent) : QWidget()
{
      this->parent = parent;
      this->completer = completer;

      QGridLayout *grille= new QGridLayout(this);
      QHBoxLayout *hb1 = new QHBoxLayout;
      QHBoxLayout *hb2 = new QHBoxLayout;
      QHBoxLayout *hb3 = new QHBoxLayout;

      l_ajouter_mot = new QLabel(tr("Ajoutez un mot � l'auto-completion :"));
      le_ajouter_mot = new QLineEdit(this);
      pb_ajouter_mot = new QPushButton(tr("Valider"),this);

      hb1->addWidget(l_ajouter_mot);
      hb1->addWidget(le_ajouter_mot);
      hb1->addWidget(pb_ajouter_mot);


      l_nb_lettre = new QLabel(tr("Choisissez le nombre de caract�re d�clanchant l'auto-completion :"));
      cb_nb_lettre = new QComboBox;
      cb_nb_lettre->addItem(tr("Choississez un nombre de lettre"));
      cb_nb_lettre->addItem("2");
      cb_nb_lettre->addItem("3");
      cb_nb_lettre->addItem("4");
      cb_nb_lettre->addItem("5");
      cb_nb_lettre->setCurrentIndex(0);
      pb_nb_lettre = new QPushButton(tr("Valider"),this);

      hb2->addWidget(l_nb_lettre);
      hb2->addWidget(cb_nb_lettre);
      hb2->addWidget(pb_nb_lettre);


      l_desactiver_completer = new QLabel(tr("Voulez-vous d�sactiver l'auto-completion ?"));
      cb_desactiver_completer = new QCheckBox(tr("d�sactiver"));

      hb3->addWidget(l_desactiver_completer);
      hb3->addWidget(cb_desactiver_completer);

      grille->addLayout(hb1,1,0);
      grille->addLayout(hb2,2,0);
      grille->addLayout(hb3,3,0);

      connect(pb_ajouter_mot, SIGNAL(clicked()),this,SLOT(ajouteMot()));
      connect(pb_nb_lettre, SIGNAL(clicked()),this,SLOT(nbLettre()));
      connect(cb_desactiver_completer,SIGNAL(clicked()),this,SLOT(desactiverCompleter()));
}


void ModifCompleter::ajouteMot()
{
    completer->ajouteVariable(le_ajouter_mot->text());
}

void ModifCompleter::nbLettre()
{
    completer->setNbLettre(cb_nb_lettre->currentText().toInt());
}

void ModifCompleter::desactiverCompleter()
{
    completer->setActif(!cb_desactiver_completer->isChecked());
}



