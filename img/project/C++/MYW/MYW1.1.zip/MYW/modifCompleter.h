#ifndef MODIFCOMPLETER_H
#define MODIFCOMPLETER_H
#include "completer.h"
#include <QObject>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QColor>
#include <QFrame>
#include <QGroupBox>
#include <QCheckBox>
#include <QPushButton>
#include "couleur.h"

class Preferences;

/*!
* \class ModifCompleter
* \brief Classe permettant de personnaliser l'auto completion
*
* Ce widget peut etre integre dans la classe preference afin de l'afficher en onglet
*
*/

class ModifCompleter : public QWidget
{
     Q_OBJECT

    private :
        Completer *completer;                   /*< le completer de l'editeur */
        QTextEdit *editeur;                     /*< le champs de texte*/
        Preferences *parent;                    /*< parent de modifCompleter*/

        QVBoxLayout *vbox;                      /*< le conteneur d'affichage horizontal*/

        QLineEdit *le_ajouter_mot;              /*< le champs accueillant le mot a ajouter*/
        QLabel *l_ajouter_mot;                  /*< les indications pour l'ajout de mot*/
        QPushButton *pb_ajouter_mot;            /*< le bouton de validation*/

        //QLineEdit *le_nb_lettre;                /*< le champs accueillant */
        QLabel *l_nb_lettre;                    /*< l'indication du choix du nombre de caractere declanchant l'auto-completion*/
        QComboBox *cb_nb_lettre;                /*< la liste de completion du choix du nombre de caractere declanchant l'auto-completion*/
        QPushButton *pb_nb_lettre;              /*< le bouton de validation du choix du nombre de caractere declanchant l'auto-completion*/

        QLabel *l_desactiver_completer;         /*< l'indication de la desactivation de l'automatisme du completer*/
        QCheckBox *cb_desactiver_completer;     /*< la check box de la desactivation de l'automatisme du completer*/


    public:
        /*!
        * \brief Constructeur
        *
        * Constructeur de la classe modifCompleter
        *
        * \param parent : le parent de la classe modifCompleter est de type Preferences
        * \param completer : le completer
        */
        ModifCompleter(Completer *completer,Preferences *parent );

    public slots:
        /*!
        * \brief ajouteMot
        *
        * le slot declenche par l'ajout d'un mot
        */
        void ajouteMot();

        /*!
        * \brief nbLettre
        *
        * le slot declenche par le choix du nombre de lettre
        */
        void nbLettre();

        /*!
        * \brief desactiverCompleter
        *
        * le slot declenche par la desactivation du completer
        */
        void desactiverCompleter();
};

#endif // MODIFCOMPLETER_H
