#include "Fichier.h"

using namespace std;

//constructeur
Fichier::Fichier()
{
	mon_fichier = "plan.html";
	Ecriture.open(mon_fichier.c_str(), ios::out | ios::app);
	Lecture.open(mon_fichier.c_str(), ios::in);
//	cout << "fichier construit" << endl;
}

//destructeur
Fichier::~Fichier()
{
}

//initialisation
void Fichier::initialiser()
{}

//accesseur
string Fichier::getMon_ficher()
{
	return mon_fichier;
}

void Fichier::setMon_fichier(string m)
{
	mon_fichier = m;
}

//saisir des donnees
void Fichier::saisie()
{
	if(Ecriture)
	{
		string en_tete;
		string bas_page;
		
		Ecriture.close();
	}
	else
	{
		cout<<"impossible d'ouvrir plan.html"<<endl;
	}
}

//effacer le fichier
void Fichier::effacer()
{}

//afficher le contenu de la page html
void Fichier::afficher()const
{
	ifstream Lecture(mon_fichier.c_str(), ios::in);
	if(Lecture)
	{
        	string ligne = "";
        	while( getline(Lecture, ligne) )  // tant que l'on peut mettre la ligne dans "contenu lu"
        	{
               		cout << ligne << endl;  // on l'affiche
        	}
        	Lecture.close();
	}
	else
	{
		cout<<"impossible d'ouvrir plan.html"<<endl;
	}

}

//en tete de notre page html
void Fichier::enTete()
{
	string s;
	
	s = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" ";
	s = s + "\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">";
	s = s + "\n";
	s = s + "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" >";
	s = s + "\n";
	s = s + "      " + "<head>";
	s = s + "\n";
	s = s + "      " + "      " + "<title>Plan du site !</title>";
	s = s + "\n";
	s = s + "      " + "      " + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />";
	s = s + "\n";
	s = s + "      " + "</head>";
	s = s + "\n";
	s = s + "      " + "<body>";
	
	ajouter(s);
}

//en queue de notre page html
void Fichier::enQueue()
{
	string s = "";
	s = s + "\n";
	s = s + "      " + "</body>";
	s = s + "\n";
	s = s + "</html>" + " \n";
	
	ajouter(s);
	
}

//ajouter des lignes dans le corps de la page html
void Fichier::ajouter(string s)
{
	if(Ecriture)
	{
		Ecriture << s;
	}
	else
	{
		cout<<"impossible d'ajouter dans plan.html"<<endl;
	}
}

//prefixe
string Fichier::prefixe(string extension)
{
	string pref;
	cout<<"taille mon fichier :"<<mon_fichier.length()<<endl;
	cout<<"taille extension :"<<extension.length()<<endl;
	
	if( mon_fichier.substr(mon_fichier.length() - extension.length(), extension.length() ) == extension )
	{
		
		pref = mon_fichier.substr(0, mon_fichier.length() - extension.length() );
		cout<< pref<< endl;
	}
	return pref;
	
}
