#ifndef Arbo_h
#define Arbo_h
#include <QDir>
#include <QStringList>
#include <QString>
#include <QList>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <iostream>
#include "Fichier.h"

using namespace std;

class Arbo
{
	private:
		DIR* repertoire;
		struct dirent* rep_pointe;
                Fichier site_map;
	public:
		Arbo();
		
		virtual ~Arbo();
		
		//lister le contenu du repertoire nom
		virtual void listerRepertoire(char* nom);
		
		virtual void listerRepertoireV2(char* nom);

                virtual void listerRepALaQt();
	
};
#endif
