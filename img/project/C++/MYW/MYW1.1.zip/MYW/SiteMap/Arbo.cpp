#include "Arbo.h"

using namespace std;

//constructeur
Arbo::Arbo()
{
	repertoire = NULL;
	rep_pointe = NULL;
}

//destructeur
Arbo::~Arbo()
{
}

//lister le contenu du repertoire nom
void Arbo::listerRepertoire(char* nom)
{
	repertoire = opendir(nom);
	
	if( repertoire == NULL )
	{
		cout<<"erreur"<<endl;
	}
	else
	{
		rep_pointe = readdir(repertoire);
		while( rep_pointe != NULL)
		{
			cout<< rep_pointe->d_name;
		}
		closedir(repertoire);
	}
}

//lister le contenu du repertoire nom avec Fichier
void Arbo::listerRepertoireV2(char* nom)
{
	repertoire = opendir(nom);
	
	if( repertoire == NULL )
	{
		cout<<"erreur"<<endl;
	}
	else
	{
		rep_pointe = readdir(repertoire);
                while( rep_pointe != NULL )
		{
			//cout<< rep_pointe->d_name;
                        site_map.setMon_fichier(rep_pointe->d_name);
                        cout<<site_map.prefixe(".html")<<endl;
		}
		closedir(repertoire);
	}
}

void Arbo::listerRepALaQt()
{
    QDir rep("SiteMap/www/");
    QStringList list = rep.entryList();
    for(int i=0; i<rep.count(); i++)
    {
//        cout<<list.value(i).toStdString()<<endl;
    }
}

