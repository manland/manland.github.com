#ifndef Fichier_h
#define Fichier_h

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class Fichier
{
	private:
		string mon_fichier;
		
		//ouverture en ecriture
		//ofstream Ecriture(mon_fichier.c_str(), ios::out | ios::trunc);
		ofstream Ecriture;
		
		//ouverture en lecture
		//ifstream Lecture(mon_fichier.c_cstr(), ios::in);
		ifstream Lecture;

	public:
		Fichier();
		
		virtual ~Fichier();
		
		virtual void saisie();
		
		virtual void initialiser();
		
		//accesseur
		virtual string getMon_ficher();
		
		virtual void setMon_fichier(string m);
		
		//effacer le contenu de la page html
		virtual void effacer();
		
		//en tete de notre page html
		virtual void enTete();
		
		//en queue de notre page html
		virtual void enQueue();
		
		//ajouter des lignes dans le corps de la page html
		virtual void ajouter(string s);
		
		//afficher le contenu de la page html
		virtual void afficher() const;
		
		//prefixe
		virtual string prefixe(string extension);
		
	
};
#endif
