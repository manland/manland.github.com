#include <iostream>
#include <fstream>
#include "Fichier.h"
#include "Arbo.h"

using namespace std;

int main(int argc, char* argv[])
{
	Fichier F;
	Arbo G;
	
	F.enTete();
	//bientot ici le corps
	F.enQueue();
	//F.afficher();
	
	//tester
	//F.prefixe(".html");
	G.listerRepertoireV2("www");
}
