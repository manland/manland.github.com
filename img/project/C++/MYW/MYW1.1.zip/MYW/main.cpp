#include <QtGui/QApplication>
#include <QTranslator>
#include <QLocale>
#include "mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTranslator qt_lang;
    QTranslator myw_lang;
    if(argc>1)
    {
        qt_lang.load("qt_"+QString(argv[1]), QString("Traductions/").prepend(systeme_relation_fichier));
        a.installTranslator(&qt_lang);
        myw_lang.load("MYW_"+QString(argv[1]), QString("Traductions/").prepend(systeme_relation_fichier));
        a.installTranslator(&myw_lang);
    }
    else
    {
        //par défaut ça cherche par rapport au système si rien n'est trouvé alors anglais
        //présents : fr, de, en (de base)
        qt_lang.load("qt_"+QLocale:: system().name(),  QString("Traductions/").prepend(systeme_relation_fichier));
        a.installTranslator(&qt_lang);
        myw_lang.load("MYW_"+QLocale::system().name(),  QString("Traductions/").prepend(systeme_relation_fichier));
        a.installTranslator(&myw_lang);
    }

    MainWindow w;

    return a.exec();
}
