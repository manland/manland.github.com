#include "erreur.h"
#include "mesConfigs.h"
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <iostream>
using namespace std;

Erreur::Erreur()
{
}

bool Erreur::ecritErreur(QString nom_classe, QString nom_fonction, int ligne)
{
    QDateTime date = QDateTime::currentDateTime();

    QString tmp = QString(systeme_relation_fichier).append("Erreurs/log.txt");
    QFile fichier(tmp);
    if(fichier.open(QFile::WriteOnly | QFile::Append))
    {
        QTextStream out(&fichier);
        out<<date.toString("Le dd.MM.yyyy a hh:mm:ss :")<<"Erreur sur le fichier "<<nom_classe<<" avec la fonction "<<nom_fonction;
        if(ligne != -1)
            out<<" a la ligne "<<ligne;
        out<<endl;
        fichier.close();
        return true;
    }
    return false;
}

bool Erreur::ecritErreurWebBrowser(QString nom_classe, QString nom_fonction, int ligne)
{
    QDateTime date = QDateTime::currentDateTime();
    QString tmp = QString(systeme_relation_fichier).append("Erreurs/logWebBrowser.txt");
    QFile fichier(tmp);
    if(fichier.open(QFile::WriteOnly | QFile::Append))
    {
        QTextStream out(&fichier);
        out<<date.toString("Le dd.MM.yyyy a hh:mm:ss :")<< "Erreur sur le fichier "<<nom_classe<<" avec la fonction "<<nom_fonction;
        if(ligne != -1)
            out<<" a la ligne "<<ligne;
        out<<endl;
        fichier.close();
        return true;
    }
    return false;
}
