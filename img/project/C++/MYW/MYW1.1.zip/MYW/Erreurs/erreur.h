#ifndef ERREUR_H
    #define ERREUR_H


/*!
* \file editeur.h
* \brief Classe principale du module Erreur.
* \author Maillet Laurent
* \date 17/05/2009
*/

#include <QString>
#include <QDateTime>

/*!
* \class Erreur
* \brief Classe principale du module Erreur.
*
*   Permet d'inscrire dans un fichier les erreurs qui ne devraient pas �tre rencontr�
*   et ainsi de les traiter en cons�quences
*
*/
class Erreur
{
    public:
        Erreur();
        /*!
         *  \brief Ecrit les erreurs en relation avec toutes les modules sauf Web Browser
         *
         *  \param c : nom de la classe o� se trouve l'erreur
         *  \param f : nom de la fonction o� se trouve l'erreur
         *  \param l : num�ro de la ligne o� se trouve l'erreur
         */
        static bool ecritErreur(QString c , QString f , int l = -1);
        /*!
         *  \brief Ecrit les erreurs en relation avec le module Web Browser
         *
         *  \param c : nom de la classe o� se trouve l'erreur
         *  \param f : nom de la fonction o� se trouve l'erreur
         *  \param l : num�ro de la ligne o� se trouve l'erreur
         */
        static bool ecritErreurWebBrowser(QString c , QString f , int l = -1);
};

#endif // ERREUR_H
