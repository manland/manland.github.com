#include "widgetDansOnglet.h"

// Constructeur
WidgetDansOnglet::WidgetDansOnglet(QTabWidget *parent, QFileInfo* info) : QWidget(parent)
{
    QHBoxLayout *hBoxLayout = new QHBoxLayout(parent);

    //** MODIF **//
    text_edit = new Editeur(parent);
    ma_widget_ligne = new WidgetLigne(text_edit);
    text_edit->setWidgetLigne(ma_widget_ligne);
    if(info)//fichier deja existant
    {
        info_fichier = info;
        enregistre = true;
    }
    else //fichier non existant
    {
        info_fichier = new QFileInfo();
        enregistre = false;
    }

    //hBoxLayout->addWidget(ma_widget_ligne);
    hBoxLayout->addWidget(text_edit);

    hBoxLayout->setMargin(0);
    hBoxLayout->setSpacing(0);
    //hBoxLayout->setContentsMargins(0, 1, 0, 0);

    QFont font_text_edit = text_edit->font();
    //this->getMaWidgetLigne()->getLabelLigne()->setFont(font_text_edit);
    //****//

    this->setLayout(hBoxLayout);
}


// GETs & SETs
WidgetLigne* WidgetDansOnglet::getMaWidgetLigne() {
    return ma_widget_ligne;
}

Editeur* WidgetDansOnglet::getTextEdit() {
    return text_edit;
}

void WidgetDansOnglet::setMaWidgetLigne(WidgetLigne *newMaWidgetLigne) {
    ma_widget_ligne = newMaWidgetLigne;
}

void WidgetDansOnglet::setTextEdit(Editeur *newTextEdit) {
    text_edit = newTextEdit;
}

void WidgetDansOnglet::setInfoFichier(QFileInfo* info)
{
    info_fichier = info;
}

QFileInfo* WidgetDansOnglet::getInfoFichier()
{
    return info_fichier;
}
void WidgetDansOnglet::setEnregistre(bool b)
{
    enregistre = b;
}

bool WidgetDansOnglet::getEnregistre()
{
    return enregistre;
}

// SLOTS

void WidgetDansOnglet::resizeEvent(QResizeEvent *e)
{
    ma_widget_ligne->resizeEvent(e);
}
