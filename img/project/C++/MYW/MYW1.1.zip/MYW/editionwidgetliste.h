#ifndef EDITIONWIDGETLISTE_H
    #define EDITIONWIDGETLISTE_H

/*!
* \file editionwidgetliste.h
* \brief Classe du module MainWindow.
* \author Maillet Laurent
* \date 16/05/2009
*/

#include "Entete.h"
#include <QWidget>
#include <QString>
#include <QGridLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QCheckBox>

/*!
* \class EditionWidgetListe
* \brief Classe du module MainWIndow.
*
* Elle s'int�gre dans les onglets de pr�f�rences
* Elle permet de g�rer les signets : ajout/suppression de signets
* les signets sont stock�s sur le pc, si un signet existe mais que qon image ne
* se trouve plus � l'endroit pr�vu alors le signet est supprim� automatiquement
* Je rappelle que les signets sont g�r�s par la stuct widgetListe
*
* Les images sont stock�es dans le dossier Images du dossier Editeur
*
*/

class EditionWidgetListe : public QWidget
{
    Q_OBJECT

    private :
        QString tableau_fiche[MAX_NOMBRE_WIDGET_LISTE][2];/*!< tableau contenant les noms et les chemin d'image des signets*/
        QCheckBox* fiche_a_supprimer;
        int taille_tableau_fiche;/*!< taille du tableau courant, doit �tre inf�rieur � MAX_NOMBRE_WIDGET_LISTE*/
        QGridLayout *grille;
        QGridLayout *sous_grille;
        QLineEdit *texte;/*!< champ dans lequel on rentre le nom d'un nouveau signet*/
        QLineEdit *chemin_image;/*!< champ dans lequel on rentre le chemin de l'image d'un nouveau signet*/
        QPushButton *bouton_chemin_image;
        QPushButton *ajouter;
        QString nom_fichier;
        QLabel** affichage_fiche;
        QLabel* texte_fiche;
        QLabel* texte_chemin_image;
        QLabel* etat; /*!< affichage de l'etat en cours : chargement de la fen�tre, suppression ou ajout de signet*/
    public:
        /*!
         *  \brief Constructeur
         *
         *  Constructeur de la classe EditionWidgetListe
         *
         *  \param parent : parent de l'objet
         *
         */
        EditionWidgetListe(QWidget* = 0);
        /*!
         *  \brief R�cup�ration des signets conserv�s sur l'ordinateur
         *
         *  Permet de r�cup�rer les signets conserv�s sur l'ordinateur.
         *  On r�cup�re uniquement le nom et le chemin du signet
         *
         *  \return le nombre de signet r�cup�r�
         *
         */
        int restaurer();
        /*!
         *  \brief Sauvegarde des signets sur l'ordinateur
         *
         *  Permet de sauvegarder les signets sur l'ordinateur.
         *  On stocke uniquement le nom et le chemin de l'image du signet
         *
         *  \return le nombre de signet r�cup�r�
         *
         */
        void sauvegarder();
        /*!
         *  \brief Mise � jour de la widget
         *
         *  Lors de l'ajout ou de la suppression d'un signet, ou lorsque on ne
         *  trouve pas l'image en rapport avec le signet, cette fonction permet
         *  de mettre � jour l'int�rieur de la widget
         *
         *  \param mode : permet de modifier l'etat de la widget, si mode = 0 c'est un ajout, si mode =1 c'est une suppression
         *
         */
        void miseAJour(int mode);
        /*!
         *  \brief Suppression d'un signet dans le tableau
         *
         *  Permet la suppression du signet dont l'indice est pass� en param�tre
         *
         *  \param i :le num�ro du signet � supprimer
         *
         */
        void supprimer(int i);

    public slots :
        /*!
         *  \brief R�cup�ration de l'image
         *
         *  ouvre une fen�tre Dialog et permet de r�cup�rer le chemin de l'image voulu
         *
         */
        void ouvreFenetreRechercheImage();
        /*!
         *  \brief Ajout d'un signet dans le tableau
         *
         *  Apr�s v�rifications d'usage (existence de l'image, non d�passement du tableau
         *  ou m�me �viter le m�me nom pour 2 signets) cette fonction ins�re le signet
         *  dont on a rentr� les param�tres puis les sauvegarde
         *
         */
        void ajoutFiche();
        /*!
         *  \brief Suppression d'un signet dans le tableau
         *
         *  Lorsqu'on coche une case � cocher(QCheckBox), cette fonction r�cup�re le signet en relation
         *  avec la case � cocher et le supprimer en faisant appel � la m�thode
         *  EditionWidgetListe::supprimer(int)
         *
         *
         */
        void supprimer();
};

#endif // EDITIONWIDGETLISTE_H
