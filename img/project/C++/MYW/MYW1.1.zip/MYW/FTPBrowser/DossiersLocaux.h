#ifndef DOSSIERSLOCAUX_H
#define DOSSIERSLOCAUX_H

/*========================================================================
Nom: DossiersLocaux.h           auteur: Maneschi Romain
Maj: 17.05.2009                   Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe gérant l'affichage de l'arborescence du workspace ou du répertoir home.
=========================================================================*/

/*!
* \file DossiersLocaux.h
* \brief Classe gérant l'affichage de l'arborescence du workspace ou du répertoir home.
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QTreeWidget>
#include <QFileInfoList>
#include <QDir>

class WidgetLocal;

#include "MessagesToolBar.h"

/*!
* \class DossiersLocaux
* \brief Classe gérant l'affichage d'un répertoir et les actions en local
*
* Cette classe affiche un repertoir local avec possibilité sur double-click de rentrer dans un
* répertoir ou de télécharger le fichier. On peut remonter au dossier parent grâce à la convention abituelle du dossier nommer ".."
*
*/
class DossiersLocaux : public virtual QTreeWidget
{
    Q_OBJECT

private:
    WidgetLocal * parent;/*!< Le parent de la classe.*/
    MessagesToolBar * messages;/*!< Pointeur vers les messages relatifs au ftp*/
    QDir rep_courant;/*!< Répertoire courant*/
    /*!
    * \brief Méthode permettant de récupérer une taille sous la forme 4Ko au lieu de 4000
    *
    * \param i : quint64 retourner sous se format par Qt
    */
    virtual QString tailleString(quint64 i);
    QTreeWidgetItem* dernier_fichier_selectionne;/*!< dernier fichier clické*/
    QTreeWidgetItem * dernier_item_menu;/*!< dernier dossier clické*/
    //renommerWidget()
    QLineEdit * nouveau_nom;/*!< edition d'un nouveau nom pour un dossier ou fichier*/

private slots:
    /*!
    * \brief Méthode appelée par un double click sur un dossier ou un fichier et appelant le cd ou le téléchargement
    *
    * \param item : QTreeWidgetItem contient les informations nécessaire au traitement
    * \param i : int colonne double clickée
    */
    virtual void cmd(QTreeWidgetItem*, int);
    /*!
    * \brief Méthode appelée par un click sur un fichier et appelant l'activation des boutons de téléchargement
    *
    * \param item : QTreeWidgetItem contient les informations nécessaire au traitement
    * \param i : int colonne double clickée
    */
    virtual void clicked(QTreeWidgetItem*, int);
    /*!
    * \brief Méthode appelée par un click sur le bouton upload et appelant le téléchargement du dernier fichier clické
    */
    virtual void upload();
    /*!
    * \brief Supprime le dernier fichier ou dossier clické
    */
    virtual void remove();
    /*!
    * \brief Affiche le widget permettant de renommer un fichier
    */
    virtual void widgetRenommer();
    /*!
    * \brief Renomme le fichier aprés validation de widgetRenommer()
    */
    virtual void widgetRenommerOk();

protected:
    /*!
    * \brief Réimplante l'évènement du click droit de la souris
    *
    * \param e : QContextMenuEvent
    */
    virtual void contextMenuEvent(QContextMenuEvent*);

public slots:
    /*!
    * \brief Méthode appelée par Qt pour ajouter un fichier ou un dossier
    *
    * \param info : QUrlInfo contient les informations sur le fichier ou le dossier à ajouter
    */
    virtual void ajouterItem(const QFileInfo &);
    /*!
    * \brief Méthode listant le contenue du répertoir courant et appelant ajouterItem()
    */
    virtual void list();

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe DossiersLocaux
    *
    * \param parent : WidgetLocal parent conteneur des dossiers locaux
    * \param dir : QDir répertoire par défaut
    */
    DossiersLocaux(WidgetLocal*, QDir);
    /*!
    * \brief Retourne le path du répertoire courant
    */
    virtual QDir getRepCourant();
    /*!
    * \brief Change le répertoir courant
    *
    * \param s : QString charge le répertoir demandé par l'utilisateur
    */
    virtual void setRepCourant(QDir);
    /*!
    * \brief Renvoie le pointeur vers les messages
    */
    virtual MessagesToolBar* getMessages();
    /*!
    * \brief Renvoie le dernier item clické
    */
    virtual QTreeWidgetItem* getDernierItem();
    /*!
    * \brief Vérifie si le fichier ou dossier nommé QString ne soit pas déjà entré
    *
    * \param nom : QString le nom du fichier ou répertoir à vérifier
    */
    virtual bool existeDeja(QString);
};

#endif // DOSSIERSLOCAUX_H
