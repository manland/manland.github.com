/*========================================================================
Nom: WidgetLocal.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe conteneur de DossiersLocaux.
=========================================================================*/

#include <iostream>
using namespace std;

#include "WidgetLocal.h"
#include "FTPBrowser.h"

WidgetLocal::WidgetLocal(FTPBrowser * p, QDir dir) : QWidget(p)
{
    parent = p;
    home_dir = dir.absolutePath();
    verifier_existe_deja = true;

    QVBoxLayout * layout = new QVBoxLayout(this);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    emplacement = new QLineEdit(dir.absolutePath(), this);
    connect(emplacement, SIGNAL(textEdited(QString)), this, SLOT(verificationEmplacement(QString)));
    connect(emplacement, SIGNAL(returnPressed()), this, SLOT(emplacementNormalePalette()));
    connect(emplacement, SIGNAL(returnPressed()), this, SLOT(recharger()));

    cd_ou_cdparent = new QPushButton("", this);
    cd_ou_cdparent->setToolTip(tr("R�pertoire parent"));
    cd_ou_cdparent->setFlat(true);
    cd_ou_cdparent->setIconSize(QSize(25, 25));
    cd_ou_cdparent->setMaximumSize(25, 25);
    cdOuCdParent(false);

    ss_layout->addWidget(emplacement);
    ss_layout->addWidget(cd_ou_cdparent);
    layout->addLayout(ss_layout);

    //qtreewidget contenant les rep et dir
    local = new DossiersLocaux(this, dir);
    layout->addWidget(local);

    ss_layout = new QHBoxLayout();
    //home dir
    bouton_home_repertoir = new QPushButton(QIcon(":/FTPImages/home.png"), "", this);
    bouton_home_repertoir->setToolTip(tr("Accueil"));
    bouton_home_repertoir->setMaximumSize(70, 60);
    bouton_home_repertoir->setMinimumSize(60, 60);
    bouton_home_repertoir->setIconSize(QSize(60, 60));
    connect(bouton_home_repertoir, SIGNAL(clicked()), this, SLOT(cdHome()));
    ss_layout->addWidget(bouton_home_repertoir);
    //cr�er dir
    bouton_nouveau_repertoir = new QPushButton(QIcon(":/FTPImages/newdossier.png"), "", this);
    bouton_nouveau_repertoir->setToolTip(tr("Cr�er Dossier"));
    bouton_nouveau_repertoir->setMaximumSize(70, 60);
    bouton_nouveau_repertoir->setMinimumSize(60, 60);
    bouton_nouveau_repertoir->setIconSize(QSize(55, 55));
    connect(bouton_nouveau_repertoir, SIGNAL(clicked()), this, SLOT(widgetAjouterDossier()));
    ss_layout->addWidget(bouton_nouveau_repertoir);
    //recharger
    bouton_recharger = new QPushButton(QIcon(":/FTPImages/reload.png"), "", this);
    bouton_recharger->setToolTip(tr("Recharger"));
    bouton_recharger->setMaximumSize(70, 60);
    bouton_recharger->setMinimumSize(60, 60);
    bouton_recharger->setIconSize(QSize(50, 50));
    connect(bouton_recharger, SIGNAL(clicked()), this, SLOT(recharger()));
    ss_layout->addWidget(bouton_recharger);
    layout->addLayout(ss_layout);

    setAttribute(Qt::WA_DeleteOnClose);
    mettreAJourEmplacement();
}

void WidgetLocal::widgetAjouterDossier()
{
    QWidget * w = new QWidget(this, Qt::Dialog);
    w->setWindowTitle(tr("Ajouter un dossier"));
    QVBoxLayout * layout = new QVBoxLayout(w);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    QLabel * l = new QLabel(tr("Emplacement : "));
    ss_layout->addWidget(l);
    emplacement_dossier = new QLineEdit(local->getRepCourant().absolutePath());
    emplacement_dossier->setEnabled(false);
    ss_layout->addWidget(emplacement_dossier);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Nom : "));
    ss_layout->addWidget(l);
    nom_dossier = new QLineEdit();
    nom_dossier->setFocus(Qt::ActiveWindowFocusReason);
    ss_layout->addWidget(nom_dossier);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    QPushButton * annuler = new QPushButton(QIcon(":/FTPImages/annuler.png"), tr("Annuler"));
    ss_layout->addWidget(annuler);
    QPushButton * ok = new QPushButton(QIcon(":/FTPImages/valider.png"), tr("Valider"));
    ss_layout->addWidget(ok);
    layout->addLayout(ss_layout);

    w->setMinimumSize(400, 100);
    w->show();
    connect(annuler, SIGNAL(clicked()), w, SLOT(close()));
    connect(ok, SIGNAL(clicked()), this, SLOT(widgetAjouterDossierOk()));
    connect(ok, SIGNAL(clicked()), w, SLOT(close()));
}

void WidgetLocal::widgetAjouterDossierOk()
{
    if(local->getRepCourant().mkdir(nom_dossier->text()))
    {
        recharger();
        local->getMessages()->ajouterMessage(QIcon(":/FTPImages/bon.gif"), tr("Dossier ")+nom_dossier->text()+tr(" ajout�."), 0);
    }
    else
    {
        local->getMessages()->ajouterMessage(QIcon(":/FTPImages/mauvais.gif"), tr("Dossier ")+nom_dossier->text()+tr(" non ajout�."), new QLabel(tr("Erreur")));
        recharger();
    }
}

void WidgetLocal::cdHome()
{
    local->setRepCourant(home_dir);
    recharger();
    mettreAJourEmplacement();
    emplacementNormalePalette();
    parent->getMessages()->ajouterMessage(QIcon(":/FTPImages/computer.png"), tr("D�placement dans le dossier <i><b>")+home_dir+tr("</b></i>"), 0);
}

void WidgetLocal::recharger()
{
    local->clear();
    local->list();

    mettreAJourEmplacement();
    emplacementNormalePalette();
    parent->getCommandes()->uploadOnOff(false);
}

FTPBrowser* WidgetLocal::getParent()
{
    return parent;
}

QString WidgetLocal::getRepCourant()
{
    return local->getRepCourant().absolutePath();
}

void WidgetLocal::mettreAJourEmplacement()
{
    emplacement->setText(local->getRepCourant().absolutePath());
    if(local->getRepCourant().absolutePath() == home_dir)
    {
        bouton_home_repertoir->setEnabled(false);
    }
    else
    {
        bouton_home_repertoir->setEnabled(true);
    }
    if(local->getRepCourant().isReadable())
    {
        bouton_nouveau_repertoir->setEnabled(true);
    }
    else
    {
        bouton_nouveau_repertoir->setEnabled(false);
    }
    if(local->getRepCourant().isRoot())
    {
        cd_ou_cdparent->setEnabled(false);
    }
    else
    {
        cd_ou_cdparent->setEnabled(true);
    }
}

void WidgetLocal::verificationEmplacement(QString s)
{
    QDir d(s);
    QPalette palette(emplacement->palette());

    if(d.exists())
    {
        palette.setColor(QPalette::Base, QColor(0,255,0));
        emplacement->setPalette(palette);
    }
    else
    {
        palette.setColor(QPalette::Base, QColor(255,0,0));
        emplacement->setPalette(palette);
    }

    cdOuCdParent(true);
}

void WidgetLocal::emplacementNormalePalette()
{
    QDir d(emplacement->text());

    if(d.exists())
    {
        QPalette palette(emplacement->palette());
        palette.setColor(QPalette::Base, QColor(255,255,255));
        emplacement->setPalette(palette);

        local->setRepCourant(d);
//        recharger();
        mettreAJourEmplacement();
        cdOuCdParent(false);
    }
    else
    {
        verificationEmplacement(emplacement->text());
        cdOuCdParent(true);
    }
}

void WidgetLocal::cdOuCdParent(bool b)//true si cd false sinon
{
    cd_ou_cdparent->disconnect();
    if(b)
    {
        cd_ou_cdparent->setIcon(QIcon(":/FTPImages/bon.gif"));
        cd_ou_cdparent->setToolTip(tr("Aller � "));
        connect(cd_ou_cdparent, SIGNAL(clicked()), emplacement, SIGNAL(returnPressed()));
        cd_ou_cdparent->setEnabled(true);
    }
    else
    {
        cd_ou_cdparent->setIcon(QIcon(":/FTPImages/up.png"));
        cd_ou_cdparent->setToolTip(tr("R�pertoire parent"));
        connect(cd_ou_cdparent, SIGNAL(clicked()), this, SLOT(cdUp()));
    }
}

void WidgetLocal::cdUp()
{
    QString rep = local->getRepCourant().absolutePath().left(local->getRepCourant().absolutePath().lastIndexOf("/"));
    if(rep.isEmpty())
    {
        rep = QDir::root().absolutePath();
    }
    local->setRepCourant(rep);
    recharger();
    parent->getMessages()->ajouterMessage(QIcon(":/FTPImages/computer.png"), tr("D�placement dans le dossier <i><b>")+rep+tr("</b></i>"), 0);
}

DossiersLocaux* WidgetLocal::getLocal()
{
    return local;
}

bool WidgetLocal::existeDeja(QString nom)
{
    return local->existeDeja(nom);
}

void WidgetLocal::widgetRemplacementFichier(QString nom, QIcon icon)
{
    QWidget * msg = new QWidget(this, Qt::Dialog);
    msg->setWindowTitle(tr("Fichier existant !"));

    QHBoxLayout * layout = new QHBoxLayout(msg);

    QLabel * l = new QLabel(this);
    QPixmap p = QPixmap(icon.pixmap(QSize(50, 50)));
    QPixmap pixmap_bonne_taille = p.scaled(50, 50, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    l->setPixmap(pixmap_bonne_taille);
    l->setMargin(30);
    layout->addWidget(l);

    QVBoxLayout * ss_layout = new QVBoxLayout();
    l = new QLabel(tr("Le fichier <b><font color=\"#FFF000000\">")+nom+tr("</font></b> existe d�j� voulez-vous le remplacer ?"));
    ss_layout->addWidget(l, Qt::AlignCenter);
    ne_plus_demander_verification_fichier = new QCheckBox(tr("Toujours remplacer."), msg);
    ss_layout->addWidget(ne_plus_demander_verification_fichier, 500, Qt::AlignRight | Qt::AlignBottom);

    QHBoxLayout * ss_ss_layout = new QHBoxLayout();
    QPushButton * annuler = new QPushButton(QIcon(":/FTPImages/flag_red.gif"), tr("Annuler"));
    connect(annuler, SIGNAL(clicked()), msg, SLOT(close()));
    ss_ss_layout->addWidget(annuler);
    QPushButton * accepter = new QPushButton(QIcon(":/FTPImages/flag_green.gif"), tr("Accepter"));
    connect(accepter, SIGNAL(clicked()), msg, SLOT(hide()));
    connect(accepter, SIGNAL(clicked()), this, SLOT(widgetRemplacementFichierOk()));
    ss_ss_layout->addWidget(accepter);

    ss_layout->addLayout(ss_ss_layout);

    layout->addLayout(ss_layout);

    msg->setLayout(layout);

    msg->show();
}

void WidgetLocal::widgetRemplacementFichierOk()
{
    if(ne_plus_demander_verification_fichier->isChecked())
    {
        verifier_existe_deja = false;
        parent->getDistant()->get(parent->getDistant()->getRepCourant()+"/"+parent->getDistant()->getDistant()->getDernierItem()->text(0),
            local->getDernierItem()->icon(0));
    }
    else
    {
        verifier_existe_deja = false;
        if(parent->getLocal()->getLocal()->getDernierItem())
        {
            parent->getDistant()->get(parent->getLocal()->getRepCourant()+"/"+parent->getLocal()->getLocal()->getDernierItem()->text(0),
                parent->getLocal()->getLocal()->getDernierItem()->icon(0));
        }
        verifier_existe_deja = true;
    }
}
