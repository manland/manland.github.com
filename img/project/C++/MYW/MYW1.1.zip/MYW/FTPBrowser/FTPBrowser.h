#ifndef FTPBROWSER_H
#define FTPBROWSER_H

/*========================================================================
Nom: FTPBrowser.h           auteur: Maneschi Romain
Maj: 17.05.2009             Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe principale de l'application. Définition de la structure struct_serveur.
=========================================================================*/

/*!
* \file FTPBrowser.h
* \brief Classe principale de l'application. Définition de la structure struct_serveur.
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QMainWindow>
#include <QSettings>
#include <QDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QFtp>
#include <QResizeEvent>

#include "CommandesToolBar.h"
#include "MessagesToolBar.h"
#include "WidgetDistant.h"
#include "WidgetLocal.h"
#include "DossiersDistants.h"
#include "DossiersLocaux.h"

/*!
* \struct struct_serveur
*
* \param url : QString l'url du serveur ftp
* \param login : QString le loggin pour se connecter au serveur ftp
* \param pass : QString le pass pour se connecter au serveur ftp
* \param port : int le port pour se connecter au serveur ftp (par défaut 21)
* \param home : QString le répertoire à charger par défaut une fois connecté
* \param proxy : QString l'url du serveur proxy
* \param port_proxy : int le port du serveur proxy
*
*/
struct struct_serveur
{
    QString url;
    QString login;
    QString pass;
    int port;
    QString home;
    QString proxy;
    int port_proxy;
};

/*!
* \class FTPBrowser
* \brief Classe principale de l'application
*
* Cette classe appelle toutes les autres classes en plus d'être leur conteneur.
*
*/
class FTPBrowser : public virtual QMainWindow
{
    Q_OBJECT

private:
    CommandesToolBar * commandes;/*!< Pointeur vers les boutons de commandes relatifs au ftp*/
    MessagesToolBar * messages;/*!< Pointeur vers les messages relatifs au ftp*/
    QList<struct_serveur> * serveurs;/*!< Liste des serveurs ajoutés */

    WidgetLocal * local;/*!< Pointeur vers WidgetLocal conteneur de DossiersLocaux*/
    WidgetDistant * distant;/*!< Pointeur vers WidgetDistant conteneur de DossiersDistants*/

    /*!
    * \brief Enregistre les url_s grâce aux qsettings
    */
    virtual void enregistrer();
    /*!
    * \brief Restaure les url_s grâce aux qsettings
    */
    virtual void restaurer();

    //----------------------AJOUTER-SERVEUR-------------------------
    QLineEdit * url_serveur;/*!< Edition de l'url du serveur ftp lors d'un ajout*/
    QLineEdit * login_serveur;/*!< Edition du login du serveur ftp lors d'un ajout*/
    QLineEdit * pass_serveur;/*!< Edition du pass du serveur ftp lors d'un ajout*/
    QLineEdit * port_serveur;/*!< Edition du port du serveur ftp lors d'un ajout*/
    QLineEdit * home_serveur;/*!< Edition de l'url par défaut du serveur ftp lors d'un ajout*/
    QCheckBox * proxy_check;/*!< Bouton permettant l'ajout d'un serveur proxy en appelant show()*/
    QWidget * proxy;/*!< Widget contenant url_serveur_proxy et port_serveur_proxy hide() à la création*/
    QLineEdit * url_serveur_proxy;/*!< Edition de l'url du serveur proxy lors d'un ajout*/
    QLineEdit * port_serveur_proxy;/*!< Edition du port du serveur proxy lors d'un ajout*/

private slots:
    //----------------------AJOUTER-SERVEUR-------------------------
    /*!
    * \brief Déclenché par proxy_check et permet d'afficher ou de cacher la partie proxy lors d'un ajout d'un serveur
    */
    virtual void afficherCacherProxy();

protected:
    /*!
    * \brief Gère la taille des widgets lors d'un agrandissement
    *
    * \param event : QResizeEvent événement déclanchant cette méthode
    */
    virtual void resizeEvent(QResizeEvent*);
    /*!
    * \brief Gère l'affichage du sous-widget ajouter serveur s'il n'y a aucun serveur d'enregistré
    *
    * \param event : QShowEvent événement déclanchant cette méthode
    */
    virtual void showEvent(QShowEvent*);

public slots:
    /*!
    * \brief Création d'une fenêtre permettant d'ajouter un serveur
    *
    * \param action : QAction si =0 alors ajouter un serveur, sinon modifie le serveur
    */
    virtual void widgetAjouterSerseur(QAction* = 0);
    /*!
    * \brief Applique les changements aux serveurs (ajout ou mofication) après validation de widgetAjouterSerseur()
    */
    virtual void widgetAjouterServeurOk();

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe FTPBrowser
    *
    * \param dir : QDir répertoire par défaut des dossiers locaux
    */
    FTPBrowser(QDir = QDir::home());
    /*!
    * \brief Retourne un pointeur vers les messages
    */
    virtual MessagesToolBar* getMessages();
    /*!
    * \brief Retourne un pointeur vers le WidgetDistant contenant les DossiersDistants
    */
    virtual WidgetDistant* getDistant();
    /*!
    * \brief Retourne un pointeur vers le WidgetLocal contenant les DossiersLocaux
    */
    virtual WidgetLocal* getLocal();
    /*!
    * \brief Retourne la liste des serveurs
    */
    virtual QList<struct_serveur>* getListeServeurs();
    /*!
    * \brief Retourne le serveur ftp contenue dans la liste en position i
    *
    * \param i : int position du serveur dans la liste des serveurs
    */
    virtual struct_serveur getServeurFTP(int);
    /*!
    * \brief Retourne un pointeur vers les commandes
    */
    virtual CommandesToolBar* getCommandes();

};
#endif // FTPBROWSER_H
