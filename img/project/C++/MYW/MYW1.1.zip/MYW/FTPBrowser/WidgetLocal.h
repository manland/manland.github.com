#ifndef WIDGETLOCAL_H
#define WIDGETLOCAL_H

/*========================================================================
Nom: WidgetLocal.h           auteur: Maneschi Romain
Maj: 17.05.2009              Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe conteneur de DossiersLocaux.
=========================================================================*/

/*!
* \file WidgetLocal.h
* \brief Classe conteneur de DossiersLocaux.
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QMessageBox>
#include <QCheckBox>

class FTPBrowser;

#include "DossiersLocaux.h"

/*!
* \class WidgetLocal
* \brief Classe gérant les boutons dessous DossiersLocaux et conteneur de cette même classe.
*
* Cette classe permet de retourner au répertoire par défaut, créer un dossier et actualiser le répertoire courant.
*
*/
class WidgetLocal : public virtual QWidget
{
    Q_OBJECT

private:
    FTPBrowser * parent;/*!< Le parent de la classe.*/
    DossiersLocaux * local;/*!< Pointeur vers DossiersLocaux*/
    bool verifier_existe_deja;/*!< True si l'utilisateur veut vérifier si un fichier existe déjà, False si non*/
    QString home_dir;/*!< Répertoire par défaut*/
    QLineEdit * emplacement;/*!< Edition de l'emplacement*/
    QPushButton * cd_ou_cdparent;/*!< Bouton permetant de remonter au dossier père, ou d'aller au dossier tappé dans emplacement*/
    QPushButton * bouton_home_repertoir;/*!< Bouton permetant de se rendre au répertoire par défaut*/
    QPushButton * bouton_nouveau_repertoir;/*!< Bouton permetant de créer un nouveu répertoire dans le dossier courant*/
    QPushButton * bouton_recharger;/*!< Bouton permetant de recharger le dossier courant*/
    /*!
    * \brief Change l'icone en flêche vers la droite pour cd et flêche vers le haut pour cdParent
    *
    * \param b : bool True = cd et false = cdParent
    */
    virtual void cdOuCdParent(bool);

    //----------------------AJOUTER-DOSSIER-------------------------
    QLineEdit * emplacement_dossier;/*!< Edition de l'emplacement du répertoire à créer*/
    QLineEdit * nom_dossier;/*!< Edition du nom du répertoire à créer*/

    //----------------------FICHIER-EXISTE-DEJA-------------------------
    /*!
    * \brief Créé le widgetRemplacementFichier()
    *
    * \param nom : QString le nom du fichier
    * \param icon : QIcon l'icone du fichier
    */
    virtual void widgetRemplacementFichier(QString, QIcon);
    QCheckBox * ne_plus_demander_verification_fichier;/*!< Bouton permettant de remplacer automatiquement un fichier existant déjà*/

private slots:
    /*!
    * \brief Affiche la fenêtre pour ajouter un dossier
    */
    virtual void widgetAjouterDossier();
    /*!
    * \brief Ajoute le dossier aprés validation de widgetAjouterDossier()
    */
    virtual void widgetAjouterDossierOk();
    /*!
    * \brief Méthode appelée lors de la frappe d'un emplacement par l'utilisateur pour colorier la barre d'édition en vers si ok sinon en rouge
    */
    virtual void verificationEmplacement(QString);
    //----------------------FICHIER-EXISTE-DEJA-------------------------
    /*!
    * \brief Remplace le fichier aprés validation de widgetRemplacementFichier()
    */
    virtual void widgetRemplacementFichierOk();

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe WidgetLocal
    *
    * \param parent : FTPBrowser parent conteneur des dossiers locaux
    * \param dir : QDir répertoire par défaut
    */
    WidgetLocal(FTPBrowser*, QDir);
    /*!
    * \brief Retourne le DossiersLocaux affichant les dossiers du répertoir courant local
    */
    virtual DossiersLocaux* getLocal();
    /*!
    * \brief Permet d'accéder au parent
    *
    * \return FTPBrowser* le pointeur du mainwindow du FTPBrowser
    */
    virtual FTPBrowser* getParent();
    /*!
    * \brief Retourne le répertoir courant
    */
    virtual QString getRepCourant();
    /*!
    * \brief Vérifie l'existence d'un fichier ou d'un dossier
    *
    * \param nom : QString nom à vérifier
    */
    virtual bool existeDeja(QString);

public slots:
    /*!
    * \brief Recharge le répertoir courant
    */
    virtual void recharger();
    /*!
    * \brief Méthode permettant d'aller au répertoir par défaut
    */
    virtual void cdHome();
    /*!
    * \brief Méthode permettant d'aller au répertoir père
    */
    virtual void cdUp();
    /*!
    * \brief Met à jour l'édition de l'url lors d'un changement de répertoir
    */
    virtual void mettreAJourEmplacement();
    /*!
    * \brief Met la couleur blanche en fond de l'édition de l'url
    */
    virtual void emplacementNormalePalette();

};

#endif // WIDGETLOCAL_H
