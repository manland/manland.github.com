#ifndef MESSAGESTOOLBAR_H
#define MESSAGESTOOLBAR_H

/*========================================================================
Nom: MessagesToolBar.h           auteur: Maneschi Romain
Maj: 17.05.2009                  Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe affichant les messages relatifs aux commandes du ftp.
=========================================================================*/

/*!
* \file MessagesToolBar.h
* \brief Classe affichant les messages relatifs aux commandes du ftp.
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QToolBar>
#include <QTableWidget>
#include <QTableView>
#include <QHeaderView>
#include <QLabel>
#include <QIcon>
#include <QProgressBar>
#include <QHBoxLayout>

class FTPBrowser;

/*!
* \class MessagesToolBar
* \brief Classe importante gérant l'affichage des messages relatifs au FTP.
*
* En plus d'afficher les messages elle gère les barres de progressions des téléchargements en upload comme en download.
* Une poubelle se trouvant dans CommandesToolBar peut vider les messages inscrits.
*
*/
class MessagesToolBar : public virtual QToolBar
{
    Q_OBJECT

private:
    FTPBrowser * parent;/*!< Le parent de la classe.*/
    QTableWidget * table;/*!< Widget contenant les messages*/
    QLabel * l;/*!< Dernier label de téléchargement ajouter*/
    QList<QProgressBar*> * telechargements;/*!< Liste des téléchargements*/
    int telechargement_en_cours;/*!< Téléchargement en cours*/

private slots:
    /*!
    * \brief Appelé par Qt lors d'un téléchargement
    *
    * \param done : qint64 le nombre d'octets téléchargés
    * \param total : qint64 le nombre total d'octets à télécharger
    */
    virtual void dernierTelechargement(qint64, qint64);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe MessagesToolBar
    *
    * \param parent : FTPBrowser parent des messages
    */
    MessagesToolBar(FTPBrowser*);
    /*!
    * \brief Permet d'ajouter un message
    *
    * \param icon : QIcon l'icone de la première colonne du message
    * \param text : QString le message à afficher dans la colonne du milieu
    * \param autre : QWidget permet d'ajouter un widget dans la troisième colonne
    */
    virtual void ajouterMessage(QIcon, QString, QWidget*);
    /*!
    * \brief Permet d'ajouter un téléchargement
    *
    * \param icon : QIcon l'icone de la première colonne du message
    * \param text : QString le message à afficher dans la colonne du milieu
    * \param b : bool true = upload, false = download
    */
    virtual void ajouterTelechargement(QIcon, QString, bool);
    /*!
    * \brief Permet de gérer les widget lors d'un changement de taille
    *
    * \param size : QSize la nouvelle taille de la fenêtre
    */
    virtual void resize(QSize);

public slots:
    /*!
    * \brief Ajoute un message spécial lors d'un abort()
    */
    virtual void abort();
    /*!
    * \brief Permet de vider les messages appelé par un click sur la corbeille
    */
    virtual void vider();
};

#endif // MESSAGESTOOLBAR_H
