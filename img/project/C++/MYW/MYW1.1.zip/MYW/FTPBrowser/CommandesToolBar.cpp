/*========================================================================
Nom: CommandesToolBar.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                     Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe g�rant les boutons du milieu de l'application permettant l'upload, le download...
=========================================================================*/

#include <iostream>
using namespace std;

#include "CommandesToolBar.h"
#include "FTPBrowser.h"

CommandesToolBar::CommandesToolBar(FTPBrowser * p) : QWidget()
{
    parent = p;

    QVBoxLayout * layout = new QVBoxLayout(this);

    //          connect �  un serveur
    bouton_serveur = new QPushButton(QIcon(":/FTPImages/serveur.png"), "");
    bouton_serveur->setToolTip(tr("Connexion Serveur"));
    bouton_serveur->setIconSize(QSize(50, 50));
    layout->addWidget(bouton_serveur);
    menu_bouton_serveur = new QMenu();
    bouton_serveur->setMenu(menu_bouton_serveur);
    remplirMenuBoutonServeurs();
    connect(menu_bouton_serveur, SIGNAL(triggered(QAction*)), this, SLOT(connectionServeur(QAction*)));

    layout->addStretch(500);

    //          uploader
    bouton_uploader = new QPushButton(QIcon(":/FTPImages/upload.png"), "");
    bouton_uploader->setToolTip(tr("Uploader"));
    bouton_uploader->setIconSize(QSize(50, 50));
    bouton_uploader->setEnabled(false);
    layout->addWidget(bouton_uploader);
    connect(bouton_uploader, SIGNAL(clicked()), this, SLOT(uploader()));

    //          downloder
    bouton_downloader = new QPushButton(QIcon(":/FTPImages/download.png"), "");
    bouton_downloader->setToolTip(tr("Downloader"));//A FER
    bouton_downloader->setIconSize(QSize(50, 50));
    bouton_downloader->setEnabled(false);
    layout->addWidget(bouton_downloader);
    connect(bouton_downloader, SIGNAL(clicked()), this, SLOT(downloader()));

    layout->addStretch(500);

    //          stop action en cour + corbeille messages
    bouton_stopper_trash = new QPushButton(QIcon(":/FTPImages/corbeillevide.png"), "");
    bouton_stopper_trash->setToolTip(tr("Vider les messages"));
    bouton_stopper_trash->setIconSize(QSize(50, 50));
    bouton_stopper_trash->setEnabled(false);
    layout->addWidget(bouton_stopper_trash);
    connect(bouton_stopper_trash, SIGNAL(clicked()), parent->getMessages(), SLOT(vider()));

    setAttribute(Qt::WA_LayoutOnEntireRect);
    layout->setAlignment(Qt::AlignCenter);
}

void CommandesToolBar::remplirMenuBoutonServeurs()
{
    if(menu_bouton_serveur)
    {
        menu_bouton_serveur->clear();
    }
    for(int i=0; i<parent->getListeServeurs()->count(); i++)
    {
        QAction * action = menu_bouton_serveur->addAction(parent->getListeServeurs()->value(i).url);
        action->setData(QVariant(i));
    }
    menu_bouton_serveur->addSeparator();
    QAction * action = menu_bouton_serveur->addAction(QIcon(":/FTPImages/icon_favourites.gif"), tr("Ajouter un serveur"));
    action->setData(QVariant(-1));
    QMenu * menu_bouton_modifier_serveur = new QMenu(tr("Modifier"));
    action = menu_bouton_serveur->addMenu(menu_bouton_modifier_serveur);
    action->setData(QVariant(-1));
    for(int i=0; i<parent->getListeServeurs()->count(); i++)
    {
        QAction * action = menu_bouton_modifier_serveur->addAction(parent->getListeServeurs()->value(i).url);
        action->setData(QVariant(QPoint(-1, i)));//pour ne pas m�langer connecter et modifier
    }
}

void CommandesToolBar::connectionServeur(QAction * action)
{
    if(action->data().toInt() != -1 && !action->data().canConvert(QVariant::Point))//pour ne pas m�langer connecter et modifier
    {
        parent->getDistant()->connexion(action->data().toInt());
    }
    else if(action->data().canConvert(QVariant::Point))//pour ne pas m�langer connecter et modifier
    {
        parent->widgetAjouterSerseur(action);
    }
    else
    {
        parent->widgetAjouterSerseur();
    }
}

void CommandesToolBar::uploadOnOff(bool b)
{
        bouton_uploader->setEnabled(b);
}

void CommandesToolBar::downloadOnOff(bool b)
{
        bouton_downloader->setEnabled(b);
}

void CommandesToolBar::uploader()
{
    parent->getDistant()->put(parent->getLocal()->getRepCourant()+"/"+parent->getLocal()->getLocal()->getDernierItem()->text(0),
                              parent->getLocal()->getLocal()->getDernierItem()->icon(0));
}

void CommandesToolBar::downloader()
{
    parent->getDistant()->get(parent->getDistant()->getRepCourant()+"/"+parent->getDistant()->getDistant()->getDernierItem()->text(0),
                              parent->getDistant()->getDistant()->getDernierItem()->icon(0));
}

void CommandesToolBar::stopToTrash()
{
    bouton_stopper_trash->disconnect();

    bouton_stopper_trash->setToolTip(tr("Vider les messages"));
    bouton_stopper_trash->setIcon(QIcon(":/FTPImages/corbeille.png"));
    bouton_stopper_trash->setEnabled(true);

    connect(bouton_stopper_trash, SIGNAL(clicked()), parent->getMessages(), SLOT(vider()));
}

void CommandesToolBar::trashToStop()
{
    bouton_stopper_trash->disconnect();

    bouton_stopper_trash->setToolTip(tr("Stopper Actions"));
    bouton_stopper_trash->setIcon(QIcon(":/FTPImages/stop.png"));
    bouton_stopper_trash->setEnabled(true);

    connect(bouton_stopper_trash, SIGNAL(clicked()), parent->getDistant()->getFtp(), SLOT(abort()));
    connect(bouton_stopper_trash, SIGNAL(clicked()), parent->getMessages(), SLOT(abort()));
}

void CommandesToolBar::trashStopOnOff(bool b)
{
    bouton_stopper_trash->setEnabled(b);
}

void CommandesToolBar::setTrash(bool vide)
{
    if(vide)
    {
        bouton_stopper_trash->setIcon(QIcon(":/FTPImages/corbeillevide.png"));
    }
    else
    {
        bouton_stopper_trash->setIcon(QIcon(":/FTPImages/corbeille.png"));
    }
}

void CommandesToolBar::ServeurToStop(bool connecte)
{
    bouton_serveur->disconnect();
    if(connecte)
    {
        bouton_serveur->setToolTip(tr("D�connexion"));
        bouton_serveur->setMenu(0);
        bouton_serveur->setIcon(QIcon(":/FTPImages/arreter.png"));

        connect(bouton_serveur, SIGNAL(clicked()), parent->getDistant(), SLOT(deconnection()));
    }
    else
    {
        bouton_serveur->setToolTip(tr("Connexion Serveur"));
        bouton_serveur->setIcon(QIcon(":/FTPImages/serveur.png"));

        menu_bouton_serveur = new QMenu();
        bouton_serveur->setMenu(menu_bouton_serveur);
        remplirMenuBoutonServeurs();
        connect(menu_bouton_serveur, SIGNAL(triggered(QAction*)), this, SLOT(connectionServeur(QAction*)));

        connect(bouton_serveur, SIGNAL(clicked()), parent->getDistant(), SLOT(deconnection()));
    }
}


