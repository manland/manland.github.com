/*========================================================================
Nom: MessagesToolBar.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                    Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe affichant les messages relatifs aux commandes du ftp.
=========================================================================*/

#include <iostream>
using namespace std;

#include "MessagesToolBar.h"
#include "FTPBrowser.h"

MessagesToolBar::MessagesToolBar(FTPBrowser * p) : QToolBar(p)
{
    parent = p;
    this->setMovable(false);
    telechargement_en_cours = 0;
    table = new QTableWidget(1, 3, this);
    table->setHorizontalHeaderItem(0, new QTableWidgetItem(tr("Icone")));
    table->setHorizontalHeaderItem(1, new QTableWidgetItem(tr("Description")));
    table->setHorizontalHeaderItem(2, new QTableWidgetItem(tr("Autre")));

    QTableWidgetItem * item = new QTableWidgetItem(tr("!! Bienvenue sur FTPBrowser !!"));
    item->setTextAlignment(Qt::AlignCenter);
    QLinearGradient gradient(50, 0, 50, 30);
    gradient.setColorAt(0.0, Qt::black);
    gradient.setColorAt(0.45, Qt::darkGray);
    gradient.setColorAt(0.55, Qt::darkGray);
    gradient.setColorAt(1.0, Qt::black);
    item->setBackground(gradient);
    item->setForeground(QBrush(QColor(250, 0, 0)));
    table->setItem(0, 1, item);
    item = new QTableWidgetItem("");
    item->setBackground(gradient);
    table->setItem(0, 0, item);
    item = new QTableWidgetItem("");
    item->setBackground(gradient);
    table->setItem(0, 2, item);
    table->setShowGrid(true);
    this->addWidget(table);

    telechargements = new QList<QProgressBar*>;
    resize(this->size());
}

void MessagesToolBar::ajouterMessage(QIcon icon, QString text, QWidget * autre)
{
    int i = table->rowCount();
    table->setRowCount(i+1);

    if(i >= 1)
    {
        parent->getCommandes()->trashStopOnOff(true);
        parent->getCommandes()->setTrash(false);

    }

    QTableWidgetItem * item_icon = new QTableWidgetItem(icon, "");
    table->setItem(i, 0, item_icon);

    table->setCellWidget(i, 1, new QLabel(text));

    if(!autre)
    {
        table->setSpan(i, 1, 0, 2);
    }
    else
    {
        table->setCellWidget(i, 2, autre);
    }

    table->setCurrentCell(i, 0);
    table->resizeColumnToContents(0);
    table->resizeColumnToContents(2);

    resize(this->size());
}

void MessagesToolBar::ajouterTelechargement(QIcon icon, QString text, bool b)//true = upload, false = download
{
    l = new QLabel();
    l->setPixmap(icon.pixmap(QSize(50, 50)));
    int i = table->rowCount();
    table->setRowCount(i+1);
    table->setCellWidget(i, 0, l);

    QWidget * w = new QWidget(this);
    QHBoxLayout * layout = new QHBoxLayout(w);

    if(b)
    {
        QLabel * t = new QLabel();
        t->setPixmap(QIcon(":/FTPImages/upload.png").pixmap(QSize(15, 15)));
        layout->addWidget(t);
        layout->addWidget(new QLabel(tr("Upload ")+text+tr(" : ")));

        QProgressBar * progress = new QProgressBar(this);
        progress->setAccessibleName("upload");
        progress->setAccessibleDescription("vide");
        progress->setMinimum(0);
        progress->setValue(0);
        telechargements->append(progress);
        layout->addWidget(progress);
    }
    else
    {
        QLabel * t = new QLabel();
        t->setPixmap(QIcon(":/FTPImages/download.png").pixmap(QSize(15, 15)));
        layout->addWidget(t);
        layout->addWidget(new QLabel(tr("Download ")+text+tr(" : ")));

        QProgressBar * progress = new QProgressBar(this);
        progress->setAccessibleName("download");
        progress->setAccessibleDescription("vide");
        progress->setMinimum(0);
        progress->setValue(0);
        telechargements->append(progress);
        layout->addWidget(progress);
    }

    if(telechargements->value(telechargement_en_cours)->accessibleDescription() == "vide" && telechargements->value(telechargement_en_cours)->value() == 0)
    {
        QProgressBar * temp = telechargements->value(telechargement_en_cours);

        connect(parent->getDistant()->getFtp(), SIGNAL(dataTransferProgress(qint64,qint64)), this, SLOT(dernierTelechargement(qint64,qint64)));
        if(temp->accessibleName() == "upload")
        {
            parent->getDistant()->lancerPut(telechargement_en_cours);
        }
        else if(temp->accessibleName() == "download")
        {
            parent->getDistant()->lancerGet(telechargement_en_cours);
        }
    }

    table->setCellWidget(i, 1, w);
    table->setCellWidget(i, 2, 0);

    table->setCurrentCell(i, 0);

    table->resizeColumnToContents(0);
    table->resizeColumnToContents(2);

    resize(this->size());

    parent->getCommandes()->trashToStop();
}

void MessagesToolBar::dernierTelechargement(qint64 done, qint64 total)
{

    QProgressBar * temp = telechargements->value(telechargement_en_cours);
    if(temp)
    {
        temp->setMaximum(total);
        temp->setValue(done);
        if(done == total)
        {
            temp->setAccessibleDescription("");
            if(temp->accessibleName() == "upload")
            {
                parent->getDistant()->recharger();
            }
            else//download
            {
                parent->getLocal()->recharger();
            }
            parent->getDistant()->closeDernierUpload();
            telechargement_en_cours++;
            if(telechargement_en_cours < telechargements->count())
            {
                parent->getDistant()->getFtp()->disconnect(this, SLOT(dernierTelechargement(qint64,qint64)));
                connect(parent->getDistant()->getFtp(), SIGNAL(dataTransferProgress(qint64,qint64)), this, SLOT(dernierTelechargement(qint64,qint64)));
                if(temp->accessibleName() == "upload")
                {
                    parent->getDistant()->lancerPut(telechargement_en_cours);
                }
                else if(temp->accessibleName() == "download")
                {
                    parent->getDistant()->lancerGet(telechargement_en_cours);
                }
            }
        }
        if(telechargements->count() == 0)
        {
            parent->getCommandes()->stopToTrash();
        }
    }
}

void MessagesToolBar::abort()
{
    telechargements->clear();
    telechargement_en_cours = 0;
    ajouterMessage(QIcon(":/FTPImages/toutstop.png"), tr("Toutes op�rations stopp�es."), new QLabel(tr("Erreur")));
    parent->getCommandes()->stopToTrash();
    parent->getCommandes()->setTrash(false);
}

void MessagesToolBar::resize(QSize size)
{
    table->setColumnWidth(1, size.width() - (table->columnWidth(0) + table->columnWidth(2) + 22));
}

void MessagesToolBar::vider()
{
    table->clear();
    table->setRowCount(1);

    table->setHorizontalHeaderItem(0, new QTableWidgetItem(tr("Icone")));
    table->setHorizontalHeaderItem(1, new QTableWidgetItem(tr("Description")));
    table->setHorizontalHeaderItem(2, new QTableWidgetItem(tr("Autre")));

    QTableWidgetItem * item = new QTableWidgetItem(tr("!! Nettoyage termin� !!"));
    item->setTextAlignment(Qt::AlignCenter);
    QLinearGradient gradient(50, 0, 50, 30);
    gradient.setColorAt(0.0, Qt::black);
    gradient.setColorAt(0.45, Qt::darkGray);
    gradient.setColorAt(0.55, Qt::darkGray);
    gradient.setColorAt(1.0, Qt::black);
    item->setBackground(gradient);
    item->setForeground(QBrush(QColor(250, 0, 0)));
    table->setItem(0, 1, item);
    item = new QTableWidgetItem("");
    item->setBackground(gradient);
    table->setItem(0, 0, item);
    item = new QTableWidgetItem("");
    item->setBackground(gradient);
    table->setItem(0, 2, item);
    table->setShowGrid(true);
    this->addWidget(table);

    resize(this->size());

    parent->getCommandes()->trashStopOnOff(false);
    parent->getCommandes()->setTrash(true);
}
