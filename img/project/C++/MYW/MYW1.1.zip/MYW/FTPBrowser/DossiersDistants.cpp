/*========================================================================
Nom: DossiersDistants.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                     Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe g�rant l'affichage de l'arborescence du serveur ftp.
=========================================================================*/

#include <iostream>
using namespace std;

#include "DossiersDistants.h"
#include "WidgetDistant.h"
#include "FTPBrowser.h"

DossiersDistants::DossiersDistants(WidgetDistant * p) : QTreeWidget(p)
{
    parent = p;

    connect(this, SIGNAL(itemActivated(QTreeWidgetItem*,int)), this, SLOT(cmd(QTreeWidgetItem*,int)));
    connect(this, SIGNAL(itemClicked(QTreeWidgetItem*,int)), this, SLOT(clicked(QTreeWidgetItem*,int)));
    messages = parent->getParent()->getMessages();
    rep_courant = "";
    
    this->setHeaderLabels(QStringList() << tr("Nom") << tr("Taille") << tr("Propri�taire") << tr("Groupe") << tr("Derni�re modification"));
    this->setColumnWidth(0, 260);
    this->resizeColumnToContents(1);
    this->resizeColumnToContents(2);
    this->resizeColumnToContents(3);
    this->resizeColumnToContents(4);

    ftp = new QFtp();
    connect(ftp, SIGNAL(commandFinished(int,bool)), this, SLOT(finCommande(int, bool)));
    connect(ftp, SIGNAL(stateChanged(int)), this, SLOT(changementEtat(int)));
    connect(ftp, SIGNAL(listInfo(const QUrlInfo &)), this, SLOT(ajouterItem(const QUrlInfo &)));
}

void DossiersDistants::finCommande(int i, bool error)
{
//    cout<<"finCommande id courrant : "<<ftp->currentId()<<"demarrageCommande : "<<ftp->currentCommand()<<endl;
    if(i == QFtp::None)
    {

    }
    if(i == QFtp::SetTransferMode)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Changement de mode demand�."), new QLabel(tr("Termin�e")));
    }
    if(i == QFtp::SetProxy)
    {

    }
    if(i == QFtp::ConnectToHost)
    {

        if (error)
        {
             messages->ajouterMessage(QIcon(":/FTPImages/mauvais.gif"), tr("Connexion impossible : ")+ftp->errorString(), new QLabel(tr("Erreur")));
             parent->reconnexion();
             return;
        }
        else
        {
//            messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Connexion �  un serveur."), new QLabel(tr("Termin�e...")));
        }
        return;
    }
    if(i == QFtp::Login)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Login demand�."), new QLabel(tr("Termin�e...")));
        this->clear();
        ftp->list();
    }
    if(i == QFtp::Close)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("D�connexion du serveur."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::List)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Indexation du dossier."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::Cd)
    {
        if (error)
        {
             messages->ajouterMessage(QIcon(":/FTPImages/mauvais.gif"), tr("D�placement dans un dossier.")+ftp->errorString(), new QLabel(tr("Erreur")));
         }
        else
        {
//            messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("D�placement dans un dossier."), new QLabel(tr("Termin�e...")));
        }
    }
    if(i == QFtp::Get)
    {
        if (error)
        {
             messages->ajouterMessage(QIcon(":/FTPImages/mauvais.gif"), tr("R�cup�ration d'un fichier.")+ftp->errorString(), new QLabel(tr("Erreur")));
         }
        else
        {
//             messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("R�cup�ration d'un fichier."), new QLabel(tr("Termin�e...")));
         }
    }
    if(i == QFtp::Put)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Envoie d'un fichier."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::Remove)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Suppression d'un fichier."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::Mkdir)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Cr�ation d'un dossier."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::Rmdir)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Suppression d'un dossier."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::Rename)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Renommage."), new QLabel(tr("Termin�e...")));
    }
    if(i == QFtp::RawCommand)
    {
//        messages->ajouterMessage(QIcon(":/Images/bon.gif"), tr("Envoie d'une commande."), new QLabel(tr("Termin�e...")));
    }
}

void DossiersDistants::changementEtat(int i)
{
    switch(i)
    {
        case QFtp::Unconnected :
        {
            messages->ajouterMessage(QIcon(":/FTPImages/feurouge.png"), tr("Non connect�."), 0);
            parent->enabledDisabledBoutons();
            parent->getParent()->getCommandes()->uploadOnOff(false);
            parent->getParent()->getCommandes()->downloadOnOff(false);
            parent->getParent()->getCommandes()->ServeurToStop(false);
            parent->getParent()->getCommandes()->stopToTrash();
            break;
        }
        case QFtp::HostLookup :
        {
            messages->ajouterMessage(QIcon(":/FTPImages/attention.png"), tr("V�rification du serveur."), 0);
            break;
        }
        case QFtp::Connecting :
        {
            messages->ajouterMessage(QIcon(":/FTPImages/attention.png"), tr("Connexion."), 0);
            break;
        }
        case QFtp::Connected :
        {
            messages->ajouterMessage(QIcon(":/FTPImages/attention.png"), tr("Connect�."), 0);
            break;
        }
        case QFtp::LoggedIn :
        {
            messages->ajouterMessage(QIcon(":/FTPImages/feuvert.png"), tr("Logg�."), 0);
            this->clear();
            ftp->cd(parent->getHomeDir());
            rep_courant = parent->getHomeDir();
            ftp->list();
            parent->enabledDisabledBoutons();
            parent->mettreAJourEmplacement();
            parent->getParent()->getCommandes()->ServeurToStop(true);
            break;
        }
        case QFtp::Closing :
        {
            messages->ajouterMessage(QIcon(":/FTPImages/attention.png"), tr("Connexion en pause."), 0);
            break;
        }
    }
}

bool DossiersDistants::existeDeja(QString nom)
{
    bool res = false;
    QList<QTreeWidgetItem*> l = this->findItems(nom, Qt::MatchFixedString);
    if(l.value(0))
    {
        res = true;
    }
    return res;
}

QString DossiersDistants::tailleString(quint64 i)
{
    if(i>=1000 && i<1000000)
    {
        return QString::number(i/1000)+" Ko";
    }
    else if(i>=1000000 && i<1000000000)
    {
        return QString::number(i/1000000)+" Mo";
    }
    else if(i>=1000000000)
    {
        return QString::number(i/1000000000)+" Go";
    }
    else
    {
        return QString::number(i)+" Octets";
    }
}

void DossiersDistants::ajouterItem(const QUrlInfo & info)
{
    this->resizeColumnToContents(1);
    this->resizeColumnToContents(2);
    this->resizeColumnToContents(3);
    this->resizeColumnToContents(4);

    if(info.name() != "." && !existeDeja(info.name()))
    {
        if((!rep_courant.isEmpty() && rep_courant != "/") || info.name() != "..")
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(this);
            item->setData(0, Qt::UserRole, QVariant(info.isDir()));
            item->setText(0, info.name());
            item->setText(1, tailleString(info.size()));
            item->setText(2, info.owner());
            item->setText(3, info.group());
            item->setText(4, info.lastModified().toString("dd MMM yyyy"));
            if(info.isFile())//si c'est un fichier
            {
                if(!info.isReadable())
                {
                    item->setIcon(0, QIcon(":/FTPImages/icon_padlock.gif"));
                }
                else if(info.name().contains(QRegExp("php$", Qt::CaseInsensitive)) ||
                   info.name().contains(QRegExp("php3$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/php.png"));
                }
                else if(info.name().contains(QRegExp("js$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/js.png"));
                }
                else if(info.name().contains(QRegExp("html$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("htm$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/html.png"));
                }
                else if(info.name().contains(QRegExp("sql$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/sql.png"));
                }
                else if(info.name().contains(QRegExp("png$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("gif$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("jpeg$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("jpg$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/image.gif"));
                }
                else if(info.name().contains(QRegExp("avi$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("divx$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("mpeg$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("ogv$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("wmv$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_video.gif"));
                }
                else if(info.name().contains(QRegExp("mp3$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("midi$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("wma$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("ogg$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_sound.gif"));
                }
                else if(info.name().contains(QRegExp("~$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("db$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("htaccess$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("config", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_settings.gif"));
                }
                else if(info.name().contains(QRegExp("pdf$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/file_acrobat.gif"));
                }
                else if(info.name().contains(QRegExp("zip$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("tar$", Qt::CaseInsensitive)) ||
                        info.name().contains(QRegExp("gz$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/icon_extension.gif"));
                }
                else
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_script.gif"));
                }
            }
            else//si c'est un dossier
            {
                if(!info.isReadable())
                {
                    item->setIcon(0, QIcon(":/FTPImages/icon_padlock.gif"));
                }
                else
                {
                    item->setIcon(0, QIcon(":/FTPImages/folder.gif"));
                }
            }
        }
        else if(!rep_courant.isEmpty() && rep_courant != "/")
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(this);
            item->setText(0, info.name());
            item->setData(0, Qt::UserRole, QVariant(info.isDir()));
            if(info.isFile())//si c'est un fichier (n'arrivera jamais)
            {
                item->setIcon(0, QIcon());
            }
            else//si c'est un dossier
            {
                item->setIcon(0, QIcon(":/FTPImages/folder.gif"));
            }
        }
    }
}

void DossiersDistants::cmd(QTreeWidgetItem * item, int column)
{
    dernier_fichier_selectionne = 0;
    if(column == 0)
    {
        if(ftp->state() == QFtp::Unconnected)
        {
            parent->reconnexion();
            ftp->cd(rep_courant);
        }
        if(item->data(0, Qt::UserRole).toBool())//si c'est un dossier
        {
            QString dir = item->text(0);
            if(dir == "..")
            {
                rep_courant = rep_courant.left(rep_courant.lastIndexOf('/'));
                if(rep_courant.isEmpty())
                {
                    ftp->cd("/");
                    ftp->list();
                }
                else
                {
                    ftp->cd("..");
                    ftp->list();
                }
            }
            else
            {
                rep_courant = rep_courant + "/" + dir;
                ftp->cd(rep_courant);
                ftp->list();
            }
            this->clear();
            parent->mettreAJourEmplacement();
            parent->emplacementNormalePalette(true);
            if(rep_courant.isEmpty())
            {
                messages->ajouterMessage(QIcon(":/FTPImages/serveur.png"), tr("D�placement dans le dossier <i><b>/</b></i>"), 0);
            }
            else
            {
                messages->ajouterMessage(QIcon(":/FTPImages/serveur.png"), tr("D�placement dans le dossier <i><b>")+rep_courant+tr("</b></i>"), 0);
            }
        }
        else//c'est un fichier
        {
            dernier_fichier_selectionne = item;
            parent->get(rep_courant+"/"+item->text(0), item->icon(0));
        }
    }
}

void DossiersDistants::clicked(QTreeWidgetItem * item, int column)
{
    dernier_fichier_selectionne = 0;
    if(column == 0)
    {
        if(!item->data(0, Qt::UserRole).toBool() && parent->getParent()->getDistant()->getFtp()->state() == QFtp::LoggedIn)//si c'est un fichier
        {
            parent->getParent()->getCommandes()->downloadOnOff(true);
            dernier_fichier_selectionne = item;
        }
        else
        {
            parent->getParent()->getCommandes()->downloadOnOff(false);
        }
    }
}

void DossiersDistants::contextMenuEvent(QContextMenuEvent * event)
{
    QTreeWidgetItem * item = dynamic_cast<QTreeWidgetItem*>(itemAt(event->pos()));
    dernier_item_menu = item;

    if(item)
    {
        clicked(item, 0);
        QMenu * menu = new QMenu(this);

        menu->addAction(QIcon(":/FTPImages/mauvais.gif"), tr("Supprimer"), this, SLOT(remove()), QKeySequence());
        menu->addAction(QIcon(), tr("Renommer..."), this, SLOT(widgetRenommer()), QKeySequence());
        menu->addSeparator();
        menu->addAction(QIcon(":/FTPImages/newdossier.png"), tr("Nouveau dossier"), parent, SLOT(widgetAjouterDossier()), QKeySequence());
        menu->addAction(QIcon(":/FTPImages/reload.png"), tr("Recharger"), parent, SLOT(recharger()), QKeySequence());
        if(!item->data(0, Qt::UserRole).toBool())//si c'est un fichier
        {
            menu->addSeparator();
            menu->addAction(QIcon(":/FTPImages/download.png"), tr("Downloader"), this, SLOT(download()), QKeySequence());
        }

        menu->move(event->globalPos());
        menu->show();
    }
    event->accept();
}

void DossiersDistants::download()
{
    if(dernier_item_menu)
    {
        parent->get(dernier_item_menu->text(0), dernier_item_menu->icon(0));
    }
}

void DossiersDistants::remove()
{
    if(dernier_item_menu)
    {
        messages->ajouterMessage(dernier_item_menu->icon(0), tr("Suppression de ")+rep_courant+"/"+dernier_item_menu->text(0), new QLabel(tr("Distant")));
        if(!dernier_item_menu->data(0, Qt::UserRole).toBool())//si c'est un fichier
        {
            ftp->remove(rep_courant+"/"+dernier_item_menu->text(0));
        }
        else
        {
            ftp->rmdir(rep_courant+"/"+dernier_item_menu->text(0));
        }
        this->clear();
        ftp->list();
    }
}

void DossiersDistants::widgetRenommer()
{
    QWidget * w = new QWidget(this, Qt::Dialog);
    w->setWindowTitle(tr("Renommer"));
    QVBoxLayout * layout = new QVBoxLayout(w);

    QLabel * l = new QLabel(tr("Fichier : ")+"<b><i>"+rep_courant+"/"+dernier_item_menu->text(0)+"</b></i>");
    layout->addWidget(l);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Nouveau nom : "));
    ss_layout->addWidget(l);
    nouveau_nom = new QLineEdit(dernier_item_menu->text(0));
    ss_layout->addWidget(nouveau_nom);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    QPushButton * annuler = new QPushButton(QIcon(":/FTPImages/annuler.png"), tr("Annuler"));
    ss_layout->addWidget(annuler);
    QPushButton * ok = new QPushButton(QIcon(":/FTPImages/valider.png"), tr("Valider"));
    ss_layout->addWidget(ok);
    layout->addLayout(ss_layout);

    w->setMinimumSize(400, 100);
    w->show();
    connect(annuler, SIGNAL(clicked()), w, SLOT(close()));
    connect(ok, SIGNAL(clicked()), this, SLOT(widgetRenommerOk()));
    connect(ok, SIGNAL(clicked()), w, SLOT(close()));
}

void DossiersDistants::widgetRenommerOk()
{
    messages->ajouterMessage(dernier_item_menu->icon(0), rep_courant+"/"+dernier_item_menu->text(0)+tr(" renomm� en ")+nouveau_nom->text(), new QLabel(tr("Distant")));

    ftp->rename(rep_courant+"/"+dernier_item_menu->text(0), nouveau_nom->text());
    this->clear();
    ftp->list();
}

QTreeWidgetItem* DossiersDistants::getDernierItem()
{
    return dernier_fichier_selectionne;
}

QString DossiersDistants::getRepCourant()
{
    return rep_courant;
}

void DossiersDistants::setRepCourant(QString s)
{
    rep_courant = s;
}

QFtp* DossiersDistants::getFtp()
{
    return ftp;
}
