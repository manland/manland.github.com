/*========================================================================
Nom: FTPBrowser.cpp           auteur: Maneschi Romain
Maj: 17.05.2009               Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe principale de l'application. D�finition de la structure struct_serveur.
=========================================================================*/

#include <iostream>
using namespace std;

#include "FTPBrowser.h"

FTPBrowser::FTPBrowser(QDir dir) : QMainWindow()
{
    this->setWindowTitle("FTPBrowser");
    this->setWindowIcon(QIcon(":/FTPImages/icone_principale.png"));

    serveurs = new QList<struct_serveur>;
    restaurer();

    messages = new MessagesToolBar(this);
    this->addToolBar(Qt::BottomToolBarArea , messages);

    QWidget * w = new QWidget(this);
    QHBoxLayout * layout = new QHBoxLayout(w);
    local = new WidgetLocal(this, dir);
    distant = new WidgetDistant(this);
    commandes = new CommandesToolBar(this);
    layout->addWidget(local);
    layout->addWidget(commandes);
    layout->addWidget(distant);

    this->setCentralWidget(w);

    this->setMinimumSize(800, 600);
}

void FTPBrowser::enregistrer()
{
    QSettings settings("MYW", "FTPBrowser");

    settings.beginWriteArray("serveurs");
    for(int i=0; i<serveurs->count(); i++)
    {
        settings.setArrayIndex(i);
        settings.setValue(QString("url"), serveurs->value(i).url);
        settings.setValue(QString("login"), serveurs->value(i).login);
        settings.setValue(QString("pass"), serveurs->value(i).pass);
        settings.setValue(QString("port"), serveurs->value(i).port);
        settings.setValue(QString("home"), serveurs->value(i).home);
        settings.setValue(QString("proxy"), serveurs->value(i).proxy);
        settings.setValue(QString("port_proxy"), serveurs->value(i).port_proxy);
    }
    settings.endArray();
    settings.sync();
}

void FTPBrowser::restaurer()
{
    QSettings settings("MYW", "FTPBrowser");

    int size = settings.beginReadArray("serveurs");

    for(int i=0; i<size; i++)
    {
        settings.setArrayIndex(i);
        struct_serveur temp;
        temp.url = settings.value(QString("url")).toString();
        temp.login = settings.value(QString("login")).toString();
        temp.pass = settings.value(QString("pass")).toString();
        temp.port = settings.value(QString("port")).toInt();
        temp.home = settings.value(QString("home")).toString();
        temp.proxy = settings.value(QString("proxy")).toString();
        temp.port_proxy = settings.value(QString("port_proxy")).toInt();
        serveurs->append(temp);
    }
    settings.endArray();
}

void FTPBrowser::widgetAjouterSerseur(QAction * action)
{

    QWidget * w = new QWidget(this, Qt::Dialog);
    int serveur = -1;
    if(action)
    {
        w->setWindowTitle(tr("Modifier un serveur"));
        serveur = action->data().toPoint().y();
    }
    else
    {
        w->setWindowTitle(tr("Ajouter un serveur"));
    }
    QVBoxLayout * layout = new QVBoxLayout(w);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    QLabel * l = new QLabel(tr("URL : "));
    ss_layout->addWidget(l);
    if(action)
    {
        url_serveur = new QLineEdit(serveurs->value(serveur).url);
        url_serveur->setAccessibleName(QString().setNum(serveur));//pour passer le bon serveur a widgetAjouterSerseurOk()
    }
    else
    {
        url_serveur = new QLineEdit("ftp.monserveur.com");
    }
    ss_layout->addWidget(url_serveur);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Login : "));
    ss_layout->addWidget(l);
    if(action)
    {
        login_serveur = new QLineEdit(serveurs->value(serveur).login);
    }
    else
    {
        login_serveur = new QLineEdit();
    }
    ss_layout->addWidget(login_serveur);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Mot de Passe : "));
    ss_layout->addWidget(l);
    if(action)
    {
        pass_serveur = new QLineEdit(serveurs->value(serveur).pass);
        pass_serveur->setEchoMode(QLineEdit::PasswordEchoOnEdit);
    }
    else
    {
        pass_serveur = new QLineEdit();
        pass_serveur->setEchoMode(QLineEdit::PasswordEchoOnEdit);
    }
    ss_layout->addWidget(pass_serveur);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Port : "));
    ss_layout->addWidget(l);
    if(action)
    {
        port_serveur = new QLineEdit(QString().setNum(serveurs->value(serveur).port));
    }
    else
    {
        port_serveur = new QLineEdit("21");
    }
    ss_layout->addWidget(port_serveur);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Dossier de d�part : "));
    ss_layout->addWidget(l);
    if(action)
    {
        home_serveur = new QLineEdit(serveurs->value(serveur).home);
    }
    else
    {
        home_serveur = new QLineEdit("/");
    }
    ss_layout->addWidget(home_serveur);
    layout->addLayout(ss_layout);

    proxy_check = new QCheckBox(tr("Utiliser un proxy"), w);
    connect(proxy_check, SIGNAL(clicked()), this, SLOT(afficherCacherProxy()));
    layout->addWidget(proxy_check);

    proxy = new QWidget(w);
    QVBoxLayout * proxy_layout = new QVBoxLayout(proxy);

    QHBoxLayout * ss_proxy_layout = new QHBoxLayout();
    l = new QLabel(tr("URL : "));
    ss_proxy_layout->addWidget(l);
    if(action)
    {
        url_serveur_proxy = new QLineEdit(serveurs->value(serveur).proxy);
    }
    else
    {
        url_serveur_proxy = new QLineEdit();
    }
    ss_proxy_layout->addWidget(url_serveur_proxy);
    proxy_layout->addLayout(ss_proxy_layout);

    ss_proxy_layout = new QHBoxLayout();
    l = new QLabel(tr("Port : "));
    ss_proxy_layout->addWidget(l);
    if(action && serveurs->value(serveur).port_proxy!=0)
    {
        port_serveur_proxy = new QLineEdit(QString().setNum(serveurs->value(serveur).port_proxy));
    }
    else
    {
        port_serveur_proxy = new QLineEdit();
    }
    ss_proxy_layout->addWidget(port_serveur_proxy);
    proxy_layout->addLayout(ss_proxy_layout);

    proxy->hide();
    if(action && !serveurs->value(serveur).proxy.isEmpty())
    {
        proxy->show();
    }
    layout->addWidget(proxy);

    ss_layout = new QHBoxLayout();
    QPushButton * annuler = new QPushButton(QIcon(":/FTPImages/annuler.png"), tr("Annuler"));
    ss_layout->addWidget(annuler);
    QPushButton * ok = new QPushButton(QIcon(":/FTPImages/valider.png"), tr("Valider"));
    ss_layout->addWidget(ok);
    layout->addLayout(ss_layout);

    w->show();
    connect(annuler, SIGNAL(clicked()), w, SLOT(close()));
    connect(ok, SIGNAL(clicked()), this, SLOT(widgetAjouterServeurOk()));
    connect(ok, SIGNAL(clicked()), w, SLOT(close()));
}

void FTPBrowser::showEvent(QShowEvent * event)
{
    if(serveurs->count() == 0)
    {
        this->widgetAjouterSerseur();
    }
    QWidget::showEvent(event);
}

void FTPBrowser::afficherCacherProxy()
{
    if(proxy_check->isChecked())
    {
        proxy->show();
    }
    else
    {
        proxy->hide();
    }
}

void FTPBrowser::widgetAjouterServeurOk()
{
    struct_serveur temp;
    temp.url = url_serveur->text();
    temp.login = login_serveur->text();
    temp.pass = pass_serveur->text();
    temp.port = port_serveur->text().toInt();
    temp.home = home_serveur->text();
    if(proxy_check->isChecked())
    {
        temp.proxy = url_serveur_proxy->text();
        temp.port_proxy = port_serveur_proxy->text().toInt();
    }
    else
    {
        temp.proxy = "";
        temp.port_proxy = 0;
    }
    if(!url_serveur->accessibleName().isEmpty())
    {
        serveurs->replace(url_serveur->accessibleName().toInt(), temp);
    }
    else
    {
        serveurs->append(temp);
    }
    enregistrer();
    commandes->remplirMenuBoutonServeurs();
}

MessagesToolBar* FTPBrowser::getMessages()
{
    return messages;
}

WidgetDistant* FTPBrowser::getDistant()
{
    return distant;
}

WidgetLocal* FTPBrowser::getLocal()
{
    return local;
}

struct_serveur FTPBrowser::getServeurFTP(int i)
{
    return serveurs->value(i);
}

QList<struct_serveur>* FTPBrowser::getListeServeurs()
{
    return serveurs;
}

CommandesToolBar* FTPBrowser::getCommandes()
{
    return commandes;
}

void FTPBrowser::resizeEvent(QResizeEvent * event)
{
    messages->resize(event->size());
}



