/*========================================================================
Nom: DossiersLocaux.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                   Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe g�rant l'affichage de l'arborescence du workspace ou du r�pertoir home.
=========================================================================*/

#include <iostream>
using namespace std;

#include "DossiersLocaux.h"
#include "FTPBrowser.h"
#include "WidgetLocal.h"

DossiersLocaux::DossiersLocaux(WidgetLocal * p, QDir dir) : QTreeWidget(p)
{
    parent = p;

    connect(this, SIGNAL(itemActivated(QTreeWidgetItem*,int)), this, SLOT(cmd(QTreeWidgetItem*,int)));
    connect(this, SIGNAL(itemClicked(QTreeWidgetItem*,int)), this, SLOT(clicked(QTreeWidgetItem*,int)));

    messages = parent->getParent()->getMessages();
    rep_courant = QDir(dir);
    this->setHeaderLabels(QStringList() << tr("Nom") << tr("Taille") << tr("Propri�taire") << tr("Groupe") << tr("Derni�re modification"));
    this->setColumnWidth(0, 260);
    this->resizeColumnToContents(1);
    this->resizeColumnToContents(2);
    this->resizeColumnToContents(3);
    this->resizeColumnToContents(4);

    list();
}

QString DossiersLocaux::tailleString(quint64 i)
{
    if(i>=1000 && i<1000000)
    {
        return QString::number(i/1000)+" Ko";
    }
    else if(i>=1000000 && i<1000000000)
    {
        return QString::number(i/1000000)+" Mo";
    }
    else if(i>=1000000000)
    {
        return QString::number(i/1000000000)+" Go";
    }
    else
    {
        return QString::number(i)+" Octets";
    }
}

void DossiersLocaux::ajouterItem(const QFileInfo & info)
{
    this->resizeColumnToContents(1);
    this->resizeColumnToContents(2);
    this->resizeColumnToContents(3);
    this->resizeColumnToContents(4);

    if(info.fileName() != ".")
    {
        if(rep_courant.absolutePath() != "/" || info.fileName() != "..")
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(this);
            item->setData(0, Qt::UserRole, QVariant(info.isDir()));
            item->setText(0, info.fileName());
            item->setText(1, tailleString(info.size()));
            item->setText(2, info.owner());
            item->setText(3, info.group());
            item->setText(4, info.lastModified().toString("dd MMM yyyy"));
            if(info.isFile())//si c'est un fichier
            {
                if(!info.isReadable())
                {
                    item->setIcon(0, QIcon(":/FTPImages/icon_padlock.gif"));
                }
                else if(info.fileName().contains(QRegExp("php$", Qt::CaseInsensitive)) ||
                   info.fileName().contains(QRegExp("php3$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/php.png"));
                }
                else if(info.fileName().contains(QRegExp("js$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/js.png"));
                }
                else if(info.fileName().contains(QRegExp("html$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("htm$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/html.png"));
                }
                else if(info.fileName().contains(QRegExp("sql$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/sql.png"));
                }
                else if(info.fileName().contains(QRegExp("png$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("gif$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("jpeg$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("jpg$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/image.gif"));
                }
                else if(info.fileName().contains(QRegExp("avi$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("divx$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("mpeg$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("ogv$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("wmv$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_video.gif"));
                }
                else if(info.fileName().contains(QRegExp("mp3$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("midi$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("wma$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("ogg$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_sound.gif"));
                }
                else if(info.fileName().contains(QRegExp("~$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("db$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("htaccess$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("config", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/page_settings.gif"));
                }
                else if(info.fileName().contains(QRegExp("pdf$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/file_acrobat.gif"));
                }
                else if(info.fileName().contains(QRegExp("zip$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("tar$", Qt::CaseInsensitive)) ||
                        info.fileName().contains(QRegExp("gz$", Qt::CaseInsensitive)))
                {
                    item->setIcon(0, QIcon(":/FTPImages/icon_extension.gif"));
                }
                else
                {
                    item->setIcon(0, QIcon(":/FTPImages/inconnu.png"));
                }
            }
            else//si c'est un dossier
            {
                if(!info.isReadable())
                {
                    item->setIcon(0, QIcon(":/FTPImages/icon_padlock.gif"));
                }
                else
                {
                    item->setIcon(0, QIcon(":/FTPImages/folder.gif"));
                }
            }
        }
        else if(rep_courant.absolutePath() != "/")
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(this);
            item->setText(0, info.fileName());
            item->setData(0, Qt::UserRole, QVariant(info.isDir()));
            if(info.isFile())//si c'est un fichier (n'arrivera jamais)
            {
                item->setIcon(0, QIcon());
            }
            else//si c'est un dossier
            {
                item->setIcon(0, QIcon(":/FTPImages/folder.gif"));
            }
        }
    }
}

void DossiersLocaux::cmd(QTreeWidgetItem * item, int column)
{
    dernier_fichier_selectionne = 0;
    if(column == 0)
    {
        if(item->data(0, Qt::UserRole).toBool())//si c'est un dossier
        {
            QString dir = item->text(0);
            if(dir == "..")
            {
                rep_courant.cdUp();
                this->clear();
                this->list();
            }
            else
            {
                rep_courant.cd(dir);
                this->clear();
                this->list();
            }
            parent->mettreAJourEmplacement();
            parent->emplacementNormalePalette();
            messages->ajouterMessage(QIcon(":/FTPImages/computer.png"), tr("D�placement dans le dossier <i><b>")+rep_courant.absolutePath()+tr("</b></i>"), 0);
        }
        else//c'est un fichier
        {
            dernier_fichier_selectionne = item;
            parent->getParent()->getDistant()->put(rep_courant.absolutePath()+"/"+item->text(0), item->icon(0));
        }
    }
}

void DossiersLocaux::clicked(QTreeWidgetItem * item, int column)
{
    dernier_fichier_selectionne = 0;
    if(column == 0)
    {
        if(!item->data(0, Qt::UserRole).toBool() && parent->getParent()->getDistant()->getFtp()->state() == QFtp::LoggedIn)//si c'est un fichier
        {
            parent->getParent()->getCommandes()->uploadOnOff(true);
            dernier_fichier_selectionne = item;
        }
        else
        {
            parent->getParent()->getCommandes()->uploadOnOff(false);
        }
    }
}

void DossiersLocaux::contextMenuEvent(QContextMenuEvent * event)
{
    QTreeWidgetItem * item = dynamic_cast<QTreeWidgetItem*>(itemAt(event->pos()));
    dernier_item_menu = item;

    if(item)
    {
        clicked(item, 0);
        QMenu * menu = new QMenu(this);

        menu->addAction(QIcon(":/FTPImages/mauvais.gif"), tr("Supprimer"), this, SLOT(remove()), QKeySequence());
        menu->addAction(QIcon(), tr("Renommer..."), this, SLOT(widgetRenommer()), QKeySequence());
        menu->addSeparator();
        menu->addAction(QIcon(":/FTPImages/newdossier.png"), tr("Nouveau dossier"), parent, SLOT(widgetAjouterDossier()), QKeySequence());
        menu->addAction(QIcon(":/FTPImages/reload.png"), tr("Recharger"), parent, SLOT(recharger()), QKeySequence());
        if(!item->data(0, Qt::UserRole).toBool() && parent->getParent()->getDistant()->getFtp()->state() == QFtp::LoggedIn)//si c'est un fichier
        {
            menu->addSeparator();
            menu->addAction(QIcon(":/FTPImages/upload.png"), tr("Uploader"), this, SLOT(upload()), QKeySequence());
        }

        menu->move(event->globalPos());
        menu->show();
    }
    event->accept();
}

void DossiersLocaux::upload()
{
    if(dernier_item_menu)
    {
        parent->getParent()->getDistant()->put(dernier_item_menu->text(0), dernier_item_menu->icon(0));
    }
}

void DossiersLocaux::remove()
{
    if(dernier_item_menu)
    {
        messages->ajouterMessage(dernier_item_menu->icon(0), tr("Suppression de : ")+rep_courant.absolutePath()+"/"+dernier_item_menu->text(0), new QLabel(tr("Local")));
        if(!dernier_item_menu->data(0, Qt::UserRole).toBool())//si c'est un fichier
        {
            rep_courant.remove(rep_courant.absolutePath()+"/"+dernier_item_menu->text(0));
        }
        else//si c'est un dossier
        {
            rep_courant.rmdir(rep_courant.absolutePath()+"/"+dernier_item_menu->text(0));
        }
        clear();
        list();
    }
}

void DossiersLocaux::widgetRenommer()
{
    QWidget * w = new QWidget(this, Qt::Dialog);
    w->setWindowTitle(tr("Renommer"));
    QVBoxLayout * layout = new QVBoxLayout(w);

    QLabel * l = new QLabel(tr("Fichier : ")+"<b><i>"+rep_courant.absolutePath()+"/"+dernier_item_menu->text(0)+"</b></i>");
    layout->addWidget(l);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    l = new QLabel(tr("Nouveau nom : "));
    ss_layout->addWidget(l);
    nouveau_nom = new QLineEdit(dernier_item_menu->text(0));
    ss_layout->addWidget(nouveau_nom);
    layout->addLayout(ss_layout);

    ss_layout = new QHBoxLayout();
    QPushButton * annuler = new QPushButton(QIcon(":/FTPImages/annuler.png"), tr("Annuler"));
    ss_layout->addWidget(annuler);
    QPushButton * ok = new QPushButton(QIcon(":/FTPImages/valider.png"), tr("Valider"));
    ss_layout->addWidget(ok);
    layout->addLayout(ss_layout);

    w->setMinimumSize(400, 100);
    w->show();
    connect(annuler, SIGNAL(clicked()), w, SLOT(close()));
    connect(ok, SIGNAL(clicked()), this, SLOT(widgetRenommerOk()));
    connect(ok, SIGNAL(clicked()), w, SLOT(close()));
}

void DossiersLocaux::widgetRenommerOk()
{
    messages->ajouterMessage(dernier_item_menu->icon(0), rep_courant.absolutePath()+"/"+dernier_item_menu->text(0)+tr(" renomm� en ")+nouveau_nom->text(), new QLabel(tr("Local")));

    rep_courant.rename(rep_courant.absolutePath()+"/"+dernier_item_menu->text(0), rep_courant.absolutePath()+"/"+nouveau_nom->text());
    clear();
    list();
}

void DossiersLocaux::list()
{
    QFileInfoList l = rep_courant.entryInfoList();
    for(int i=0; i<l.count(); i++)
    {
        ajouterItem(l.value(i));
    }
}

QDir DossiersLocaux::getRepCourant()
{
    return rep_courant;
}

void DossiersLocaux::setRepCourant(QDir dir)
{
    rep_courant = QDir(dir);
}

MessagesToolBar* DossiersLocaux::getMessages()
{
    return messages;
}

QTreeWidgetItem* DossiersLocaux::getDernierItem()
{
    return dernier_fichier_selectionne;
}

bool DossiersLocaux::existeDeja(QString nom)
{
    bool res = false;
    QList<QTreeWidgetItem*> l = this->findItems(nom, Qt::MatchFixedString);
    if(l.value(0))
    {
        res = true;
    }
    return res;
}
