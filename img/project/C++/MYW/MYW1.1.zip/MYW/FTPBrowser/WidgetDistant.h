#ifndef WIDGETDISTANT_H
#define WIDGETDISTANT_H

/*========================================================================
Nom: WidgetDistant.h           auteur: Maneschi Romain
Maj: 17.05.2009                Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe conteneur de DossiersDistants.
=========================================================================*/

/*!
* \file WidgetDistant.h
* \brief Classe conteneur de DossiersDistants.
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QMessageBox>
#include <QCheckBox>
#include <QFile>

class FTPBrowser;

#include "DossiersDistants.h"

struct struct_put_get
{
    QFile * file;
    QString nom;
};

/*!
* \class WidgetDistant
* \brief Classe gérant les boutons dessous DossiersDistants et conteneur de cette même classe.
*
* Cette classe permet de retourner au répertoire par défaut, créer un dossier et actualiser le répertoire courant.
*
*/
class WidgetDistant : public virtual QWidget
{
    Q_OBJECT

private:
    FTPBrowser * parent;/*!< Le parent de la classe.*/
    DossiersDistants * distant;/*!< Pointeur vers DossiersDistants*/
    QList<struct_put_get> * put_s;/*!< Liste des uploads en cours*/
    QList<struct_put_get> * get_s;/*!< Liste des download en cours*/
    int serveur_en_cours;/*!< Serveur en cours d'utilisation*/
    QString home_dir;/*!< Répertoire par défaut*/
    bool verifier_existe_deja;/*!< True si l'utilisateur veut vérifier si un fichier existe déjà, False si non*/
    QFile * file_dernier_upload;/*!< Le dernier fichier télécharger (permet de le close())*/
    QLineEdit * emplacement;/*!< Edition de l'emplacement*/
    QPushButton * cd_ou_cdparent;/*!< Bouton permetant de remonter au dossier père, ou d'aller au dossier tappé dans emplacement*/
    QPushButton * bouton_home_repertoir;/*!< Bouton permetant de se rendre au répertoire par défaut*/
    QPushButton * bouton_nouveau_repertoir;/*!< Bouton permetant de créer un nouveu répertoire dans le dossier courant*/
    QPushButton * bouton_recharger;/*!< Bouton permetant de recharger le dossier courant*/
    /*!
    * \brief Change l'icone en flêche vers la droite pour cd et flêche vers le haut pour cdParent
    *
    * \param b : bool True = cd et false = cdParent
    */
    virtual void cdOuCdParent(bool);

    //----------------------AJOUTER-DOSSIER-------------------------
    QLineEdit * emplacement_dossier;/*!< Edition de l'emplacement du répertoire à créer*/
    QLineEdit * nom_dossier;/*!< Edition du nom du répertoire à créer*/

    //----------------------FICHIER-EXISTE-DEJA-------------------------
    /*!
    * \brief Créé le widgetRemplacementFichier()
    *
    * \param nom : QString le nom du fichier
    * \param icon : QIcon l'icone du fichier
    */
    virtual void widgetRemplacementFichier(QString, QIcon);
    QCheckBox * ne_plus_demander_verification_fichier;/*!< Bouton permettant de remplacer automatiquement un fichier existant déjà*/

private slots:
    /*!
    * \brief Ajoute le dossier aprés validation de widgetAjouterDossier()
    */
    virtual void widgetAjouterDossierOk();
    /*!
    * \brief Méthode appelée lors de la frappe d'un emplacement par l'utilisateur pour colorier la barre d'édition en vers si ok sinon en rouge
    */
    virtual void verificationEmplacement(QString);
    //----------------------FICHIER-EXISTE-DEJA-------------------------
    /*!
    * \brief Remplace le fichier aprés validation de widgetRemplacementFichier()
    */
    virtual void widgetRemplacementFichierOk();

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe WidgetDistant
    *
    * \param parent : FTPBrowser parent du conteneur des dossiers du ftp
    */
    WidgetDistant(FTPBrowser*);

    /*!
    * \brief Permet d'accéder au parent
    *
    * \return FTPBrowser* le pointeur du mainwindow du FTPBrowser
    */
    virtual FTPBrowser* getParent();
    /*!
    * \brief Retourne le répertoir courant
    */
    virtual QString getRepCourant();
    /*!
    * \brief Retourne le ftp en cours d'utilisation
    */
    virtual QFtp* getFtp();
    /*!
    * \brief Retourne le path du répertoir par défaut
    */
    virtual QString getHomeDir();
    /*!
    * \brief Ajoute un upload à la liste des téléchargements
    *
    * \param chemin_fichier : QString path absolu du fichier à upload
    * \param icon : QIcon icone du fichier à upload
    */
    virtual void put(QString, QIcon);/*chemin absolu*/
    /*!
    * \brief Lance l'upload situé en position i
    *
    * \param i : int position dans la liste des téléchargements de l'upload à lancer
    */
    virtual void lancerPut(int);
    /*!
    * \brief Ajoute un download à la liste des téléchargements
    *
    * \param chemin_fichier : QString path absolu du fichier à download
    * \param icon : QIcon icone du fichier à download
    */
    virtual void get(QString nom/*chemin absolu*/, QIcon icon);
    /*!
    * \brief Lance le download situé en position i
    *
    * \param i : int position dans la liste des téléchargements du download à lancer
    */
    virtual void lancerGet(int);
    /*!
    * \brief Retourne le DossiersDistants affichant les dossiers du répertoir courant du ftp
    */
    virtual DossiersDistants* getDistant();
    /*!
    * \brief Permet de close() le dernier fichier uploader
    */
    virtual void closeDernierUpload();

public slots:
    /*!
    * \brief Affiche la fenêtre pour ajouter un dossier
    */
    virtual void widgetAjouterDossier();
    /*!
    * \brief Recharge le répertoir courant
    */
    virtual void recharger();
    /*!
    * \brief Grise ou affiche les boutons créer dossier, aller au répertoir par défaut et recharger en fonction de l'état du serveur ftp
    */
    virtual void enabledDisabledBoutons();
    /*!
    * \brief Connect au serveur ftp numéro i
    *
    * \param i : int numéro du serveur auquel on souhaite se connecter
    */
    virtual void connexion(int);
    /*!
    * \brief Se reconnect au dernier serveur ftp connecté dans la session en cours
    */
    virtual void reconnexion();
    /*!
    * \brief Met à jour l'édition de l'url lors d'un changement de répertoir
    */
    virtual void mettreAJourEmplacement();
    /*!
    * \brief Met la couleur blanche en fond de l'édition de l'url
    */
    virtual void emplacementNormalePalette(bool = false);
    /*!
    * \brief Méthode permettant d'aller au répertoir par défaut
    */
    virtual void cdHome();
    /*!
    * \brief Méthode permettant d'aller au répertoir père
    */
    virtual void cdUp();
    /*!
    * \brief Méthode permettant de se déconnecter du serveur en cours
    */
    virtual void deconnection();

};

#endif // WIDGETDISTANT_H
