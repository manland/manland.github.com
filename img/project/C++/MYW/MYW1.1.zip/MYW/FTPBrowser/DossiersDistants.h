#ifndef DOSSIERSDISTANTS_H
#define DOSSIERSDISTANTS_H

/*========================================================================
Nom: DossiersDistants.h           auteur: Maneschi Romain
Maj: 17.05.2009                   Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe gérant l'affichage de l'arborescence du serveur ftp.
=========================================================================*/

/*!
* \file DossiersDistants.h
* \brief Classe gérant l'affichage de l'arborescence du serveur ftp.
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QTreeWidget>
#include <QUrlInfo>
#include <QTreeWidgetItem>
#include <QFtp>

class WidgetDistant;

#include "MessagesToolBar.h"

/*!
* \class DossiersDistants
* \brief Classe très importante gérant l'affichage d'un répertoir et les actions sur le ftp
*
* Cette classe affiche un repertoir du ftp avec possibilité sur double-click de rentrer dans un
* répertoir ou de télécharger le fichier. On peut remonter au dossier parent grâce à la convention abituelle du dossier nommer ".."
*
*/
class DossiersDistants : public virtual QTreeWidget
{
    Q_OBJECT

private:
    WidgetDistant * parent;/*!< Le parent de la classe.*/
    QFtp * ftp;/*!< Variable essentielle à tout le programme*/

    MessagesToolBar * messages;/*!< Pointeur vers les messages relatifs au ftp*/
    QString rep_courant;/*!< Répertoire courant*/
    /*!
    * \brief Méthode permettant de récupérer une taille sous la forme 4Ko au lieu de 4000
    *
    * \param i : quint64 retourner sous se format par Qt
    */
    virtual QString tailleString(quint64 i);
    QTreeWidgetItem * dernier_fichier_selectionne;/*!< dernier fichier clické*/
    QTreeWidgetItem * dernier_item_menu;/*!< dernier dossier clické*/
    //widgetRenommer()
    QLineEdit * nouveau_nom;/*!< edition d'un nouveau nom pour un dossier ou fichier*/

private slots:
    /*!
    * \brief Méthode appelée par QFtp lorsque le serveur passe de déconnecté à connecté
    *
    * \param i : int numéro d'état interne à Qt
    */
    virtual void changementEtat(int);
    /*!
    * \brief Méthode appelée par QFtp lorsque le serveur fini une commande telle que cd, ls...
    *
    * \param i : int numéro d'état interne à Qt
    * \param error : bool true si une erreur est survenue durant la commande, false sinon
    */
    virtual void finCommande(int, bool);
    /*!
    * \brief Méthode appelée par un double click sur un dossier ou un fichier et appelant le cd ou le téléchargement
    *
    * \param item : QTreeWidgetItem contient les informations nécessaire au traitement
    * \param i : int colonne double clickée
    */
    virtual void cmd(QTreeWidgetItem*, int);
    /*!
    * \brief Méthode appelée par un click sur un fichier et appelant l'activation des boutons de téléchargement
    *
    * \param item : QTreeWidgetItem contient les informations nécessaire au traitement
    * \param i : int colonne double clickée
    */
    virtual void clicked(QTreeWidgetItem*, int);
    /*!
    * \brief Méthode appelée par un click sur le bouton download et appelant le téléchargement du dernier fichier clické
    */
    virtual void download();
    /*!
    * \brief Supprime le dernier fichier ou dossier clické
    */
    virtual void remove();
    /*!
    * \brief Affiche le widget permettant de renommer un fichier
    */
    virtual void widgetRenommer();
    /*!
    * \brief Renomme le fichier aprés validation de widgetRenommer()
    */
    virtual void widgetRenommerOk();

protected:
    /*!
    * \brief Réimplante l'évènement du click droit de la souris
    *
    * \param e : QContextMenuEvent
    */
    virtual void contextMenuEvent(QContextMenuEvent*);

public slots:
    /*!
    * \brief Méthode appelée par Qt pour ajouter un fichier ou un dossier
    *
    * \param info : QUrlInfo contient les informations sur le fichier ou le dossier à ajouter
    */
    virtual void ajouterItem(const QUrlInfo &);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe DossiersDistants
    *
    * \param parent : WidgetDistant parent conteneur des dossiers du ftp
    */
    DossiersDistants(WidgetDistant*);
    /*!
    * \brief Retourne le path du répertoire courant
    */
    virtual QString getRepCourant();
    /*!
    * \brief Change le répertoir courant
    *
    * \param s : QString charge le répertoir demandé par l'utilisateur
    */
    virtual void setRepCourant(QString);
    /*!
    * \brief Retourne le pointeur du ftp
    */
    virtual QFtp* getFtp();
    /*!
    * \brief Vérifie si le fichier ou dossier nommé QString ne soit pas déjà entré
    *
    * \param nom : QString le nom du fichier ou répertoir à vérifier
    */
    virtual bool existeDeja(QString);
    /*!
    * \brief Renvoie le dernier item clické
    */
    virtual QTreeWidgetItem* getDernierItem();
};

#endif // DOSSIERSDISTANTS_H
