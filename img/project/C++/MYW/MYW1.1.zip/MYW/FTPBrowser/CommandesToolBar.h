#ifndef COMMANDESTOOLBAR_H
#define COMMANDESTOOLBAR_H

/*========================================================================
Nom: CommandesToolBar.h           auteur: Maneschi Romain
Maj: 17.05.2009                   Creation: 20.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe gérant les boutons du milieu de l'application permettant l'upload, le download...
=========================================================================*/

/*!
* \file CommandesToolBar.h
* \brief Classe gérant les boutons du milieu de l'application permettant l'upload, le download...
* \author Maneschi Romain
* \date 20.04.2009
*/

#include <QWidget>
#include <QAction>
#include <QLabel>
#include <QHBoxLayout>
#include <QMenu>
#include <QPushButton>
#include <QVBoxLayout>

class FTPBrowser;

/*!
* \class CommandesToolBar
* \brief Classe gérant les boutons du milieu de l'application
*
* Cette classe gère entièrement (boutons + actions) la boite d'outil du milieu
*
*/
class CommandesToolBar : public virtual QWidget
{
    Q_OBJECT

private:
    FTPBrowser * parent;/*!< Le parent de la classe.*/
    QPushButton * bouton_serveur;/*!< Bouton permettant de se connecter à un serveur ou de se déconnecté*/
    QPushButton * bouton_uploader;/*!< Bouton lançant un upload si un fichier est sélectionné*/
    QPushButton * bouton_downloader;/*!< Bouton lançant un download si un fichier est sélectionné*/
    QPushButton * bouton_stopper_trash;/*!< Bouton vidant les messages ou permettant l'arrêt d'un téléchargement*/
    QMenu * menu_bouton_serveur;/*!< Menu du bouton_serveur*/

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe CommandesToolBar
    *
    * \param parent : FTPBrowser parent des commandes
    */
    CommandesToolBar(FTPBrowser*);
    /*!
    * \brief Méthode remplissant le bouton serveur à partir des serveurs enregistrer
    */
    virtual void remplirMenuBoutonServeurs();
    /*!
    * \brief Méthode permettant de griser le bouton de téléchargement
    *
    * Condition pour qu'il ne soit pas grisés :
    * - serveur connecté
    * - fichier sélectionné
    *
    * \param b : bool false pour griser, true sinon
    */
    virtual void uploadOnOff(bool);
    /*!
    * \brief Méthode permettant de griser le bouton de chargement
    *
    * Condition pour qu'il ne soit pas grisés :
    * - serveur connecté
    * - fichier sélectionné
    *
    * \param b : bool false pour griser, true sinon
    */
    virtual void downloadOnOff(bool);
    /*!
    * \brief Méthode permettant de changer la corbeille en stop (car un téléchargement est en cours)
    */
    virtual void stopToTrash();
    /*!
    * \brief Méthode permettant de changer le stop en corbeille (car aucun téléchargement n'est en cours)
    */
    virtual void trashToStop();
    /*!
    * \brief Méthode permettant de griser le bouton permettant de vider la corbeille
    *
    * Condition pour qu'il ne soit pas grisés :
    * - au moins un élément affiché dans les messages
    * - ou un téléchargement
    *
    * \param b : bool false pour griser, true sinon
    */
    virtual void trashStopOnOff(bool);
    /*!
    * \brief Change la corbeille en corbeille vide
    *
    * \param vide : bool true pour la mettre vide, false si non
    */
    virtual void setTrash(bool/*vide*/);
    /*!
    * \brief Méthode permettant de changer le bouton serveur en bouton déconnexion
    *
    * \param connecte : bool false pour serveur, true pour déconnexion
    */
    virtual void ServeurToStop(bool/*connecte*/);

private slots:
    /*!
    * \brief Méthode permettant de connecter le ftp au serveur
    *
    * \param action : QAction contient les infos permettant de se connecter
    */
    virtual void connectionServeur(QAction*);
    /*!
    * \brief Méthode permettant de télécharger un fichier du serveur vers le client
    */
    virtual void uploader();
    /*!
    * \brief Méthode permettant de télécharger un fichier du client vers le serveur
    */
    virtual void downloader();
};

#endif // COMMANDESTOOLBAR_H
