#ifndef CHANGERCOLORATION_H
#define CHANGERCOLORATION_H

/*!
* \changerColoration.h
* \brief Ce fichier contient tout ce qui est n&eacute;cessaire &agrave; la cr&eacute;ation du widget changerColoration
* \author Novak Audrey
* \date 12.03.2009
*/

#include "coloration.h"
#include <QObject>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QColor>
#include <QFrame>
#include <QGroupBox>
#include <QPushButton>
#include <QSettings>
#include "couleur.h"

class Preferences;

/*!
* \class ChangerColoration
* \brief Classe permettant de construire le widget changerColoration
*
* Cette classe permet de changer la coloration des diff&eacute;rents mots cl&eacute;s.
* Elle est int&eacute;gr&eacute;e dans le widget Pr&eacute;f&eacute;rences. ChangerColoration est construite &agrave; partir de quatre
* QGroupBox (boites permettant de contenir des boutons, du texte ...), une pour chaque type de langage.
* Ces QGroupBox contiennent chacune un texte correspondant &agrave; la liste de mots cl&eacute;s ou d'expressions r&eacute;guli&egrave;res
* concern&eacute;s, ainsi que pour chacune d'elle une frame color&eacute;e, un bouton G (Gras) et un bouton I (italique), qui
* correspondent au format associ&eacute; &agrave; la liste de mots cl&eacute;s. La frame color&eacute;e est construite &agrave; partir de la classe
* Couleur qui h&eacute;rite de QFrame, et qui prend comme couleur, la couleur des mots cl&eacute;s correspondant aux param&egrave;tres
* pass&eacute;s dans son constructeur. En cliquant sur la frame, on affiche une boite de dialogue permettant de changer la
* coloration des mots cl&eacute;s du langage. Le widget changerColoration contient &eacute;galement un bouton valider qui permet
* d'appliquer tous les changements de format aux mots cl&eacute;s et ce pour tous les onglets d'&eacute;dition ouverts.
*/


class ChangerColoration : public QWidget
{
     Q_OBJECT

    private :
        Coloration *coloration;             /*< parent de ChangerColoration */
        Preferences *parent;                /*< parent de ChangerColoration */

        QVBoxLayout *vbox;                  /*< layout g&eacute;n&eacute;rale contenant les autres layout */
// boite php :
        QGroupBox *groupe_php;              /*< groupe php */
        Couleur *couleur_php1;              /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de php 1*/
        Couleur *couleur_php2;              /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de php 2*/
        Couleur *couleur_php3;              /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de php 3*/
        Couleur *couleur_variables_php;     /*< Frame construite &agrave; partir de la classe Couleur pour les variables php*/
        QPushButton *gras_php1;             /*< bouton gras php1 */
        QPushButton *gras_php2;             /*< bouton gras php2 */
        QPushButton *gras_php3;             /*< bouton gras php3 */
        QPushButton *gras_php_variables;    /*< bouton gras variables php */
        QPushButton *italique_php1;         /*< bouton italique php1 */
        QPushButton *italique_php2;         /*< bouton italique php2 */
        QPushButton *italique_php3;         /*< bouton italique php3 */
        QPushButton *italique_php_variables; /*< bouton italique variables php */


// boite javascript
        QGroupBox *groupe_javascript;           /*< groupe javascript */
        Couleur *couleur_javascript1;           /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de javascript 1*/
        Couleur *couleur_javascript2;           /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de javascript 2*/
        Couleur *couleur_javascript3;           /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de javascript 3*/
        QPushButton *gras_javascript1;          /*< bouton gras javascript1 */
        QPushButton *gras_javascript2;          /*< bouton gras javascript2 */
        QPushButton *gras_javascript3;          /*< bouton gras javascript3 */
        QPushButton *italique_javascript1;      /*< bouton italique javascript1 */
        QPushButton *italique_javascript2;      /*< bouton italique javascript2 */
        QPushButton *italique_javascript3;      /*< bouton italique javascript3 */

// boite css :
        QGroupBox *groupe_css;           /*< groupe javascript */
        Couleur *couleur_css1;           /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de css 1*/
        Couleur *couleur_css2;           /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de css 2 */
        QPushButton *gras_css1;          /*< bouton gras css1 */
        QPushButton *gras_css2;          /*< bouton gras css2 */
        QPushButton *italique_css1;      /*< bouton italique css1 */
        QPushButton *italique_css2;      /*< bouton italique css2 */

// boite html :
        QGroupBox *groupe_html;             /*< groupe html */
        Couleur *couleur_html_mot_cle;      /*< Frame construite &agrave; partir de la classe Couleur pour la liste de mots cl&eacute;s de html*/
        Couleur *couleur_html_attributs;    /*< Frame construite &agrave; partir de la classe Couleur pour la liste d'attributs html*/
        QPushButton *gras_html_mc;          /*< bouton gras html mots cl&eacute;s*/
        QPushButton *gras_html_att;         /*< bouton gras attributs html */
        QPushButton *italique_html_mc;      /*< bouton italique mots cl&eacute;s html */
        QPushButton *italique_html_att;     /*< bouton italique attributs html */

// boite general :
        QGroupBox *groupe_general;              /*< groupe g&eacute;n&eacute;ral */
        Couleur *couleur_commentaire_simple;    /*< Frame construite &agrave; partir de la classe Couleur pour les commentaires simples*/
        Couleur *couleur_commentaire_multiple;  /*< Frame construite &agrave; partir de la classe Couleur pour les commentaires multiples*/
        Couleur *couleur_quote;                 /*< Frame construite &agrave; partir de la classe Couleur pour les chaines de caract&egrave;res*/
        Couleur *couleur_fonction;              /*< Frame construite &agrave; partir de la classe Couleur pour les fonctions*/
        Couleur *couleur_e_commercial;          /*< Frame construite &agrave; partir de la classe Couleur pour &amp;*/
        QPushButton *gras_comm_simple;          /*< bouton gras commentaire simple*/
        QPushButton *gras_comm_multi;           /*< bouton gras commentaire multiple*/
        QPushButton *gras_quote;                /*< bouton gras chaine de caract&egrave;res*/
        QPushButton *gras_fonction;             /*< bouton gras fonction*/
        QPushButton *gras_e_commercial;         /*< bouton gras &amp; */
        QPushButton *italique_comm_simple;      /*< bouton italique commentaire simple*/
        QPushButton *italique_comm_multi;       /*< bouton italique commentaire multiple*/
        QPushButton *italique_quote;            /*< bouton italique chaine de caract&egrave;res*/
        QPushButton *italique_fonction;         /*< bouton italique fonction*/
        QPushButton *italique_e_commercial;     /*< bouton italique &amp; */

/*!
* \brief Fonction permettant d'enregistrer les formats des listes de mots cl&eacute;s
*
* Les formats sont sauvegard&eacute;s gr�ce &agrave; un QSettings, et seront restaur&eacute;s lors la r&eacute;ouverture du logiciel.
*/
        void enregistrer();

    public:
 /*!
* \brief Constructeur
*
* Constructeur de la classe ChangerColoration
*
* \param parent : le parent de la classe changerColoration est de type Preferences
* \param colo : le widget changerColoration est construit &agrave; partir de la classe Coloration
*/
        ChangerColoration(Coloration *colo=0,Preferences *parent=0);

 /*!
* \brief Permet de construire la boite de dialogue pour le php
*
*/
        void construireBoitePhp();

 /*!
* \brief Permet de construire la boite de dialogue pour le css
*
*/
        void construireBoiteCss();

 /*!
* \brief Permet de construire la boite de dialogue pour le javascript
*
*/
        void construireBoiteJavascript();

 /*!
* \brief Permet de construire la boite de dialogue pour le g&eacute;n&eacute;ral
*
*/
        void construireBoiteGeneral();

 /*!
* \brief Permet de construire la boite de dialogue pour le html
*
*/
        void construireBoiteHtml();

    public slots:
/*!
* \brief Slot appel&eacute; par le bouton valider
*
* Le bouton appliquer lance l'enregistrement des couleurs dans le fichier du QSettings,
* le changement automatique du format de chaque langage, la recoloration automatique de chaque mot cl&eacute;,
*  en faisant appel aux fonctions : changerFormatPhp1(QColor coul, bool estGras, bool estItalique)
* (respectivement javascript, html, css), de la classe Coloration.
*/
        void validerChangerCouleur();

        void reinitialiserFormats();

/*!
* \brief Slot permettant d'appliquer une recoloration de tous les onglets ouverts,
* d&egrave;s que l'utilisateur aura appuyer sur tout_appliquer
* Fait appel au rehighlight de Coloration
*
*/
        void recolorer();
};

#endif // CHANGERCOLORATION_H
