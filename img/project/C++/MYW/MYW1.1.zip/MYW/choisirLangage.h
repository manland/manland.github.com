#ifndef CHOISIRLANGAGE_H
#define CHOISIRLANGAGE_H

/*!
* \choisirLangage.h
* \brief Ce fichier contient tout ce qui est n&eacute;cessaire &agrave; la cr&eacute;ation du widget choisirLangage
* \author Novak Audrey
* \date 12.03.2009
*/

#include <QObject>
#include <QWidget>
#include <QGroupBox>
#include <QRadioButton>
#include <QCheckBox>
#include <QLabel>
#include "coloration.h"

class Preferences;

/*!
* \class ChoisirLangage
* \brief Classe permettant de construire le widget choisirLangage
*
* Par d&eacute;faut, le type de coloration syntaxique est automatique,
* c'est &agrave; dire que la coloration est appliqu&eacute;e en fonction des blocs d&eacute;tect&eacute;s dans l'&eacute;diteur.
* Cependant, gr�ce &agrave; ce widget, il est possible de choisir de colorer automatiquement (par balises),
* et de rajouter la coloration des mots cl&eacute;s d'un autre langage (hors balises).
* Par exemple, on ouvre une balise php, on est alors dans l'&eacute;tat php, mais on souhaite
* aussi colorer les mots cl&eacute; du javascript afin d'avoir une meilleure vue des diff&eacute;rentes
* parties de notre code, il suffira de cocher automatique, et javascript. Il est aussi possible
* de choisir de colorer seulement les mots cl&eacute;s d'un certain langage, sans m&ecirc;me avoir reconnu
* l'ouverture d'un bloc, il faudra alors d&eacute;cocher la case automatique, et cocher la case du langage d&eacute;sir&eacute;.
* Ce widget est constitu&eacute; de QCheckBox, une pour chaque langage, une pour la coloration personnalis&eacute;e et une
* pour la coloration automatique. En cochant la case personnalis&eacute;e, on a acc&egrave;s aux QCheckBox des langages.
* La fenetre choisir le type de coloration contient aussi un bouton appliquer qui permet d'appliquer toutes
* les modifications aux onglets ouverts et de recolorer automatiquement les mots en fonctions des cases coch&eacute;es,
* il fait appel aux fonctions setPhp(), et estPhp() (respectivement javascript, css et html) de la classe Coloration.
* Ces fonctions rappellent la boucle de reconnaissance de mots cl&eacute;s par rapport &agrave; leur expression r&eacute;guli&egrave;re,
* dans le vecteur de r&egrave;gles correspondant.
*/

class ChoisirLangage : public QWidget
{
     Q_OBJECT

    private :
        Coloration *coloration;         /*< parent de choisirLangage */
        Preferences *parent;            /*< parent de choisirLangage */

        // pour le choix d'une coloration automatique ou personnalis&eacute;e :
        QCheckBox *automatique;         /*< QCheckBox permettant de cocher la detection automatique */
        QCheckBox *personnalisee;       /*< QCheckBox permettant de cocher la detection personnalis&eacute;e */


        // pour l'affichage des diff&eacute;rents langages possibles :
        QCheckBox *php_checkBox;        /*< QCheckBox permettant de cocher la case php */
        QCheckBox *css_checkBox;        /*< QCheckBox permettant de cocher la case css */
        QCheckBox *javascript_checkBox; /*< QCheckBox permettant de cocher la case javascript */
        QCheckBox *html_checkBox;       /*< QCheckBox permettant de cocher la case html */

        bool javascriptSelectionne;     /*< bool&eacute;en permettant de savoir si la case javascript est coch&eacute;e ou non */
        bool phpSelectionne;            /*< bool&eacute;en permettant de savoir si la case php est coch&eacute;e ou non */
        bool cssSelectionne;            /*< bool&eacute;en permettant de savoir si la case css est coch&eacute;e ou non */
        bool automatiqueSelectionne;    /*< bool&eacute;en permettant de savoir si la case automatique est coch&eacute;e ou non */

        QLabel *explication;            /*< label expliquant ce que fait ce widget */

    public:
 /*!
* \brief Constructeur
*
* Constructeur de la classe ChoisirLangage
*
* \param parent : le parent de la classe choisirLangage est de type Preferences
* \param colo : le widget choisirLangage est construit &agrave; partir de la classe Coloration
*/
        ChoisirLangage(Coloration *colo=0,Preferences *parent = 0);

/*!
* \brief Permet de changer l'&eacute;tat de selection du langage javascript en fonction de la case coch&eacute;e
*
* \param b : bool, si la case javascript est coch&eacute;e, b=true, sinon b= false
*/
        void setJavascriptSelectionne(bool);

/*!
* \brief Renvoi l'&eacute;tat de la case de langage javascript
*
* \return brai si la case javascript est coch&eacute;e, faux sinon.
*/
        bool estJavascriptSelectionne();

/*!
* \brief Permet de changer l'&eacute;tat de selection du langage javascript en fonction de la case coch&eacute;e
*
* \param b : bool, si la case javascript est coch&eacute;e, b=true, sinon b= false
*/
        void setPhpSelectionne(bool);

/*!
* \brief Renvoi l'&eacute;tat de la case de langage php
*
* \return brai si la case php est coch&eacute;e, faux sinon.
*/
        bool estPhpSelectionne();

/*!
* \brief Permet de changer l'&eacute;tat de selection du langage javascript en fonction de la case coch&eacute;e
*
* \param b : bool, si la case javascript est coch&eacute;e, b=true, sinon b= false
*/
        void setCssSelectionne(bool);

/*!
* \brief Renvoi l'&eacute;tat de la case de langage css
*
* \return brai si la case css est coch&eacute;e, faux sinon.
*/
        bool estCssSelectionne();

/*!
* \brief Permet de changer l'&eacute;tat de selection de la case automatique en fonction de la case coch&eacute;e
*
* \param b : bool, si la case automatique est coch&eacute;e, b=true, sinon b= false
*/
        void setAutomatiqueSelectionne(bool);

/*!
* \brief Renvoi l'&eacute;tat de la case de langage css
*
* \return brai si la case css est coch&eacute;e, faux sinon.
*/
        bool estAutomatiqueSelectionne();

    public slots :
/*!
* \brief Slot appel&eacute; par le bouton appliquer, si une case est coch&eacute;e, alors suivant la case, on a un appel &agrave; la
* classe Coloration, dans la fonction highlightBlock. Le clic sur le bouton appliquer appliquera cette m&eacute;thode &agrave; tous
* les onglets ouverts
*
*/
            void validerChoisirLangage();

 /*!
* \brief Slot appel&eacute; lorsque l'utilisateur cliquera sur la case "personnalisee", qui d&eacute;clenchera le d&eacute;grisement des
* cases php, javascript, css, html.
*
*/
            void afficherListeLangage();

/*!
* \brief Slot permettant d'appliquer une recoloration de tous les onglets ouverts,
* d&egrave;s que l'utilisateur aura appuyer sur tout_appliquer
* Fait appel au rehighlight de Coloration
*
*/
            void recolorer();
};

#endif // CHOISIRLANGAGE_H
