#ifndef MESCONFIGS_H
#define MESCONFIGS_H

    // MainWindow
    #define mainWindow_WIDTH 1000
    #define mainWindow_HEIGHT 500

    // workspace
    //#define workspace "./"

    // SYSTEMES
    /* Permet de définir si on se trouve dans windob ou linux bug par rapport au dossier dû �  qtCreator probablement.
        utilisé dans :
            coloration.cpp,
            WebBrowser.cpp, Pages.cpp, Page.cpp, MarquesPages.cpp, MarquePageFleches.cpp, HistoriqueWidget.cpp

       Utiliser fonctionUtilisantUnFichier(QString("nomdefichier.extension").prepend(systeme_relation_fichier));
       Sans oublier #include "mesConfigs.h" en haut du .cpp
    */
    //#define systeme_relation_fichier "../" //pour windob
    #define systeme_relation_fichier "./" //pour les autres
    #if (defined(Q_WS_WIN))
        #define systeme_relation_fichier "../"
    #endif

#endif // MESCONFIGS_H
