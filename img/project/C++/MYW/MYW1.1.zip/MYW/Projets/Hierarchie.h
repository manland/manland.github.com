/*========================================================================
Nom: Hierarchie.h           auteur: K�NIG M&eacute;lanie
Maj:  17/05/09         Creation:
Projet: MYW
--------------------------------------------------------------------------
Specification:
Ce fichier contient l'entete du l'arborescence du workspace
=========================================================================*/
/*!
* \file Hierarchie.h
* \brief Arborescence du workspace
* \author K�NIG M&eacute;lanie
* \date 17.05.2009
*
* Ce fichier contient tout ce qui est necessaire pour r&eacute;aliser le premier niveau de l'arborescence de l'espace de travail
*
*/
#ifndef HIERARCHIE_H
#define HIERARCHIE_H

/*!
* \class Hierarchie
* \brief Classe permettant de construire la base de l'arborescence de l'espace de travail
*
* Cette classe liste tous les dossiers de l'espace de travail et construit pour chacun un projet.
* Elle est instanci&eacute; dans le mainWindow avec en param&egrave;tre de son constructeur un QDir* qui contient toutes les informations sur
* l'espace de travail choisit par l'utilisateur. Elle affiche dans le dock ou elle est instanci&eacute;e la hierarchie de l'espace de
* travail
*/

#include <QTreeWidget>
#include <QFileInfo>
#include <QDir>

#include <iostream>
using namespace std;


#include "Projet.h"


class Hierarchie : public virtual QTreeWidget
{
     Q_OBJECT

    private:
    QDir* espaceDeTravail;/*!< contient les informations du dossier choisit par l'utilisateur comme espace de travail (workspace)*/
    QWidget* parent;/*!< le parent de cette hierarchie dans notre projet, le mainWindow*/

    public:
    /*!
    * \brief Constructeur
    * Constructeur de la classe Hierarchie
    * \param  chemin : QString contenant le chemin du workspace a lister
    * \param parent : QWidget parent de la hierarchie
    */
    Hierarchie(QString chemin, QWidget* parent=0);
     /*!
    * \brief ajoute un projet
    * ajoute le projet donn&eacute; en param&egrave;tre &agrave; la hierarchie
    * \param  projet : Projet &agrave; ajouter &agrave; la hierarchie du workspace
    */
    void ajouteProjet(Projet*);
     /*!
    * \brief dit si le wokspace contient le fichier
    * Retourne vrai si la hierarchie contient le fichier dont les informations sont donn&eacute;es en para�m&egrave;tre, faux sinon
    * \param  fichier : QFileInfo representant les infos du fichier a rechercher
    */
    bool contient(QFileInfo* info);
     /*!
    * \brief liste l'espace de travail
    * fonction r&eacute;cursive qui parcourt le dossier de l'espace de travail et liste les dossiers qu'il contient
    */
    void parcours();

    public slots:
     /*!
    * \brief slot emit lorsqu'un item est double-cliqu&eacute;
    * red&eacute;finition du slot &eacute;mit lorsqu'un item est double-cliqu&eacute;
    * \param  item : QTreeWidgetItem pointant sur l'item double-cliqu&eacute;
    */
    void doucleClicItem(QTreeWidgetItem* item);

};


#endif // HIERARCHIE_H
