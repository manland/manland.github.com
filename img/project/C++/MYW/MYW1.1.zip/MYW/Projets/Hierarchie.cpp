#include "mainwindow.h"
#include "Hierarchie.h"

Hierarchie::Hierarchie(QString chemin, QWidget* par):QTreeWidget(par)
{
    parent = par;
    espaceDeTravail = new QDir(chemin);
    espaceDeTravail->mkpath(chemin);
    parcours();

    connect(this,SIGNAL(itemDoubleClicked(QTreeWidgetItem*,int)),this,SLOT(doucleClicItem(QTreeWidgetItem*)));
}

void Hierarchie::ajouteProjet(Projet* projet)
{
    this->addTopLevelItem(projet);
}

bool Hierarchie::contient(QFileInfo * fichier)
{
    int n = this->topLevelItemCount();
    int i=0;
    bool pasTrouve = true;
    while(i<n && pasTrouve)
    {
        ItemHierarchie * item = dynamic_cast<ItemHierarchie*>(this->topLevelItem(i));
        if(item ){
            if(item->getInfoFichier()->absoluteFilePath() == fichier->absoluteFilePath())
                return true;
            pasTrouve = !item->contient(fichier);
        }
        i++;
    }
    return !pasTrouve;
}

void Hierarchie::parcours()
{
     QFileInfoList contenu = espaceDeTravail->entryInfoList();
    Projet* projet;
    for(int i=2; i<contenu.length(); i++)//debut a 2 pour ne pas regarder . et ..
    {
        if(contenu.at(i).isDir())
        {
            QFileInfo * infoProjet = new QFileInfo(contenu.at(i));
            projet = new Projet(infoProjet, infoProjet->baseName());
            this->ajouteProjet(projet);
        }
    }
}

void Hierarchie::doucleClicItem ( QTreeWidgetItem * it)
{
   ItemHierarchie * item = dynamic_cast<ItemHierarchie*>(it);
   MainWindow * fenetre = static_cast<MainWindow*>(this->parent);
   if(item)
   {
       if(fenetre)
       {
        fenetre->ouvreFichier(item->getInfoFichier(), false);
      }
   }
}
