#include "Itemhierarchie.h"

ItemHierarchie::ItemHierarchie(QFileInfo* fichier,QString nom):QTreeWidgetItem(QStringList(nom))
{
    infoFichier = fichier;
    if(fichier->suffix() == "php")
        this->setIcon(0,QIcon(":/images/php.png"));
    else if(fichier->suffix() == "html")
        this->setIcon(0,QIcon(":/images/html.png"));
    else if(fichier->suffix() == "js")
        this->setIcon(0,QIcon(":/images/js.png"));
    else if(fichier->suffix() == "sql")
        this->setIcon(0,QIcon(":/images/sql.png"));
    else
        this->setIcon(0,QIcon(":/images/inconnu.png"));
}

QFileInfo* ItemHierarchie::getInfoFichier()
{
    return infoFichier;
}

bool ItemHierarchie::contient(QFileInfo* fichier)
{
    int n = this->childCount();
    int i=0;
    bool pasTrouve = true;
    while(i<n && pasTrouve)
    {
        ItemHierarchie * item = dynamic_cast<ItemHierarchie*>(this->child(i));
        if(item)
        {
            if( item->getInfoFichier()->absoluteFilePath() == fichier->absoluteFilePath())
                return true;
            pasTrouve = !item->contient(fichier);
        }
        i++;
    }
    return !pasTrouve;
}
