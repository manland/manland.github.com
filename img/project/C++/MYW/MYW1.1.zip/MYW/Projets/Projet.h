/*========================================================================
Nom: Projet.h           auteur: K�NIG M&eacute;lanie
Maj:  17/05/09         Creation:
Projet: MYW
--------------------------------------------------------------------------
Specification:
Ce fichier contient l'entete de projet
=========================================================================*/
/*!
* \file Projet.h
* \brief projet pour l'utilisateur
* \author K�NIG M&eacute;lanie
* \date 17.05.2009
*
* Projet pour l'utilisateur
*
*/

#ifndef PROJET_H
#define PROJET_H

/*!
* \class Projet
* \brief Classe permettant de cr&eacute;er les dossiers de l'arborescence de l'espace de travail
*
* Cette classe stocke les informations sur le dossier qu'elle repr&eacute;sente liste son contenu pour cr&eacute;er
* les &eacute;l&eacute;ments qu'il contient et affiche dans l'arborescence un item avec une icone 'dossier'.
* Elle est instanci&eacute;e dans Projet ou Hierarchie pour chaque dossier qu'ils contiennent, avec en param&egrave;tre
* un QFileInfo* qui contient les informations relatives au dossier qu'elle repr&eacute;sente et une QString qui
* contient le nom du projet.
*
*/

 #include <QTreeWidgetItem>
 #include <QFile>
 #include <QDir>
 #include <QIcon>


 #include "Itemhierarchie.h"

class Projet : public virtual ItemHierarchie
{
    private:
    QString nom;/*!< le nom de ce projet dans la hierarchie*/

public:
    /*!
    * \brief Constructeur
    * Constructeur de la classe Projet
    * \param info : QFileInfo contenant les informations sur le dossier qui contient le projet
    * \param nom : QString contenant le texte a afficher dans la hierarchie
    */
    Projet(QFileInfo* info, QString nom);
    /*!
    * \brief ajoute un fichier
    * ajoute un fichier au projet avec les infos contenu par QFileInfo
    * \param info : QFileInfo repr&eacute;sentant les informations du fichier &agrave; ajouter au projet
    * \param nom : QString contenant le texte a afficher dans la hierarchie pour le fichier
    */
    void ajouteFichier(QFileInfo* info,QString nom);
    /*!
    * \brief liste le projet
    * fonction recursive qui parcourt le dossier du projet et liste les fichiers qu'il contient
    * \param dossier : QDir contenant les informations du dossier parcouru
    */
    void parcours(QDir* dossier);

};

#endif // PROJET_H
