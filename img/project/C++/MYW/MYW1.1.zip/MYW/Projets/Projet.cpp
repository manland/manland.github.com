#include "Projet.h"
#include <iostream>
using namespace std;

Projet::Projet(QFileInfo* infoProjet,QString nom):ItemHierarchie(infoProjet,nom)
{
    this->nom = nom;
    QDir* projet = new QDir(infoProjet->absoluteFilePath());
    parcours(projet);
    this->setIcon(0,QIcon(":/images/dossier.gif"));
}


void Projet::ajouteFichier(QFileInfo* fic, QString nom)
{
    ItemHierarchie* fichier = new ItemHierarchie(fic,nom);
    this->addChild( fichier);
}

void Projet::parcours(QDir* dossier)
{
     //on recup�re le contenu de notre dossier
    QFileInfoList contenu = dossier->entryInfoList();
    for(int i=2; i<contenu.length(); i++)//on le parcourt
    {
        if(contenu.at(i).isDir() && !contenu.at(i).isSymLink ())
            //si c'est un dossier on ajoute un niveau � l'arborescence et on le parcourt
        {
           QDir* sousDossier = new QDir(contenu.at(i).absoluteFilePath());
           QFileInfo* sousInfo = new QFileInfo(contenu.at(i));
           this->addChild(new Projet(sousInfo, sousInfo->baseName()));
        }
        else if(contenu.at(i).isFile())
            //si c'est un fichier on l'ajoute a l'arborescence
        {
            QFileInfo* infoFichier = new QFileInfo(contenu.at(i));
            ajouteFichier(infoFichier, infoFichier->fileName());
        }
    }
}
