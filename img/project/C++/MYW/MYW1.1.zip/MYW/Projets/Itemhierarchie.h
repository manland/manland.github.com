/*========================================================================
Nom: ItemHierarchie.h           auteur: K�NIG M&eacute;lanie
Maj:  17/05/09         Creation:
Projet: MYW
--------------------------------------------------------------------------
Specification:
Ce fichier contient l'entete d'un item de l'arborescence d'un projet
=========================================================================*/
/*!
* \file ItemHierarchie.h
* \brief item de la hierachie d'un projet
* \author K�NIG M&eacute;lanie
* \date 17.05.2009
*
* item de la hierarchie representant un fichier du projet
*
*/
#ifndef ITEMHIERARCHIE_H
#define ITEMHIERARCHIE_H

/*!
* \class ItemHierarchie
* \brief Classe permettant de cr&eacute;er les fichiers de l'arborescence de l'espace de travail
*
* Cette classe stocke les informations sur le fichiers qu'elle repr&eacute;sente et affiche dans l'arborescence un
* item avec une icone correspondant &agrave; l'extension du fichier.
* Elle est instanci&eacute;e dans un projet pour chaque fichier qu'il contient, avec en param&egrave;tre QFileInfo* qui contient les informations relatives au fichier
* qu'elle repr&eacute;sente.
*/

#include<QTreeWidgetItem>
#include <QFileInfo>

class ItemHierarchie: public QTreeWidgetItem
{

   private:
    QFileInfo* infoFichier;/*!< contient les informations du fichier represent&eacute; par cet itemHierarchie*/

public:
    /*!
    * \brief Constructeur
    * Constructeur de la classe ItemHierarchie
    * \param info represente les informations du fichier que represente l'itemHierarchie
    * \param nom de l'&eacute;tiquette du fichier dans la hierarchie
    */
    ItemHierarchie(QFileInfo* info,QString nom);
    /*!
    * \brief donne les informations du fichier
    * donne les informations du fichier represent&eacute; par l'itemHierarchie au moyen d'un QFileInfo
    */
    QFileInfo* getInfoFichier();
    /*!
    * \brief dit si l'item contient le fichier d'information info
    * retourne vrai si l'itemHierarchie a pour sous-item un itemHierarchie dont les informations fichier correcpondent a celle pass&eacute; en param&egrave;tre
    */
    bool contient(QFileInfo* info);
};

#endif // ITEMHIERARCHIE_H
