#include "validateurparser.h"
#include <iostream>
using namespace std;

ValidateurParser::ValidateurParser()
{
    fichier.setFileName("test.html");
    if(!fichier.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate))
        return ;
    sortie.setDevice(&fichier);

    QFileInfo truc(fichier);
    this->setNomFichier(truc.absoluteFilePath());
}


bool ValidateurParser::startDocument()
{
    sortie << "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" lang=\"fr\">" << "\n";
    sortie <<"<head>" << "\n";
    sortie << "<title>R&eacute;sultat du validateur</title>" << "\n";
    sortie << "<meta http-equiv=\"Content-Type\" content=\"text/html;charset=iso-8859-15\" />" << "\n";
    sortie << "<style type=\"text/css\">" << "\n";
    sortie << "table { margin-bottom : 30px; width : 100%; border : 2px solid black; border-collapse : collapse}" << "\n";
    sortie << "tr { text-align : center;border : 2px solid black;}" << "\n";
    sortie << "td, th { text-align : center;border : 2px solid black; width : 50%}" << "\n";
    sortie << "th { font-size : 16px;}" << "\n";
    sortie << "</style>" << "\n";
    sortie << "</head><body>" << "\n";
    return true;
}

bool ValidateurParser::endDocument()
{
    sortie << "</body></html>"<< "\n";
    fichier.close();
    return true;
}

bool ValidateurParser::startElement(const QString& namespaceUri, const QString& localName,
                                    const QString& qName, const QXmlAttributes& att)
{
    if(qName == "m:markupvalidationresponse")
    {
        sortie << "<div>"<< "\n";
    }
    else if(qName == "m:uri")
    {
        sortie << "<table>"<< "\n";
        sortie << "<tr>"<< "\n";
        sortie << "<th>"<< "\n";
    }
    else if(qName == "m:checkedby")
    {
        sortie << "<th> Valid&eacute; par :"<< "\n";
    }
    else if(qName == "m:doctype")
    {
        sortie << "<tr>"<< "\n";
        sortie << "<td> Doctype :"<< "\n";
    }
    else if(qName == "m:charset")
    {
        sortie << "<td> Charset utilis&eacute; :"<< "\n";
    }
    else if(qName == "m:validity")
    {
        sortie << "<tr>"<< "\n";
        sortie << "<td colspan=\"2\" style=\"background-color : #D2AAFF\"> Validit&eacute; :"<< "\n";
    }
    else if(qName == "m:errors")
    {
        sortie << "<table>"<< "\n";
    }
    else if(qName == "m:errorcount")
    {
        sortie << "<tr>"<< "\n";
        sortie << "<th colspan=\"2\"> Vous avez "<< "\n";
    }
    else if(qName == "m:error")
    {
        sortie << "<tr>"<< "\n";
    }
    else if(qName == "m:line")
    {
        sortie << "<td rowspan=\"3\"> ligne : "<< "\n";
    }
    else if(qName == "m:col")
    {
        sortie << ", colonne : "<< "\n";
    }
    else if(qName == "m:source")
    {
        sortie << "<tr>"<< "\n";
        sortie << "<td style=\"background-color :#FF9EB3;\">"<< "\n";
    }
    else if(qName == "m:explanation")
    {
        sortie << "<tr>"<< "\n";
        sortie << "<td>"<< "\n";
    }
    else if(qName == "m:message")
    {
        sortie << "<td>"<< "\n";
    }
    else if(qName == "m:warnings")
    {
        sortie << "<table>"<< "\n";
    }
    else if(qName == "m:warningcount")
    {
        sortie << "<tr>"<< "\n";
        sortie << "<th colspan=\"2\"> Vous avez "<< "\n";
    }
    else if(qName == "m:warning")
    {
        sortie << "<tr>"<< "\n";
    }
    else if(qName == "m:messageid")
    {
        sortie << "<span style=\"display:none;\">"<< "\n";
    }



    return true;
}


bool ValidateurParser::endElement(const QString& namespaceUri, const QString& localName,
                                    const QString& qName)
{
    if(qName == "m:markupvalidationresponse")
    {
        sortie << "</div>"<< "\n";
    }
    else if(qName == "m:uri")
    {
        sortie << "</th>"<< "\n";
    }
    else if(qName == "m:checkedby")
    {
        sortie << "</th>"<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:doctype")
    {
        sortie << "</td>"<< "\n";
    }
    else if(qName == "m:charset")
    {
        sortie << "</td>"<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:validity")
    {
        sortie << "</td>"<< "\n";
        sortie << "</tr>"<< "\n";
        sortie << "</table>"<< "\n";
    }
    else if(qName == "m:errors")
    {
        sortie << "</table>"<< "\n";
    }
    else if(qName == "m:errorcount")
    {
        sortie << " erreurs</th> "<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:error")
    {
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:col")
    {
        sortie << "</td>"<< "\n";
    }
    else if(qName == "m:source")
    {
        sortie << "</td>"<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:explanation")
    {
        sortie << "</td>"<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:message")
    {
        sortie << "</td>"<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:warnings")
    {
        sortie << "</table>"<< "\n";
    }
    else if(qName == "m:warningcount")
    {
        sortie << " warnings</th> "<< "\n";
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:warning")
    {
        sortie << "</tr>"<< "\n";
    }
    else if(qName == "m:messageid")
    {
        sortie << "</span>"<< "\n";
    }
    return true;
}

bool ValidateurParser::characters ( const QString & name )
{

    if(!name.isEmpty())
    {
        if(name == "false")
            sortie <<" <span style=\" color : red; font-weight : bold;\"> Non</span>"<<"\n";
        else if(name == "true")
            sortie <<" <span style=\" color : green; font-weight : bold;\"> Oui </span>"<<"\n";
        else
            sortie<<name<<"\n";
    }
    return true;
}

QString ValidateurParser::getNomFichier() { return nom_fichier;}
void ValidateurParser::setNomFichier(QString n) {nom_fichier = n;}
