#include "validation.h"
#include <QWidget>
#include <iostream>
using namespace std;

Validation::Validation(MainWindow* m)
{
    parent = m;
    requeteHTML = new QHttp;
    requeteCSS = new QHttp;
    connect(requeteHTML, SIGNAL(done(bool)), this, SLOT(finHTML(bool)));
    connect(requeteCSS, SIGNAL(done(bool)), this, SLOT(finCSS(bool)));
    fichier.setFileName("out.xml");


   /* connect(requeteCSS, SIGNAL(dataReadProgress(int, int)), this, SLOT(dataReadProgress(int, int)));
    connect(requeteCSS, SIGNAL(dataSendProgress(int, int)), this, SLOT(dataSendProgress(int, int)));
    connect(requeteCSS, SIGNAL(done(bool)), this, SLOT(done(bool)));
    connect(requeteCSS, SIGNAL(requestFinished(int, bool)), this, SLOT(requestFinished(int, bool)));
    connect(requeteCSS, SIGNAL(requestStarted(int)), this, SLOT(requestStarted(int)));
    connect(requeteCSS, SIGNAL(responseHeaderReceived(const QHttpResponseHeader &)), this, SLOT(responseHeaderReceived(const QHttpResponseHeader &)));
    connect(requeteCSS, SIGNAL(stateChanged(int)), this, SLOT(stateChanged(int)));*/
}



void Validation::lancerValidation(int mode)
{
    if(mode == 0)
    {

        if(fichier.fileName() != "out.xml")
            fichier.setFileName("out.xml");
        fichier.open(QIODevice::WriteOnly | QIODevice::Text);
        QByteArray bytes;

        QString nom_fichier = parent->getInterieurOnglet()->getInfoFichier()->fileName();
        if(nom_fichier.isEmpty())
            nom_fichier = "Temp";
        /*
           Debut de la requeteHTML
        */
        bytes.append("--AaB03x\r\n");
        bytes.append("Content-Disposition: form-data; name=\"uploaded_file\"; filename=\""+nom_fichier+"\"\r\n");
        bytes.append("\r\n");

        /*
           Contenu �  valider par w3c
        */

        bytes.append(parent->getInterieurOnglet()->getTextEdit()->toPlainText().toLatin1());
        bytes.append("\r\n");

        /*
           Demande de réponse sous forme xml
        */
        bytes.append("--AaB03x\r\n");
        bytes.append("Content-Disposition: form-data; name=\"output\"\r\n");
        bytes.append("\r\n");
        bytes.append("soap12\r\n");

        /*
          Fin de la requeteHTML
        */
        bytes.append("--AaB03x--\r\n");

        QHttpRequestHeader headerP("POST", "/check");
        headerP.setValue("Host", "validator.w3.org");
        headerP.setContentType("multipart/form-data, boundary=AaB03x");
        headerP.setContentLength(bytes.length());

        requeteHTML->setHost("validator.w3.org", 80);
        requeteHTML->request(headerP, bytes, &fichier);
    }
    else
    {
        fichier.setFileName("outCSS.xml");
        fichier.open(QIODevice::ReadWrite | QIODevice::Text);

        QByteArray bytes;
       // bytes.append("--AaB03x\r\n");
        //bytes.append("Content-Disposition: form-data; name=\"text\"\r\n");
       // bytes.append("\r\n");
        bytes.append("table");
        bytes.append("{");
        bytes.append("border-collapse:collapse;");
        bytes.append("}");

        QHttpRequestHeader headerP("POST", "/css-validator/validator");
        headerP.setValue("Host", "jigsaw.w3.org");
        headerP.setContentType("application/x-www-form-urlencoded");
        bytes =  QUrl::toPercentEncoding("text=" + bytes);


        requeteCSS->setHost("jigsaw.w3.org", 80);
        requeteCSS->request(headerP,bytes, &fichier);
    }

}

void Validation::finHTML(bool erreur)
{
    fichier.close();
    if(!erreur)
    {

        ValidateurParser validateur_parser;
        QXmlInputSource source( &fichier );
        QXmlSimpleReader lecteur;
        lecteur.setContentHandler( &validateur_parser );
        lecteur.parse( source );
        QString fic = validateur_parser.getNomFichier();
        parent->getWebBrowser()->ouvrirFichier(fic);
        parent->getWebBrowser()->show();
        fichier.close();
    }
    else
        ;
}

void Validation::finCSS(bool erreur)
{
    fichier.close();
    if(!erreur)
    {

        ValidateurParser validateur_parser;
        QXmlInputSource source( &fichier );
        QXmlSimpleReader lecteur;
        lecteur.setContentHandler( &validateur_parser );
        lecteur.parse( source );
        QString fic = validateur_parser.getNomFichier();
        parent->getWebBrowser()->ouvrirFichier(fic);
        parent->getWebBrowser()->show();
        fichier.close();
    }
    else
        ;
}

/*
void Validation::dataReadProgress(int done, int total)
{
        qDebug() << "read:" << done << "/" << total;
}

void Validation::dataSendProgress(int done, int total)
{
        qDebug() << "send:" << done << "/" << total;
}

void Validation::done(bool error)
{
        qDebug() << "done" << error;
}

void Validation::requestFinished(int id, bool error)
{
        qDebug() << "request finished:" << id << error;
        fichier.close();
}

void Validation::requestStarted(int id)
{
        qDebug() << "request started" << id;

}

void Validation::responseHeaderReceived(const QHttpResponseHeader &resp)
{
        qDebug() << "---response header---";
        qDebug() << resp.statusCode() << resp.reasonPhrase();
        foreach(QString key, resp.keys())
                qDebug() << key << resp.value(key);
        qDebug() << "--- ---";
}

void Validation::stateChanged(int state)
{
        qDebug() << "state:" << state;
}*/
