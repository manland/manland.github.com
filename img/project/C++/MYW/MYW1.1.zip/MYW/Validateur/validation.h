#ifndef VALIDATION_H
    #define VALIDATION_H

/*!
* \file validation.h
* \brief Classe principale de la Validation.
* \author Maillet Laurent
* \date 25/05/2009
*/

#include <QHttp>
#include <QFile>
#include <QWidget>
#include "editeur.h"
#include "mainwindow.h"
#include "validateurparser.h"

/*!
* \class Validation
* \brief Classe principale de la Validation.
*
* C'est la classe qui envoit une requête HTTP au W3c et lorsque la requête est terminé, alors elle lance un parsage sur le 
* fichier reçu, puis lance le fichier crée dans le webBrowser
*/

class Validation : public QWidget
{
    Q_OBJECT

    private :
        QHttp* requeteHTML;/*!< Requête HTTP pour les fichiers html*/
        QHttp* requeteCSS;/*!< Requête HTTP pour les fichiers css*/
        QFile fichier;/*!< Fichier recevant la réponse de la requête*/
        MainWindow* parent;/*!< Parent*/

    public slots :
        /*!
         *  \brief fonction appelé lors de la fin de la requête HTTP pour les fichiers html
         *
         *  Elle lance le parsage du fichier reçu puis ouvre le fichier crée dans le WebBrowser
         *
         *  \param bool b : vaut true si une erreur a été rencontré durant la requête, false sinon
         */
        void finHTML(bool b);
        /*!
         *  \brief fonction appelé lors de la fin de la requête HTTP pour les fichiers css
         *
         *  Elle lance le parsage du fichier reçu puis ouvre le fichier crée dans le WebBrowser
         *
         *  \param bool b : vaut true si une erreur a été rencontré durant la requête, false sinon
         */
        void finCSS(bool b);


        /*void dataReadProgress(int done, int total);
        void dataSendProgress(int done, int total);
        void done(bool error);
        void requestFinished(int id, bool error);
        void requestStarted(int id);
        void responseHeaderReceived(const QHttpResponseHeader &resp);
        void stateChanged(int state);*/

    public:

        /*!
         *  \brief Constructeur
         *
         *  Constructeur de la classe Validation, connecte les variables QHttp avec les slots correspondant
         *
         *  \param parent : parent de l'objet
         *
         */
        Validation(MainWindow * parent);

        /*!
         *  \brief Lance la requête HTTP pour la validation du document
         *
         *  Lance la requête sur le serveur correspondant au mode passer en paramètre
         *
         *  \param mode : type de requête à effectuer, css(1) ou html(0)
         *
         */
        void lancerValidation(int mode = 0);

};

#endif // VALIDATION_H
