#ifndef VALIDATEURPARSER_H
    #define VALIDATEURPARSER_H

/*!
* \file validateurparser.h
* \brief Classe parsant un fichier xml renvoyé par le w3c.
* \author Maillet Laurent
* \date 25/05/2009
*/

#include <QtXml>
#include <QString>
#include <QFile>
#include <QTextStream>

/*!
* \class ValidateurParser
* \brief Classe parsant un fichier xml renvoyé par le w3c.
*
* Elle reçoit des entités xml, les étudie et construit un fichier HTML en conséquence
*/

class ValidateurParser : public QXmlDefaultHandler
{
    private :
        QString nom_fichier;/*!< Chemin absolu du fichier en construction*/
        QFile fichier;/*!< fichier que l'on construit */
        QTextStream sortie;/*!< Flux pour écrire dans le fichier */
    public:

        /*!
         *  \brief Constructeur
         *
         *  Rentre les données de départ du fichier, lie le flux au fichier et récupère le chemin absolu du fichier
         */
        ValidateurParser();

        /*!
         *  \brief Appelé lors de l'ouverture du document XML à parser
         *
         *  Met un entête HTML dans le fichier
         *
         *  \return un booléen valant false si une erreur est rencontré, true sinon
         *
         */
        bool startDocument();

        /*!
         *  \brief Appelé lors de la fermeture du document XML à parser
         *
         *  Ferme les balises HTML ouverte dans startDocument()
         *
         *  \return un booléen valant false si une erreur est rencontré, true sinon
         *
         */
        bool endDocument();

        /*!
         *  \brief Appelé lors de la rencontre d'un élement XML ouvrant
         *
         *  Cherche l'element ouvert et insère le code HTML correspondant
         *
         *  \param QString n : uri retourné
         *  \param QString l : nom de la balise (si m:xx, renvoit xx)
         *  \param QString q : nom de la balise (si m:xx, renvoit m:xx)
         *  \param QXmlAttributes a : attribut XML
         *  \return un booléen valant false si une erreur est rencontré, true sinon
         */
        bool startElement(const QString& n, const QString& l, const QString& q, const QXmlAttributes& a);

        /*!
         *  \brief Appelé lors de la rencontre de caractères
         *
         *  Ecrit les caractères rencontrés dans le fichier
         *
         *  \param QString n : caracteres à afficher
         *  \return un booléen valant false si une erreur est rencontré, true sinon
         */
        bool characters(const QString & n);

        /*!
         *  \brief Appelé lors de la rencontre d'un élement XML fermant
         *
         *  Cherche l'element fermant et insère le code HTML correspondant
         *
         *  \param QString n : uri retourné
         *  \param QString l : nom de la balise (si m:xx, renvoit xx)
         *  \param QString q : nom de la balise (si m:xx, renvoit m:xx)
         *  \return un booléen valant false si une erreur est rencontré, true sinon
         */
        bool endElement(const QString&, const QString &, const QString&);

        /*!
         *  \brief Retourne le nom du fichier
         *
         *  \return le nom du fichier
         */
        QString getNomFichier();

        /*!
         *  \brief Change le nom du fichier
         *
         *  \param QString n :  le nom du fichier
         */
        void setNomFichier(QString n);
};

#endif // VALIDATEURPARSER_H
