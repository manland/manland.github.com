#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QToolBar>
#include <QtGui/QStatusBar>

#include <QPaintEvent>
#include <QPainter>
#include <QDockWidget>

#include <QTabWidget>
#include <QTextEdit>
#include <QRegExp>
#include <QRegExpValidator>

#include <iostream>
#include <QLineEdit>

#include <QList>
#include <QUrl>
#include <QFileDialog>
#include <QDesktopServices>
#include <QFileInfo>
#include <QFile>
#include <QTextStream>

#include <QCloseEvent>
#include <QMessageBox>
#include <QPushButton>
#include <QIcon>
#include <QObject>
#include <QIODevice>
#include <QPrintPreviewDialog>

#include "mesConfigs.h"
#include "widgetDansOnglet.h"
#include "widgetLigne.h"
#include "Hierarchie.h"
#include "Preferences.h"
#include "RechercherRemplacer/FindDialog.h" //PLUS
#include "FTPBrowser.h"

/*!
* \file MainWindow.h
* \brief Classe qui reimplante QMainWindow.
* \author FHAL Jonathan
* \date 25.05.2009
*/

class Validation;

using namespace std;

/*!
* \class MainWindow
* \brief Classe permettant d'intégrer toutes les modules du projet
* et gère l'interface comme le menu, la barre d'outils ...
*/
class MainWindow : public QMainWindow
{
    Q_OBJECT

private:
    // Principal
    QWidget *central_widget; /*!< classe contenant la partie centrale du projet: l'editeur*/
    QWidget *central_widget_haut;
    FindDialog *rechercher_remplacer; 
    QComboBox * cb;

    QMenuBar *menu_bar;
    QToolBar *tool_bar;
    QStatusBar *status_bar;
    Preferences *mes_preferences;
    WebBrowser * w;
    FTPBrowser * ftp;

    // Menu
    QMenu *menu_fichier;
    QMenu *menu_edition;
    QMenu *menu_affichage;
    QMenu *menu_outils;
    QMenu *menu_aide;
    QMenu *sous_menu_outil;

    // Actions Menu
    //-> Fichier
    QAction *action_menu_nouveau;
    QAction *action_menu_nouveau_projet;
    QAction *action_menu_ouvrir;
    QAction *action_menu_enregistrer;
    QAction *action_menu_enregistrer_sous;
    QAction *action_menu_enregistrer_tout;
    QAction *action_menu_imprimer;
    QAction *action_menu_quitter;
    //-> Edition
    QAction *action_menu_annuler;
    QAction *action_menu_retablir;
    QAction *action_menu_couper;
    QAction *action_menu_copier;
    QAction *action_menu_coller;
    QAction *action_menu_select_tout;
    QAction *action_menu_zoom_plus;
    QAction *action_menu_zoom_moins;
    QAction *action_menu_preferences;
    QAction *action_menu_rechercher_remplacer; //PLUS
	
    //-> Affichage
    QAction *action_menu_afficher_cacher_num_ligne;
    QAction *action_menu_plein_ecran;
        //SousMenuOutil
        QAction *action_menu_outil_fichier;
        QAction *action_menu_outil_edition;
                QAction *action_menu_outil_projet;

    // Toolbar Outils
    QToolBar *tool_fichier;
    QToolBar *tool_edition;
    QToolBar *tool_affichage;
    QToolBar *tool_aide;

    //Outils
    QAction *action_menu_web_browser;
    QAction *action_menu_ftp_browser;
    QAction *action_menu_validateur;

    //Aide
    QAction *action_menu_aide;

    // Dans centralWidget
    QTabWidget *tab_widget;
    WidgetDansOnglet *interieur_onglet; // contient qwidget(contient QLabel et QLabel) et QTextEdit

    // Docks
    QDockWidget *dock_projet;
    Hierarchie* hierarchie;

        // Dans statusBar
    QLabel *label_nb_lignes;
    QLabel *label_nb_caracteres;

    /*!
	* \brief Methode permettant de recuperer le chemin du workspace
	*/
    void restaurer();
    QPushButton * ok_workspace;
    QLineEdit * path_workspace;
    QString workspace;
    QFileDialog * chooseDir;
    QLineEdit * nouveau_projet;
   
    Validation * validation;


private slots:
    void workspaceChoisi();
    void fichierNouveauProjet();
    void fichierNouveauProjetOk();


public:
    // ACCESSEURS
	/*! \return le widget central */
    QWidget *getCentralWidget();
	/*! \return la barre de menu */
    QMenuBar *getMenuBar();
	/*! \return la barre d'outils */
    QToolBar *getToolBar();
	/*! \return la barre de status */
    QStatusBar *getStatusBar();
	 /*! \return l'onglet des preferences */
    Preferences *getMesPreferences();
	/*! \return le widget permetant de rechercher ou remplacer un mot */
    FindDialog* getRechercherRemplacer();
	/*! \return le Web Browser */
    WebBrowser* getWebBrowser();
	/*! \return le ftp browser */
    FTPBrowser* getFtpBrowser();

    // Menu
	/*! \return le menu nommé Fichier */
    QMenu *getMenuFichier();
	/*! \return le menu nommé Edition */
    QMenu *getMenuEdition();
	/*! \return le menu nommé Affichage */
    QMenu *getMenuAffichage();
	/*! \return le menu nommé Aide */
    QMenu *getMenuAide();
	/*! \return le sous menu nommé Outils */
    QMenu *getSousMenuOutil();

    // Actions Menu
    //-> Fichier
	/*! \return l'action Nouveau */
    QAction *getActionMenuNouveau();
	/*! \return l'action Ouvrir */
    QAction *getActionMenuOuvrir();
	/*! \return l'action Enregistrer */
    QAction *getActionMenuEnregistrer();
	/*! \return l'action EnregistrerSous */
    QAction *getActionMenuEnregistrerSous();
	/*! \return l'action EnregistrerTout */
    QAction *getActionMenuEnregistrerTout();
	/*! \return l'action Imprimer */
    QAction *getActionMenuImprimer();
	/*! \return l'action WebBrowser */
    QAction *getActionMenuWebBrowser();
	/*! \return l'action Quitter */
    QAction *getActionMenuQuitter();
    //-> Edition
	/*! \return l'action Annuler */
    QAction *getActionMenuAnnuler();
	/*! \return l'action Retablir */
    QAction *getActionMenuRetablir();
	/*! \return l'action Couper */
    QAction *getActionMenuCouper();
	/*! \return l'action Copier */
    QAction *getActionMenuCopier();
	/*! \return l'action Coller */
    QAction *getActionMenuColler();
	/*! \return l'action SelectionnerTout */
    QAction *getActionMenuSelectTout();
	/*! \return l'action Zoom Avant */
    QAction *getActionMenuZoomPlus();
	/*! \return l'action Zoom Arriere */
    QAction *getActionMenuZoomMoins();
	/*! \return l'action du menu des preferences */
    QAction *getActionMenuPreferences();
	/*! \return l'action de recherche et de remplacement */
    QAction *getActionMenuRechercherRemplacer(); //PLUS
	
    //-> Affichage
	/*! \return l'action afficher cacher les lignes */
    QAction *getActionMenuAfficherCacherNumLigne();
	/*! \return l'action de mise en plein ecran */
    QAction *getActionMenuPleinEcran();
        //SousMenuOutil
		/*! \return l'action du MenuOutilFichier */
        QAction *getActionMenuOutilFichier();
		/*! \return l'action MenuOutilEdition */
        QAction *getActionMenuOutilEdition();
			/*! \return l'action MenuOutilProjet */
            QAction *getActionMenuOutilProjet();

    // Outils
	/*! \return la barre d'outils fichier */
    QToolBar *getToolFichier();
	/*! \return la barre d'outils edition */
    QToolBar *getToolEdition();
	/*! \return la barre d'outils affichage */
    QToolBar *getToolAffichage();
	/*! \return la barre d'outils aide */
    QToolBar *getToolAide();

    // Dans centralWidget
	/*! \return le Widget contenant tous les onglets */
    QTabWidget *getTabWidget(int = -1);
	/*! \return le contenu de l'onglet courant: contient qwidget(contient QLabel et QLabel) et QTextEdit */
    WidgetDansOnglet *getInterieurOnglet();

    // Docks
	/*! \return le dockwidget contant l'arborescence du projet  en cours */
    QDockWidget *getDock_projet();
	/*! \return la hierarchie du workspace */
    Hierarchie* getHierarchie();
	
	// Dans statusBar
	/*! \return le label du nombre de ligne */
    QLabel *getLabel_nb_lignes();
	/*! \return le label du nombre de caracteres */
    QLabel *getLabel_nb_caracteres();

    // Methodes
	/*!
	*  \brief Constructeur
	*
	*  Constructeur de la classe MainWindow
	*
	*  \param parent : parent de l'objet
	*/
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
	/*!
	 *  \brief Gestion de la barre de menu
	 *  Ajoute les differents menu �  la barre de menu
	 *  puis l'affiche
	*/
    void gestionMenuBarre();
	/*!
	 *  \brief Gestion des menus
	 *  Creation de differents QMenu apparaissant dans la barre
	*/
    void gestionMenu();
	 /*!
         *  \brief Gestion de la Barre d'Outils
         *  Ajoute les differents menu �  la barre d'outils
    */
    void gestionBarreOutils();
	 /*!
         *  \brief Gestion des actions du menu
         *  Creation d'actions et de raccourcis claviers
    */
    void gestionMenuActions();
	/*!
         *  \brief Gestion Menu Item
         *  Associe une action a un item du menu
    */
    void gestionMenuItems();
	/*!
         *  \brief Gestion Barre d'Outils Item
         *  Associe une action a un item de la barre d'outils
    */
    void gestionBarreOutilsItems();
	/*!
         *  \brief Gestion des Onglets
         *  Permet de rendre les onglets déplaçables, fermables et modifie le contenu de la barre de status
    */
    void gestionOnglets();
	/*!
         *  \brief Gestion des Docks
         *  permet de dimensionner et ajouter des DockWidget
    */
    void gestionDocks();
	 /*!
         *  \brief Gestion de la barre de status
         *  Ajoute un widget permanent d'afficher le nombre de caracteres et
         *  le nombre de ligne pour chaque onglet
    */
    void gestionBarreStatus();
/*!
         *  \brief Gestion des la fermeture des onglets
         *  Si le contenu de l'onglet est vide alors pas d'enregistrement lors de la fermeture
         *  Sinon Si c'est un fichier importé alors il est enregistrer automatiquement
         *  Sinon on ouvre une fenetre pour choisir l'endroit de l'enregistrement

         *  \param QCloseEvent
    */
    void closeEvent(QCloseEvent * event);
	/*!
         *  \brief Message de fermeture
         *  Permet de choisir de fermer ou d'annuler la procédure

         *  \param QCloseEvent
    */
    void messageQuitter(QCloseEvent * event);
	  /*!
         *  \brief Message d'enregistrement
         *  Permet de choisir d'enregistrer le fichier ou d'annuler la procédure

         *  \param QCloseEvent
         *  \param QString nomFichier: nom du fichier que l'on enregistre
    */
    void messageEnregistrer(QCloseEvent * event, QString nomFichier);
	 /*!
         *  \brief Enregistrement
         *  Si le fichier existe alors il est écrasé
    */
    void enregistrer();
	  /*!
         *  \brief Enregistrer Sous
         *  Le fichier n'existe pas donc on choisit l'emplacement de l'enregistrement
    */
    void enregistrerSous();
	/*!
         *  \brief Enregistrer Tout
         *  Enregistre tout les fichiers ouverts
    */
    void enregistrerTout();
	/*!
         *  \brief ChangeNom
         *  Modifie le nom de l'onglet lors d'une ouverture ou d'un enregistrement de fichier

         * \param QString: nom que l'on veut donner �  l'onglet
    */
    void changeNom(QString);

    void ouvreFichier(QFileInfo*, bool=true);
    int ongletDejaOuvert(QFileInfo*);


    // Graphisme
    void paintEvent(QPaintEvent *event);

     /*!
         *  \brief widgetChoisirWorkspace
         *  Ouvre une fenetre qui permet de definir le workspace sur lequel on travail

         * \param QWidget: parent
         * \param bool
    */
    QWidget* widgetChoisirWorkspace(QWidget* = 0, bool = false);

public slots:
    // Fichiers
	 /*! \brief Cree un nouveau fichier */
    void fichierNouveau();
    void fichierNouveauOk();
    void setNouvellePage(int);
	/*! \brief Ouvre un fichier */
    void fichierOuvrir();
	/*! \brief Enregistre un fichier */
    void fichierEnregistrer();
	/*! \brief Enregistre un fichier �  un emplacement choisi par l'utilisateur */
    void fichierEnregistrerSous();
	/*! \brief Enregistre tous les fichiers ouverts */
    void fichierEnregistrerTout();
	/*! \brief Ouvre une fenetre affichant un aperçu avant impression */
    void fichierImprimer();


    // Editions
	/*! \brief Coupe le texte selectionner */
    void editionCouper();
	/*! \brief Copie le texte selectionner */
    void editionCopier();
	/*! \brief Colle le texte du presse-papier */
    void editionColler();
	/*! \brief Selectionne tout le texte contenu dans l'onglet courant */
    void editionSelectTout();
	/*! \brief Annule la derniere action */
    void editionAnnuler();
	/*! \brief Retablie une action */
    void editionRetablir();
	/*! \brief Permet de grossir la police de l'onglet courant */
    void editionZoomPlus();
	/*! \brief Permet de rappetissir la police de l'onglet courant */
    void editionZoomMoins();
	/*! \brief Permet d'ouvrir le panneau des preferences */
    void editionPreferences();
	/*! \brief Permet d'afficher ou cacher la barre de recherche */
    void editionRechercherRemplacer(); //PLUS

    // Affichage
	/*! \brief Permet d'afficher ou cacher le numeros de lignes */
    void affichageNumLigne();
	/*! \brief Permet de mettre ou d'enlever le plein ecran */
    void affichagePleinEcran();
	/*! \brief Permet d'afficher ou cacher la barre d'outils fichier */
    void affichageOutilFichier();
	/*! \brief Permet d'afficher ou cacher la barre d'outils edition */
    void affichageOutilEdition();
	/*! \brief Permet d'afficher ou cacher la barre d'outils projet */
    void affichageOutilProjet();

    //Outils
	/*! \brief Permet d'ouvrir le webBrowser */
    void outilsOuvrirWebBrowser();
	/*! \brief Permet d'ouvrir le ftpBrowser */
    void outilsOuvrirFtpBrowser();
/*! \brief Ferme un onglet
        *   \param int: place de l'onglet �  fermer
    */
    void fermerTab(int);
	/*! \brief Met �  jour le nombre de ligne dans la berre de status */
    void modifNbLignes();
	/*! \brief Modifie le nom de l'onglet */
    void modifNomTab();
	/*! \brief Modifie le les informations de la barre de status */
    void modifBarreStatus();
	/*! \brief Permet d'activer ou désactiver des fonctions lors d'un changement d'onglet courant
        *   \param int: place de l'onglet courant dans la TabWidget
    */
    void quandChangeOngletCourant(int);
	/*! \brief Choisi l'icone apparaissant dans l'onglet en fonction de l'extension du fichier
    *   \param QString: extension du fichier
    */
    QIcon choixIcone(QString);
	/*! \brief Impressioon du document courant
    *   \param QPrinter
    */
    void imprimerOk(QPrinter*);

	/*! \brief Sauvegarde les parametres dans les registres */
    void enregistrerSettings();
	/*! \brief Lance tous les modules dependant du workspace (projets, ftp...) */
    void constructeurApresWorkspace();

    void workspaceClavier(QString);
	/*! \brief Lance la validation du module internet */
    void outilsValidateur();
	/*! \brief Rend cliquable ou pas la Validation */
    void outilsValidateurOnOff(bool);

    void apropos();
};

#endif // MAINWINDOW_H
