#ifndef PREFERENCES_H
#define PREFERENCES_H

/*!
* \Preferences.h
* \brief Ce fichier contient tout ce qui est n&eacute;cessaire &agrave; la cr&eacute;ation de la fen&ecirc;tre d'option de l'&eacute;diteur
* \author Novak Audrey - Fhal Jonathan
* \date 12.03.2009
*/


#include <QTabWidget>
#include <QDialog>
#include <QDialogButtonBox>
#include "modifierLangage.h"
#include "choisirLangage.h"
#include "editionwidgetliste.h"
#include "changerColoration.h"
#include "modifCompleter.h"

class MainWindow;

    /*!
    * \class Preferences
    * \brief Classe contenant tout ce qui est n&eacute;cessaire &agrave; la cr&eacute;ation de la fen&ecirc;tre d'options de l'&eacute;diteur
    *
    * Cette classe rassemble dans un m&ecirc;me widget toutes les options disponibles dans notre logiciel.
    * En effet, elle est constitu&eacute;e de diff&eacute;rents onglets contenant chacun un widget, ainsi qu'un bouton
    * appliquer et un bouton quitter. Le bouton appliquer permet d'appliquer toutes les options en m&ecirc;me
    * temps pour chaque onglet d'&eacute;dition ouvert.
    */



class Preferences: public QDialog
{
    Q_OBJECT

    private:
        MainWindow *parent;                 /*< parent de Preferences */
        QTabWidget *tab_widget;             /*< onglet */
        ModifierLangage *langage;           /*< permettra de construire l'onglet modifierLangage */
        ChoisirLangage * choisir_langage;   /*< permettra de construire l'onglet choisirLangage */
        EditionWidgetListe *edition_widget_liste;
        ChangerColoration *changerCouleur;  /*< permettra de construire l'onglet changerCouleur */
        ModifCompleter * modif_completer;   /*< permettra de construire l'onglet gerant le completer */
        QPushButton* tout_appliquer;        /*< bouton tout appliquer qui appliquera toutes les modifications &agrave; tous les onglets */
        QPushButton* quitter;               /*< bouton permettant de quitter la fen&ecirc;tre Preferences */

    public:
/*!
* \brief Constructeur
*
* Constructeur de la classe Preference
*
* \param parent : le parent de la classe coloration est de type MainWindow
*/
        Preferences(MainWindow *parent);

/*!
* \brief Permet de connaitre le parent de la classe Preferences
*
* \return MainWindow le parent de Preferences
*/
        MainWindow* getParent();

/*!
* \brief Permet d'atteindre l'onglet courant
*
* \return QTabWidget : renvoie l'onglet courant de Preferences
*/
        QTabWidget *getTabWidget();

/*!
* \brief Permet d'atteindre ModifierLangage
*
* \return ModifierLangage : renvoie le widget modifierLangage
*/
        ModifierLangage *getLangage();

/*!
* \brief Permet d'atteindre le bouton tout_appliquer
*
* \return QPushButton : renvoie le bouton tout_appliquer */
        QPushButton *getTout_appliquer();

/*!
* \brief Permet d'atteindre le bouton quitter
*
* \return QPushButton : renvoie le bouton quitter
*/
        QPushButton *getQuitter();

/*!
* \brief Permet d'atteindre choisirLangage
*
* \return QTabWidget : renvoie le widget choisirLangage
*/
        ChoisirLangage *getChoisirLangage();

    public slots:
/*!
* \brief Slot permettant d'appliquer toutes les modifications effectu&eacute;es &agrave; tous les onglets ouverts
*
*/
        void toutAppliquer();

/*!
* \brief Slot permettant de mettre &agrave; jour les signets
*
*/
        void majListe();

/*!
* \brief Slot permettant d'appliquer une recoloration de tous les onglets ouverts,
* d&egrave;s que l'utilisateur aura appuyer sur tout_appliquer
* Fait appel au rehighlight de Coloration
*
*/
        void recolorer();
};
#endif // PREFERENCES_H
