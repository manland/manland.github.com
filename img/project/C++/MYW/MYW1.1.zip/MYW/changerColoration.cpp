#include <QString>
#include <QTextEdit>
#include <QWidget>
#include <QAction>
#include <QLabel>
#include <QPalette>
#include <QColor>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QActionGroup>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QHBoxLayout>
#include <QTextStream>
#include <iostream>
#include "modifierLangage.h"
#include "mesConfigs.h"
#include "Preferences.h"
#include <QTabWidget>
#include "widgetDansOnglet.h"
#include "mainwindow.h"
#include "coloration.h"
#include <QFrame>
#include <QColorDialog>
#include <QRgb>
#include "couleur.h"
using namespace std;

ChangerColoration::ChangerColoration(Coloration *colo,Preferences *parent) : QWidget(parent)
{
     this->parent = parent;
     QPushButton *appliquer=new QPushButton(tr("Appliquer"));
     QPushButton *reinitialiser=new QPushButton(tr("R�initialiser"));
     QGridLayout *grille= new QGridLayout(this);
     QHBoxLayout *hbox = new QHBoxLayout;


     construireBoitePhp();
     construireBoiteJavascript();
     construireBoiteCss();
     construireBoiteHtml();
     construireBoiteGeneral();

     hbox->addWidget(appliquer);
     hbox->addWidget(reinitialiser);

      grille->addWidget(groupe_php,1,0);
      grille->addWidget(groupe_javascript,1,1);
      grille->addWidget(groupe_css,2,0);
      grille->addWidget(groupe_html,3,0);
      grille->addWidget(groupe_general,2,1);
      grille->addLayout(hbox,3,1);
      grille->setSpacing(15);

      connect(appliquer,SIGNAL(clicked()),this,SLOT(validerChangerCouleur()));
      connect(reinitialiser,SIGNAL(clicked()),this,SLOT(reinitialiserFormats()));
      connect(appliquer,SIGNAL(clicked()),this,SLOT(recolorer()));

}

void ChangerColoration :: construireBoitePhp()
{
    // creation de la "boite" de choix de couleur pour le php :
      QVBoxLayout *vbox_php = new QVBoxLayout;
      groupe_php=new QGroupBox("Php");
      QHBoxLayout *hbox_php1 = new QHBoxLayout;
      QHBoxLayout *hbox_php2 = new QHBoxLayout;
      QHBoxLayout *hbox_php3 = new QHBoxLayout;
      QHBoxLayout *hbox_variables_php = new QHBoxLayout;

      QLabel *mots_cles_php1=new QLabel(tr("Mots cl�s php1 :"));
      QLabel *mots_cles_php2=new QLabel(tr("Mots cl�s php2 :"));
      QLabel *mots_cles_php3=new QLabel(tr("Mots cl�s php3 :"));
      QLabel *variables_php=new QLabel(tr("Variables :"));

      gras_php1 = new QPushButton(tr("G"));
      italique_php1 = new QPushButton(tr("I"));
      gras_php2 = new QPushButton(tr("G"));
      italique_php2 = new QPushButton(tr("I"));
      gras_php3 = new QPushButton(tr("G"));
      italique_php3 = new QPushButton(tr("I"));
      gras_php_variables = new QPushButton(tr("G"));
      italique_php_variables = new QPushButton(tr("I"));

      gras_php1->setFixedSize(20,20);
      italique_php1->setFixedSize(20,20);
      gras_php2->setFixedSize(20,20);
      italique_php2->setFixedSize(20,20);
      gras_php3->setFixedSize(20,20);
      italique_php3->setFixedSize(20,20);
      gras_php_variables->setFixedSize(20,20);
      italique_php_variables->setFixedSize(20,20);

      gras_php1->setCheckable(true);
      gras_php2->setCheckable(true);
      gras_php3->setCheckable(true);
      gras_php_variables->setCheckable(true);
      italique_php1->setCheckable(true);
      italique_php2->setCheckable(true);
      italique_php3->setCheckable(true);
      italique_php_variables->setCheckable(true);

      gras_php1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(1));
      gras_php2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(2));
      gras_php3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(3));
      gras_php_variables->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(4));

      italique_php1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(1));
         italique_php2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(2));
         italique_php3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(3));
         italique_php_variables->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(4));


      couleur_php1 = new Couleur(this, parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(1).foreground().color());
      couleur_php2 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(2).foreground().color());
      couleur_php3 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(3).foreground().color());
      couleur_variables_php = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(4).foreground().color());

      hbox_php1->addWidget(mots_cles_php1);
      hbox_php1->addWidget(couleur_php1);
      hbox_php1->addWidget(gras_php1);
      hbox_php1->addWidget(italique_php1);

      hbox_php2->addWidget(mots_cles_php2);
      hbox_php2->addWidget(couleur_php2);
      hbox_php2->addWidget(gras_php2);
      hbox_php2->addWidget(italique_php2);

      hbox_php3->addWidget(mots_cles_php3);
      hbox_php3->addWidget(couleur_php3);
      hbox_php3->addWidget(gras_php3);
      hbox_php3->addWidget(italique_php3);

      hbox_variables_php->addWidget(variables_php);
      hbox_variables_php->addWidget(couleur_variables_php);
      hbox_variables_php->addWidget(gras_php_variables);
      hbox_variables_php->addWidget(italique_php_variables);

      vbox_php->addLayout(hbox_php1);
      vbox_php->addLayout(hbox_php2);
      vbox_php->addLayout(hbox_php3);
      vbox_php->addLayout(hbox_variables_php);

//      hbox_php1->setContentsMargins(15,0,35,0);
   //   vbox->addLayout(vbox_php);
      groupe_php->setLayout(vbox_php);

//      connect(gras_php1,SIGNAL(clicked()),this,SLOT(validerChangerCouleur()));

}

void ChangerColoration :: construireBoiteJavascript()
{
    // creation de la "boite" de choix de couleur pour le javascript :
      groupe_javascript = new QGroupBox("Javascript");
      QVBoxLayout *vbox_javascript = new QVBoxLayout;
      QHBoxLayout *hbox_javascript1 = new QHBoxLayout;
      QHBoxLayout *hbox_javascript2 = new QHBoxLayout;
      QHBoxLayout *hbox_javascript3 = new QHBoxLayout;

      QLabel *mots_cles_javascript1=new QLabel(tr("Mots cl�s javascript1"));
      QLabel *mots_cles_javascript2=new QLabel(tr("Mots cl�s javascript2"));
      QLabel *mots_cles_javascript3=new QLabel(tr("Mots cl�s javascript3"));

      gras_javascript1 = new QPushButton(tr("G"));
      italique_javascript1 = new QPushButton(tr("I"));
      gras_javascript2 = new QPushButton(tr("G"));
      italique_javascript2 = new QPushButton(tr("I"));
      gras_javascript3 = new QPushButton(tr("G"));
      italique_javascript3 = new QPushButton(tr("I"));

      gras_javascript1->setFixedSize(20,20);
      italique_javascript1->setFixedSize(20,20);
      gras_javascript2->setFixedSize(20,20);
      italique_javascript2->setFixedSize(20,20);
      gras_javascript3->setFixedSize(20,20);
      italique_javascript3->setFixedSize(20,20);

      gras_javascript1->setCheckable(true);
      gras_javascript2->setCheckable(true);
      gras_javascript3->setCheckable(true);
      italique_javascript1->setCheckable(true);
      italique_javascript2->setCheckable(true);
      italique_javascript3->setCheckable(true);


       gras_javascript1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(5));
       gras_javascript2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(6));
       gras_javascript3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(7));

      italique_javascript1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(5));
      italique_javascript2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(6));
      italique_javascript3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(7));



      couleur_javascript1 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(5).foreground().color());
      couleur_javascript2 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(6).foreground().color());
      couleur_javascript3 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(7).foreground().color());

      hbox_javascript1->addWidget(mots_cles_javascript1);
      hbox_javascript1->addWidget(couleur_javascript1);
      hbox_javascript1->addWidget(gras_javascript1);
      hbox_javascript1->addWidget(italique_javascript1);

      hbox_javascript2->addWidget(mots_cles_javascript2);
      hbox_javascript2->addWidget(couleur_javascript2);
      hbox_javascript2->addWidget(gras_javascript2);
      hbox_javascript2->addWidget(italique_javascript2);

      hbox_javascript3->addWidget(mots_cles_javascript3);
      hbox_javascript3->addWidget(couleur_javascript3);
      hbox_javascript3->addWidget(gras_javascript3);
      hbox_javascript3->addWidget(italique_javascript3);

      vbox_javascript->addLayout(hbox_javascript1);
      vbox_javascript->addLayout(hbox_javascript2);
      vbox_javascript->addLayout(hbox_javascript3);

   //   vbox->addLayout(vbox_javascript);
      groupe_javascript->setLayout(vbox_javascript);
}

void ChangerColoration :: construireBoiteCss()
{
    // creation de la "boite" de choix de couleur pour le javascript :
      QVBoxLayout *vbox_css = new QVBoxLayout;
      groupe_css=new QGroupBox("Css");
      QHBoxLayout *hbox_css1 = new QHBoxLayout;
      QHBoxLayout *hbox_css2 = new QHBoxLayout;

      QLabel *mots_cles_css1=new QLabel(tr("Mots cl�s css1"));
      QLabel *mots_cles_css2=new QLabel(tr("Mots cl�s css2"));

      gras_css1 = new QPushButton(tr("G"));
      italique_css1 = new QPushButton(tr("I"));
      gras_css2 = new QPushButton(tr("G"));
      italique_css2 = new QPushButton(tr("I"));

      gras_css1->setFixedSize(20,20);
      italique_css1->setFixedSize(20,20);
      gras_css2->setFixedSize(20,20);
      italique_css2->setFixedSize(20,20);

      gras_css1->setCheckable(true);
      gras_css2->setCheckable(true);
      italique_css1->setCheckable(true);
      italique_css2->setCheckable(true);

      gras_css1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(8));
      gras_css2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(9));

      italique_css1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(8));
      italique_css2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(9));

      couleur_css1 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(8).foreground().color());
      couleur_css2 = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(9).foreground().color());

      hbox_css1->addWidget(mots_cles_css1);
      hbox_css1->addWidget(couleur_css1);
      hbox_css1->addWidget(gras_css1);
      hbox_css1->addWidget(italique_css1);

      hbox_css2->addWidget(mots_cles_css2);
      hbox_css2->addWidget(couleur_css2);
      hbox_css2->addWidget(gras_css2);
      hbox_css2->addWidget(italique_css2);

      vbox_css->addLayout(hbox_css1);
      vbox_css->addLayout(hbox_css2);

      //vbox->addLayout(vbox_css);
      groupe_css->setLayout(vbox_css);
}

void ChangerColoration::construireBoiteHtml()
{
// creation de la "boite" de choix de couleur pour le javascript :
      QVBoxLayout *vbox_html = new QVBoxLayout;
      groupe_html=new QGroupBox("Html");
      QHBoxLayout *hbox_html_mc = new QHBoxLayout;
      QHBoxLayout *hbox_html_att = new QHBoxLayout;

      QLabel *label_html_mc=new QLabel(tr("Mots cl�s html :"));
      QLabel *label_html_att=new QLabel(tr("Attributs :"));

      gras_html_mc = new QPushButton(tr("G"));
      italique_html_mc = new QPushButton(tr("I"));
      gras_html_att = new QPushButton(tr("G"));
      italique_html_att = new QPushButton(tr("I"));

      gras_html_mc->setFixedSize(20,20);
      italique_html_mc->setFixedSize(20,20);
      gras_html_att->setFixedSize(20,20);
      italique_html_att->setFixedSize(20,20);

      gras_html_mc->setCheckable(true);
      gras_html_att->setCheckable(true);
      italique_html_mc->setCheckable(true);
      italique_html_att->setCheckable(true);

     gras_html_mc->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(10));
     gras_html_att->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(11));

     italique_html_mc->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(10));
     italique_html_att->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(11));


      couleur_html_attributs = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(11).foreground().color());
      couleur_html_mot_cle = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(10).foreground().color());

      hbox_html_mc->addWidget(label_html_mc);
      hbox_html_mc->addWidget(couleur_html_mot_cle);
      hbox_html_mc->addWidget(gras_html_mc);
      hbox_html_mc->addWidget(italique_html_mc);

      hbox_html_att->addWidget(label_html_att);
      hbox_html_att->addWidget(couleur_html_attributs);
      hbox_html_att->addWidget(gras_html_att);
      hbox_html_att->addWidget(italique_html_att);

      vbox_html->addLayout(hbox_html_mc);
      vbox_html->addLayout(hbox_html_att);

      //vbox->addLayout(vbox_css);
      groupe_html->setLayout(vbox_html);
}

void ChangerColoration :: construireBoiteGeneral()
{
 // creation de la "boite" de choix de couleur pour le php :
      QVBoxLayout *vbox_general = new QVBoxLayout;
      groupe_general=new QGroupBox(tr("G�n�ral :"));
      QHBoxLayout *hbox_commentaire_simple = new QHBoxLayout;
      QHBoxLayout *hbox_commentaire_multiple = new QHBoxLayout;
      QHBoxLayout *hbox_quote = new QHBoxLayout;
      QHBoxLayout *hbox_fonction = new QHBoxLayout;
      QHBoxLayout *hbox_e_commercial = new QHBoxLayout;

      QLabel *comm_simple=new QLabel(tr("Commentaires simples :"));
      QLabel *comm_multiple=new QLabel(tr("Commentaires multiples :"));
      QLabel *label_quote=new QLabel(tr("Quotes :"));
      QLabel *label_fonction=new QLabel(tr("Fonction :"));
      QLabel *label_e_commercial=new QLabel(tr("& (� commercial):"));

      gras_comm_simple = new QPushButton(tr("G"));
      italique_comm_simple = new QPushButton(tr("I"));
      gras_comm_multi = new QPushButton(tr("G"));
      italique_comm_multi = new QPushButton(tr("I"));
      gras_quote = new QPushButton(tr("G"));
      italique_quote = new QPushButton(tr("I"));
      gras_fonction = new QPushButton(tr("G"));
      italique_fonction = new QPushButton(tr("I"));
      gras_e_commercial = new QPushButton(tr("G"));
      italique_e_commercial = new QPushButton(tr("I"));

      gras_comm_simple->setFixedSize(20,20);
      italique_comm_simple->setFixedSize(20,20);
      gras_comm_multi->setFixedSize(20,20);
      italique_comm_multi->setFixedSize(20,20);
      gras_quote->setFixedSize(20,20);
      italique_quote->setFixedSize(20,20);
      gras_fonction->setFixedSize(20,20);
      italique_fonction->setFixedSize(20,20);
      gras_e_commercial->setFixedSize(20,20);
      italique_e_commercial->setFixedSize(20,20);

      gras_comm_simple->setCheckable(true);
      gras_comm_multi->setCheckable(true);
      gras_quote->setCheckable(true);
      gras_fonction->setCheckable(true);
      gras_e_commercial->setCheckable(true);
      italique_comm_simple->setCheckable(true);
      italique_comm_multi->setCheckable(true);
      italique_quote->setCheckable(true);
      italique_fonction->setCheckable(true);
      italique_e_commercial->setCheckable(true);

      gras_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(12));
      gras_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(13));
      gras_e_commercial->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(14));
      gras_fonction->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(15));
      gras_quote->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(16));

      italique_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(12));
      italique_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(13));
      italique_e_commercial->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(14));
      italique_fonction->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(15));
      italique_quote->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(16));


      couleur_commentaire_simple = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(13).foreground().color());
      couleur_commentaire_multiple = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(12).foreground().color());
      couleur_quote = new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(16).foreground().color());
      couleur_fonction=new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(15).foreground().color());
      couleur_e_commercial=new Couleur(this,parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(14).foreground().color());


      hbox_commentaire_simple->addWidget(comm_simple);
      hbox_commentaire_simple->addWidget(couleur_commentaire_simple);
      hbox_commentaire_simple->addWidget(gras_comm_simple);
      hbox_commentaire_simple->addWidget(italique_comm_simple);

      hbox_commentaire_multiple->addWidget(comm_multiple);
      hbox_commentaire_multiple->addWidget(couleur_commentaire_multiple);
      hbox_commentaire_multiple->addWidget(gras_comm_multi);
      hbox_commentaire_multiple->addWidget(italique_comm_multi);

      hbox_quote->addWidget(label_quote);
      hbox_quote->addWidget(couleur_quote);
      hbox_quote->addWidget(gras_quote);
      hbox_quote->addWidget(italique_quote);

      hbox_fonction->addWidget(label_fonction);
      hbox_fonction->addWidget(couleur_fonction);
      hbox_fonction->addWidget(gras_fonction);
      hbox_fonction->addWidget(italique_fonction);

      hbox_e_commercial->addWidget(label_e_commercial);
      hbox_e_commercial->addWidget(couleur_e_commercial);
      hbox_e_commercial->addWidget(gras_e_commercial);
      hbox_e_commercial->addWidget(italique_e_commercial);

      vbox_general->addLayout(hbox_commentaire_simple);
      vbox_general->addLayout(hbox_commentaire_multiple);
      vbox_general->addLayout(hbox_quote);
      vbox_general->addLayout(hbox_fonction);
      vbox_general->addLayout(hbox_e_commercial);

//      hbox_php1->setContentsMargins(15,0,35,0);
   //   vbox->addLayout(vbox_php);
      groupe_general->setLayout(vbox_general);

}

void ChangerColoration :: validerChangerCouleur()
{
    for(int i=0;i<parent->getParent()->getTabWidget()->count();i++)
    {
        WidgetDansOnglet* interieurOnglet = dynamic_cast<WidgetDansOnglet*> (parent->getParent()->getTabWidget()->widget(i));
        if(interieurOnglet)
        {
              if(gras_php1->isChecked())
              {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp1(couleur_php1->getCouleur(),true,false);
                if(italique_php1->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp1(couleur_php1->getCouleur(),true,true);
                }
            }
            else if(gras_php1->isChecked() && italique_php1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp1(couleur_php1->getCouleur(),true,true);
            }
            else if(italique_php1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp1(couleur_php1->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp1(couleur_php1->getCouleur(),false,false);
            }
            if(gras_php2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp2(couleur_php2->getCouleur(),true,false);
                if(italique_php2->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp2(couleur_php2->getCouleur(),true,true);
                }
            }
            else if(gras_php2->isChecked() && italique_php1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp2(couleur_php2->getCouleur(),true,true);
            }
            else if(italique_php2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp2(couleur_php2->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp2(couleur_php3->getCouleur(),false,false);
            }
            if(gras_php3->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp3(couleur_php3->getCouleur(),true,false);
                if(italique_php3->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp3(couleur_php3->getCouleur(),true,true);
                }
            }
            else if(gras_php3->isChecked() && italique_php3->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp3(couleur_php3->getCouleur(),true,true);
            }
            else if(italique_php3->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp3(couleur_php3->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhp3(couleur_php3->getCouleur(),false,false);
            }
            if(gras_php_variables->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhpVariables(couleur_variables_php->getCouleur(),true,false);
                if(italique_php_variables->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatPhpVariables(couleur_variables_php->getCouleur(),true,true);
                }
            }
            else if(gras_php_variables->isChecked() && italique_php_variables->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhpVariables(couleur_variables_php->getCouleur(),true,true);
            }
            else if(italique_php_variables->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhpVariables(couleur_variables_php->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatPhpVariables(couleur_variables_php->getCouleur(),false,false);
            }
// changement pour html mots cl� et attribut:
            if(gras_html_mc->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatHtml(couleur_html_mot_cle->getCouleur(),true,false);
                if(italique_html_mc->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatHtml(couleur_html_mot_cle->getCouleur(),true,true);
                }
            }
            else if(gras_html_mc->isChecked() && italique_html_mc->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatHtml(couleur_html_mot_cle->getCouleur(),true,true);
            }
            else if(italique_html_mc->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatHtml(couleur_html_mot_cle->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatHtml(couleur_html_mot_cle->getCouleur(),false,false);
            }
            if(gras_html_att->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatAttributHtml(couleur_html_attributs->getCouleur(),true,false);
                if(italique_html_att->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatAttributHtml(couleur_html_attributs->getCouleur(),true,true);
                }
            }
            else if(gras_html_att->isChecked() && italique_html_att->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatAttributHtml(couleur_html_attributs->getCouleur(),true,true);
            }
            else if(italique_html_att->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatAttributHtml(couleur_html_attributs->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatAttributHtml(couleur_html_attributs->getCouleur(),false,false);
            }
            // cas javascript
            if(gras_javascript1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript1(couleur_javascript1->getCouleur(),true,false);
                if(italique_javascript1->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript1(couleur_javascript1->getCouleur(),true,true);
                }
            }
            else if(gras_javascript1->isChecked() && italique_javascript1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript1(couleur_javascript1->getCouleur(),true,true);
            }
            else if(italique_javascript1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript1(couleur_javascript1->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript1(couleur_javascript1->getCouleur(),false,false);
            }
            if(gras_javascript2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript2(couleur_javascript2->getCouleur(),true,false);
                if(italique_javascript2->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript2(couleur_javascript2->getCouleur(),true,true);
                }
            }
            else if(gras_javascript2->isChecked() && italique_javascript2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript2(couleur_javascript2->getCouleur(),true,true);
            }
            else if(italique_javascript2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript2(couleur_javascript2->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript2(couleur_javascript2->getCouleur(),false,false);
            }
            if(gras_javascript3->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript3(couleur_javascript3->getCouleur(),true,false);
                if(italique_javascript3->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript3(couleur_javascript3->getCouleur(),true,true);
                }
            }
            else if(gras_javascript3->isChecked() && italique_javascript3->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript3(couleur_javascript3->getCouleur(),true,true);
            }
            else if(italique_javascript3->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript3(couleur_javascript3->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatJavascript3(couleur_javascript3->getCouleur(),false,false);
            }
// changement de couleur pour css :
            if(gras_css1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss1(couleur_css1->getCouleur(),true,false);
                if(italique_css1->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatCss1(couleur_css1->getCouleur(),true,true);
                }
            }
            else if(gras_css1->isChecked() && italique_css1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss1(couleur_css1->getCouleur(),true,true);
            }
            else if(italique_css1->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss1(couleur_css1->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss1(couleur_css1->getCouleur(),false,false);
            }
             if(gras_css2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss2(couleur_css2->getCouleur(),true,false);
                if(italique_css2->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatCss2(couleur_css2->getCouleur(),true,true);
                }
            }
            else if(gras_css2->isChecked() && italique_css2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss2(couleur_css2->getCouleur(),true,true);
            }
            else if(italique_css2->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss2(couleur_css2->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCss2(couleur_css2->getCouleur(),false,false);
            }
            // cas commentaire commentaire multiple
            if(gras_comm_multi->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireMultiple(couleur_commentaire_multiple->getCouleur(),true,false);
                if(italique_comm_multi->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireMultiple(couleur_commentaire_multiple->getCouleur(),true,true);
                }
            }
            else if(gras_comm_multi->isChecked() && italique_comm_multi->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireMultiple(couleur_commentaire_multiple->getCouleur(),true,true);
            }
            else if(italique_comm_multi->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireMultiple(couleur_commentaire_multiple->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireMultiple(couleur_commentaire_multiple->getCouleur(),false,false);
            }
            // cas commentaire commentaire simple
            if(gras_comm_simple->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireSimple(couleur_commentaire_simple->getCouleur(),true,false);
                if(italique_comm_simple->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireSimple(couleur_commentaire_simple->getCouleur(),true,true);
                }
            }
            else if(gras_comm_simple->isChecked() && italique_comm_simple->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireSimple(couleur_commentaire_simple->getCouleur(),true,true);
            }
            else if(italique_comm_simple->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireSimple(couleur_commentaire_simple->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatCommentaireSimple(couleur_commentaire_simple->getCouleur(),false,false);
            }
            // cas quote
            if(gras_quote->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatQuote(couleur_quote->getCouleur(),true,false);
                if(italique_quote->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatQuote(couleur_quote->getCouleur(),true,true);
                }
            }
            else if(gras_quote->isChecked() && italique_quote->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatQuote(couleur_quote->getCouleur(),true,true);
            }
            else if(italique_quote->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatQuote(couleur_quote->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatQuote(couleur_quote->getCouleur(),false,false);
            }
            // cas fonction
            if(gras_fonction->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatFonction(couleur_fonction->getCouleur(),true,false);
                if(italique_fonction->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatFonction(couleur_fonction->getCouleur(),true,true);
                }
            }
            else if(gras_fonction->isChecked() && italique_fonction->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatFonction(couleur_fonction->getCouleur(),true,true);
            }
            else if(italique_fonction->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatFonction(couleur_fonction->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatFonction(couleur_fonction->getCouleur(),false,false);
            }
             // cas &
            if(gras_e_commercial->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatECommercial(couleur_e_commercial->getCouleur(),true,false);
                if(italique_e_commercial->isChecked())
                {
                    interieurOnglet->getTextEdit()->getColoration()->changerFormatECommercial(couleur_e_commercial->getCouleur(),true,true);
                }
            }
            else if(gras_e_commercial->isChecked() && italique_e_commercial->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatECommercial(couleur_e_commercial->getCouleur(),true,true);
            }
            else if(italique_e_commercial->isChecked())
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatECommercial(couleur_e_commercial->getCouleur(),false,true);
            }
            else
            {
                interieurOnglet->getTextEdit()->getColoration()->changerFormatECommercial(couleur_e_commercial->getCouleur(),false,false);
            }
        }
    }
    enregistrer();
}

void ChangerColoration :: reinitialiserFormats()
{
         parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->initialiserFormats();
         couleur_php1->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(1).foreground().color());
         couleur_php2->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(2).foreground().color());
         couleur_php3->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(3).foreground().color());
         couleur_variables_php->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(4).foreground().color());
         couleur_javascript1->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(5).foreground().color());
         couleur_javascript2->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(6).foreground().color());
         couleur_javascript3->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(7).foreground().color());
         couleur_css1->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(8).foreground().color());
         couleur_css2->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(9).foreground().color());
         couleur_html_mot_cle->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(10).foreground().color());
         couleur_html_attributs->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(11).foreground().color());
         couleur_commentaire_multiple->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(12).foreground().color());
         couleur_commentaire_simple->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(13).foreground().color());
         couleur_e_commercial->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(14).foreground().color());
         couleur_fonction->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(15).foreground().color());
         couleur_quote->setCouleur(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->getFormat(16).foreground().color());

         gras_php1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(1));
         gras_php2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(2));
         gras_php3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(3));
         gras_php_variables->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(4));
         gras_javascript1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(5));
         gras_javascript2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(6));
         gras_javascript3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(7));
         gras_css1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(8));
         gras_css2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(9));
         gras_html_mc->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(10));
         gras_html_att->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(11));
         gras_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(12));
         gras_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(13));
         gras_e_commercial->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(14));
         gras_fonction->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(15));
         gras_quote->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estGras(16));

         italique_php1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(1));
         italique_php2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(2));
         italique_php3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(3));
         italique_php_variables->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(4));
         italique_javascript1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(5));
         italique_javascript2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(6));
         italique_javascript3->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(7));
         italique_css1->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(8));
         italique_css2->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(9));
         italique_html_mc->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(10));
         italique_html_att->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(11));
         italique_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(12));
         italique_comm_multi->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(13));
         italique_e_commercial->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(14));
         italique_fonction->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(15));
         italique_quote->setChecked(parent->getParent()->getInterieurOnglet()->getTextEdit()->getColoration()->estItalique(16));

}


void ChangerColoration:: recolorer()
{
        for(int i=0;i<parent->getParent()->getTabWidget()->count();i++)
        {
             WidgetDansOnglet* interieurOnglet = dynamic_cast<WidgetDansOnglet*> (parent->getParent()->getTabWidget()->widget(i));
             if(interieurOnglet)
             {
                 interieurOnglet->getTextEdit()->getColoration()->rehighlight();
             }
        }
}

void ChangerColoration::enregistrer()
{
    QSettings settings("MYW", "Coloration");
    settings.beginGroup("php1");
        settings.setValue("couleurR", QVariant(couleur_php1->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_php1->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_php1->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_php1->isChecked()));
        settings.setValue("italique", QVariant(italique_php1->isChecked()));
    settings.endGroup();
    settings.beginGroup("php2");
        settings.setValue("couleurR", QVariant(couleur_php2->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_php2->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_php2->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_php2->isChecked()));
        settings.setValue("italique", QVariant(italique_php2->isChecked()));
    settings.endGroup();
    settings.beginGroup("php3");
        settings.setValue("couleurR", QVariant(couleur_php3->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_php3->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_php3->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_php3->isChecked()));
        settings.setValue("italique", QVariant(italique_php3->isChecked()));
    settings.endGroup();
    settings.beginGroup("php_variable");
        settings.setValue("couleurR", QVariant(couleur_variables_php->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_variables_php->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_variables_php->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_php_variables->isChecked()));
        settings.setValue("italique", QVariant(italique_php_variables->isChecked()));
    settings.endGroup();
        settings.beginGroup("javascript1");
        settings.setValue("couleurR", QVariant(couleur_javascript1->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_javascript1->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_javascript1->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_javascript1->isChecked()));
        settings.setValue("italique", QVariant(italique_javascript1->isChecked()));
    settings.endGroup();
    settings.beginGroup("javascript2");
        settings.setValue("couleurR", QVariant(couleur_javascript2->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_javascript2->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_javascript2->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_javascript2->isChecked()));
        settings.setValue("italique", QVariant(italique_javascript2->isChecked()));
    settings.endGroup();
    settings.beginGroup("javascript3");
        settings.setValue("couleurR", QVariant(couleur_javascript3->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_javascript3->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_javascript3->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_javascript3->isChecked()));
        settings.setValue("italique", QVariant(italique_javascript3->isChecked()));
    settings.endGroup();
     settings.beginGroup("css1");
        settings.setValue("couleurR", QVariant(couleur_css1->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_css1->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_css1->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_css1->isChecked()));
        settings.setValue("italique", QVariant(italique_css1->isChecked()));
    settings.endGroup();
    settings.beginGroup("css2");
        settings.setValue("couleurR", QVariant(couleur_css2->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_css2->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_css2->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_css2->isChecked()));
        settings.setValue("italique", QVariant(italique_css2->isChecked()));
    settings.endGroup();
         settings.beginGroup("html_balises");
        settings.setValue("couleurR", QVariant(couleur_html_mot_cle->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_html_mot_cle->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_html_mot_cle->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_html_mc->isChecked()));
        settings.setValue("italique", QVariant(italique_html_mc->isChecked()));
    settings.endGroup();
    settings.beginGroup("html_attributs");
        settings.setValue("couleurR", QVariant(couleur_html_attributs->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_html_attributs->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_html_attributs->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_html_att->isChecked()));
        settings.setValue("italique", QVariant(italique_html_att->isChecked()));
    settings.endGroup();
         settings.beginGroup("commentaire_simple");
        settings.setValue("couleurR", QVariant(couleur_commentaire_simple->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_commentaire_simple->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_commentaire_simple->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_comm_simple->isChecked()));
        settings.setValue("italique", QVariant(italique_comm_simple->isChecked()));
    settings.endGroup();
    settings.beginGroup("commentaire_multiple");
        settings.setValue("couleurR", QVariant(couleur_commentaire_multiple->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_commentaire_multiple->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_commentaire_multiple->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_comm_multi->isChecked()));
        settings.setValue("italique", QVariant(italique_comm_multi->isChecked()));
    settings.endGroup();
    settings.beginGroup("quote");
        settings.setValue("couleurR", QVariant(couleur_quote->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_quote->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_quote->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_quote->isChecked()));
        settings.setValue("italique", QVariant(italique_quote->isChecked()));
    settings.endGroup();
    settings.beginGroup("fonction");
        settings.setValue("couleurR", QVariant(couleur_fonction->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_fonction->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_fonction->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_fonction->isChecked()));
        settings.setValue("italique", QVariant(italique_fonction->isChecked()));
    settings.endGroup();
     settings.beginGroup("e_commercial");
        settings.setValue("couleurR", QVariant(couleur_e_commercial->getCouleur().red()));
        settings.setValue("couleurG", QVariant(couleur_e_commercial->getCouleur().green()));
        settings.setValue("couleurB", QVariant(couleur_e_commercial->getCouleur().blue()));
        settings.setValue("gras", QVariant(gras_e_commercial->isChecked()));
        settings.setValue("italique", QVariant(italique_e_commercial->isChecked()));
    settings.endGroup();


    settings.sync();//permet de synchroniser le qsetting
}


