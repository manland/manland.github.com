#include "Preferences.h"
#include "mainwindow.h"

Preferences::Preferences(MainWindow *par): QDialog(par, Qt::Dialog)
{
    parent = par;
    langage = new ModifierLangage(parent->getInterieurOnglet()->getTextEdit()->getColoration(),this);
    choisir_langage = new ChoisirLangage(parent->getInterieurOnglet()->getTextEdit()->getColoration(),this);
    changerCouleur = new ChangerColoration(parent->getInterieurOnglet()->getTextEdit()->getColoration(),this);//Modifier par Audrey
    modif_completer = new ModifCompleter(parent->getInterieurOnglet()->getTextEdit()->getCompleter(), this);
    tab_widget = new QTabWidget();
    edition_widget_liste = new EditionWidgetListe();
// ----------------------------Modifier par m@n-POUR WORKSAPCE-----------------------------
    tab_widget->addTab(par->widgetChoisirWorkspace(this, true), "Workspace");
// ----------------------------Modifier par m@n-POUR WORKSAPCE--FIN---------------------------
    tab_widget->addTab(langage, tr("Langages"));
    tab_widget->addTab(choisir_langage, tr("Choisir type coloration"));//Modifier par Audrey
    tab_widget->addTab(changerCouleur, tr("Changer couleur"));
    tab_widget->addTab(edition_widget_liste, tr("Signets"));
    tab_widget->addTab(modif_completer, trUtf8("Auto-complétion"));
    this->setGeometry(500, 300, langage->width(), langage->height());
    this->setMinimumSize(370, 300);

    tout_appliquer = new QPushButton(tr("Tout Appliquer"));
    quitter = new QPushButton(tr("Quitter"));

    connect(tout_appliquer, SIGNAL(clicked()), this, SLOT(toutAppliquer()));
// ----------------------------Modifier par Audrey------------------------------
    connect(tout_appliquer,SIGNAL(clicked()),this,SLOT(recolorer()));
// ----------------------------Modifier par Audrey fin------------------------------
    connect(quitter, SIGNAL(clicked()), this, SLOT(close()));

    QHBoxLayout *mainLayout2 = new QHBoxLayout;
    mainLayout2->addWidget(tout_appliquer);
    mainLayout2->addWidget(quitter);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(tab_widget);
    mainLayout->addLayout(mainLayout2);
    setLayout(mainLayout);


 }

// Accesseurs
MainWindow* Preferences::getParent() { return parent; }
QTabWidget* Preferences::getTabWidget() { return tab_widget; }
ModifierLangage* Preferences::getLangage() { return langage; }
QPushButton* Preferences::getTout_appliquer() { return tout_appliquer; }
QPushButton* Preferences::getQuitter() { return quitter; }

// Slot
void Preferences::toutAppliquer() {
    this->getLangage()->validerModifierLangage();
//    this->choisir_langage->validerChoisirLangage();
    this->hide();
    this->majListe();
    changerCouleur->validerChangerCouleur();
// ----------------------------Modifier par m@n-POUR WORKSAPCE-----------------------------
    parent->enregistrerSettings();
    parent->constructeurApresWorkspace();
// ----------------------------Modifier par m@n-POUR WORKSAPCE--FIN---------------------------
}

void Preferences::majListe()
{
    for(int i=0; i<this->getParent()->getTabWidget()->count(); i++)
    {
        WidgetDansOnglet * t = dynamic_cast<WidgetDansOnglet*> (this->getParent()->getTabWidget()->widget(i));
        if(t)
            t->getMaWidgetLigne()->miseAJourWidgetListe();
    }
}

// ----------------------------Modifier par Audrey------------------------------
ChoisirLangage* Preferences:: getChoisirLangage()
{
    return choisir_langage;
}

void Preferences:: recolorer()
{
   choisir_langage->recolorer();
}
// ----------------------------Modifier par Audrey fin------------------------------
