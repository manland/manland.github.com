#ifndef WIDGETLIGNE_H
    #define WIDGETLIGNE_H
/*!
* \file widgetLigne.h
* \brief Classe du module Editeur.
* \author Maillet Laurent
* \date 16/05/2009
*/

#include <QPainter>
#include <QPaintEvent>
#include <QPixmap>
#include <QMenu>
#include <QAction>
#include <QIcon>

#include <QTextEdit>
#include <QTextBlock>
#include <QTextLayout>
#include <QList>

#include <QScrollBar>
#include <QApplication>
#include <iostream>
#include <QMouseEvent>
using namespace std;

#include "editeur.h"
#include "Entete.h"

/*!
* \class WidgetLigne
* \brief Classe du module Editeur.
*
*   C'est la classe g�rant l'affichage du num�ro des lignes et des signets sur le c�t�
*   gauche de l'�diteur
*
*   Elle r�cup�re le nombre de lignes du fichier et peut ainsi en d�duire la taille n�cesaire
*   pour la widget
*
*   Lorsqu'un clic survient sur la widget, un calcul survient pour d�couvrir sur quel ligne l'�v�nement a eu lieu :
*   _ si c'est un clic gauche , on affiche le premier signet
*   _ si c'est un clic droit, un affiche le signet suivant
*   _ si c'est un clic central on affiche un menu avec l'ensemble des signets, un lien vers l'ouverture des pr�f�rences ainsi que le choix d'inverser l'affichage des lignes et des signets.
*
*
*/

class WidgetLigne : public QWidget
{

    Q_OBJECT

    public:
        /*!
         *  \brief Constructeur
         *
         *  Constructeur de la classe WidgetLigne
         *
         *  \param p : Editeur li� � la WidgetLigne
         *
         */
        WidgetLigne(Editeur* p);
        /*!
         *  \brief Taille de la WidgetLigne
         *
         *  Rend la WidgetLigne � la m�me taille que l' Editeur auquel elle est li�
         *
         *  \param e : contient les donn�es relatifs aux �v�nements agissant sur la taille
         *
         */
        virtual void resizeEvent(QResizeEvent* e);
        /*!
         *  \brief R�cup�re un signet
         *
         *  \param i : le num�ro du signet � r�cup�rer dans la liste des signets
         *  \return la liste existe ou NULL
         *
         */
        WidgetListe* getListe(int i);
        /*!
         *  \brief Enl�ve une ligne � un signet
         *
         *  Enl�ve la ligne courante(sur laquelle on a cliqu�) de la widgetliste au num�ro pass� en param�tre
         *
         *  \param i : num�ro de la liste dans laquelle on retire la ligne courante
         *  \return 1 si tout s'est bien pass�, -1 sinon
         *
         */
        int enleveLigne(int i);
        /*!
         *  \brief Ajoute une ligne ou l'enl�ve d'un signet si elle existe deja
         *
         *  Si la ligne courante est contenu dans la widgetliste dont le num�ro est pass� en parm�tre alors on la supprime sinon on l'y ajoute
         *  M�me op�ration si le num�ro de la liste n'est pas connu sauf que tout s epasse dans la premi�re widgetliste
         *
         *  \param i : num�ro de la widgetliste dans laquelle on ajoute ou retire la ligne courante
         *  \return 1 si un ajout a eu lieu, 0 pour une suppression et -1 sinon
         *
         */
        int ajoutLigne(int i=-1);
        /*!
         *  \brief Ajoute un signet dans la liste des signets
         *
         *  \param w : ajout une widgetListe deja cr�ee
         */
        void ajoutWidgetListe(WidgetListe* w);
        /*!
         *  \brief Ajoute un signet dans la liste des signets
         *
         *  Cr�e un signet � partir des param�tres et l'ajoute dans la liste des signets
         *
         *  \param a : action li� au signet
         *  \param t : nom du signet
         *  \param i : chemin de l'image du signet
         */
        void ajoutWidgetListe(QAction* a, QString t, QString i);
        void afficheListe(int);
        /*!
         *  \brief Retourne le num�ro du signet contenant la ligne courante
         *
         *  \return le num�ro du signet contenant la ligne courante
         */
        int listeContientLigne();
        /*!
         *  \brief Change la liste contenant la ligne courante
         *
         *  Si il n'y a qu'un signet, alors on ajoute la ligne courante a ce signet
         *  Si le signet est le dernier de la liste on l'enl�ve de cette liste
         *  Sinon on ins�re le signet dans la liste suivant le num�ro de la liste pass� en param�tre et on l'enl�ve de cette derni�re
         *
         *  \param i: le num�ro du signet contenant la ligne courante
         */
        void incrementeListe(int i);
        /*!
         *  \brief R�cup�ration des signets
         *
         *  R�cup�re les signets contenu sur l'ordinateur de l'utilisateur et les ajoute dans la liste des signets
         */
        void chargement();
        /*!
         *  \brief Taille du widgetLigne
         *
         *  Calcul la taille n�cessaire en largeur pour le widgetLigne et impose la marge en cons�quence pour l' Editeur reli� � la widgetLigne
         */
        void miseAJourMargin();
        /*!
         *  \brief Mise � jour de la liste des signets
         *
         *  Lorsque l'utilisateur a modifi� ces signets, on v�rifie qu'il n'a pas supprim� des signets existant, si c'est le cas on les supprime
         *  de la liste des signets et on ajoute les signets qu'il a cr�e.
         *
         */
        void miseAJourWidgetListe();
        /*!
         *  \brief V�rifie l'existence d'un WidgetListe
         *
         *  V�rifie l'existence de la liste ayant pour nom et chemin de l'image les donn�es pass�es en param�tre
         *  Si on a une correspondance, on renvoit la WidgetListe
         *
         *  \param t : nom du signet
         *  \param c : chemin de l'image du signet
         *  \return la liste si elle existe, NULL sinon
         */
        WidgetListe* existeListe(QString t , QString c);
        /*!
         *  \brief Enl�ve un WidgetListe de la liste des signets
         *
         * Supprime le widgetListe pass� en param�tre de la liste des signets
         *
         *  \param w : WidgetListe � supprimer
         */
        void enleveWidgetListe(WidgetListe* w);

        /*!
         *  \brief Modifie les valeurs des lignes dans les listes
         *
         * Change la valeur des lignes contenue dans chaque liste de fichier en y ajoutant la diff�rence pour toutes les lignes sup�rieures � start
         *
         *  \param debut : lignes � partir de laquelle on ajoute la diff�rence
         *  \param difference : valeur � ajouter aux lignes
         */
        void incrementeLigneListe(int debut,int difference);

    protected:
        /*!
         *  \brief fonction appel�e pour afficher les num�ros de ligne et les signets, ref�finition de QWidget::paintEvent
         *
         *  On parcourt le document � la recherche de la bonne ligne � afficher
         *  On parcourt le document block par block, on compare la position des block et de la scrollBar
         *  Une fois trouv� la ligne correspondante on a juste � afficher le num�ro de la ligne
         *  Pour la ligne dont on affiche le num�ro on v�rifie si elle est contenu dans un signet,
         *  Si c'est le cas on affiche l'image du signet correpondant
         *
         *  \param QPaintEvent* e : contient les param�tres d�crivant le style � appliquer
         */
        virtual void paintEvent(QPaintEvent*);
        /*!
         *  \brief fonction appel�e au clic de la souris, ref�finition de QWidget::mousePressEvent
         *
         *   Lorsqu'un clic survient sur la widget, un calcul survient pour d�couvrir sur quel ligne l'�v�nement a eu lieu :
         *   _ si c'est un clic gauche , on affiche le premier signet
         *   _ si c'est un clic droit, un affiche le signet suivant
         *   _ si c'est un clic central on affiche un menu avec l'ensemble des signets, un lien vers l'ouverture des pr�f�rences ainsi que le choix d'inverser l'affichage des lignes et des signets.
         *
         *
         *  \param QMouseEvent* e : contient les param�tres d�crivant l'�v�nement de la souris
         */
        virtual void mousePressEvent(QMouseEvent*);

    private:
        Editeur *editeur_texte;  /*!< Editeur reli� � la widgetLigne*/
        QPixmap* mon_image;
        int numero_premiere_ligne;/*!< R�cup�re le num�ro de la premi�re ligne visible*/
        QRectF rectangle; /*!< rectanle li� � la ligne courante de Editeur*/
        QPointF position_layout; /*!< point en haut � gauche du rectangle*/
        int vertical_scroll_bar_value; /*!< position de la scrollBar vertical de Editeur*/
        int ligne_courante; /*!< Ligne sur laquelle on vient de cliquer*/
        QList<WidgetListe*> ma_liste; /*!< liste de signets*/
        int taille_image; /*!< taille de l'image des signets, elle se modifie avec les zoom*/
        bool ligne_a_droite; /*!< ordre dans lequel on affiche les lignes et les signets, si c'est vrai on affiche les signets � gauche et les ligne a droite, on fait l'inverse sinon*/

    public slots:
        /*!
         *  \brief Choix de l'action � realiser
         *
         *  Fonction permettant de savoir quel ation du menu ouvert par le clic central de la souris a �t� activ� :
         *  _ soit c'est l'inversement des positions entre les lignes et les signets
         *  _ soit on ajoute une ligne � l'action reli� au signet
         *
         *  \param w : WidgetListe � supprimer
         */
        void cliqueMenu(QAction*);
        /*!
         *  \brief Mise a jour des listes de lignes des signets
         *
         *  Suppression des lignes  dans la liste des lignes des signet �tant apr�s la derni�re ligne du document
         *
         */
        void miseAJourListe();
};

#endif
