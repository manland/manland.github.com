#ifndef FRAMEAIDE_H
    #define FRAMEAIDE_H
/*!
* \file frameaide.h
* \brief Classe du module Editeur.
* \author Maillet Laurent
* \date 16/05/2009
*/

#include <QLabel>
#include <QWidget>
#include <QPaintEvent>
#include <QPainter>

/*!
* \class FrameAide
* \brief Classe du module Editeur.
*
* C'est la classe permettant l'affichage d'une sorte de bulle d'aide lorsqu'un
* mot de Editeur est reconnu comme un mot-clef d'un langage
*
*
*/

class FrameAide : public QLabel
{
    public:
        /*!
         *  \brief Constructeur
         *
         *  Constructeur de la classe FrameAide
         *
         *  \param parent : parent de l'objet
         *  \param s = Texte � afficher
         *
         */
        FrameAide(QString s, QWidget* parent = 0);
    private :
        QWidget* parent; /*!< parent de FrameAide*/
    protected :
        /*!
         *  \brief fonction appel�e pour dessiner la FrameAide, ref�finition de QLabel::paintEvent
         *
         *  Elle permet de donner le style � la FrameAide, les couleurs, les bordures, etc.
         *
         *  \param QPaintEvent* e : contient les param�tres d�crivant le style � appliquer
         */
        void paintEvent(QPaintEvent*);
};

#endif // FRAMEAIDE_H
