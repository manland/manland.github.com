#ifndef COMPLETER_H
#define COMPLETER_H

/*!
* \file completer.h
* \brief Classe responsable de l'auto-completion.
* \author Sauvan William
* \date 01.03.2009
*/

#include <QCompleter>
#include <QKeyEvent>
#include <QStringList>
#include <QFile>

#include "erreur.h"

class QAbstractItemModel;
class QComboBox;
class QCompleter;
class QLabel;
class QLineEdit;
class QProgressBar;
class QTextEdit;

using namespace std;

class Editeur;

/*!
* \class completer
* \brief Classe responsable de l'auto-completion.
*
* Rattacher cette classe &agrave; un QTextEdit lors de sa d&eacute;claration par un : completer = new Completer(parent);
* Penser &agrave; activer le completer sur le KeyPressEvent via : completer->activeComplete(evenement);
* Il faut aussi ignorer les touches qui ne doivent pas &eacute;crire quand la fen&ecirc;tre du completer est visible.
* Ainsi que les touches de raccourci.
*
*
*/

class Completer : public virtual QCompleter
{
    Q_OBJECT

private:

        Erreur erreur;/*!< Pour afficher les erreurs dans un fichier texte*/

        Editeur * parent;/*!< L'&eacute;diteur auquel est li&eacute; le completer*/
        QStringList words;/*!< La liste de mot pr&eacute;d&eacute;fini du completer*/
        QString chemin_fichier_variables;/*!< Le chemin du fichier stockant les noms de variables/fonction*/
        QString ancien_mot;/*!< Le mot se trouvant avant le mot courant*/

        int nb_lettre;/*!< Le nombre de caractere d&eacute;clenchant le completer*/
        bool completer_actif;/*!< Pour activer ou non le completer*/

        /*!
        * \brief Remet &agrave; jour la liste de mot du completer selon le langage actuel
        */
        void majListeVariables();

        /*!
        * \brief D&eacute;fini le mod&egrave;le du completer depuis words et le fichier de variable
        *
        * \return Un mod&egrave;le de completion de type valide pour le completer
        */
        QAbstractItemModel *modelFromFile();

public slots :

        /*!
        * \brief Ins&egrave;re le mot entier
        * \param completion : QString le mot entier &agrave; ins&eacute;rer
        */
        void insertCompletion(const QString &completion);

public :

        /*!
        * \brief Accesseur. R&eacute;cup&egrave;re la liste des mots propos&eacute;s du completer
        */
        QStringList getWords() const;

        /*!
        * \brief Constructeur
        *
        * Constructeur de la classe completer
        *
        * \param parent : Editeur le text edit p&egrave;re
        */
        Completer(Editeur* parent);

        /*!
        * \brief Destructeur
        *
        * Le destructeur ne fait rien
        */
        ~Completer();

        /*!
        * \brief Remet la liste de mot propos&eacute; du completer &agrave; jour selon le langage actuel programm&eacute;
        */
        void mettreAJourListe();

        /*!
        * \brief Fonction v&eacute;rifiant si le mot tap&eacute; est une variable/fonction
        *
        * Cherche les mots pr&eacute;c&eacute;dent pour voir si une variable/fonction &agrave; &eacute;t&eacute; d&eacute;clar&eacute;e et remplis ancien_mot en fonction
        */
        void verifVariable();

        /*!
        * \brief Fonction principale
        *
        * Fonction r&eacute;agissant &agrave; chaque touche du clavier
        *
        * \param e : Ev&egrave;nement du clavier
        */
        void activeComplete(QKeyEvent *e);

        /*!
        * \brief R&eacute;cup&egrave;re le mot courant via la classe coloration car elle le poss&egrave;de d&eacute;j&agrave;
        *
        * \return le mot situ&eacute; sous le curseur
        */
        QString textUnderCursor() const;

        /*!
        * \brief Donne directement une liste au completer
        *
        * \param nouvelle_liste : QStringList la liste de mot que l'on veut mettre pour la completion
        */
        void setListeDeCompletion(QStringList nouvelle_liste);

        /*!
        * \brief D&eacute;fini le mot pr&eacute;c&eacute;dent
        *
        * Permet &agrave; l'&eacute;diteur de d&eacute;finir l'ancien mot pour savoir s'il faut conserver un nom de variable/fonction
        *
        * \param parent : Editeur le text edit p&egrave;re
        */
        void setAncienMot(QString mot);

        /*!
        * \brief D&eacute;fini le nombre de caract&egrave;re d&eacute;clenchant le completer
        *
        * \param nb : int le nombre de carac
        */
        void setNbLettre(int nb);

        /*!
        * \brief D&eacute;fini si le completer se d&eacute;clenche
        *
        * \param actif : bool l'&eacute;tat du completer
        */
        void setActif(bool actif);

        /*!
        * \brief Ajoute une liste &agrave; la liste d&eacute;j&agrave; pr&eacute;sente
        *
        * Agrandit la liste de liste ajout
        *
        * \param liste_ajout : QStringList la liste que l'on rajoute en plus de celle d&eacute;j&agrave; pr&eacute;sente
        */
        void ajouteListeCompletion(QStringList liste_ajout);

        /*!
        * \brief Ajoute un mot de completion
        *
        * Ajoute un mot simple &agrave; la liste de mot d&eacute;j&agrave; pr&eacute;sente
        *
        * \param mot_ajout : QString Le mot que l'on veut ajouter
        */
        void ajouteMotCompletion(QString mot_ajout);

        /*!
        * \brief Ajoute un nom de variable/fonction &agrave; stocker
        *
        * Ajoute le nom de variable/fonction pass&eacute; en param&egrave;tre &agrave; la liste de completion et au fichier texte contenant tous les noms
        *
        * \param var_ajout : QString le nom &agrave; ajouter
        */
        void ajouteVariable(QString var_ajout);

};

#endif

