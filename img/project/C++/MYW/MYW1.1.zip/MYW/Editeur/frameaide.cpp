#include "frameaide.h"
#include <iostream>
using namespace std;

FrameAide::FrameAide(QString texte, QWidget* parent) : QLabel(texte,parent)
{
    this->parent = parent;
    setFrameStyle(QFrame::StyledPanel | QFrame::Plain);
    this->show();
}

void FrameAide::paintEvent(QPaintEvent * e)
{
    QPainter painter(this);
    QLinearGradient gradient(0, 0, this->sizeHint().width(), this->sizeHint().height());
    gradient.setColorAt(0.0, Qt::darkGray);
    gradient.setColorAt(0.3, Qt::lightGray);
    gradient.setColorAt(0.7, Qt::lightGray);
    gradient.setColorAt(1.0, Qt::darkGray);
    painter.setPen(QColor(0,0,0,255));
    painter.setBrush(gradient);
    painter.drawRect(0, 0, this->width(), this->height());
    painter.end();
    QLabel::paintEvent(e);
}
