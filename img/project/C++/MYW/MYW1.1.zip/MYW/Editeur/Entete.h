#ifndef ENTETE_H
    #define ENTETE_H
#include <QAction>
#include <QList>
#include <QString>

const int MAX_NOMBRE_WIDGET_LISTE = 10;
const int TAILLE_IMAGE_LARGEUR = 40;
const int TAILLE_IMAGE_LONGUEUR = 40;

struct WidgetListe
{
    QAction* mon_action;
    QString chemin_image;
    QList<int>* ligne_fiche;
    QString texte;
};


#endif // ENTETE_H
