
#ifndef INDENT_H
#define INDENT_H
/*!
* \file ident.h 
* \author AZRIA Julien DURAND Romain
*/
 #include <QTextEdit>

class Indent: virtual public QWidget
{
    Q_OBJECT

    private:
        QTextEdit* editeur;

    public:
        Indent(QTextEdit* e);
        void indenter(QString);

    public slots:
        void texteChange(int,int,int);
};

#endif // INDENT_H
