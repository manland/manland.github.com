#ifndef EDITEUR_H
 #define EDITEUR_H

/*!
* \file editeur.h
* \brief Classe principale du module Editeur.
* \author Maillet Laurent
* \date 15/05/2009
*/

#include <QTextEdit>
#include <QMouseEvent>
#include <QLabel>
#include <QTimer>
#include <QKeyEvent>
#include <QUrl>
#include <QTextBlock>
#include <QHttp>
#include "frameaide.h"

#include "coloration.h"
#include "syntaxe.h"
#include "WebBrowser.h"
#include "completer.h"
class WidgetLigne;

/*!
* \class Editeur
* \brief Classe principale du module Editeur.
*
* C'est la classe de base : c'est elle la zone de texte, la o� l'utilisateur va entr�e son code.
* C'est donc � partir de cette classe que les fonctionnalit�s importantes telles que l'auto-completer
* vont �tre appel�es (dans la fonction keypressEvent).
* Elle contient �galement les classes importantes pour l�dition du texte que sont Coloration et Syntaxe.
*
* Pour cr�er une instance de cette classe il suffit d'appeller son constructeur dont le nombre d'argument
* varie de 0 � 3 :
* _le p�re
* _le temps d'attente de l'affichage de l'aide par la souris
* _le temps d'attente de l'affichage de l'aide par le clavier
*
* Elle permet �galement d'ouvrir la naigateur web, principalement pour acc�der � des aides rapides.
* Il suffit d'utiliser la fonction ouvrirNavigateurInternet(QString)
*
* Elle est visible par d�faut
*
*
*/
 class Editeur : public QTextEdit
 {
     Q_OBJECT

     private:
        void initialiseEditeur();
        Coloration *coloration; /*!< classe permattant la coloration du texte*/
        Syntaxe *syntaxe; /*!< classe permettant l'analyse du texte*/
        Completer * completer;/*!< classe permettant l'auto-compl�tion du texte*/
        WidgetLigne* widget_ligne; /*!< widgetLigne li� � l'editeur */

        QTextBlock* block_sous_souris; /*!< block contenue sous la souris ou au niveau du curseur selon le moyen utilis� pour se d�placer dans la fichier*/
        QWidget* parent; /*!< parent de Editeur*/
        QString selection; /*!< texte s�lectionn�, affich� par la frame aide*/
        FrameAide* aide; /*!< classe permettant d'afficher un texte reconnu comme un mot-clef d'un langage, elle s'affiche sous forme de bulle*/
        QTimer* temps_souris;/*!< timer nous donnant le temps �coul� depuis le dernier mouvement de la souris, il est utilis� pour savoir quand afficher la FrameAide*/
        QTimer* temps_clavier;/*!< timer nous donnant le temps �coul� depuis le dernier mouvement du curseur, il est utilis� pour savoir quand afficher la FrameAide*/
        QPoint position_curseur; /*!< permet de connaitre la position de la souris, utilis� pour savoir o� afficher la FrameAide*/
        const int temps_attente_souris;/*!< temps d'attente avant d'afficher la FrameAide lorsque la souris bouge, initialis� � la cr�ation de l'objet*/
        const int temps_attente_clavier;/*!< temps d'attente avant d'afficher la FrameAide lorsque le curseur bouge, initialis� � la cr�ation de l'objet*/
        int nombre_caractere; /*!< nombre total de caract�re contenus dans la QTextEdit*/
        int nombre_ligne;/*!< nombre total de lignes contenus dans la QTextEdit*/
        int nombre_caractere_sans_espace; /*!< nombre de caract�re -except� les espaces, saut de lignes, tabulations- contenus dans la QTextEdit*/



    protected :
        /*!
         *  \brief fonction appel�e au mouvement de la souris, ref�finition de QTextEdit::mouseMoveEvent
         *
         *  Elle permet d'activer le timer de la souris pour l'affichage de l'aide
         *
         *  \param QMouseEvent* e : contient les param�tres d�crivant l'�v�nement de la souris
         */
        void mouseMoveEvent(QMouseEvent*);
        /*!
         *  \brief fonction appel�e lors de l'appui sur une touche du clavier, ref�finition de QTextEdit::keyPressEvent
         *
         *  Elle permet d'afficher la fen�tre d'auto-compl�tion ainsi que quelques options conernant cette fonctionnalit�,
         *  d'ouvrir le navigateur lors de l'appuie sur la touche F1
         *  et de changer les variables concernant les caract�res et les lignes
         *
         *  \param QMouseEvent* e : contient les param�tres d�crivant l'�v�nement de la souris
         */
        void keyPressEvent(QKeyEvent*);
        /*!
         *  \brief fonction appel�e lors de l'appui sur une touche du clavier, ref�finition de QTextEdit::keyReleaseEvent
         *
         *  Lorsqu'on rel�che une touche on calcul la diff�rence de ligne entre avant l'appuie sur la touche et apr�s, si une ligne a �t� rajout� ou enlev�
         *  il faut mettre � jour les lignes des signets en cons�quences
         *
         *  \param QMouseEvent* e : contient les param�tres d�crivant l'�v�nement de la souris
         */
        void keyReleaseEvent(QKeyEvent*);
        void mousePressEvent(QMouseEvent*);

    public slots :
        /*!
         *  \brief Modifie les valeurs des param�tres concernant les caract�res et les lignes
         *
         *  R�cup�re le nombre de lignes et de caract�res avec et sans espace dans Editeur,
         *  et modifie les variables correspondantes.
         *
         */
        void changeNombreCaractere();
        /*!
         *  \brief R�cup�re le mot sous le curseur
         *
         *  Methode appel� lorsque le curseur bouge et permet de r�cup�rer le mot situ� sous le curseur
         *
         */
        void changeSelection();

        /*!
         *  \brief R�cup�re le mot sous la souris
         *
         *  Une fois la souris immobile durant x ms(sp�cifi� par la variable temps_attente_souris,
         *  cette fonction est appel�e et permet de r�cup�rer le mot situ� sous le curseur de la souris puis de l'afficher
         *  par la FrameAide
         *
         */
        void changeSelectionSouris();

        /*!
         *  \brief R�cup�re le mot sous la souris
         *
         *  Une fois le curseur immobile durant x ms(sp�cifi� par la variable temps_attente_clavier,
         *  cette fonction est appel� et permet de lancer l'affichage de la FrameAide
         *
         */
        void afficheLabelCurseur();



     public:

        /*!
         *  \brief Constructeur
         *
         *  Constructeur de la classe Editeur
         *
         *  \param parent : parent de l'objet
         *  \param temps_souris = temps d'attente du timer de la souris
         *  \param temps_curseur = temps d'attente du timer du clavier
         *
         */
        Editeur(QWidget* parent = 0, int temps_souris = 250, int temps_curseur = 250);


        /*!
         *  \brief affiche la FrameAide
         *
         *  Appel� lors de la fin d'un des deux timers, elle v�rifie qu'un mot a �t� s�lectionn�,
         *  puis appelle la fonction coloration::langage(QString,QTextBlock)
         *  permettant de savoir si le mot est un mot-clef � afficher
         *  Si c'est le cas on affiche la FrameAide
         *
         */
        void afficheLabel();
        /*!
         *  \brief ouvre la navigateur web
         *
         *  Appel� lors de l'appuie sur la touche F1, elle ouvre le navigateur web avec la QString en url
         *
         *  \param url : url � ouvrir sur le navigateur
         *
         */
        void ouvrirNavigateurInternet(QString url);
        /*!
         *  \brief returne une url
         *
         *  Selon le mode dans lequel l'utilisateur code(PHP, html..) cette fonction cr�e une url et la renvoit
         *  afin que l'utilisateur tombe sur la page d'aide appropri�
         *
         *  \return l'url correspondante au mode si une aide est affichable,
         *  un QString vide sinon
         *
         */
        QString recupereUrl();
        /*!
         *  \brief Renvoit le nombre de ligne de Editeur
         *
         *  \return le nombre de ligne dans Editeur
         */
        int getNombreLigne();
        /*!
         *  \brief Renvoit le nombre de caract�res dans Editeur
         *
         *  \return le nombre de caract�res totals dans Editeur
         */
        int getNombreCaractere();
        /*!
         *  \brief Renvoit le nombre de caract�res sans les espaces, tabulation, etc. dans Editeur
         *
         *  \return le nombre de caract�res sans les espaces, tabulation, etc. dans Editeur
         */
        int getNombreCaractereSansEspace();
        /*!
         *  \brief Modifie le nombre de caract�res de Editeur
         *
         *  \param le nombre de caract�res dans Editeur
         */
        void setNombreCaractere(int);
        /*!
         *  \brief Modifie le nombre de lignes de Editeur
         *
         *  \param le nombre de lignes dans Editeur
         */
        void setNombreLigne(int);
        /*!
         *  \brief Modifie le nombre de caract�res  sans les espaces, tabulation, etc. dans Editeur
         *
         *  \param le nombre de caract�res sans les espaces, tabulation, etc. dans Editeur
         */
        void setNombreCaractereSansEspace(int);
        /*!
         *  \brief Modifie la WidgetLigne li� � l'editeur.
         *
         *  \param w: widgetListe li� � l'editeur
         */
        void setWidgetLigne(WidgetLigne* w);
        /*!
         *  \brief Modifie la marge
         *
         *  Modifie la marge autour de la zone de d�filement, utilis� pour afficher les lignes sur le c�t�
         *
         * \param l : marge � gauche
         * \param t : marge en haut
         * \param r : marge � droite
         * \param b : marge en bas
         */
        void setMargins(int l, int t, int r, int b);
        /*!
         *  \brief Renvoit le colorateur
         *
         *  \return le colorateur
         */
        Coloration* getColoration();
        /*!
         *  \brief Renvoit le bloc sous la souris
         *
         *  \return le bloc sous la souris
         */
        QTextBlock* getBlockSousSouris();

        /*!
         *  \brief Renvoit le compl�teur
         *
         *  \return le bloc sous la souris
         */
        Completer* getCompleter() const;
//        /*!
//         *  \brief fonction appel�e lors de l'appui sur une touche du clavier, ref�finition de QTextEdit::focusInEvent
//         *
//         *  Permet au Completer de se dessiner dans l' Editeur
//         *
//         *  \param QFocusEvent* e : �v�nement du clavier
//         */
//        void focusInEvent(QFocusEvent*);
        /*!
         *  \brief Met � jour la liste des �l�ments du completeur
         *
         *  Met � jour la liste des �l�ments du completeur
         */
        void miseAJourCompleter();
        int ligne_curseur;/*!< position du curseur dans l' Editeur avant d'appuyer sur une touche*/
//----------------------------MODIFIER-PAR-WilloW--fin------------------------------
 };

 #endif
