
#include <QStack>
#include <QRegExp>
using namespace std;

#include "ident.h"
/*!
* \file ident.cpp 
* \author AZRIA Julien DURAND Romain
*/

/*!
* \brief Constructeur
*
* Constructeur d'ident
*
* \param parametre : QTextEdit e correspondant a l'editeur
*/
Indent::Indent(QTextEdit* e):editeur(e)
{
    connect(editeur->document(), SIGNAL(contentsChange(int, int,int)), this, SLOT(texteChange(int, int, int)));
    QTextCursor curseur(editeur->document());
    curseur.movePosition(QTextCursor::Start);
}


/*!
* \brief fonction d'identation.
* \param QString S : re�oit directement le contenu du QTexte edit.
*/
void Indent::indenter(QString s)
{
     int indent = 0; //varriable d'indentation nb de tabulation
     bool php = false;
     QTextCursor curseur(editeur->document());  //position actuelle du curseur
     QStringList lignes = s.split("\n"); 
     for (int i=0; lignes.size();i++) {
         //supression d'�ventuel espaces tab ou autre/
         lignes.replaceInStrings(QRegExp("^\t"), "");
         lignes.replaceInStrings(QRegExp("^ "), "");
         int p = lignes.at(i).count("<?php");
         int fp = lignes.at(i).count("?>");
         if (p>0)php = true;         
         if (fp>0)php = false;
         for(int j= 0; j<= indent; j++)lignes.replaceInStrings(QRegExp("^"), "\t");
         int acolO=0,acolF=0,ouver=0,ferme=0,vide=0;
         if (php){
                  acolO = lignes.at(i).count("{");
                  acolF = lignes.at(i).count("}");
                  }
         else {
                  ouver = lignes.at(i).count("<");
                  ferme = lignes.at(i).count("<//");
                  vide  = lignes.at(i).count("//>");
                  }
         indent = indent + (ouver-(vide+ferme)) + (acolO - acolF);
     }
     s = lignes.join("\n");
}


//--------------------------------------------------------------------------------------
// slots
//--------------------------------------------------------------------------------------

//fonction appel�e quand le texte de l'�diteur change, lance la verification syntaxique du texte
void Indent::texteChange(int pos, int ajout, int enleve)
{
    if(ajout != 0 || enleve != 0)
    {
//        cout<<"texte chang�"<<endl;
        QString s = editeur->toPlainText();
        if(!s.isEmpty())
        {
            indenter(s);
        }
    }
}
