/*========================================================================
Nom: Syntaxe.h           auteur: K�NIG M&eacute;lanie
Maj:  17/05/09         Creation:
Projet: MYW
--------------------------------------------------------------------------
Specification:
Ce fichier contient l'entete du verificateur de syntaxe
=========================================================================*/
/*!
* \file Syntaxe.h
* \brief verificateur de syntaxe
* \author K�NIG M&eacute;lanie
* \date 17.05.2009
*
* V&eacute;rificateur de syntaxe qui effectue un controle sur le parenth&eacute;sage et grise le bloc parenth&eacute;s&eacute; quand le curseur est &agrave; c�t&eacute;
*
*/
#ifndef SYNTAXE_H
#define SYNTAXE_H

/*!
* \class Syntaxe
* \brief Classe Permet de faire une v&eacute;rification sur le parenth&eacute;sage
*
* Cette classe permet d'afficher une erreur lorsqu'une erreur de parenth&egrave;se est detect&eacute;e et de surligner le
* bloc parenth&egrave;se lorsque le curseur est positionn&eacute; &agrave; cot&eacute;.
* Elle est int&eacute;gr&eacute;e dans Editeur avec en param&egrave;tre une r&eacute;f&eacute;rence vers l'&eacute;diteur qui l'instancie.
*/

 #include <QTextEdit>
 #include <QList>

class Syntaxe: virtual public QWidget
{
    Q_OBJECT

    private:
        QTextEdit* editeur;/*!< l'editeur auquel est associ&eacute; cette syntaxe*/
        int compteur; /*!< le nombre d'appel au slot texteChange*/
        QTextCursor* surligne;/*!< le curseur contenant le texte surlign&eacute;*/
        QList<QTextCursor> listeSouligne;/*!< la liste de curseur qui contiennent les textes soulign&eacute;s*/
        QList<QTextCursor> bloc;/*!< la liste des curseurs marquants les blocs corrects*/

    public:
         /*!
        * \brief Constructeur
        * Constructeur de la classe Syntaxe
        * \param  edit : QTextEdit representant l'editeur auquel la syntaxe est associ&eacute;
        * \param parent : QWidget parent
        */
        Syntaxe(QTextEdit* edit = 0,QWidget *parent = 0);
         /*!
        * \brief verifie le parenth&eacute;sage
        * verifie le parenth&egrave;sage (, { et [ du texte pass&eacute; en param&egrave;tre souligne en rouge si incorrect
        * \param  texte : QString contenant le texte a verifier
        * \param debut : indice ou commencer la verification
        * \param fin : indice ou finir la verification
        */
        void verification(QString texte,int debut,int fin);
        /*!
        * \brief souligne une erreur
        * souligne en rouge ondul&eacute; la ligne du curseur pass&eacute; en param&egrave;tre
        * \param curseur : QTextCurseur representant le curseur &agrave; cot&eacute; duquel est l'erreur
        */
        void souligneErreur(QTextCursor curseur);
        /*!
        * \brief grise un bloc de parenth&egrave;se
        * grise le bloc contenu entre deux parenth&egrave;ses
        * \param  curseur: QTextCurseur repr&eacute;sentant le curseur du document
        * \param pas : -1 si le curseur est en fin de bloc, 1 s'il est en debut
        * \param ouverture : QRegExp permetant d'identifier l'ouverture du bloc
        * \param fermeture : QRegExp permetant d'identifier la fermeture du bloc
        * \param lg_debut : longueur du reperage de l'ouverture du bloc ex: pour <?php c'est 5
        * \param lg_fin : longueur du reperage de la fermeture du bloc
        */
        void surligneBloc( QTextCursor* curseur, int pas, QRegExp ouverture, QRegExp fermeture, int lg_deb, int lg_fin);

    public slots:
         /*!
        * \brief slot appel&eacute; lorsque le texte change
        * slot appel&eacute; lorsque le texte de l'editeur est chang&eacute;
        * \param pos : indice de la position ou a eut lieu le changement
        * \param ajout : nombre de lettre ajout&eacute;es
        * \param enleve: nombre de lettre enlev&eacute;es
        */
        void texteChange(int pos, int ajout, int enleve);
         /*!
        * \brief slot appel&eacute; lorsque le curseur bouge
        * slot appel&eacute; lorsque le curseur du document est boug&eacute;
        */
        void curseurBouge();
};

#endif // SYNTAXE_H
