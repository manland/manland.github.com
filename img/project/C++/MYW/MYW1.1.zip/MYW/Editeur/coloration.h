#ifndef COLORATION_H
#define COLORATION_H

/*!
* \coloration.h
* \brief Ce fichier contient tout ce qui est n&eacute;cessaire &agrave; la coloration des mots cl&eacute;s tap&eacute;s dans l'&eacute;diteur de texte
* \author Novak Audrey
* \date 12.03.2009
*/

#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QMouseEvent>
#include <QBrush>
#include <QTextBlock>
#include <QList>
#include <QVariant>

class QTextDocument;
class Editeur;

/*!
* \class Coloration
* \brief Classe contenant les m&eacute;thodes permettant de colorer le texte contenu dans la fenetre d'&eacute;dition
*
* Cette classe r&eacute;impl&eacute;mente la classe QSyntaxHighlighter de Qt.
* Pour qu'un QTextEdit puisse b&eacute;n&eacute;ficier de la coloration syntaxique, il faut&eacute;
* inclure ce .h, et cr&eacute;er un Coloration *coloration = new Coloration(QTextEdit).
* C'est dans le constructeur de cette classe que sont d&eacute;finis les expressions r&eacute;guli&egrave;res
* et leur format de coloration.
* Cette classe contient une m&eacute;thode qui est appel&eacute;e &agrave; chaque fois que l'utilisateur entre une lettre dans la
* fen&ecirc;tre d'&eacute;dition et elle se chargera de reconnaitre le type de langage dans lequel le curseur se trouve
* ainsi que reconnaire les mots cl&eacute;s, et de les colorer.
*
*/

/*!
* \struct ReglesColoration
*
* \param expression_reg : QRegExp expression r&eacute;guli&egrave;re d&eacute;finissant le mot cl&eacute; ou l'expression
* \param format : QTextCharFormat format appliqu&eacute; &agrave; l'expression r&eacute;guli&egrave;re, un format peut avoir une couleur, &ecirc;tre en gras ou en italique
*/
    struct ReglesColoration
    {
        QRegExp expression_reg;  /*!<struct expression_reg : QRegExp expression r&eacute;guli&egrave;re definissant le mot cl&eacute; ou l'expression */
        QTextCharFormat format;  /*!<struct format : QTextCharFormat format applique &agrave; l'expression r&eacute;guli&egrave;re, un format peut avoir une couleur, &ecirc;tre en gras ou en italique */
    };


class Coloration : public QSyntaxHighlighter
{
    Q_OBJECT

  private:

    QVector<ReglesColoration> regles_coloration; /*!< vecteur de ReglesColoration pour les commentaires, les chaines de texte dans le cas ou aucun langage ne serait defini*/
    QVector<ReglesColoration> regles_coloration_php; /*!< vecteur de ReglesColoration pour le langage php*/
    QVector<ReglesColoration> regles_coloration_javascript;/*!< vecteur de ReglesColoration pour le langage javascript*/
    QVector<ReglesColoration> regles_coloration_css;/*!< vecteur de ReglesColoration pour le langage css*/
    QVector<ReglesColoration> regles_coloration_html;/*!< vecteur de ReglesColoration pour le langage html*/
    QVector<ReglesColoration> regles_coloration_balise_html;/*!< vecteur de ReglesColoration pour les balises html*/
    QVector<ReglesColoration> regles_coloration_balise_html_fermantes;/*!< vecteur de ReglesColoration pour les balises fermantes */



    ReglesColoration rule;   /*!< structure dans le cas ou il n'y a aucun langage, cas normal*/
    ReglesColoration rule_php;/*!< structure pour le langage php*/
    ReglesColoration rule_css;/*!< structure pour le langage css*/
    ReglesColoration rule_javascript;/*!< structure pour le langage javascript*/
    ReglesColoration rule_html;/*!< structure pour le langage html (attributs)*/
    ReglesColoration rule_html_balise_fermante;/*!< structure pour les balises html */

    bool est_html_selectionne;  /*!< bool identifiant si la case correspondant au langage html est coch&eacute;e dans le widget ChoisirLangage de Preferences.*/
    bool est_php_selectionne;/*!< bool identifiant si la case correspondant au langage php est coch&eacute;e dans le widget ChoisirLangage de Preferences.*/
    bool est_javascript_selectionne;/*!< bool identifiant si la case correspondant au langage javascript est coch&eacute;e dans le widget ChoisirLangage de Preferences.*/
    bool est_css_selectionne;/*!< bool identifiant si la case correspondant au langage  est coch&eacute;e dans le widget ChoisirLangage de Preferences.*/
    bool est_automatique_selectionne;/*!< bool identifiant si la case automatique est coch&eacute;e dans le widget ChoisirLangage de Preferences.*/


    bool est_fichier_php;                /*!< bool identifiant si le fichier est de type php*/
    bool est_fichier_css;                /*!< bool identifiant si le fichier est de type css*/
    bool est_fichier_javascript;         /*!< bool identifiant si le fichier est de type javascript*/
    bool est_fichier_html;               /*!< bool identifiant si le fichier est de type html*/

    int etat;       /*!< int correspondant &agrave; l'&eacute;tat du bloc dans lequel se trouve le curseur */

    QTextBlock *bloc_php;
    QTextBlock *bloc_javascript;
    QTextBlock *bloc_css;
    QTextBlock *bloc_html;

    Editeur *editeur;

//--------------------------------------------
//          Coloration php
//--------------------------------------------
    QStringList mots_cle_php1; /*!< QStringList contenant les mots cl&eacute;s de php*/
    QStringList mots_cle_php2; /*!< QStringList contenant les mots cl&eacute;s de php*/
    QStringList mots_cle_php3; /*!< QStringList contenant les mots cl&eacute;s de php*/
    QStringList mots_cle_php4; /*!< QStringList contenant les mots cl&eacute;s de php*/
    QStringList mots_cle_php5; /*!< QStringList contenant les mots cl&eacute;s de php*/
    QStringList variables_php; /*!< QStringList contenant les mots cl&eacute;s de php*/

    QRegExp debut_php;  /*!< QRegExp correspondant au debut d'un bloc php : <?php */
    QRegExp fin_php; /*!< QRegExp correspondant a la fin d'un bloc php : ?> */

    QTextCharFormat format_mots_cle_php1;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de php*/
    QTextCharFormat format_mots_cle_php2;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de php*/
    QTextCharFormat format_mots_cle_php3;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de php*/
    QTextCharFormat format_variables_php;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de php*/


//--------------------------------------------
//          Coloration css
//--------------------------------------------
    QStringList mots_cle_css1; /*!< QStringList contenant les mots cl&eacute;s de css*/
    QStringList mots_cle_css2; /*!< QStringList contenant les mots cl&eacute;s de css*/
    QStringList symboles_css; /*!< QStringList contenant les mots cl&eacute;s de css*/

    QRegExp debut_css;        /*!< QRegExp correspondant au d&eacute;but d'un bloc css : <style type="text/css" */
    QRegExp fin_css;          /*!< QRegExp correspondant au d&eacute;but d'un bloc css : </style> */

    QTextCharFormat format_mots_cle_css1;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de css*/
    QTextCharFormat format_mots_cle_css2;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de css*/


//--------------------------------------------
//          Coloration javascript
//--------------------------------------------
    QStringList mots_cle_javascript1; /*!< QStringList contenant les mots cl&eacute;s de javascript*/
    QStringList mots_cle_javascript2; /*!< QStringList contenant les mots cl&eacute;s de javascript*/
    QStringList mots_cle_javascript3; /*!< QStringList contenant les mots cl&eacute;s de javascript*/

    QRegExp debut_javascript1;         /*!< QRegExp correspondant au d&eacute;but d'un bloc javascript : <script langage="javascript" */
    QRegExp fin_javascript1;           /*!< QRegExp correspondant au d&eacute;but d'un bloc javascript : </script> */
    QRegExp debut_javascript2;         /*!< QRegExp correspondant au d&eacute;but d'un bloc javascript : <script langage="javascript" */
    QRegExp fin_javascript2;           /*!< QRegExp correspondant au d&eacute;but d'un bloc javascript : </script> */


    QTextCharFormat format_mots_cle_javascript1;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de javascript*/
    QTextCharFormat format_mots_cle_javascript2;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de javascript*/
    QTextCharFormat format_mots_cle_javascript3;  /*!< QTextCharFormat associ&eacute; aux mots cl&eacute;s de javascript*/


//--------------------------------------------
//          Coloration html
//--------------------------------------------
    QStringList html_balises_fermantes;     /*!< QStringList contenant les balises html fermantes de type : </a> */
    QStringList html_balises_non_fermantes; /*!< QStringList contenant les balises html non fermantes de type <img /> */
    QStringList html_balises_ouvrantes;     /*!< QStringList contenant les balises html ouvrantes de type <html> */
    QStringList attributs_html;             /*!< QStringList contenant les attributs*/

    QTextCharFormat format_balise_html;     /*!< QTextCharFormat associ&eacute; aux balises de html*/
    QTextCharFormat format_attributs_html;  /*!< QTextCharFormat associ&eacute; aux attributs de html*/


//--------------------------------------------
//       Commentaires et Autres
//--------------------------------------------
    QRegExp debut_commentaire;              /*!< QRegExp correspondant au d&eacute;but d'un bloc de commentaire multiple */
    QRegExp fin_commentaire;                /*!< QRegExp correspondant a la fin d'un bloc de commentaire mutliple */
    QRegExp debut_commentaire_html;         /*!< QRegExp correspondant au d&eacute;but d'un bloc de commentaire multiple html */
    QRegExp fin_commentaire_html;           /*!< QRegExp correspondant a la fin d'un bloc de commentaire mutliple html */

    QTextCharFormat format_commentaire_simple;    /*!< QTextCharFormat associ&eacute; aux commentaires simple d'expression : QRegExp("//[^\n]*")*/
    QTextCharFormat format_commentaire_multiple;  /*!< QTextCharFormat associ&eacute; aux commentaires multiple et commentaire multiple html*/
    QTextCharFormat format_quote;                 /*!< QTextCharFormat associ&eacute; aux chaines de caracteres*/
    QTextCharFormat format_fonction;              /*!< QTextCharFormat associ&eacute; aux fonctions, texte suivi de (*/
    QTextCharFormat format_Ecommecial;            /*!< QTextCharFormat associ&eacute; a & d'exrpression : QRegExp("&[^_;][A-Za-z0-9_#]*;"); */



public:
/*!
* \brief Constructeur
*
* Constructeur de la classe Coloration
*
* \param parent : le parent de la classe coloration est de type Editeur
*/
    Coloration(Editeur *parent = 0);

/*!
* \brief Permet d'ajouter dans une QStringList, les mots cl&eacute;s contenus dans un fichier texte, et de leur associer un QTextCharFormat.
*
* \param chemin : QString chemin du fichier contenant les mots cl&eacute;s
* \param liste : QStringListe liste qui contiendra les mots cl&eacute;s
* \param format : QTextCharFormat format qui s'appliquera sur les mots contenus dans la liste
*/
    void ajouteMotCleFichier(const QString&,QStringList&, QTextCharFormat);

/*!
* \brief Permet d'ajouter dans une QStringList, les balises fermantes html contenus dans un fichier texte, et de leur associ&eacute; un QTextCharFormat.
*
* \param chemin : QString chemin du fichier contenant les mots cl&eacute;s
* \param liste : QStringListe liste qui contiendra les mots cl&eacute;s
* \param format : QTextCharFormat format qui s'appliquera sur les mots contenus dans la liste
*/
    void ajouteMotCleBalisesFermantes(const QString&, QStringList&, QTextCharFormat);

/*!
* \brief Permet d'ajouter dans une QStringList, les balises html contenues dans un fichier texte, et de leur associer un QTextCharFormat.
*
* \param chemin : QString chemin du fichier contenant les mots cl&eacute;s
* \param liste : QStringListe liste qui contiendra les mots cl&eacute;s
* \param format : QTextCharFormat format qui s'appliquera sur les mots contenus dans la liste
*/
    void ajouterMotCleBalises(const QString&, QStringList&, QTextCharFormat);



/*!
* \brief Permet de modifier un fichier texte en lui rajoutant
*  la chaine pass&eacute;e en param&egrave;tre. Utilis&eacute;e dans modifierLangage
*
* \param chemin : QString chemin du fichier contenant les mots cl&eacute;s
* \param chaine : QStringListe liste qui contiendra les mots cl&eacute;s
*/
    void modifieFichier(const QString&, const QString&);

/*!
* \brief Initialise le langage php, cette fonction ajoute les mots cl&eacute;s php,
*  aux listes correspondantes, leur ajoute un format,
*  elle ajoute &eacute;galement les diff&eacute;rentes expressions r&eacute;guli&egrave;res que l'on veut reconnaitre
*
*/
    void initialisationPhp();

/*!
* \brief Initialise le langage css, cette fonction ajoute les mots cl&eacute;s css,
*  aux listes correspondantes, leur ajoute un format,
*  elle ajoute &eacute;galement les diff&eacute;rentes expressions r&eacute;guli&egrave;res que l'on veut reconnaitre
*
*/
    void initialisationCss();

/*!
* \brief Initialise le langage javascript, cette fonction ajoute les mots cl&eacute;s javascript,
*  aux listes correspondantes, leur ajoute un format,
*  elle ajoute &eacute;galement les diff&eacute;rentes expressions r&eacute;guli&egrave;res que l'on veut reconnaitre
*
*/
    void initialisationJavascript();

/*!
* \brief Initialise le langage html, cette fonction ajoute les mots cl&eacute;s html,
*  aux listes correspondantes, leur ajoute un format,
*  elle ajoute &eacute;galement les diff&eacute;rentes expressions r&eacute;guli&egrave;res que l'on veut reconnaitre
*/
    void initialisationHtml();

/*!
* \brief Cette fontion lit ce qu'il y a dans un fichier texte et renvoie sous forme de liste son contenu,
* elle est utilis&eacute;e dans la classe modifierLangage afin de faire afficher la liste de mots cl&eacute;s.
*
* \param chemin : chemin du fichier texte
* \return mot_cle : QStringList la liste de mots cl&eacute;s contenus dans le fichier texte
*/
    QStringList recupererFichier(const QString&);

/*!
* \brief Cette fontion permet de renvoyer sous forme de QString le type de langage du texte
 *  qui est dans le bloc situ&eacute; sous la souris. Utilis&eacute;e dans Editeur.
*
* \param texte : texte situ&eacute; sous la souris
* \param bloc_editeur : QStringList la liste de mots cl&eacute;s contenus dans le fichier texte
* \return resultat : QString nom du langage
*/
    QString langage(const QString&, const QTextBlock*);

/*!
* \brief Cette fonction renvoi sous forme de QString, le mot plac&eacute; &agrave; cot&eacute; du curseur
*
* \return QString mot pr&eacute;sent &agrave; cot&eacute; du curseur.
*/
    QString recupererTexte();

/*!
* \brief En fonction de la liste pass&eacute; en param&egrave;tre, cette fonction
*  renvoit le langage sous forme de QString.
*
* \param liste : QStringList liste contenant des mots cl&eacute;s
* \return resultat : QString nom du langage dans lequel appartient la liste
*/
    QString renvoieListe(QStringList&);

/*!
* \brief En fonction de l'&eacute;tat dans lequel on se trouve (type de langage),
*  cette fonction renvoie la liste de tous les mots cl&eacute;s de ce langage (somme de toutes les listes du langage concern&eacute;).
*  apr&egrave;s avoir r&eacute;cup&eacute;r&eacute; dans une liste temporaire la somme des listes du langage,
*  on enl&egrave;ve les \\b.
*  Cette fonction est utilis&eacute;e pour renvoyer une liste de mots cl&eacute;s dans le Completer
*
*\return resultat : QStringList liste de mot cl&eacute;s contenant la somme de toutes les listes du langage concern&eacute;
*/
    QStringList getListe();

/*!
* \brief Fonction appel&eacute;e dans highlightblock, elle concerne la boucle de reconnaissance et de coloration de mots cl&eacute;s php
*
*\param text : texte tap&eacute; par l'utilisateur
*/
    void colorerPhp(const QString&);

/*!
* \brief Fonction appel&eacute;e dans highlightblock, elle concerne la boucle de reconnaissance et de coloration de mots cl&eacute;s javascript
*
*\param text : texte tap&eacute; par l'utilisateur
*/
    void colorerJavascript(const QString&);

/*!
* \brief Fonction appel&eacute;e dans highlightblock, elle concerne la boucle de reconnaissance et de coloration de mots cl&eacute;s css
*
*\param text : texte tap&eacute; par l'utilisateur
*/
    void colorerCss(const QString&);

/*!
* \brief Cet accesseur permet de mettre est_php_selectionne &agrave; vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : la case php de choisirLangage est coch&eacute;e, ou on a ouvert un fichier .php
*
*\param  b: bool  vrai si case coch&eacute;e (ou si .php), faux sinon
*/
    void setPhp(bool);

/*!
* \brief Cet accesseur permet de mettre est_css_selectionne &agrave; vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : la case css de choisirLangage est coch&eacute;e, ou on a ouvert un fichier .css
*
*\param  b: bool  vrai si case coch&eacute;e (ou si .css), faux sinon
*/
    void setCss(bool);

/*!
* \brief Cet accesseur permet de mettre est_javascript_selectionne &agrave; vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : la case javascript de choisirLangage est coch&eacute;e, ou on a ouvert un fichier .js
*
*\param  b: bool  vrai si case coch&eacute;e (ou si .js), faux sinon
*/
    void setJavascript(bool);

/*!
* \brief Cet accesseur permet de mettre est_html_selectionne &agrave; vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : la case html de choisirLangage est coch&eacute;e
*
*\param  b: bool  vrai si case coch&eacute;e, faux sinon
*/
    void setHtml(bool);

/*!
* \brief Cet accesseur permet de mettre est_automatique_selectionne vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : la case automatique de choisirLangage est coch&eacute;e
*
*\param  b: bool  vrai si case coch&eacute;e, faux sinon
*/
    void setAutomatique(bool);

/*!
* \brief Cet accesseur permet de mettre est_fichier_php vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : le fichier a une extension de type .php
*
*\param  b: bool  vrai si case coch&eacute;e, faux sinon
*/
    void setFichierPhp(bool);

/*!
* \brief Cet accesseur permet de mettre est_fichier_javascript vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : le fichier a une extension de type .js
*
*\param  b: bool  vrai si case coch&eacute;e, faux sinon
*/
    void setFichierJavascript(bool);

/*!
* \brief Cet accesseur permet de mettre est_fichier_css vrai ou faux, en fonction du bool&eacute;en pass&eacute; en param&egrave;tre.
*  Ce qui correspond &agrave; : le fichier a une extension de type .css
*
*\param  b: bool  vrai si case coch&eacute;e, faux sinon
*/
    void setFichierCss(bool);

/*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param  i: int num&eacute;ro de la liste de mots cl&eacute;s
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormat(int, QColor,bool,bool);

/*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatPhp1(QColor,bool,bool);

/*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatPhp2(QColor, bool,bool);

 /*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatPhp3(QColor, bool,bool);

/*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatPhpVariables(QColor, bool,bool);

 /*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatJavascript1(QColor,bool,bool);

     /*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatJavascript2(QColor, bool,bool);

 /*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatJavascript3(QColor, bool,bool);

 /*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatCss1(QColor,bool,bool);

 /*!
* \brief Permet de changer le format d'une liste de mots cl&eacute;s, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; la liste
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatCss2(QColor, bool,bool);

    void changerFormatHtml(QColor, bool,bool);
    void changerFormatAttributHtml(QColor, bool,bool);

 /*!
* \brief Permet de changer le format des commentaires simples, en leur appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e aux commentaires simples
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatCommentaireSimple(QColor,bool,bool);

 /*!
* \brief Permet de changer le format des commentaires multiples, en leur appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e aux commentaires multiples
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatCommentaireMultiple(QColor,bool,bool);

/*!
* \brief Permet de changer le format des chaines de caract&egrave;res, en leur appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e aux chaines de caract&egrave;res
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatQuote(QColor,bool,bool);

 /*!
* \brief Permet de changer le format des fonctions, en leur appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e eux fonctions
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatFonction(QColor,bool,bool);

/*!
* \brief Permet de changer le format des &amp;, en lui appliquant une couleur, gras et/ou italique
*
*\param coul : QColor couleur qui sera appliqu&eacute;e &agrave; &amp;
*\param estGras : bool correspond &agrave; la case gras de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*\param estItalique : bool correspond &agrave; la case italique de ChangerColoration a &eacute;t&eacute; coch&eacute;e
*/
    void changerFormatECommercial(QColor,bool,bool);

/*!
* \brief fonction permettant de recup&eacute;rer le format d'une liste ou d'une expression reguli&egrave;re
*  qui correspond au int pass&eacute; en param&egrave;tre
*
*\param i : int entier correspondant au num&eacute;ro d'une liste de mots cl&eacute;s ou d'expression r&eacute;guli&egrave;re
*\return QTextCharFormat format de la liste correspondant au int pass&eacute; en param&egrave;tre
*/
    QTextCharFormat getFormat(int);

/*!
* \brief Cette fonction renvoi un bool&eacute;en si la liste de mots cl&eacute;s correspondant &agrave; l'entier pass&eacute;
* en param&egrave;tre aura un format en italique.
*
*\param i : int entier correspondant au num&eacute;ro d'une liste de mots cl&eacute;s ou d'expression r&eacute;guli&egrave;re
*\return italique : bool renvoie vrai si les mots cl&eacute;s seront en italique, faux sinon
*/
    bool estItalique(int);

  /*!
* \brief Cette fonction renvoi un bool&eacute;en si la liste de mots cl&eacute;s correspondant &agrave; l'entier pass&eacute;
* en param&egrave;tre aura un format en gras.
*
*\param i : int entier correspondant au num&eacute;ro d'une liste de mots cl&eacute;s ou d'expression r&eacute;guli&egrave;re
*\return gras : bool renvoie vrai si les mots cl&eacute;s seront en gras, faux sinon
*/
    bool estGras(int);

    void initialiserFormats();

/*!
* \brief Cette fonction utilise le QSetting enregistr&eacute; dans la classe ChangerColoration afin de
* restaurer les couleurs et ainsi de recuperer les bons formats.
* Il faut appeller cette fonction dans le constructeur de coloration apr&egrave;s avoir cr&eacute;er les QTextFormats
*
*/
    virtual void restaurer();


public slots :

/*!
* \brief Ce slot relance l'initialisation des langages, apr&egrave;s avoir
* vider les listes de mots cl&eacute;s, et les vecteurs de r&egrave;gles de coloration
* ce slot est utilis&eacute; dans Preference, lorsqu'on appuie sur le bouton valider.
*
*/

    void relancerInitialisationLangages();


protected:
/*!
*  \brief fonction appel&eacute;e &agrave; chaque lettre tapee par l'utilisateur dans le QTextEdit, ref&eacute;finition de QSyntaxHighlighter::highlightBlock(const Qtring &text)
*
*  Cette fonction d&eacute;termine le langage dans lequel le curseur se trouve en analysant chaque lettre que l'utilisateur pousse.
* Si le texte ainsi entre correspond au commencement d'un langage, le bloc est alors debute en prenant comme etat la valeur en entier du langage concerne.
* Les mots cles du langage peuvent alors etre colores.
*  \param QString& text : texte entre dans l'Editeur par l'utilisateur.
*/
   virtual void highlightBlock(const QString &text);


/*! Enumeration correspondant au differents &eacute;tats dans lesquels notre editeur pourra se trouver.
  * un &eacute;tat correspond au type de langage dans lequel on est.
  */
    enum Etat {
            normal = -1,                        /*!< etat normal, par d&eacute;fault =-1 */
            commentaire_simple,                 /*!< etat commentaire simple = 0 */
            commentaire_multiple,               /*!< etat commentaire mutliple = 1 */
            commentaire_multiple_html,          /*!< etat commentaire mutliple html = 2 */
            commentaire_multiple_php,           /*!< etat commentaire mutliple php = 3 */
            commentaire_multiple_javascript,    /*!< etat commentaire mutliple javascript = 4 */
            commentaire_multiple_css,           /*!< etat commentaire mutliple css= 5 */
            php,                                /*!< etat php = 6 */
            javascript,                         /*!< etat javascript = 7 */
            css,                                /*!< etat css = 8 */
            quote,                              /*!< etat chaine de caract&egrave;re = 9 */
            quote_php,                          /*!< etat chaine de caract&egrave;re php = 10 */
            quote_javascript,                   /*!< etat chaine de caract&egrave;re javascript = 11 */
            quote_css                           /*!< etat chaine de caract&egrave;re css = 12 */
        };


};
#endif
