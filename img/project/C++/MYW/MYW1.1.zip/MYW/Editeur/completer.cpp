#include "completer.h"
#include "editeur.h"
#include "mesConfigs.h"
#include <QString>
#include <QKeyEvent>
#include <QtGui>
#include <stdio.h>
#include <iostream>



Completer::Completer(Editeur * parent) : QCompleter(parent)
{

    this->parent = parent;
    chemin_fichier_variables  = QString(systeme_relation_fichier).append("fichiers/variables.txt");
    nb_lettre = 3;
    completer_actif = true;

    this->setModel(modelFromFile());
    this->setModelSorting(QCompleter::CaseInsensitivelySortedModel);
    this->setCaseSensitivity(Qt::CaseInsensitive);
    this->setWrapAround(false);
    this->setWidget(parent);
    this->setCompletionMode(QCompleter::PopupCompletion);
    this->setCaseSensitivity(Qt::CaseInsensitive);
    QObject::connect(this, SIGNAL(activated(const QString&)),this, SLOT(insertCompletion(const QString&)));

}

Completer::~Completer()
{

}

QString Completer::textUnderCursor() const
{
    return parent->getColoration()->recupererTexte();
}

void Completer::insertCompletion(const QString& completion)
{
    if (this->widget() != parent)
        return;
    QTextCursor * tc = new QTextCursor(parent->textCursor());
    int extra = completion.length() - this->completionPrefix().length();
    tc->movePosition(QTextCursor::Left);
    tc->movePosition(QTextCursor::EndOfWord);
    tc->insertText(completion.right(extra));
    parent->setTextCursor(*tc);
}

void Completer::majListeVariables()
{
    QFile fichier(chemin_fichier_variables);
    if (!fichier.open(QFile::ReadOnly))
    {
        erreur.ecritErreur("Completer.cc","AjouteListeMots",50);
    }

    fichier.seek(0);

    while (!fichier.atEnd()) {
        QString line = fichier.readLine();
        QStringList contenu = line.split("|");
        words.append(contenu);
    }

    fichier.close();
}

QAbstractItemModel *Completer::modelFromFile()
{


    if(!parent->getColoration()->getListe().isEmpty())
    {
        words.append(parent->getColoration()->getListe());
    }

    majListeVariables();

    words.sort();

    return new QStringListModel(words, this);

}

void Completer::mettreAJourListe()
{
    words.clear();
    this->setModel(modelFromFile());
}

QStringList Completer::getWords() const
{
    return words;
}

void Completer::setListeDeCompletion(QStringList nouvelle_liste)
{
    words.clear();
    words<<nouvelle_liste;
    this->setModel(new QStringListModel(words, this));
}

void Completer::setActif(bool actif)
{
    completer_actif = actif;
}

void Completer::setNbLettre(int nb)
{
    nb_lettre = nb;
}

void Completer::ajouteListeCompletion(QStringList liste_ajout)
{
    words.append(liste_ajout);
    words.sort();
    this->setModel(new QStringListModel(words, this));
}

void Completer::ajouteMotCompletion(QString mot_ajout)
{
    words.append(mot_ajout);
    words.sort();
    this->setModel(new QStringListModel(words, this));
}

void Completer::ajouteVariable(QString var_ajout)
{
    if(!words.contains(var_ajout))
    {
        this->ajouteMotCompletion(var_ajout);

        QFile fichier_variables(chemin_fichier_variables);
        if(fichier_variables.open(QFile::WriteOnly | QFile::Append))
        {
            QTextStream out(&fichier_variables);
            out<<"|";
            out<<var_ajout;
            fichier_variables.close();
        }
    }
}

void Completer::setAncienMot(QString mot)
{
    ancien_mot = mot;
}

void Completer::verifVariable()
{
    static QString fin_de_mot("~!@#%^&*()+{}|:\"<>?,./;'[]\\-=");
    QTextCursor curseur = parent->textCursor();
    curseur.select(QTextCursor::WordUnderCursor);
    QString motcourant = curseur.selectedText();
    curseur.movePosition(QTextCursor::PreviousWord);
    curseur.movePosition(QTextCursor::PreviousWord);
    curseur.select(QTextCursor::WordUnderCursor);
    QString decla = curseur.selectedText();
    if(!(motcourant.contains(fin_de_mot)))
    {
        if(decla=="var")
        {
            ancien_mot = motcourant;
        }
        else
        if(decla=="function")
        {
            ancien_mot = motcourant;
        }
        else
        if(motcourant.left(1)=="$")
        {
            ancien_mot = motcourant;
        }
        this->ajouteVariable(ancien_mot);
    }
}

void Completer::activeComplete(QKeyEvent *e)
{

    bool est_touche_de_raccourci = ((e->modifiers() & Qt::ControlModifier) && e->key() == Qt::Key_Space);

    QString completion_prefixe = this->textUnderCursor();

    static QString fin_de_mot("~!@#$%^&*()_+{}|:\"<>?,./;'[]\\-=");

    const bool est_ctrl_ou_shift = e->modifiers() & (Qt::ControlModifier | Qt::ShiftModifier);
    if (!this || (est_ctrl_ou_shift && e->text().isEmpty()))
    {
        return;
    }

    bool hasModifier = (e->modifiers() != Qt::NoModifier) && !est_ctrl_ou_shift;

    if (!est_touche_de_raccourci && (hasModifier || e->text().isEmpty()|| completion_prefixe.length() < nb_lettre
                      || fin_de_mot.contains(e->text().right(1)) || !completer_actif))
    {
        this->popup()->hide();
        return;
    }

    if (completion_prefixe != this->completionPrefix())
    {
        this->setCompletionPrefix(completion_prefixe);
        this->popup()->setCurrentIndex(this->completionModel()->index(0, 0));
    }
    QRect carre_de_completion = QRect(parent->cursorRect());
    carre_de_completion.setWidth(this->popup()->sizeHintForColumn(0) + this->popup()->verticalScrollBar()->sizeHint().width());
    this->complete(carre_de_completion);

}

