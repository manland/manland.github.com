#include "widgetLigne.h"
#include <QSettings>


WidgetLigne::WidgetLigne(Editeur* a): QWidget(a), editeur_texte(a)
{
    connect(editeur_texte , SIGNAL( textChanged()) ,
    this , SLOT ( update() ));
    connect(editeur_texte->verticalScrollBar() , SIGNAL( valueChanged(int)) ,
    this , SLOT ( update() ));
    connect(editeur_texte, SIGNAL(textChanged()), this, SLOT(miseAJourListe()));
    chargement();
    taille_image = 0;
    ligne_a_droite = true;
    repaint();
}

void WidgetLigne::chargement()
{
    QSettings settings("MYW", "WidgetListe");
    int size = settings.beginReadArray("WidgetListe");
    for (int i = 0; i < size; i++) {
        settings.setArrayIndex(i);
        QString texte = settings.value(QString("texte")).toString();
        QString chemin_image = settings.value(QString("chemin_image")).toString();
        ajoutWidgetListe(new QAction(this), texte, chemin_image);
    }
    settings.endArray();
}

void WidgetLigne::paintEvent(QPaintEvent *e)
{
    e->accept();
    numero_premiere_ligne = -1;
    QPainter p(this);
    int m_lineNumber = 1;
    const QFontMetrics fm = fontMetrics();
    const int ascent = fontMetrics().ascent();
    QTextBlock block = editeur_texte->document()->begin();
    int contentsY = editeur_texte->verticalScrollBar()->value();
    qreal pageBottom = contentsY + editeur_texte->viewport()->height();
    for ( ; block.isValid(); block = block.next(), ++m_lineNumber )
    {
        QTextLayout* layout = block.layout();
        QPointF position = layout->position();
        const QRectF boundingRect = layout->boundingRect();

        if ( position.y() + boundingRect.height() < contentsY )
            continue;

        if ( position.y() > pageBottom )
            break;


        const QString txt = QString::number( m_lineNumber );
        taille_image = fontMetrics().height()-2;
        int nombre_ligne = 0;
        if(numero_premiere_ligne == -1)
        {
            numero_premiere_ligne = m_lineNumber;
            rectangle = boundingRect;
            position_layout = position;
            vertical_scroll_bar_value = contentsY;
        }

        int position_texte;
        int position_image;
        if(ligne_a_droite)
        {
            position_texte = width() - fm.width(txt) - 10;
            position_image = 10;
        }
        else
        {
            position_texte = 10;
            position_image = width() - taille_image - 10;
        }
        p.drawText(position_texte, qRound(position.y()) - contentsY + ascent, txt);
        for(int i=0; i<ma_liste.size();i++)
        {
            if(ma_liste[i]->ligne_fiche->contains(m_lineNumber))
            {
                mon_image = new QPixmap(ma_liste[i]->chemin_image);
                *mon_image = mon_image->scaled(taille_image,taille_image);
                p.drawPixmap(position_image, qRound(position.y()) - contentsY,*mon_image);
            }
        }
    }
    p.end();
    miseAJourMargin();
}

void WidgetLigne::miseAJourListe()
{
    int numero_max = editeur_texte->getNombreLigne();

    for(int i=0; i<ma_liste.size();i++)
    {
        for(int j=0; j<ma_liste[i]->ligne_fiche->size(); j++)
        {
            if(numero_max < (*(ma_liste[i]->ligne_fiche))[j])
                ma_liste[i]->ligne_fiche->removeOne((*(ma_liste[i]->ligne_fiche))[j]);
        }
    }
}

void WidgetLigne::mousePressEvent(QMouseEvent* e)
{
    const QFontMetrics fm = fontMetrics();
    int taille_bloc = fm.height();
    int tmp = qRound(position_layout.y()) - vertical_scroll_bar_value;
    //int ligne = ((e->pos().y()-tmp) / (int)rectangle.height())+numero_premiere_ligne;
    int ligne = ((e->pos().y()-tmp) / taille_bloc)+numero_premiere_ligne;

    int m_lineNumber = 1;
    const int ascent = fontMetrics().ascent();
    QTextBlock block = editeur_texte->document()->begin();
    int contentsY = editeur_texte->verticalScrollBar()->value();
    qreal pageBottom = contentsY + editeur_texte->viewport()->height();
    int tmp2 = numero_premiere_ligne-1;
    int taille = taille_bloc;
    for ( ; block.isValid(); block = block.next(), ++m_lineNumber )
    {
        QTextLayout* layout = block.layout();
        QPointF position = layout->position();
        const QRectF boundingRect = layout->boundingRect();

        if ( position.y() + boundingRect.height() < contentsY )
            continue;

        if ( position.y() > pageBottom )
            break;

        int ajout = boundingRect.height() /taille;
        if(tmp2<ligne)
            tmp2+=ajout;
        else
            break;
    }


    ligne_courante = m_lineNumber-1;
    if(ligne > editeur_texte->getNombreLigne() && e->button() != Qt::MidButton)
        return;
    if(e->button() == Qt::LeftButton)
    {
        ajoutLigne();
    }
    else if(e->button() == Qt::RightButton)
    {
        int est_dans = listeContientLigne();
        incrementeListe(est_dans);
    }
    else if(e->button() == Qt::MidButton)
    {
        QMenu * menu = new QMenu();
        menu->setAttribute(Qt::WA_DeleteOnClose);
        for(int i=0; i<ma_liste.size(); i++)
        {
            ma_liste[i]->mon_action = new QAction(QIcon(QString(ma_liste[i]->chemin_image)),ma_liste[i]->texte, NULL);
            menu->addAction(ma_liste[i]->mon_action);
            ma_liste[i]->mon_action->setCheckable(true);
        }
        menu->addSeparator();
        QAction * inverser = menu->addAction(tr("Inverser les icones et les lignes"));//Ajout de m@n
        inverser->setData(QString("inverserLigneIcone"));//Ajout de m@n
        connect(menu, SIGNAL(triggered(QAction*)), this, SLOT(cliqueMenu(QAction*)));
        menu->move(e->globalPos());
        menu->show();
    }
    repaint();
}

void WidgetLigne::miseAJourMargin()
{
    int nombre_ligne = editeur_texte->getNombreLigne();
    const QString txt = QString::number( nombre_ligne );
    const QFontMetrics fm = fontMetrics();
    int largeur = fm.width(txt) + 20 + taille_image;
    editeur_texte->setMargins(largeur,0,0,0);
    setFixedWidth(largeur);
}

void WidgetLigne::cliqueMenu(QAction* a)
{
    if(a->data().toString() == "inverserLigneIcone")//Ajout de m@n
    {
        if(ligne_a_droite)
        {
            ligne_a_droite = false;
        }
        else
        {
            ligne_a_droite = true;
        }
        return;
    }
    for(int i=0; i<ma_liste.size();i++)
    {
        enleveLigne(i);
        if(ma_liste[i]->mon_action->isChecked())
        {
            ajoutLigne(i);
        }
    }
}

int WidgetLigne::listeContientLigne()
{
    int numero_liste = -1;
    for(int i=0;i<ma_liste.size();i++)
    {
        if(ma_liste[i]->ligne_fiche->contains(ligne_courante))
            numero_liste = i;
    }
    return numero_liste;
}

void WidgetLigne::incrementeListe(int numero_liste)
{
    if(ma_liste.size() == 1 || numero_liste == -1)
        this->ajoutLigne(0);
    else if(numero_liste == ma_liste.size())
        this->enleveLigne(numero_liste);
    else
    {
        this->enleveLigne(numero_liste);
        this->ajoutLigne(numero_liste+1);
    }

}

int WidgetLigne::ajoutLigne(int numero_liste)
{
    if(numero_liste == -1)
    {
        bool a_enleve = false;
        for(int i=0; i<ma_liste.size();i++)
        {
            if(ma_liste[i]->ligne_fiche->contains(ligne_courante))
            {
                enleveLigne(i);
                a_enleve = true;
            }
        }
        if(a_enleve)
            return 0;
        else return ajoutLigne(0);
    }
    else if(ma_liste.size() > numero_liste && numero_liste >= 0)
    {
        if(ma_liste[numero_liste]->ligne_fiche->contains(ligne_courante))
        {
            ma_liste[numero_liste]->ligne_fiche->removeOne(ligne_courante);
            return 0;
        }
        else
        {
            ma_liste[numero_liste]->ligne_fiche->append(ligne_courante);
            return 1;
        }
    }
    return -1;
}

int WidgetLigne::enleveLigne(int numero_liste)
{
    if(ma_liste.size() > numero_liste && numero_liste >= 0)
    {
        if(ma_liste[numero_liste]->ligne_fiche->contains(ligne_courante))
        {
            ma_liste[numero_liste]->ligne_fiche->removeOne(ligne_courante);
            return 1;
        }
    }
    return -1;
}

void WidgetLigne::ajoutWidgetListe(WidgetListe* ma_widget_liste)
{
    ma_liste.append(ma_widget_liste);
}

void WidgetLigne::ajoutWidgetListe(QAction* a, QString t, QString u)
{
    WidgetListe* tmp = new WidgetListe;
    tmp->mon_action = a;
    tmp->texte = t;
    tmp->chemin_image = u;
    tmp->ligne_fiche = new QList<int>();
    ma_liste.append(tmp);
}

WidgetListe* WidgetLigne::getListe(int numero)
{
    if(numero>=0 && numero < ma_liste.size())
        return ma_liste[numero];
    return NULL;
}

void WidgetLigne::resizeEvent(QResizeEvent *e)
{
    e->accept();
    setFixedHeight(editeur_texte->height());
}

void WidgetLigne::afficheListe(int numero)
{
    if(numero>=0 && numero < ma_liste.size())
        for(int i=0; i<this->getListe(numero)->ligne_fiche->size();i++)
            cout<<this->getListe(numero)->ligne_fiche->value(i)<<ends;
}

void WidgetLigne::miseAJourWidgetListe()
{

    QSettings settings("MYW", "WidgetListe");
    int size = settings.beginReadArray("WidgetListe");
    QString texte[size];
    QString chemin_image[size];
    for (int i = 0; i < size; i++) {
        settings.setArrayIndex(i);
        texte[i] = settings.value(QString("texte")).toString();
        chemin_image[i] = settings.value(QString("chemin_image")).toString();
        WidgetListe* retour = existeListe(texte[i], chemin_image[i]);
        if(!retour)
            ajoutWidgetListe(new QAction(this), texte[i], chemin_image[i]);
    }

    for(int i=0; i<ma_liste.size(); i++)
    {
        bool b = false;
        for(int j = 0; j<size; j++)
        {
            if(ma_liste[i]->texte == texte[j] && ma_liste[i]->chemin_image == chemin_image[j])
                b = true;
        }
        if(!b)
            enleveWidgetListe(ma_liste[i]);
    }

    settings.endArray();
}

WidgetListe* WidgetLigne::existeListe(QString texte, QString chemin_image)
{
    for(int i = 0; i < ma_liste.size(); i++)
        if(ma_liste[i]->texte == texte && ma_liste[i]->chemin_image == chemin_image)
            return ma_liste[i];
    return NULL;
}

void WidgetLigne::enleveWidgetListe(WidgetListe* liste)
{
    ma_liste.removeOne(liste);
}


void WidgetLigne::incrementeLigneListe(int debut,int difference)
{
    if(difference > 0)
    {
        for(int i = 0; i < ma_liste.size(); i++)
        {
            for(int j=0; j<this->getListe(i)->ligne_fiche->size();j++)
            {
                int val = ma_liste[i]->ligne_fiche->value(j);
                if(debut < val)
                {
                    ma_liste[i]->ligne_fiche->replace(j, val+difference);
                }
            }
        }
    }
    else if(difference < 0)
    {
        for(int i = 0; i < ma_liste.size(); i++)
        {
            for(int j=0; j<this->getListe(i)->ligne_fiche->size();j++)
            {
                int val = ma_liste[i]->ligne_fiche->value(j);
                if(debut <= val)
                {
                    ma_liste[i]->ligne_fiche->replace(j, val+difference);
                }
            }
        }
    }
    repaint();
}
