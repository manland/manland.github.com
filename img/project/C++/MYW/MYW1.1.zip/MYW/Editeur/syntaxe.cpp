#include <iostream>
#include <QTextCursor>
#include <QStack>
#include <QRegExp>
using namespace std;

#include "syntaxe.h"


//constructeur du verificateur de syntaxe
Syntaxe::Syntaxe(QTextEdit* e, QWidget* parent):editeur(e),QWidget(parent)
{
    connect(editeur->document(), SIGNAL(contentsChange(int, int,int)), this, SLOT(texteChange(int, int, int)));
    connect(editeur,SIGNAL(cursorPositionChanged( )), this, SLOT(curseurBouge()));
    surligne = new QTextCursor();
    listeSouligne = QList<QTextCursor>();
    bloc = QList<QTextCursor>();
    compteur = 0;
}

//verifie la correction syntaxique
void Syntaxe::verification(QString s, int deb, int fin)
{
    QStack<QChar> attendu;
    QTextCursor curseur(editeur->document());

    //enlever tous les soulignements
    QTextCharFormat souligne;
    souligne.setFontUnderline(false);
    QTextCursor item;
    while(!listeSouligne.isEmpty())
    {
        item = listeSouligne.first();
        item.mergeCharFormat(souligne);
        listeSouligne.removeFirst();
    }

    curseur.setPosition(deb);
    for(int i = deb; i<fin; i++)
    {
        QChar c = s[i];

        if(c=='(')
        {
            attendu.push(')');
        }
        else if(c=='{')
        {
            attendu.push('}');
        }
        else if(c=='[')
        {
            attendu.push(']');
        }
        else if(c==')' || c=='}' || c==']')
        {
            if(attendu.isEmpty() || attendu.top() != c)
            {
                souligneErreur(curseur);
            }
            else
            {
                attendu.pop();
            }
        }
        curseur.setPosition(curseur.position()+1);
    }
}

//souligne en erreur la ligne ou le curseur est positionn�
void Syntaxe::souligneErreur(QTextCursor curseur)
{
    if(!curseur.isNull())
    {
         QTextCharFormat souligne;
         souligne.setFontUnderline(true);
         souligne.setUnderlineStyle(QTextCharFormat::WaveUnderline);
         souligne.setUnderlineColor(Qt::red);
         curseur. movePosition(QTextCursor::StartOfLine);
         curseur.movePosition(QTextCursor::EndOfLine,QTextCursor::KeepAnchor);
         curseur.mergeCharFormat(souligne);
         listeSouligne.push_back(curseur);
     }
}

//grise le bloc de la parenth�se ou accolade a cot� du curseur
void Syntaxe::surligneBloc(QTextCursor* curseur, int pas, QRegExp debut, QRegExp fin, int longueur_deb, int longueur_fin)
{
    QString contenu = editeur->toPlainText();
    curseur->setPosition(editeur->textCursor().position());
    int ind = curseur->position();
    int bon = -1;
    bool pastrouve = true;
    while(ind <= contenu.length() && ind >= 0 && pastrouve)
    {
        if(fin.exactMatch(contenu.mid(ind,longueur_fin)))
        {
            if(bon == 0)
            {
                pastrouve = false;
                if(pas<0)
                {
                    ind++;
                }
                else
                {
                    ind = ind + longueur_fin - pas;
                }
            }
            else
                bon--;
        }
        else if(debut.exactMatch(contenu.mid(ind,longueur_deb)))
        {
            bon++;
        }
        ind += pas;
    }
    if(!pastrouve)
    {
        curseur->setPosition(ind, QTextCursor::KeepAnchor);
        QTextCharFormat grise;
        grise.setBackground(Qt::gray);
        curseur->mergeCharFormat(grise);
        surligne = curseur;
    }
}


//--------------------------------------------------------------------------------------
// slots
//--------------------------------------------------------------------------------------

//fonction appel�e quand le texte de l'�diteur change, lance la verification syntaxique du texte
void Syntaxe::texteChange(int pos, int ajout, int enleve)
{
    QString s = editeur->toPlainText();
    if(!s.isEmpty() && (ajout != 0 || enleve != 0))
    {
            verification(s,0,s.size());
    }
}

void Syntaxe::curseurBouge()
{

    QTextCursor* curseur = new QTextCursor(editeur->textCursor());

    //enlever tous les gris�s
    if(surligne)
    {
        QTextCharFormat grise;
        grise.setBackground(Qt::white);
        surligne->mergeCharFormat(grise);
        surligne = NULL;
    }


    curseur->setPosition(editeur->textCursor().position());
    int ind = curseur->position();
    QString contenu = editeur->toPlainText();

    QRegExp debut_php = QRegExp("<\\?php");
    debut_php.setCaseSensitivity(Qt::CaseInsensitive);
    QRegExp debut_parent = QRegExp("\\(");
    QRegExp debut_accol = QRegExp("\\{");
    QRegExp debut_crochet = QRegExp("\\[");

    QRegExp fin_php = QRegExp("\\?>");
    QRegExp fin_parent = QRegExp("\\)");
    QRegExp fin_accol = QRegExp("\\}");
    QRegExp fin_crochet = QRegExp("\\]");

    if(debut_accol.exactMatch(contenu.mid(ind,1)))
    {
        surligneBloc(curseur, 1, debut_accol, fin_accol, 1, 1);

    }
    else if(ind >0 && fin_accol.exactMatch(contenu.mid(ind-1,1)) && !curseur->atStart())
    {
         curseur->setPosition(ind-1);
         surligneBloc(curseur, -1, fin_accol, debut_accol, 1, 1);
    }
    else if(debut_parent.exactMatch(contenu.mid(ind,1)))
    {
        surligneBloc(curseur, 1, debut_parent, fin_parent, 1, 1);

    }
    else if(ind >0 && fin_parent.exactMatch(contenu.mid(ind-1,1)) && !curseur->atStart())
    {
         curseur->setPosition(ind-1);
         surligneBloc(curseur, -1, fin_parent, debut_parent, 1, 1);
    }
    else if(debut_php.exactMatch( contenu.mid(ind,5)))
    {
        surligneBloc(curseur, 1, debut_php, fin_php, 5, 2);
    }
    else if(ind >1 && fin_php.exactMatch( contenu.mid(ind-2,2)) && !curseur->atStart())
    {
         curseur->setPosition(ind-2);
        surligneBloc(curseur, -1, fin_php, debut_php, 2, 5);
    }
}
