#include <QFont>
#include <QKeySequence>
#include <QString>
#include <QWidget>
#include <iostream>
#include <QDebug>
using namespace std;

#include "editeur.h"
#include "syntaxe.h"
#include "coloration.h"
#include "mainwindow.h"
#include "widgetLigne.h"

#include <QPoint>
#include <QPalette>
#include <QColor>
#include <QFile>
#include <QByteArray>
#include <QDataStream>
#include <QHttpRequestHeader>

Editeur::Editeur(QWidget* parent, int t1, int t2)
     : QTextEdit(parent), temps_attente_souris (t1), temps_attente_clavier(t2)
 {
    //connect(http, SIGNAL(stateChanged(int)), this, SLOT(etat(int)));
   // connect(http, SIGNAL(requestFinished(int,bool)), this, SLOT(finRequete(int,bool)));
   // connect(http, SIGNAL(responseHeaderReceived(QHttpResponseHeader)), this, SLOT(reponse(QHttpResponseHeader)));
    initialiseEditeur();

    this->parent = parent;
    connect(this,SIGNAL(cursorPositionChanged()), this, SLOT(changeSelection()));
    this->setMouseTracking(true);
    aide = NULL;
    temps_souris = new QTimer();
    connect(temps_souris, SIGNAL(timeout()), this, SLOT(changeSelectionSouris()));
    temps_clavier = new QTimer();
    connect(temps_clavier, SIGNAL(timeout()), this, SLOT(afficheLabelCurseur()));
    block_sous_souris = NULL;
    /////////////////////////////////////////////////////
    completer = new Completer(this);



 }


 void Editeur::initialiseEditeur()
 {
     QFont font;
     font.setFamily("Courier");
     font.setFixedPitch(true);
     font.setPointSize(11);

     this->setFont(font);
     coloration = new Coloration(this);
     syntaxe = new Syntaxe(this);
 }


 //
 //Je peux la foutre dans afficheLabelCurseur ???????????
 //
 void Editeur::changeSelection()
{
    if(aide != NULL)
    {
        aide->hide();
        aide->close();
        this->selection = "";
    }
    block_sous_souris = NULL;

    if(temps_clavier->isActive())
        temps_clavier->stop();
    temps_clavier->start(temps_attente_clavier);

    QTextCursor curseur = this->textCursor();
    curseur.select(QTextCursor::WordUnderCursor);
    this->selection = curseur.selectedText();
    block_sous_souris = new QTextBlock(curseur.block());
}

void Editeur::afficheLabelCurseur()
{
    temps_clavier->stop();
    afficheLabel();
}

void Editeur::changeSelectionSouris()
{
    QPoint position = position_curseur;
    position.setX(position.x() + 10);
    position.setY(position.y() + 10);
    QTextCursor curseur = this->cursorForPosition(position);
    curseur.select(QTextCursor::WordUnderCursor);
    this->selection = curseur.selectedText();
    //curseur.select(QTextCursor::BlockUnderCursor);
    block_sous_souris = new QTextBlock(curseur.block());
    temps_souris->stop();
    afficheLabel();
}

void Editeur::afficheLabel()
{
    QRegExp expression_reguliere("[a-zA-Z0-9_]*");
    QString tmp = selection;
    tmp.prepend("\\b").append("\\b");
    if(this->hasFocus() && !selection.isEmpty() && expression_reguliere.exactMatch(selection)
        && "rien" != this->coloration->langage(tmp,getBlockSousSouris()) )
    {
        if(aide == NULL)
        {
            QString tmp = selection;
            aide = new FrameAide(tmp.prepend("<font color=\"#2200FF\">").append("</font>"), this);
            aide->move(position_curseur.x() + 10, position_curseur.y() + 10);
        }
        else
        {
            aide->hide();
            aide->close();
            QString tmp = selection;
            aide = new FrameAide(tmp.prepend("<font color=\"#2200FF\">").append("</font>"), this);
            aide->setText(aide->text());
            aide->move(position_curseur.x() + 10, position_curseur.y() + 10);
        }
    }
}

void Editeur::ouvrirNavigateurInternet(QString url)
{
    MainWindow * mw = dynamic_cast<MainWindow*>(parent->parentWidget()->parentWidget()->parentWidget());
    if(!selection.isEmpty() && mw)
    {
        mw->getWebBrowser()->chargerPage(url, 1);
        mw->getWebBrowser()->show();
    }
}

QString Editeur::recupereUrl()
{
    QRegExp expression_reguliere("[a-zA-Z0-9_]*");
    QString url = selection;
    QString tmp = selection;
    QString type;
    tmp.prepend("\\b").append("\\b");
    if(this->hasFocus() && !selection.isEmpty() && expression_reguliere.exactMatch(selection) )
    {
        type = this->coloration->langage(tmp,getBlockSousSouris());
        if(type == "php")
            url.prepend("$:");
        else if(type == "javascript")
            url.prepend("js:");
        else
            url = "";
    }
    else
        url = "";
    return url;
}

void Editeur::mouseMoveEvent(QMouseEvent* evenement)
{
    if(temps_souris->isActive())
        temps_souris->stop();
    temps_souris->start(temps_attente_souris);
    this->position_curseur = evenement->pos();

    if(aide != NULL)
    {
        aide->hide();
        aide->close();
        this->selection = "";
    }
    block_sous_souris = NULL;
    QTextEdit::mouseMoveEvent(evenement);
}

void Editeur::setNombreCaractere(int nombre_caractere) { this->nombre_caractere = nombre_caractere ; }
void Editeur::setNombreLigne(int nombre_ligne) { this->nombre_ligne = nombre_ligne ; }
void Editeur::setNombreCaractereSansEspace(int nombre_caractere) { this->nombre_caractere_sans_espace = nombre_caractere; }
void Editeur::setWidgetLigne(WidgetLigne* w) { this->widget_ligne = w; }

int Editeur::getNombreCaractere() { return this->nombre_caractere; }
int Editeur::getNombreLigne() { return this->nombre_ligne; }
int Editeur::getNombreCaractereSansEspace() { return this->nombre_caractere_sans_espace; }
QTextBlock* Editeur::getBlockSousSouris() { return this->block_sous_souris; }


void Editeur::changeNombreCaractere()
{
    QRegExp rx("[^ \n\t]");
    QString texte = this->toPlainText();
    nombre_caractere = texte.count();
    nombre_ligne = texte.count("\n");
    if(nombre_caractere != 0)
        nombre_ligne += 1;
    nombre_caractere_sans_espace = texte.count(rx);
}

Coloration* Editeur::getColoration()
{
    return coloration;
}

void Editeur::keyPressEvent(QKeyEvent* evenement)
{
    ligne_curseur = textCursor().blockNumber() + 1;
    //----------------------------MODIFIER-PAR-WilloW--POUR-Le completer------------------------------
    bool isShortcut = ((evenement->modifiers() & Qt::ControlModifier) && evenement->key() == Qt::Key_Space);

    if(!(isShortcut) && (evenement->key()==Qt::Key_Space || evenement->key()==Qt::Key_Enter || evenement->key()==Qt::Key_Return))
    {
        completer->verifVariable();
    }

    if (completer && completer->popup()->isVisible())
    {
       switch (evenement->key()) {
       case Qt::Key_Enter:
       case Qt::Key_Return:
       case Qt::Key_Escape:
       case Qt::Key_Tab:
       case Qt::Key_Backtab:
            evenement->ignore();
            return;
       default:
           break;
       }
    }

    if (!isShortcut || !completer)
    {
        QTextEdit::keyPressEvent(evenement);
    }

    //----------------------------MODIFIER-PAR-WilloW--fin------------------------------

    if(evenement->key() == Qt::Key_F1)
    {
        if(aide != NULL)
        {
            aide->hide();
            aide->close();
        }
        QString url = this->recupereUrl();
        if(!url.isEmpty())
            ouvrirNavigateurInternet(url);
        this->selection = "";
    }

    //----------------------------MODIFIER-PAR-WilloW--POUR-Le completer------------------------------
    completer->activeComplete(evenement);
    //----------------------------MODIFIER-PAR-WilloW--fin------------------------------
}

void Editeur::mousePressEvent(QMouseEvent* e)
{
    setFocus();
    QTextEdit::mousePressEvent(e);
}

void Editeur::keyReleaseEvent(QKeyEvent* e)
{
    int nb_ligne_avant = getNombreLigne();
    changeNombreCaractere();
    int nb_ligne_apres = getNombreLigne();
    int difference = nb_ligne_apres - nb_ligne_avant;
    if(difference != 0)
    {
        widget_ligne->incrementeLigneListe(ligne_curseur, difference);
    }
}


void Editeur::setMargins(int l, int r, int t, int b)
{
    setViewportMargins(l, r, t, b);
}

    //----------------------------MODIFIER-PAR-WilloW--POUR-Le completer------------------------------

Completer* Editeur::getCompleter() const
{
    return completer;
}


//void Editeur::focusInEvent(QFocusEvent *e)
//{
////    if (completer)
////    {
//        completer->setWidget(this);
////    }
//    QTextEdit::focusInEvent(e);
//}

void Editeur::miseAJourCompleter()
{
    completer->mettreAJourListe();
}
    //----------------------------MODIFIER-PAR-WilloW--fin------------------------------
