#include <QFont>
#include <QRegExp>
#include <QString>
#include <QStringList>
#include <QSyntaxHighlighter>
#include <QFile>
#include <iostream>
#include <QIODevice>
#include <QTextStream>
#include <QTextCursor>
#include <QChar>
using namespace std;
#include "coloration.h"
#include "syntaxe.h"
#include "mesConfigs.h"
#include "editeur.h"
#include <QSettings>


 Coloration :: Coloration(Editeur *parent)
     : QSyntaxHighlighter(parent)
 {     
     this->editeur=parent;
    //bloc=new QTextBlock;
    bloc_php=new QTextBlock;
    bloc_javascript=new QTextBlock;
    bloc_css=new QTextBlock;
    bloc_html=new QTextBlock;

     est_php_selectionne=false;
     est_css_selectionne=false;
     est_javascript_selectionne=false;
     est_html_selectionne=false;
     est_automatique_selectionne=true;

     est_fichier_php= false;
     est_fichier_javascript= false;
     est_fichier_html= false;
     est_fichier_css= false;

    initialiserFormats();

     // permet de restaurer les formats choisit precedement dans le widget ChangerColoration
     restaurer();

    if(format_mots_cle_php1.foreground().color()==QColor(0,0,0) && format_mots_cle_css1.foreground().color()==QColor(0,0,0) && format_mots_cle_javascript1.foreground().color()==QColor(0,0,0) && format_quote.foreground().color()==QColor(0,0,0))
     {
        initialiserFormats();
    }




     rule.expression_reg = QRegExp("<!--[^-->]+-->");
     rule.format = format_commentaire_multiple;
     regles_coloration.append(rule);

     rule.expression_reg = QRegExp("/\\*[^\\*/]+\\*/");
     rule.format = format_commentaire_multiple;
     regles_coloration.append(rule);


     rule.expression_reg = QRegExp("//[^\n]*");
     rule.format = format_commentaire_simple;
     regles_coloration.append(rule);


     rule.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
     rule.format = format_fonction;
     regles_coloration.append(rule);


     rule.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
     rule.format = format_Ecommecial;
     regles_coloration.append(rule);

     rule.expression_reg = QRegExp("\"[^\"]+\"");
     rule.format = format_quote;
     regles_coloration.append(rule);

     rule.expression_reg = QRegExp("\'[^\']+\'");
     rule.format = format_quote;
     regles_coloration.append(rule);


     debut_commentaire = QRegExp("/\\*");
     fin_commentaire = QRegExp("\\*/");

     debut_commentaire_html=QRegExp("<!--");
     fin_commentaire_html = QRegExp("-->");

     debut_php=QRegExp("<\\?php");
     debut_php.setCaseSensitivity(Qt::CaseInsensitive);

     debut_css=QRegExp("<STYLE type=\"text/css\"");
     fin_css=QRegExp("</STYLE>");
     debut_css.setCaseSensitivity(Qt::CaseInsensitive);
     fin_css.setCaseSensitivity(Qt::CaseInsensitive);

     debut_javascript1=QRegExp("<SCRIPT langage=\"Javascript\"");
     fin_javascript1=QRegExp("</SCRIPT>");
      debut_javascript2=QRegExp("<SCRIPT type=\"text/javascript\"");
     debut_javascript1.setCaseSensitivity(Qt::CaseInsensitive);
     debut_javascript2.setCaseSensitivity(Qt::CaseInsensitive);
     fin_javascript1.setCaseSensitivity(Qt::CaseInsensitive);




    // initialisation des langages
     initialisationPhp();
     initialisationCss();
     initialisationJavascript();
     initialisationHtml();
 }

void Coloration :: initialiserFormats()
{
    // -----------------------------------------
     //     implementation des formats :
     // -----------------------------------------
     format_quote.setForeground(Qt::darkGreen);
     format_commentaire_multiple.setForeground(Qt::lightGray);
     format_commentaire_multiple.setFontItalic(true);
     format_commentaire_simple.setForeground(Qt::gray);
     format_commentaire_simple.setFontItalic(true);
     format_fonction.setForeground(Qt::blue);
     format_fonction.setFontItalic(true);
     format_Ecommecial.setForeground(Qt::magenta);
     format_Ecommecial.setFontItalic(true);
     format_variables_php.setForeground(Qt::magenta);
     format_variables_php.setFontItalic(true);
     format_mots_cle_php1.setForeground(Qt::darkYellow);
     format_mots_cle_php1.setFontWeight(QFont::Bold);
     format_mots_cle_php2.setForeground(Qt::black);
     format_mots_cle_php2.setFontWeight(QFont::Bold);
     format_mots_cle_php3.setForeground(Qt::darkMagenta);
     format_mots_cle_php3.setFontWeight(QFont::Bold);

     format_mots_cle_javascript1.setForeground(Qt::black);
     format_mots_cle_javascript1.setFontWeight(QFont::Bold);
     format_mots_cle_javascript2.setForeground(QColor(189,140,42));
     format_mots_cle_javascript2.setFontWeight(QFont::Bold);
     format_mots_cle_javascript3.setForeground(Qt::green);
     format_mots_cle_javascript3.setFontWeight(QFont::Bold);

     format_mots_cle_css1.setForeground(QColor(22,160,90));
     format_mots_cle_css1.setFontWeight(QFont::Bold);
     format_mots_cle_css2.setForeground(QColor(100,32,112));
     format_mots_cle_css2.setFontWeight(QFont::Bold);

     format_balise_html.setForeground(QColor(47,112,127));
     format_balise_html.setFontWeight(QFont::Bold);
     format_attributs_html.setForeground(QColor(192,16,112));
     format_attributs_html.setFontWeight(QFont::Bold);
}

void Coloration :: initialisationPhp()
{
     rule_php.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
     rule_php.format = format_fonction;
     regles_coloration_php.append(rule_php);

     // coloration des variables php
     rule_php.expression_reg = QRegExp("\\$[^_][A-Za-z0-9_]*");      // $ suivi de lettres ou de chiffres de _ mais ne doit pas commencer par _
     rule_php.format = format_variables_php;
     regles_coloration_php.append(rule_php);

     rule_php.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
     rule_php.format = format_Ecommecial;
     regles_coloration_php.append(rule_php);



     // initialisation de la coloration pour le langage php
      ajouteMotCleFichier(QString("fichiers/mot_cle_php1.txt").prepend(systeme_relation_fichier),mots_cle_php1,format_mots_cle_php1);
      ajouteMotCleFichier(QString("fichiers/mot_cle_php2.txt").prepend(systeme_relation_fichier),mots_cle_php2,format_mots_cle_php2);
      ajouteMotCleFichier(QString("fichiers/mot_cle_php3.txt").prepend(systeme_relation_fichier),mots_cle_php3,format_mots_cle_php3);
      ajouteMotCleFichier(QString("fichiers/mot_cle_php4.txt").prepend(systeme_relation_fichier),mots_cle_php4,format_mots_cle_php3);
      ajouteMotCleFichier(QString("fichiers/mot_cle_php5.txt").prepend(systeme_relation_fichier),mots_cle_php5,format_mots_cle_php3);

     rule_php.expression_reg = QRegExp("/\\*[^\\*/]+\\*/");
     rule_php.format = format_commentaire_multiple;
     regles_coloration_php.append(rule_php);

      rule_php.expression_reg = QRegExp("[^\\\"]*[^\\*/]+\\*/");
     rule_php.format = format_commentaire_multiple;
     regles_coloration_php.append(rule_php);


     rule_php.expression_reg = QRegExp("\\#[^\n]*");      // # => commentaire php, equivalent a //
     rule_php.format = format_commentaire_simple;
     regles_coloration_php.append(rule_php);

     rule_php.expression_reg = QRegExp("//[^\n]*");
     rule_php.format = format_commentaire_simple;
     regles_coloration_php.append(rule_php);

     rule_php.expression_reg = QRegExp("\"[^\"]+\"");
     rule_php.format = format_quote;
     regles_coloration_php.append(rule_php);

     rule_php.expression_reg = QRegExp("\'[^\']+\'");
     rule_php.format = format_quote;
     regles_coloration_php.append(rule_php);

 }

void Coloration :: initialisationCss()
{
    rule_css.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
     rule_css.format = format_Ecommecial;
     regles_coloration_css.append(rule_css);

      rule_css.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
     rule_css.format = format_fonction;
     regles_coloration_css.append(rule_css);

     // initialisation de la coloration pour le langage css
  ajouteMotCleFichier(QString("fichiers/mot_cle_css1.txt").prepend(systeme_relation_fichier),mots_cle_css1,format_mots_cle_css1);
  ajouteMotCleFichier(QString("fichiers/mot_cle_css2.txt").prepend(systeme_relation_fichier),mots_cle_css2,format_mots_cle_css2);


     rule_css.expression_reg = QRegExp("\"[^\"]+\"");
     rule_css.format = format_quote;
     regles_coloration_css.append(rule_css);

     rule_css.expression_reg = QRegExp("\'[^\']+\'");
     rule_css.format = format_quote;
     regles_coloration_css.append(rule_css);

     rule_css.expression_reg = QRegExp("/\\*[^\\*]+\\*/");
     rule_css.format = format_commentaire_multiple;
     regles_coloration_css.append(rule_css);
     
      rule_css.expression_reg = QRegExp("[^\\\"]*[^\\*/]+\\*/");
     rule_css.format = format_commentaire_multiple;
     regles_coloration_css.append(rule_css);

     rule_css.expression_reg = QRegExp("//[^\n]*");
     rule_css.format = format_commentaire_simple;
     regles_coloration_css.append(rule_css);
}

void Coloration :: initialisationJavascript()
{
     rule_javascript.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
     rule_javascript.format = format_Ecommecial;
     regles_coloration_javascript.append(rule_javascript);

      rule_javascript.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
     rule_javascript.format = format_fonction;
     regles_coloration_javascript.append(rule_javascript);

     // initialisation de la coloration pour le langage javascript
  ajouteMotCleFichier(QString("fichiers/mot_cle_javascript1.txt").prepend(systeme_relation_fichier),mots_cle_javascript1,format_mots_cle_javascript1);
  ajouteMotCleFichier(QString("fichiers/mot_cle_javascript2.txt").prepend(systeme_relation_fichier),mots_cle_javascript2,format_mots_cle_javascript2);
  ajouteMotCleFichier(QString("fichiers/mot_cle_javascript3.txt").prepend(systeme_relation_fichier),mots_cle_javascript3,format_mots_cle_javascript3);



     rule_javascript.expression_reg = QRegExp("\"[^\"]+\"");
     rule_javascript.format = format_quote;
     regles_coloration_javascript.append(rule_javascript);

     rule_javascript.expression_reg = QRegExp("\'[^\']+\'");
     rule_javascript.format = format_quote;
     regles_coloration_javascript.append(rule_javascript);

      rule_javascript.expression_reg = QRegExp("[^\\\"]*[^\\*/]+\\*/");
     rule_javascript.format = format_commentaire_multiple;
     regles_coloration_javascript.append(rule_javascript);

     rule_javascript.expression_reg =  QRegExp("/\\*[^\\*]+\\*/");;
     rule_javascript.format = format_commentaire_multiple;
     regles_coloration_javascript.append(rule_javascript);

     rule_javascript.expression_reg = QRegExp("//[^\n]*");
     rule_javascript.format = format_commentaire_simple;
     regles_coloration_javascript.append(rule_javascript);
}

void Coloration :: initialisationHtml()
{
     rule_html.expression_reg = QRegExp("\"[^\"]+\"");
     rule_html.format = format_quote;
     regles_coloration_html.append(rule_html);

     rule_html.expression_reg = QRegExp("\'[^\']+\'");
     rule_html.format = format_quote;
     regles_coloration_html.append(rule_html);

     ajouteMotCleBalisesFermantes(QString("fichiers/html_balises_fermantes.txt").prepend(systeme_relation_fichier),html_balises_fermantes,format_balise_html);
      ajouterMotCleBalises(QString("fichiers/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier),html_balises_non_fermantes,format_balise_html);
      ajouterMotCleBalises(QString("fichiers/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier),html_balises_ouvrantes,format_balise_html);
      ajouteMotCleFichier(QString("fichiers/attribut_html.txt").prepend(systeme_relation_fichier),attributs_html,format_attributs_html);


     rule_html.expression_reg = QRegExp("<!--( *<?/*[a-zA-Z0-9\"\'_&*\?.!/]*>? *)*-->");
     rule_html.format = format_commentaire_multiple;
     regles_coloration_html.append(rule_html);
     rule_html.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
     rule_html.format = format_Ecommecial;
     regles_coloration_html.append(rule_html);

     rule_html.expression_reg = QRegExp("/\\*[^\\*]+\\*/");
     rule_html.format = format_commentaire_multiple;
     regles_coloration_html.append(rule_html);

     rule_html.expression_reg = QRegExp("//[^\n]*");
     rule_html.format = format_commentaire_simple;
     regles_coloration_html.append(rule_html);
}


// fonction deja presente a surcharger en fonction de ce qu'on veut rajouter
 void Coloration::highlightBlock(const QString &text)
{
    editeur->getCompleter()->mettreAJourListe();

    if(est_automatique_selectionne)
    {
        etat = previousBlockState();
        int debut = 0;
        for (int i = 0; i < text.length(); ++i)
        {
            if (etat == php)
            {
                if(text.mid(i,2)=="/*")
                {
                    debut=i;
                    etat=commentaire_multiple_php;
                }
               else  if(text.mid(i,1)=="\"")
                {
                    debut=i;
                    etat=quote_php;
                }
               if(text.mid(i,2)=="*/")
                {
                    debut=i;
                    setFormat(debut,text.length(),Qt::green );
                    break;
                    //etat=commentaire_multiple_php;
                }
                else if (text.mid(i, 2) == "\?>")
                {
                    etat=normal;
                }
            }
            else if(etat== commentaire_multiple_php)
            {
                if (text.mid(i, 2) == "*/")
                {
                    etat = php;
                    setFormat(debut, i - debut + 2, format_commentaire_multiple);
                }
            }
            else if(etat== quote_php)
            {
                if (text.mid(i, 1) == "\"")
                {
                    etat = php;
                    setFormat(debut, i - debut + 1, format_quote);
                }
            }
            else if (etat == javascript)
            {
                if(text.mid(i,2)=="/*")
                {
                    debut=i;
                    etat=commentaire_multiple_javascript;
                }
                if(text.mid(i,1)=="\"")
                {
                    debut=i;
                    etat=quote_javascript;
                }
                if (fin_javascript1.exactMatch(text.mid(i, 9)))
                {
                    etat = normal;
                }

            }
            else if(etat== commentaire_multiple_javascript)
            {
                if (text.mid(i, 2) == "*/")
                {
                    etat = javascript;
                    setFormat(debut, i - debut + 2, format_commentaire_multiple);
                }
            }
            else if(etat== quote_javascript)
            {
                if (text.mid(i, 1) == "\"")
                {
                    etat = javascript;
                    setFormat(debut, i - debut + 1, format_quote);
                }
            }
            else if (etat == css)
            {
                if(text.mid(i,2)=="/*")
                {
                    debut=i;
                    etat=commentaire_multiple_css;
                }
               if(text.mid(i,1)=="\"")
                {
                    debut=i;
                    etat=quote_css;
                }
                if (fin_css.exactMatch(text.mid(i, 8)))
                {
                    etat = normal;
                }
            }
            else if(etat== commentaire_multiple_css)
            {
                if (text.mid(i, 2) == "*/")
                {
                    etat = css;
                    setFormat(debut, i - debut + 2, format_commentaire_multiple);
                }
            }
            else if(etat== quote_css)
            {
                if (text.mid(i, 1) == "\"")
                {
                    etat = css;
                    setFormat(debut, i - debut + 1, format_quote);
                }
            }
            else if(etat == quote)
            {
                if (text.mid(i, 1) == "\"")
                {
                    etat =normal;
                    setFormat(debut, i - debut + 1, format_quote);
                }
            }
            else if(etat == commentaire_multiple_html)
            {
                if (text.mid(i, 3) == "-->")
                {
                    etat = normal;
                    setFormat(debut, i - debut + 3, format_commentaire_multiple);
                }
            }
            else if(etat == commentaire_multiple)
            {
                if (text.mid(i, 2) == "*/")
                {
                    etat = normal;
                    setFormat(debut, i - debut + 2, format_commentaire_multiple);
                }
            }
            else
            {
                if (text.mid(i, 2) == "//")
                {
                    setFormat(i, text.length() - i, format_commentaire_simple);
                    break;
                }
                else if (text.mid(i, 1) == "\"")
                {
                    debut = i;
                    etat=quote;
                }
                else if (text.mid(i, 2) == "/*")
                {
                    debut = i;
                    etat=commentaire_multiple;
                }
                else if(text.mid(i,4)=="<!--")
                {
                    debut = i;
                    etat=commentaire_multiple_html;
                }
                else if(debut_php.exactMatch(text.mid(i,5)))
                {
                    debut = i;
                    bloc_php->setUserState(php);
                    etat=php;
                }
                else if (debut_javascript1.exactMatch(text.mid(i, 28)) || debut_javascript2.exactMatch(text.mid(i,30)))
                {
                    debut = i;
                    bloc_javascript->setUserState(javascript);
                    etat = javascript;
                }
                else if (debut_css.exactMatch(text.mid(i, 22)))
                {
                    debut = i;
                    bloc_css->setUserState(css);
                    etat = css;
                }
                else
                {
                    foreach (ReglesColoration rule, regles_coloration_balise_html_fermantes)
                             {
                                 QRegExp expression(rule.expression_reg);
                                 int index = text.indexOf(expression);
                                 while (index >= 0)
                                 {
                                     int length = expression.matchedLength();
                                     setFormat(index, length, rule.format);
                                     index = text.indexOf(expression, index + length);
                                 }
                             }
                            foreach (ReglesColoration rule, regles_coloration_balise_html)
                             {
                                 QRegExp expression(rule.expression_reg);
                                 int index = text.indexOf(expression);
                                 while (index >= 0)
                                 {
                                     int length = expression.matchedLength();
                                     setFormat(index, length+1, rule.format);
                                     index = text.indexOf(expression, index + length);
                                 }
                             }
                            foreach (ReglesColoration rule, regles_coloration_html)
                             {
                                 QRegExp expression(rule.expression_reg);
                                 int index = text.indexOf(expression);
                                 while (index >= 0)
                                 {
                                     int length = expression.matchedLength();
                                     setFormat(index, length, rule.format);
                                     index = text.indexOf(expression, index + length);
                                 }
                             }
                             foreach (ReglesColoration rule, regles_coloration)
                             {
                                 QRegExp expression(rule.expression_reg);
                                 int index = text.indexOf(expression);
                                 while (index >= 0)
                                 {
                                     int length = expression.matchedLength();
                                     setFormat(index, length, rule.format);
                                     index = text.indexOf(expression, index + length);
                                 }
                             }
                }
            }
        }
        if(etat==quote)
        {
            setFormat(debut, text.length() - debut, format_quote);
        }
        if(etat==commentaire_multiple_html || etat==commentaire_multiple)
        {
            setFormat(debut, text.length() - debut, format_commentaire_multiple);
        }
        if(etat==commentaire_multiple_php || etat==commentaire_multiple_javascript || etat==commentaire_multiple_css)
        {
            setFormat(debut, text.length()-debut, format_commentaire_multiple);
        }
        if (etat == php)
        {
            foreach (ReglesColoration rule, regles_coloration_php)
             {
                 QRegExp expression(rule.expression_reg);
                 int index = text.indexOf(expression);
                 while (index >= 0)
                 {
                     int length = expression.matchedLength();
                     setFormat(index, length, rule.format);
                     index = text.indexOf(expression, index + length);
                 }
             }
        }
        if (etat == javascript)
        {
            foreach (ReglesColoration rule, regles_coloration_javascript)
             {
                 QRegExp expression(rule.expression_reg);
                 int index = text.indexOf(expression);
                 while (index >= 0)
                 {
                     int length = expression.matchedLength();
                     setFormat(index, length, rule.format);
                     index = text.indexOf(expression, index + length);
                 }
             }
        }
        if (etat == css)
        {
                foreach (ReglesColoration rule, regles_coloration_css)
                 {
                     QRegExp expression(rule.expression_reg);
                     int index = text.indexOf(expression);
                     while (index >= 0)
                     {
                         int length = expression.matchedLength();
                         setFormat(index, length, rule.format);
                         index = text.indexOf(expression, index + length);
                     }
                 }
            }
        setCurrentBlockState(etat);
}

    if(est_php_selectionne==true)
    {
        colorerPhp(text);
    }
    if(est_css_selectionne==true)
    {
        colorerCss(text);
    }
    if(est_javascript_selectionne==true)
    {
        colorerJavascript(text);
    }

// partie concerant les fichiers dont les extension sont .php, .js, .css
     if(est_fichier_php==true)
     {
        etat = previousBlockState();
        int debut = 0;
        for (int i = 0; i < text.length(); ++i)
        {
                if(etat == quote)
                {
                    if (text.mid(i, 1) == "\"")
                    {
                        etat = normal;
                        setFormat(debut, i - debut + 1, format_quote);
                    }
                }
                else if(etat == commentaire_multiple)
                {
                    if (text.mid(i, 2) == "*/")
                    {
                        etat = normal;
                        setFormat(debut, i - debut + 2, format_commentaire_multiple);
                    }
                }
               else
               {
                   if (text.mid(i, 2) == "//")
                   {
                       setFormat(i, text.length() - i, format_commentaire_simple);
                       break;
                   }
                   else if (text.mid(i, 1) == "\"")
                   {
                       debut = i;
                       etat=quote;
                   }
                   else if (text.mid(i, 2) == "/*")
                   {
                       debut = i;
                       etat=commentaire_multiple;
                   }
               }
           }
            colorerPhp(text);
            if(etat==quote)
            {
                setFormat(debut, text.length() - debut, format_quote);
            }
            if(etat==commentaire_multiple_html || etat==commentaire_multiple)
            {
                setFormat(debut, text.length() - debut, format_commentaire_multiple);
            }
             setCurrentBlockState(etat);
     }
     if(est_fichier_css==true)
     {
        etat = previousBlockState();
        int debut = 0;
        for (int i = 0; i < text.length(); ++i)
        {
                if(etat == quote)
                {
                    if (text.mid(i, 1) == "\"")
                    {
                        etat = normal;
                        setFormat(debut, i - debut + 1, format_quote);
                    }
                }
                else if(etat == commentaire_multiple)
                {
                    if (text.mid(i, 2) == "*/")
                    {
                        etat = normal;
                        setFormat(debut, i - debut + 2, format_commentaire_multiple);
                    }
                }
               else
               {
                   if (text.mid(i, 2) == "//")
                   {
                       setFormat(i, text.length() - i, format_commentaire_simple);
                       break;
                   }
                   else if (text.mid(i, 1) == "\"")
                   {
                       debut = i;
                       etat=quote;
                   }
                   else if (text.mid(i, 2) == "/*")
                   {
                       debut = i;
                       etat=commentaire_multiple;
                   }
               }
           }
           colorerCss(text);
           if(etat==quote)
           {
               setFormat(debut, text.length() - debut, format_quote);
           }
           if(etat==commentaire_multiple_html || etat==commentaire_multiple)
           {
               setFormat(debut, text.length() - debut, format_commentaire_multiple);
           }
           setCurrentBlockState(etat);
     }
     if(est_fichier_javascript==true)
     {
          etat = previousBlockState();
        int debut = 0;
        for (int i = 0; i < text.length(); ++i)
        {
                if(etat == quote)
                {
                    if (text.mid(i, 1) == "\"")
                    {
                        etat = normal;
                        setFormat(debut, i - debut + 1, format_quote);
                    }
                }
                else if(etat == commentaire_multiple)
                {
                    if (text.mid(i, 2) == "*/")
                    {
                        etat = normal;
                        setFormat(debut, i - debut + 2, format_commentaire_multiple);
                    }
                }
               else
               {
                   if (text.mid(i, 2) == "//")
                   {
                       setFormat(i, text.length() - i, format_commentaire_simple);
                       break;
                   }
                   else if (text.mid(i, 1) == "\"")
                   {
                       debut = i;
                       etat=quote;
                   }
                   else if (text.mid(i, 2) == "/*")
                   {
                       debut = i;
                       etat=commentaire_multiple;
                   }
               }
           }
           colorerJavascript(text);
           if(etat==quote)
           {
               setFormat(debut, text.length() - debut, format_quote);
           }
           if(etat==commentaire_multiple_html || etat==commentaire_multiple)
           {
               setFormat(debut, text.length() - debut, format_commentaire_multiple);
           }
           setCurrentBlockState(etat);
     }

 }


 // fonction permettant d'ajouter les mots cl�s d'un fichier dans une liste de mots cl�
 QString Coloration :: renvoieListe(QStringList &liste)
 {
     QString resultat;
     if(liste==mots_cle_php1 || liste == mots_cle_php2 || liste == mots_cle_php3 || liste == mots_cle_php4 || liste == mots_cle_php5)
     {
         resultat="php";
     }
     else if (liste == mots_cle_javascript1 || liste == mots_cle_javascript2 || liste == mots_cle_javascript3)
     {
         resultat="javascript";
     }
     else if (liste == mots_cle_css1 || liste == mots_cle_css2)
     {
         resultat="css";
     }
     else if (liste==html_balises_non_fermantes || liste==html_balises_ouvrantes)
     {
         resultat="html_balise";
     }
     else if( liste==attributs_html)
     {
         resultat="attributs_html";
     }
     else if( liste==html_balises_fermantes)
     {
         resultat="html_balise_fermante";
     }
     else
     {
         resultat="rien";
     }
     return resultat;
 }


 // fonction permettant d'ajouter les mots cl�s d'un fichier dans une liste de mots cl�, permet d'initialiser les langages
 void Coloration :: ajouteMotCleFichier(const QString &chemin,QStringList &liste,QTextCharFormat format)
 {
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // le fichier n'existe pas
        cout<< "le fichie n'existe pas." <<endl;
    }

  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice::ReadOnly) )
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }

    QString fic= fichier.readAll().trimmed();     // permet d'enlever les caracteres de fins de ligne (entre autre)

    QStringList list = fic.split("|");
    QString ajout = "\\b";
    QString a;
    foreach(QString s, list)
    {        
        QRegExp exp(s,Qt::CaseInsensitive);
   //     cout<<exp.pattern().toStdString()<<endl;
        exp.setCaseSensitivity(Qt::CaseInsensitive);
        a=exp.pattern();
        a.replace(a,ajout+a+ajout);
   //     cout<<a.toStdString()<<endl;
        liste.push_back(a);
    }


    // permet de donner les regles de coloration a la liste
    if(renvoieListe(liste)=="php")
    {
        foreach (QString expression_reg, liste)
        {
            rule.expression_reg = QRegExp(expression_reg);
            rule.format = format;
            regles_coloration_php.append(rule);
         }
    }
    else if(renvoieListe(liste)=="javascript")
    {
         foreach (QString expression_reg, liste)
        {
            rule_javascript.expression_reg = QRegExp(expression_reg);
            rule_javascript.format = format;
            regles_coloration_javascript.append(rule_javascript);
         }
    }
    else if(renvoieListe(liste)=="css")
    {
         foreach (QString expression_reg, liste)
        {
            rule_css.expression_reg = QRegExp(expression_reg);
            rule_css.format = format;
            regles_coloration_css.append(rule_css);
         }
    }
    else if(renvoieListe(liste)=="attributs_html")
    {
         foreach (QString expression_reg, liste)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format;
            regles_coloration_html.append(rule_html);
         }
    }
    else
    {
         foreach (QString expression_reg, liste)
        {
            rule.expression_reg = QRegExp(expression_reg);
            rule.format = format;
            regles_coloration.append(rule);
         }
    }
     fichier.close();
 }


 void Coloration :: ajouteMotCleBalisesFermantes(const QString &chemin,QStringList &liste,QTextCharFormat format)
 {
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // le fichier n'existe pas
        cout<< "le fichie n'existe pas." <<endl;
    }

  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice::ReadOnly) )
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }

    QString fic= fichier.readAll().trimmed();     // permet d'enlever les caracteres de fins de ligne (entre autre)

    QStringList list = fic.split("|");
    QString a;
    foreach(QString s, list)
    {
        QRegExp exp(s,Qt::CaseInsensitive);
   //     cout<<exp.pattern().toStdString()<<endl;
        exp.setCaseSensitivity(Qt::CaseInsensitive);
        a=exp.pattern();
   //     cout<<a.toStdString()<<endl;
        liste.push_back(a);
    }


    // permet de donner les regles de coloration a la liste
   if(renvoieListe(liste)=="html_balise_fermante")
    {
         foreach (QString expression_reg, liste)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format;
            regles_coloration_balise_html_fermantes.append(rule_html);
         }
    }
    else
    {
         foreach (QString expression_reg, liste)
        {
            rule.expression_reg = QRegExp(expression_reg);
            rule.format = format;
            regles_coloration.append(rule);
         }
    }
     fichier.close();
 }

 void Coloration :: ajouterMotCleBalises(const QString &chemin,QStringList &liste,QTextCharFormat format)
 {
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // le fichier n'existe pas
        cout<< "le fichie n'existe pas." <<endl;
    }

  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice::ReadOnly) )
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }

    QString fic= fichier.readAll().trimmed();     // permet d'enlever les caracteres de fins de ligne (entre autre)

    QStringList list = fic.split("|");
    QString ajout = "\\b";
    QString a;
    foreach(QString s, list)
    {
        QRegExp exp(s,Qt::CaseInsensitive);
   //     cout<<exp.pattern().toStdString()<<endl;
        exp.setCaseSensitivity(Qt::CaseInsensitive);
        a=exp.pattern();
        a.replace(a,a+ajout);
   //     cout<<a.toStdString()<<endl;
        liste.push_back(a);
    }


    // permet de donner les regles de coloration a la liste
   if(renvoieListe(liste)=="html_balise")
    {
         foreach (QString expression_reg, liste)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format;
            regles_coloration_balise_html.append(rule_html);
         }
    }
    else
    {
         foreach (QString expression_reg, liste)
        {
            rule.expression_reg = QRegExp(expression_reg);
            rule.format = format;
            regles_coloration.append(rule);
         }
    }
     fichier.close();
 }

// fonction permettant de modifier les fichiers de langage
 void Coloration :: modifieFichier(const QString &chemin, const QString &chaine)
 {
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // si le fichier n'existe pas :
        cout<< "le fichier n'existe pas." <<endl;
    }
  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice::WriteOnly | QIODevice::Append))
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }

    QString s=chaine;
    s.replace(s,"|"+s);
    QString truc = fichier.readAll().trimmed();
    truc.append(s);
    QTextStream flux(&fichier);
    flux<<truc;
    fichier.close();
 }


 QStringList Coloration :: recupererFichier(const QString & chemin)
 {
    QStringList mot_cle;
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // Le fichier n'existe pas
        cout<< "le fichie n'existe pas." <<endl;
    }

  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice::ReadOnly) )
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }

    QString fic= fichier.readLine().trimmed();
    QStringList list = fic.split("|");

    foreach(QString s, list)
    {
        mot_cle.push_back(s);
    }
    fichier.close();
    return mot_cle;
 }


// renvoi le langage dans lequel appratient le texte rentr�
QString Coloration :: langage(const QString &texte, const QTextBlock *bloc_editeur)
{
    QString resultat;
     if(bloc_editeur && bloc_php
       &&((est_php_selectionne ||  est_fichier_php ||
         bloc_editeur->userState()==php
        || etat==php ) &&((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
    {

        resultat = "php";
        if(est_javascript_selectionne && ((mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript3.contains(texte)) && ((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
        {
            resultat="php";
        }
        if(est_css_selectionne && ((mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte)) && ((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
        {
            resultat="php";
        }
        if(est_html_selectionne && ((html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)) && ((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
        {
            resultat="php";
        }

    }
    else if(bloc_editeur && bloc_javascript
       &&((est_javascript_selectionne|| est_fichier_javascript ||
         (bloc_editeur->userState()==javascript)
        || etat==javascript)  && (mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript2.contains(texte))))
    {
        resultat = "javascript";
        if(est_php_selectionne && ((mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript3.contains(texte)) && ((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
        {
            resultat="javascript";
        }
        if(est_javascript_selectionne && ((mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte)) && (mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript3.contains(texte))))
        {
            resultat="javascript";
        }
        if(est_html_selectionne && ((html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)) && (mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript3.contains(texte))))
        {
            resultat="javascript";
        }
    }
    else if(bloc_editeur && bloc_css
       &&((est_css_selectionne || est_fichier_css ||
         (bloc_editeur->userState()==css)
        || etat==css) && (mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte))))
    {
        resultat = "css";
        if(est_php_selectionne && ((mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte)) && ((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
        {
            resultat="css";
        }
        if(est_javascript_selectionne && ((mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte)) && (mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript3.contains(texte))))
        {
            resultat="css";
        }
        if(est_html_selectionne && ((html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)) && (mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte))))
        {
            resultat="css";
        }
    }
    else if((est_html_selectionne) && (html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)))
    {
        resultat = "html";
        if(est_php_selectionne && ((html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)) && ((mots_cle_php2.contains(texte)) || (mots_cle_php1.contains(texte)) ||(mots_cle_php3.contains(texte)) || (mots_cle_php4.contains(texte)) ||(mots_cle_php5.contains(texte)))))
        {
            resultat="html";
        }
        if(est_javascript_selectionne && ((html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)) && (mots_cle_javascript1.contains(texte) || mots_cle_javascript2.contains(texte) || mots_cle_javascript3.contains(texte))))
        {
            resultat="html";
        }
        if(est_css_selectionne && ((html_balises_fermantes.contains(texte) || html_balises_non_fermantes.contains(texte) || html_balises_ouvrantes.contains(texte) || attributs_html.contains(texte)) && (mots_cle_css1.contains(texte) || mots_cle_css2.contains(texte))))
        {
            resultat="html";
        }
    }
    else
    {
        resultat = "rien";
    }
    return resultat;
}

// renvoi la liste dans laquelle appartient le mot

QString Coloration :: recupererTexte()
{
    QTextCursor curseur = editeur->textCursor();
    curseur.select(QTextCursor::WordUnderCursor);
    return curseur.selectedText();
}


QStringList Coloration :: getListe()
{
    QStringList res;
    QStringList resultat;
    if(etat==php || est_php_selectionne || est_fichier_php)
    {
        res = mots_cle_php1+mots_cle_php2+mots_cle_php3+mots_cle_php4+mots_cle_php5;
    }
    else if(etat==javascript || est_javascript_selectionne || est_fichier_javascript)
    {
        res = mots_cle_javascript1+mots_cle_javascript2+mots_cle_javascript3;
    }
    else if(etat==css || est_css_selectionne || est_fichier_css)
    {
        res = mots_cle_css1+mots_cle_css2;
    }
    else if(est_html_selectionne)
    {
        res = html_balises_fermantes+html_balises_non_fermantes+html_balises_ouvrantes+attributs_html;
    }
    else
    {
        res = QStringList();
    }

    foreach(QString s, res)
    {
        s.remove("\\b");
        s.split("|");
        resultat.push_back(s);
    }
    return resultat;
}

void Coloration :: relancerInitialisationLangages()
{
    mots_cle_css1.clear();
    mots_cle_css2.clear();
    mots_cle_javascript1.clear();
    mots_cle_javascript2.clear();
    mots_cle_javascript3.clear();
    mots_cle_php1.clear();
    mots_cle_php2.clear();
    mots_cle_php3.clear();
    mots_cle_php4.clear();
    mots_cle_php5.clear();
    html_balises_fermantes.clear();
    html_balises_non_fermantes.clear();
    html_balises_ouvrantes.clear();
    attributs_html.clear();

    regles_coloration_php.clear();
    regles_coloration_balise_html.clear();
    regles_coloration_css.clear();
    regles_coloration_html.clear();
    regles_coloration_javascript.clear();
    regles_coloration_php.clear();

    initialisationCss();
    initialisationHtml();
    initialisationJavascript();
    initialisationPhp();
}


void Coloration :: colorerPhp(const QString &text)
{
    foreach (ReglesColoration rule, regles_coloration_php)
     {
         QRegExp expression(rule.expression_reg);
         int index = text.indexOf(expression);
         while (index >= 0)
         {
             int length = expression.matchedLength();
             setFormat(index, length, rule.format);
             index = text.indexOf(expression, index + length);
         }
     }
}

void Coloration::colorerCss(const QString &text)
{
     foreach (ReglesColoration rule, regles_coloration_css)
     {
         QRegExp expression(rule.expression_reg);
         int index = text.indexOf(expression);
         while (index >= 0)
         {
             int length = expression.matchedLength();
             setFormat(index, length, rule.format);
             index = text.indexOf(expression, index + length);
         }
     }
}

void Coloration::colorerJavascript(const QString &text)
{
     foreach (ReglesColoration rule, regles_coloration_javascript)
     {
         QRegExp expression(rule.expression_reg);
         int index = text.indexOf(expression);
         while (index >= 0)
         {
             int length = expression.matchedLength();
             setFormat(index, length, rule.format);
             index = text.indexOf(expression, index + length);
         }
     }
}

void Coloration :: setPhp(bool b)
{
    est_php_selectionne=b;
}

void Coloration :: setCss(bool b)
{
    est_css_selectionne=b;
}

void Coloration :: setJavascript(bool b)
{
    est_javascript_selectionne=b;
}

void Coloration :: setHtml(bool b)
{
    est_html_selectionne=b;
}

void Coloration :: setAutomatique(bool b)
{
    est_automatique_selectionne=b;
}

void Coloration :: setFichierPhp(bool b)
{
    est_fichier_php=b;
}

void Coloration :: setFichierJavascript(bool b)
{
    est_fichier_javascript=b;
}

void Coloration :: setFichierCss(bool b)
{
    est_fichier_css=b;
}

// fonctions permettant de changer les couleurs des mots cl�s :
void Coloration :: changerFormat(int i, QColor coul, bool estGras, bool estItalique)
{
    getFormat(i).setForeground(coul);
        if(estGras)
        {
            getFormat(i).setFontWeight(QFont::Bold);
            if(estItalique)
            {
                getFormat(i).setFontItalic(true);
            }
            else
            {
                getFormat(i).setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            getFormat(i).setFontItalic(true);
            if(!estGras)
            {
                getFormat(i).setFontWeight(QFont::Normal);
            }
        }
        else
        {
            getFormat(i).setFontItalic(false);
            getFormat(i).setFontWeight(QFont::Normal);
        }

        if(i==1)    // regles de php
        {
            foreach (QString expression_reg, mots_cle_php1)
            {
                rule_php.expression_reg = QRegExp(expression_reg);
                rule_php.format = format_mots_cle_php1;
                regles_coloration_php.append(rule_php);
            }
        }
        else if(i==2)
        {
            foreach (QString expression_reg, mots_cle_php2)
            {
                rule_php.expression_reg = QRegExp(expression_reg);
                rule_php.format = getFormat(i);
                regles_coloration_php.append(rule_php);
            }
        }
        else if(i==3)
        {
            foreach (QString expression_reg, mots_cle_php3)
            {
                rule_php.expression_reg = QRegExp(expression_reg);
                rule_php.format = getFormat(i);
                regles_coloration_php.append(rule_php);
            }
        }
         else if(i==4)
        {
            rule_php.expression_reg = QRegExp("\\$[^_][A-Za-z0-9_]*");      // $ suivi de lettres ou de chiffres de _ mais ne doit pas commencer par _
            rule_php.format = format_variables_php;
            regles_coloration_php.append(rule_php);
        }
        else if(i==5)
        {
            foreach (QString expression_reg, mots_cle_javascript1)
            {
                rule_javascript.expression_reg = QRegExp(expression_reg);
                rule_javascript.format = format_mots_cle_javascript1;
                regles_coloration_javascript.append(rule_javascript);
            }
        }
        else if(i==6)
        {
            foreach (QString expression_reg, mots_cle_javascript2)
            {
                rule_javascript.expression_reg = QRegExp(expression_reg);
                rule_javascript.format = getFormat(i);
                regles_coloration_javascript.append(rule_javascript);
            }
        }


}

void Coloration::changerFormatPhp1(QColor coul, bool estGras, bool estItalique)
{
     format_mots_cle_php1.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_php1.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_php1.setFontItalic(true);
            }
            else
            {
                format_mots_cle_php1.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_php1.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_php1.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_php1.setFontItalic(false);
            format_mots_cle_php1.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_php1)
        {
            rule_php.expression_reg = QRegExp(expression_reg);
            rule_php.format = format_mots_cle_php1;
            regles_coloration_php.append(rule_php);
        }
}

void Coloration :: changerFormatPhp2(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_php2.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_php2.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_php2.setFontItalic(true);
            }
            else
            {
                format_mots_cle_php2.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_php2.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_php2.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_php2.setFontItalic(false);
            format_mots_cle_php2.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_php2)
        {
            rule_php.expression_reg = QRegExp(expression_reg);
            rule_php.format = format_mots_cle_php2;
            regles_coloration_php.append(rule_php);
        }
}

void Coloration :: changerFormatPhp3(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_php3.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_php3.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_php3.setFontItalic(true);
            }
            else
            {
                format_mots_cle_php3.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_php3.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_php3.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_php3.setFontItalic(false);
            format_mots_cle_php3.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_php3)
        {
            rule_php.expression_reg = QRegExp(expression_reg);
            rule_php.format = format_mots_cle_php3;
            regles_coloration_php.append(rule_php);
        }
        foreach (QString expression_reg, mots_cle_php4)
        {
            rule_php.expression_reg = QRegExp(expression_reg);
            rule_php.format = format_mots_cle_php3;
            regles_coloration_php.append(rule_php);
        }
        foreach (QString expression_reg, mots_cle_php5)
        {
            rule_php.expression_reg = QRegExp(expression_reg);
            rule_php.format = format_mots_cle_php3;
            regles_coloration_php.append(rule_php);
        }
}

void Coloration :: changerFormatPhpVariables(QColor coul, bool estGras, bool estItalique)
{
    format_variables_php.setForeground(coul);
        if(estGras)
        {
            format_variables_php.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_variables_php.setFontItalic(true);
            }
            else
            {
                format_variables_php.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_variables_php.setFontItalic(true);
            if(!estGras)
            {
                format_variables_php.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_variables_php.setFontItalic(false);
            format_variables_php.setFontWeight(QFont::Normal);
        }

        rule_php.expression_reg = QRegExp("\\$[^_][A-Za-z0-9_]*");      // $ suivi de lettres ou de chiffres de _ mais ne doit pas commencer par _
        rule_php.format = format_variables_php;
        regles_coloration_php.append(rule_php);
}

void Coloration :: changerFormatJavascript1(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_javascript1.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_javascript1.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_javascript1.setFontItalic(true);
            }
            else
            {
                format_mots_cle_javascript1.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_javascript1.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_javascript1.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_javascript1.setFontItalic(false);
            format_mots_cle_javascript1.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_javascript1)
        {
            rule_javascript.expression_reg = QRegExp(expression_reg);
            rule_javascript.format = format_mots_cle_javascript1;
            regles_coloration_javascript.append(rule_javascript);
        }
}

void Coloration :: changerFormatJavascript2(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_javascript2.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_javascript2.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_javascript2.setFontItalic(true);
            }
            else
            {
                format_mots_cle_javascript2.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_javascript2.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_javascript2.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_javascript2.setFontItalic(false);
            format_mots_cle_javascript2.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_javascript2)
        {
            rule_javascript.expression_reg = QRegExp(expression_reg);
            rule_javascript.format = format_mots_cle_javascript2;
            regles_coloration_javascript.append(rule_javascript);
        }
}

void Coloration :: changerFormatJavascript3(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_javascript3.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_javascript3.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_javascript3.setFontItalic(true);
            }
            else
            {
                format_mots_cle_javascript3.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_javascript3.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_javascript3.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_javascript3.setFontItalic(false);
            format_mots_cle_javascript3.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_javascript3)
        {
            rule_javascript.expression_reg = QRegExp(expression_reg);
            rule_javascript.format = format_mots_cle_javascript3;
            regles_coloration_javascript.append(rule_javascript);
        }
}

void Coloration :: changerFormatCss1(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_css1.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_css1.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_css1.setFontItalic(true);
            }
            else
            {
                format_mots_cle_css1.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_css1.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_css1.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_css1.setFontItalic(false);
            format_mots_cle_css1.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_css1)
        {
            rule_css.expression_reg = QRegExp(expression_reg);
            rule_css.format = format_mots_cle_css1;
            regles_coloration_css.append(rule_css);
        }
}

void Coloration :: changerFormatCss2(QColor coul, bool estGras, bool estItalique)
{
    format_mots_cle_css2.setForeground(coul);
        if(estGras)
        {
            format_mots_cle_css2.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_mots_cle_css2.setFontItalic(true);
            }
            else
            {
                format_mots_cle_css2.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_mots_cle_css2.setFontItalic(true);
            if(!estGras)
            {
                format_mots_cle_css2.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_mots_cle_css2.setFontItalic(false);
            format_mots_cle_css2.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_css2)
        {
            rule_css.expression_reg = QRegExp(expression_reg);
            rule_css.format = format_mots_cle_css2;
            regles_coloration_css.append(rule_css);
        }
}

void Coloration :: changerFormatHtml(QColor coul, bool estGras, bool estItalique)
{
    format_balise_html.setForeground(coul);
        if(estGras)
        {
            format_balise_html.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_balise_html.setFontItalic(true);
            }
            else
            {
                format_balise_html.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_balise_html.setFontItalic(true);
            if(!estGras)
            {
                format_balise_html.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_balise_html.setFontItalic(false);
            format_balise_html.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, html_balises_fermantes)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format_balise_html;
            regles_coloration_balise_html.append(rule_html);
        }

        foreach (QString expression_reg, html_balises_non_fermantes)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format_balise_html;
            regles_coloration_balise_html.append(rule_html);
        }

        foreach (QString expression_reg, html_balises_ouvrantes)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format_balise_html;
            regles_coloration_balise_html.append(rule_html);
        }
}


void Coloration :: changerFormatAttributHtml(QColor coul, bool estGras, bool estItalique)
{
    format_attributs_html.setForeground(coul);
        if(estGras)
        {
            format_attributs_html.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_attributs_html.setFontItalic(true);
            }
            else
            {
                format_attributs_html.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_attributs_html.setFontItalic(true);
            if(!estGras)
            {
                format_attributs_html.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_attributs_html.setFontItalic(false);
            format_attributs_html.setFontWeight(QFont::Normal);
        }
        foreach (QString expression_reg, mots_cle_css1)
        {
            rule_html.expression_reg = QRegExp(expression_reg);
            rule_html.format = format_mots_cle_css1;
            regles_coloration_balise_html.append(rule_html);
        }
}



void Coloration :: changerFormatCommentaireMultiple(QColor coul,bool estGras,bool estItalique)
{
    format_commentaire_multiple.setForeground(coul);
        if(estGras)
        {
            format_commentaire_multiple.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_commentaire_multiple.setFontItalic(true);
            }
            else
            {
                format_commentaire_multiple.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_commentaire_multiple.setFontItalic(true);
            if(!estGras)
            {
                format_commentaire_multiple.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_commentaire_multiple.setFontItalic(false);
            format_commentaire_multiple.setFontWeight(QFont::Normal);
        }

         rule.expression_reg = QRegExp("<!--[^-->]+-->");
         rule.format = format_commentaire_multiple;
         regles_coloration.append(rule);

         rule.expression_reg = QRegExp("/\\*[^\\*/]+\\*/");
         rule.format = format_commentaire_multiple;
         regles_coloration.append(rule);

         rule_php.expression_reg = QRegExp("/\\*[^\\*/]+\\*/");
         rule_php.format = format_commentaire_multiple;
         regles_coloration_php.append(rule_php);

         rule_php.expression_reg = QRegExp("[^\\\"]*[^\\*/]+\\*/");
         rule_php.format = format_commentaire_multiple;
         regles_coloration_php.append(rule_php);

          rule_css.expression_reg = QRegExp("/\\*[^\\*]+\\*/");
          rule_css.format = format_commentaire_multiple;
          regles_coloration_css.append(rule_css);

          rule_javascript.expression_reg = QRegExp("/\\*[^\\*]+\\*/");
          rule_javascript.format = format_commentaire_multiple;
          regles_coloration_javascript.append(rule_javascript);
}

void Coloration :: changerFormatCommentaireSimple(QColor coul, bool estGras, bool estItalique)
{
    format_commentaire_simple.setForeground(coul);
        if(estGras)
        {
            format_commentaire_simple.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_commentaire_simple.setFontItalic(true);
            }
            else
            {
                format_commentaire_simple.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_commentaire_simple.setFontItalic(true);
            if(!estGras)
            {
                format_commentaire_simple.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_commentaire_simple.setFontItalic(false);
            format_commentaire_simple.setFontWeight(QFont::Normal);
        }

        rule_php.expression_reg = QRegExp("\\#[^\n]*");      // # => commentaire php, equivalent a //
        rule_php.format = format_commentaire_simple;
        regles_coloration_php.append(rule_php);

        rule_php.expression_reg = QRegExp("//[^\n]*");
        rule_php.format = format_commentaire_simple;
        regles_coloration_php.append(rule_php);

        rule_javascript.expression_reg = QRegExp("//[^\n]*");
        rule_javascript.format = format_commentaire_simple;
        regles_coloration_javascript.append(rule_javascript);

        rule_css.expression_reg = QRegExp("//[^\n]*");
        rule_css.format = format_commentaire_simple;
        regles_coloration_css.append(rule_css);

        rule.expression_reg = QRegExp("//[^\n]*");
        rule.format = format_commentaire_simple;
        regles_coloration.append(rule);
}

void Coloration :: changerFormatQuote(QColor coul, bool estGras, bool estItalique)
{
    format_quote.setForeground(coul);
        if(estGras)
        {
            format_quote.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_quote.setFontItalic(true);
            }
            else
            {
                format_quote.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_quote.setFontItalic(true);
            if(!estGras)
            {
                format_quote.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_quote.setFontItalic(false);
            format_quote.setFontWeight(QFont::Normal);
        }

        rule.expression_reg = QRegExp("\"[^\"]+\"");
         rule.format = format_quote;
        regles_coloration.append(rule);

        rule.expression_reg = QRegExp("\'[^\']+\'");
        rule.format = format_quote;
        regles_coloration.append(rule);

        rule_php.expression_reg = QRegExp("\"[^\"]+\"");
        rule_php.format = format_quote;
        regles_coloration_php.append(rule_php);

        rule_php.expression_reg = QRegExp("\'[^\']+\'");
        rule_php.format = format_quote;
        regles_coloration_php.append(rule_php);

        rule_css.expression_reg = QRegExp("\"[^\"]+\"");
        rule_css.format = format_quote;
        regles_coloration_css.append(rule_css);


        rule_css.expression_reg = QRegExp("\'[^\']+\'");
        rule_css.format = format_quote;
        regles_coloration_css.append(rule_css);

        rule_javascript.expression_reg = QRegExp("\"[^\"]+\"");
         rule_javascript.format = format_quote;
        regles_coloration_javascript.append(rule_javascript);

        rule_javascript.expression_reg = QRegExp("\'[^\']+\'");
        rule_javascript.format = format_quote;
        regles_coloration_javascript.append(rule_javascript);

        rule_html.expression_reg = QRegExp("\"[^\"]+\"");
        rule_html.format = format_quote;
        regles_coloration_html.append(rule_html);

        rule_html.expression_reg = QRegExp("\'[^\']+\'");
        rule_html.format = format_quote;
        regles_coloration_html.append(rule_html);
}

void Coloration :: changerFormatFonction(QColor coul, bool estGras, bool estItalique)
{
    format_fonction.setForeground(coul);
        if(estGras)
        {
            format_fonction.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_fonction.setFontItalic(true);
            }
            else
            {
                format_fonction.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_fonction.setFontItalic(true);
            if(!estGras)
            {
                format_fonction.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_fonction.setFontItalic(false);
            format_fonction.setFontWeight(QFont::Normal);
        }

        rule.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
        rule.format = format_fonction;
        regles_coloration.append(rule);

        rule_php.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
        rule_php.format = format_fonction;
        regles_coloration_php.append(rule_php);

        rule_css.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
        rule_css.format = format_fonction;
        regles_coloration_css.append(rule_css);

        rule_javascript.expression_reg = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
        rule_javascript.format = format_fonction;
        regles_coloration_javascript.append(rule_javascript);
}

void Coloration :: changerFormatECommercial(QColor coul, bool estGras, bool estItalique)
{
    format_Ecommecial.setForeground(coul);
        if(estGras)
        {
            format_Ecommecial.setFontWeight(QFont::Bold);
            if(estItalique)
            {
                format_Ecommecial.setFontItalic(true);
            }
            else
            {
                format_Ecommecial.setFontItalic(false);
            }
        }
        else if(estItalique)
        {
            format_Ecommecial.setFontItalic(true);
            if(!estGras)
            {
                format_Ecommecial.setFontWeight(QFont::Normal);
            }
        }
        else
        {
            format_Ecommecial.setFontItalic(false);
            format_Ecommecial.setFontWeight(QFont::Normal);
        }

        rule.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
        rule.format = format_Ecommecial;
        regles_coloration.append(rule);

        rule_php.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
        rule_php.format = format_Ecommecial;
        regles_coloration_php.append(rule_php);

        rule_javascript.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
        rule_javascript.format = format_Ecommecial;
        regles_coloration_javascript.append(rule_javascript);

        rule_css.expression_reg = QRegExp("&[^_;][A-Za-z0-9_#]*;");
        rule_css.format = format_Ecommecial;
        regles_coloration_css.append(rule_css);
}


QTextCharFormat Coloration :: getFormat(int i)
{
    // format pour le php :
    if(i==1)
    {
        return format_mots_cle_php1;
    }
    else if(i==2)
    {
        return format_mots_cle_php2;
    }
    else if(i==3)
    {
        return format_mots_cle_php3;
    }
    else if(i==4)
    {
        return format_variables_php;
    }
    // format pour le javascript :
    else if(i==5)
    {
        return format_mots_cle_javascript1;
    }
    else if(i==6)
    {
        return format_mots_cle_javascript2;
    }
    else if(i==7)
    {
        return format_mots_cle_javascript3;
    }
    // format pour le css :
    else if(i==8)
    {
        return format_mots_cle_css1;
    }
    else if(i==9)
    {
        return format_mots_cle_css2;
    }
    // format pour html :
    else if(i==10)
    {
        return format_balise_html;
    }
    else if(i==11)
    {
        return format_attributs_html;
    }
    else if(i==12)
    {
        return format_commentaire_multiple;
    }
    else if(i==13)
    {
        return format_commentaire_simple;
    }
    else if(i==14)
    {
        return format_Ecommecial;
    }
    else if(i==15)
    {
        return format_fonction;
    }
    else if(i==16)
    {
        return format_quote;
    }
}

bool Coloration :: estItalique(int i)
{
    bool italique=false;
    if(i==1)
    {
        if(format_mots_cle_php1.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==2)
    {
       if(format_mots_cle_php2.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==3)
    {
       if(format_mots_cle_php3.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==4)
    {
       if(format_variables_php.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==5)
    {
       if(format_mots_cle_javascript1.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==6)
    {
       if(format_mots_cle_javascript2.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==7)
    {
       if(format_mots_cle_javascript3.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==8)
    {
       if(format_mots_cle_css1.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==9)
    {
       if(format_mots_cle_css2.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==10)
    {
       if(format_balise_html.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==11)
    {
       if(format_attributs_html.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==12)
    {
       if(format_commentaire_multiple.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==13)
    {
       if(format_commentaire_simple.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==14)
    {
       if(format_Ecommecial.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==15)
    {
       if(format_fonction.fontItalic())
        {
            italique=true;
        }
    }
    else if(i==16)
    {
       if(format_quote.fontItalic())
        {
            italique=true;
        }
    }
    return italique;


}

bool Coloration :: estGras(int i)
{
    bool gras=false;
    if(i==1)
    {
        if(format_mots_cle_php1.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==2)
    {
       if(format_mots_cle_php2.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==3)
    {
       if(format_mots_cle_php3.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==4)
    {
       if(format_variables_php.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==5)
    {
       if(format_mots_cle_javascript1.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==6)
    {
       if(format_mots_cle_javascript2.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==7)
    {
       if(format_mots_cle_javascript3.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==8)
    {
       if(format_mots_cle_css1.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==9)
    {
       if(format_mots_cle_css2.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==10)
    {
       if(format_balise_html.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==11)
    {
       if(format_attributs_html.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==12)
    {
       if(format_commentaire_multiple.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==13)
    {
       if(format_commentaire_simple.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==14)
    {
       if(format_Ecommecial.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==15)
    {
       if(format_fonction.fontWeight()==75)
        {
            gras=true;
        }
    }
    else if(i==16)
    {
       if(format_quote.fontWeight()==75)
        {
            gras=true;
        }
    }
    return gras;
}

// implementation du QSettings :
void Coloration :: restaurer()
{
    QSettings settings("MYW", "Coloration");

    settings.beginGroup("php1");
    format_mots_cle_php1.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_php1.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_php1.setFontWeight(QFont::Normal);
    }
    format_mots_cle_php1.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
    settings.beginGroup("php2");
    format_mots_cle_php2.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_php2.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_php2.setFontWeight(QFont::Normal);
    }
    format_mots_cle_php2.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("php3");
    format_mots_cle_php3.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_php3.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_php3.setFontWeight(QFont::Normal);
    }
    format_mots_cle_php3.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("php_variable");
    format_variables_php.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_variables_php.setFontWeight(QFont::Bold);
    }
    else
    {
        format_variables_php.setFontWeight(QFont::Normal);
    }
    format_variables_php.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("javascript1");
    format_mots_cle_javascript1.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_javascript1.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_javascript1.setFontWeight(QFont::Normal);
    }
    format_mots_cle_javascript1.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
    settings.beginGroup("javascript2");
    format_mots_cle_javascript2.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_javascript2.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_javascript2.setFontWeight(QFont::Normal);
    }
    format_mots_cle_javascript2.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
    settings.beginGroup("javascript3");
    format_mots_cle_javascript3.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_javascript3.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_javascript3.setFontWeight(QFont::Normal);
    }
    format_mots_cle_javascript3.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
    settings.beginGroup("css1");
    format_mots_cle_css1.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_css1.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_css1.setFontWeight(QFont::Normal);
    }
    format_mots_cle_css1.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("css2");
    format_mots_cle_css2.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_mots_cle_css2.setFontWeight(QFont::Bold);
    }
    else
    {
        format_mots_cle_css2.setFontWeight(QFont::Normal);
    }
    format_mots_cle_css2.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("html_balises");
    format_balise_html.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_balise_html.setFontWeight(QFont::Bold);
    }
    else
    {
        format_balise_html.setFontWeight(QFont::Normal);
    }
    format_balise_html.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("html_attributs");
    format_attributs_html.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_attributs_html.setFontWeight(QFont::Bold);
    }
    else
    {
        format_attributs_html.setFontWeight(QFont::Normal);
    }
    format_attributs_html.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
    settings.beginGroup("commentaire_simple");
    format_commentaire_simple.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_commentaire_simple.setFontWeight(QFont::Bold);
    }
    else
    {
        format_commentaire_simple.setFontWeight(QFont::Normal);
    }
    format_commentaire_simple.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("commentaire_multiple");
    format_commentaire_multiple.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_commentaire_multiple.setFontWeight(QFont::Bold);
    }
    else
    {
        format_commentaire_multiple.setFontWeight(QFont::Normal);
    }
    format_commentaire_multiple.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("quote");
    format_quote.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_quote.setFontWeight(QFont::Bold);
    }
    else
    {
        format_quote.setFontWeight(QFont::Normal);
    }
    format_quote.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("fonction");
    format_fonction.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_fonction.setFontWeight(QFont::Bold);
    }
    else
    {
        format_fonction.setFontWeight(QFont::Normal);
    }
    format_fonction.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();
     settings.beginGroup("e_commercial");
    format_Ecommecial.setForeground(QColor(settings.value("couleurR").toInt(),
                                         settings.value("couleurG").toInt(),
                                         settings.value("couleurB").toInt()));
    if(settings.value("gras").toBool()==true)
    {
        format_Ecommecial.setFontWeight(QFont::Bold);
    }
    else
    {
        format_Ecommecial.setFontWeight(QFont::Normal);
    }
    format_Ecommecial.setFontItalic(settings.value("italique").toBool());
    settings.endGroup();



}
