#include "couleur.h"
#include "coloration.h"
#include "changerColoration.h"
#include <QPalette>
#include <iostream>
#include <QMouseEvent>
#include <QColorDialog>
#include "changerColoration.h"
using namespace std;

Couleur::Couleur(ChangerColoration *parent, const QColor c)
    : QFrame(parent)
{
    // coul=QColor();
   // setFixedSize(20, 30);
    setAutoFillBackground(true);
   // setFrameStyle(QFrame::Sunken | QFrame::StyledPanel);
    QPalette palette(this->palette());
    couleur = QColor(c);
    palette.setColor(QPalette::Window, couleur);
    setPalette(palette);

    setFixedSize(30,20);
}

void Couleur::mousePressEvent(QMouseEvent * event)
{
        QColor col = QColorDialog::getColor(couleur, this);

        setCouleur(col);
}

QColor Couleur :: getCouleur()
{
    return couleur;
}

void Couleur :: setCouleur(QColor coul)
{
    couleur=coul;
    QPalette palette;
     palette.setColor(QPalette::Window, couleur);
     this->setPalette(palette);

}
