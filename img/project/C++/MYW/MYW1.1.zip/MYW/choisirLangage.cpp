#include <QAction>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QLabel>
#include "choisirLangage.h"
#include "widgetDansOnglet.h"
#include "Preferences.h"
#include "mainwindow.h"


ChoisirLangage::ChoisirLangage(Coloration * colo,Preferences *parent) : QWidget(parent)
{
    this->parent = parent;
    coloration=colo;
    QGridLayout *grille = new QGridLayout;
    QVBoxLayout *vbox_generale = new QVBoxLayout;
    QHBoxLayout *hbox1 = new QHBoxLayout;


    javascriptSelectionne=false;
    phpSelectionne=false;
    cssSelectionne=false;
    automatiqueSelectionne=true;
    QLabel *texte= new QLabel(tr("Choisissez le type de coloration que vous souhaitez : "),this);

     automatique = new QCheckBox(tr("Automatique"));
     automatique->setChecked(true);

     personnalisee = new QCheckBox(tr("Personnalis�e"));
     personnalisee->setChecked(false);

     php_checkBox = new QCheckBox(tr("Php"));
     php_checkBox->setChecked(false);
     php_checkBox->setEnabled(false);
     css_checkBox = new QCheckBox(tr("Css"));
     css_checkBox->setChecked(false);
     css_checkBox->setEnabled(false);
     javascript_checkBox = new QCheckBox(tr("Javascript"));
     javascript_checkBox->setChecked(false);
     javascript_checkBox->setEnabled(false);
     html_checkBox = new QCheckBox(tr("Html"));
     html_checkBox->setChecked(false);
     html_checkBox->setEnabled(false);

     QVBoxLayout *vbox = new QVBoxLayout;
     vbox->addWidget(texte);
     vbox->addWidget(automatique);
     vbox->addWidget(personnalisee);
     vbox->addWidget(php_checkBox);
     vbox->addWidget(css_checkBox);
     vbox->addWidget(javascript_checkBox);
     vbox->addWidget(html_checkBox);
     vbox->addStretch(1);


     QPushButton *appliquer = new QPushButton(tr("Appliquer"));

     QVBoxLayout *vbox2 = new QVBoxLayout;
     vbox2->addWidget(appliquer);

     explication = new QLabel(tr("Ici vous pouvez choisir une coloration des mots cl�s \nreconnus par leurs balises, \nou choisir une coloration personnalis�e \nc'est � dire, colorer les mots cl�s d'un langage en particulier. \nVous avez aussi la possibilit� de colorer automatiquement \net de rajouter une coloration personnalis�e afin de mieux \nvoir les parties de votre code. \nPour que ces modifications s'appliquent � l'onglet courant, \nvous devez appuyer sur appliquer (ci-dessous) "));
     explication->setFixedSize(300,200);

     QVBoxLayout *vbox3 = new QVBoxLayout;
     vbox3->addWidget(explication);

     hbox1->addLayout(vbox,100);
     hbox1->addWidget(explication, 100, Qt::AlignTop);

     vbox_generale->addLayout(hbox1);
     vbox_generale->addLayout(vbox2);

     grille->addLayout(vbox_generale,3,3,Qt::AlignVCenter);

     setLayout(grille);

    connect(appliquer,SIGNAL(clicked()),this,SLOT(validerChoisirLangage()));
    connect(appliquer,SIGNAL(clicked()),this,SLOT(recolorer()));
    connect(personnalisee,SIGNAL(clicked()),this,SLOT(afficherListeLangage()));
}

void ChoisirLangage :: validerChoisirLangage()
{
     WidgetDansOnglet* interieurOnglet = dynamic_cast<WidgetDansOnglet*> (parent->getParent()->getInterieurOnglet());
         if(interieurOnglet)
         {
             if(php_checkBox->isChecked()==true)
             {
                 setPhpSelectionne(true);
                 interieurOnglet->getTextEdit()->getColoration()->setPhp(true);
             }
             else
             {
                 setPhpSelectionne(false);
                 interieurOnglet->getTextEdit()->getColoration()->setPhp(false);
             }
             if(css_checkBox->isChecked()==true)
             {
                 setCssSelectionne(true);
                 interieurOnglet->getTextEdit()->getColoration()->setCss(true);
             }
             else
             {
                 setCssSelectionne(false);
                 interieurOnglet->getTextEdit()->getColoration()->setCss(false);
             }
             if(javascript_checkBox->isChecked()==true)
             {
                 setJavascriptSelectionne(true);
                 interieurOnglet->getTextEdit()->getColoration()->setJavascript(true);
             }
             else
             {
                 setJavascriptSelectionne(false);
                 interieurOnglet->getTextEdit()->getColoration()->setJavascript(false);
             }
             if(html_checkBox->isChecked()==true)
             {
                 interieurOnglet->getTextEdit()->getColoration()->setHtml(true);
             }
             else
             {
                 interieurOnglet->getTextEdit()->getColoration()->setHtml(false);
             }
             if(automatique->isChecked()==false)
             {
                 setAutomatiqueSelectionne(true);
                 interieurOnglet->getTextEdit()->getColoration()->setAutomatique(false);
             }
             else
             {
                 setAutomatiqueSelectionne(false);
                 interieurOnglet->getTextEdit()->getColoration()->setAutomatique(true);
             }
         }
    // }
}

void ChoisirLangage:: afficherListeLangage()
{
    if(personnalisee->isChecked()==false)
    {
        php_checkBox->setEnabled(false);
        css_checkBox->setEnabled(false);
        javascript_checkBox->setEnabled(false);
        html_checkBox->setEnabled(false);

        php_checkBox->setChecked(false);
        css_checkBox->setChecked(false);
        javascript_checkBox->setChecked(false);
        html_checkBox->setChecked(false);
    }
    else
    {
        php_checkBox->setEnabled(true);
        css_checkBox->setEnabled(true);
        javascript_checkBox->setEnabled(true);
        html_checkBox->setEnabled(true);
    }
}


void ChoisirLangage :: setJavascriptSelectionne(bool b)
{
    javascriptSelectionne=b;
}

bool ChoisirLangage:: estJavascriptSelectionne()
{
    return javascriptSelectionne;
}

void ChoisirLangage :: setPhpSelectionne(bool b)
{
    phpSelectionne=b;
}

bool ChoisirLangage:: estPhpSelectionne()
{
    return phpSelectionne;
}

void ChoisirLangage :: setCssSelectionne(bool b)
{
    cssSelectionne=b;
}

bool ChoisirLangage:: estCssSelectionne()
{
    return cssSelectionne;
}

void ChoisirLangage :: setAutomatiqueSelectionne(bool b)
{
    automatiqueSelectionne=b;
}

bool ChoisirLangage:: estAutomatiqueSelectionne()
{
    return automatiqueSelectionne;
}


void ChoisirLangage:: recolorer()
{
        for(int i=0;i<parent->getParent()->getTabWidget()->count();i++)
        {
             WidgetDansOnglet* interieurOnglet = dynamic_cast<WidgetDansOnglet*> (parent->getParent()->getTabWidget()->widget(i));
             if(interieurOnglet)
             {
                 interieurOnglet->getTextEdit()->getColoration()->rehighlight();
             }
        }
}
