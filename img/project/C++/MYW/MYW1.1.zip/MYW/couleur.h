#ifndef COULEUR_H
#define COULEUR_H

/*!
* \Couleur.h
* \brief Ce fichier contient tout ce qui est n&eacute;cessaire &agrave; la cr&eacute;ation des frames color&eacute;es dans le widget changerColoration
* \author Novak Audrey
* \date 12.03.2009
*/

#include <QFrame>
#include <QColor>
#include <QMouseEvent>

class ChangerColoration;

/*!
* \class Couleur
* \brief Classe permettant de cr&eacute;er des frames qui seront color&eacute;es
* avec les couleurs correspondants aux mots cl&eacute;s des langages
*
*/

 class Couleur : public QFrame
 {
        private :
                QColor couleur;             /*< couleur de la frame */
        public:

/*!
* \brief Constructeur
*
* Constructeur de la classe Couleur
*
* \param parent : le parent de la classe coloration est de type ChangerColoration
* \param couleur : couleur que prendra la frame
*/
                Couleur(ChangerColoration * parent, const QColor = QColor());

/*!
* \brief R&eacute;impl&eacute;mente l'&eacute;venement du clic de la souris sur la frame, d&eacute;clenchera une boite de dialogue permettant de
* choisir une couleur
* \param event : &eacute;v&eacute;nement de la souris
*/
                virtual void mousePressEvent(QMouseEvent*);

/*!
* \brief Accesseur de la couleur de la frame
*
* \return couleur : la couleur de la frame (couleur du constructeur)
*/
                QColor getCouleur();

/*!
* \brief Accesseur de couleur
*
*
* \param coul : permet de donner une couleur &agrave; la frame
*/
                void setCouleur(QColor);
};

#endif // COULEUR_H
