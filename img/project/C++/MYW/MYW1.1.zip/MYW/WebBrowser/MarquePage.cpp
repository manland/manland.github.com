/*========================================================================
Nom: MarquePage.cpp           auteur: Maneschi Romain
Maj: 17.05.2009               Creation: 05.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QPushButton pour les marques-pages.
=========================================================================*/

#include <iostream>
using namespace std;

#include "MarquePage.h"

#include "MarquesPages.h"
#include "WebBrowser.h"

MarquePage::MarquePage(QString t, MarquesPages * p, int i) : QPushButton(t, p)
{
    parent = p;
    estDeplace = false;
    estClicke = false;
    this->setMouseTracking(true);
    setAcceptDrops(true);
    place_dans_liste = i;
    setAttribute(Qt::WA_DeleteOnClose);
}

void MarquePage::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
    QLinearGradient gradient(this->width()/2, 0, this->width()/2, this->height());
    gradient.setColorAt(0.0, Qt::black);
    gradient.setColorAt(0.45, Qt::darkGray);
    gradient.setColorAt(0.55, Qt::darkGray);
    gradient.setColorAt(1.0, Qt::black);
    painter.setPen(Qt::black);
    painter.setBrush(gradient);
    painter.drawRect(this->rect());
    QPixmap p = this->icon().pixmap(this->iconSize());
    if(!this->accessibleDescription().isEmpty())
    {
        painter.drawPixmap(5, 10, p);
        painter.setPen(Qt::white);
        painter.drawText(5, 5, "...");
    }
    else
    {
        painter.drawPixmap(5, 5, p);
    }
    painter.setPen(Qt::red);
    painter.drawText(5+this->iconSize().width()+5, 20, this->text());
    painter.end();
    event->accept();
}

void MarquePage::dragLeaveEvent(QDragLeaveEvent * event)
{
    if(this->accessibleDescription().isEmpty())//si menu alor fermer
    {
        this->menu()->hide();
    }
}

void MarquePage::dragEnterEvent(QDragEnterEvent * event)
{
    parent->supprimerFleche();
    if(this->accessibleDescription().isEmpty())//si menu alor ouvrir
    {
        this->menu()->show();
        if(parent->orientation() == Qt::Horizontal)
        {
            this->menu()->move(parent->getParent()->pos().x() + parent->pos().x() + this->pos().x() + 4,
                               parent->getParent()->pos().y() + parent->pos().y() + this->height() + 24);
        }
        else
        {
            this->menu()->move(parent->getParent()->pos().x() + parent->pos().x() + this->pos().x() + this->width() + 4,
                               parent->getParent()->pos().y() + parent->pos().y() + this->pos().y());
        }
        event->accept();
    }
    else
    {
        event->setAccepted(false);
        event->ignore();
    }
}

void MarquePage::mousePressEvent(QMouseEvent * event)
{
    startPos = event->pos();
    estClicke = true;
}

void MarquePage::mouseReleaseEvent(QMouseEvent * event)
{
    int distance = (event->pos() - startPos).manhattanLength();
    if(!estDeplace && distance < 10)//si la souris n'a presque pas bouger c'est un click
    {
        if(event->button() == Qt::LeftButton)
        {
            if(!this->accessibleDescription().isEmpty())
            {
                parent->charger(QUrl(this->accessibleDescription()), 0);
            }
            else
            {
                this->showMenu();
            }
            event->accept();
        }
        else if(event->button() == Qt::MidButton)
        {
            if(!this->accessibleDescription().isEmpty())
            {
                parent->charger(QUrl(this->accessibleDescription()), 1);
                event->accept();
            }
            else
            {
                event->ignore();
            }
        }
        else
        {
            event->ignore();
        }
    }
    estClicke = false;
}

void MarquePage::mouseMoveEvent(QMouseEvent * event)
{
    if(!this->accessibleDescription().isEmpty())//si c'est un dossier et que la souris est sur les ... alors le curseur est une main
    {
        if(QRect(0, 0, 20, 20).contains(event->pos()))
        {
            this->setCursor(Qt::OpenHandCursor);
        }
        else
        {
            this->unsetCursor();
        }
    }
    int distance = (event->pos() - startPos).manhattanLength();
    if(distance > 10 && !this->accessibleDescription().isEmpty() && estClicke)
    {
        estDeplace = true;
        startDrag(event);
        event->accept();
    }
}

void MarquePage::startDrag(QMouseEvent * event)
{
    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);

    dataStream << this->text() << this->accessibleDescription() << place_dans_liste;

    QMimeData * mimeData = new QMimeData;
    mimeData->setData("text/html", itemData);

    QDrag *drag = new QDrag(this);
    drag->setMimeData(mimeData);

    QPixmap pixmap(this->size());
    this->render(&pixmap, QPoint(0, 0), QRegion (0, 0, this->width(), this->height()), RenderFlags());

    drag->setPixmap(pixmap);
    drag->setHotSpot(event->pos());

    if (drag->exec(Qt::CopyAction, Qt::IgnoreAction) == Qt::CopyAction)
    {
        estDeplace = false;
        estClicke = false;
    }
    else
    {
        parent->supprimerFleche();
        estDeplace = false;
        estClicke = false;
    }
}

void MarquePage::dropEvent(QDropEvent * event)
{
    if(this->accessibleDescription().isEmpty() && event->mimeData()->hasFormat("text/html"))//si c'est un menu
    {
        QByteArray itemData = event->mimeData()->data("text/html");
        QDataStream dataStream(&itemData, QIODevice::ReadOnly);

        QString titre;
        QString url;
        int mp_place_dans_liste;
        dataStream >> titre >> url >> mp_place_dans_liste/*place de l'ancien bouton ou du nouvo si < 0*/;

        if(mp_place_dans_liste >= 0)
        {
            parent->supprimerMarquePage(mp_place_dans_liste);
        }
        parent->ajouter(place_dans_liste, titre, url, true);
        event->setDropAction(Qt::CopyAction);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

int MarquePage::getPlaceDansListe()
{
    return place_dans_liste;
}

MarquesPages* MarquePage::getParent()
{
    return parent;
}
