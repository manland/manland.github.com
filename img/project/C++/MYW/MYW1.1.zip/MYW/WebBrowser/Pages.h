#ifndef PAGES_H
#define PAGES_H

/*========================================================================
Nom: Pages.h           auteur: Maneschi Romain
Maj: 17.05.2009        Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QTabWidget contenant les pages internet.
=========================================================================*/

/*!
* \file Pages.h
* \brief Classe qui réimplante QTabWidget contenant les pages internet.
* \author Maneschi Romain
* \date 01.03.2009
*/

#include <QVector>
#include <QTabWidget>
#include <QWebView>
#include <QMenu>
#include <QPushButton>
#include <QHBoxLayout>
#include <QIcon>

#include "Page.h"

class WebBrowser;

/*!
* \class Pages
* \brief Classe qui réimplante QTabWidget contenant les pages internet.
*
* Cette classe est un QTabWidget contenant un QVector<Page*> pour gérer le fait d'ouvrir plusieurs fenêtres en même temps.
* Elle gère le boutton droit pour fermer un onglet. Et le fait de charger une page pour la connecter avec le WebBrowser parent.
*
*/
class Pages : public virtual QTabWidget
{
    Q_OBJECT

private:
    QUrl url_par_default;/*!< s'ouvre quand on ferme tout, la dernière page ou click sur Home*/
    WebBrowser * parent;/*!< pointeur vers le parent*/
    int page_courante;/*!< garde la page courante pour savoir quelle page fermer avec les bouttons de droites.*/
    QVector<Page*> * pages;/*!< vector des pages ouvertes*/
    QPushButton * boutton_fermer;/*!< boutton de doite des onglets permettais de fermer les tab avant qt 4.5 qui permet d'ajouter le boutton sur l'onglet*/
    QPushButton * boutton_nouvel_onglet;
    QMenu * boutton_fermer_menu;/*!< menu du boutton boutton_fermer*/
    QVector<QAction*> * urls_en_cours;/*!< actions contenues dans boutton_fermer_menu*/

private slots:
    /*!
    * \brief Assigne au boutton fermer et à l'onglet le titre de la page.
    *
    * \param s : QString le nom de la page
    */
    virtual void actionTitrePage(QString);
    /*!
    * \brief Change le titre de la page et le temps de chargement en fonction du changement de tab. Et place le numéraux de la page courrante dans page_courrante.
    *
    * \param i : int numéraux de la page
    */
    virtual void changementTab(int);
    /*!
    * \brief Assigne au boutton fermer et à l'onglet l'icone de la page.
    */
    virtual void chargementIcon();
    /*!
    * \brief permet de mettre à jours le titre et l'icon de la page si ça n'a pas déjà était fait.
    *
    * \param b : booléen si b=true alors le chargement c'est bien passé sinon erreur.
    */
    virtual void chargementTermine(bool);
    /*!
    * \brief permet d'ouvrir un nouvel onglet avec url_par_default.
    */
    virtual void nouvelOnglet();

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe Pages
    *
    * \param url : QUrl à charger dans la première page
    * \param parent : WebBrowser obligatoire car on a besoins d'appeler des méthodes
    */
    Pages(QUrl, WebBrowser*);
    /*!
    * \brief Retourne le QWebView de la page courante
    */
    virtual Page* getPageCourante();
    /*!
    * \brief Retourne l'id du QWebView de la page courante
    */
    virtual int getIdPageCourante();
    /*!
    * \brief Retourne le WebBrowser parent de this
    */
    virtual WebBrowser* getParent();
    /*!
    * \brief Charge l'url dans un nouvel onglet.
    *
    * \param u : QUrl l'url à charger
    */
    virtual void charger(QUrl);
    /*!
    * \brief Fait le tour des pages ouvertes et remet à jour le boutton fermer de droite.
    */
    virtual void mettreAJourBouttonFermer();

    virtual Page* getPage(int);

public slots:
    /*!
    * \brief Ferme l'onglet de la QAction du menu de droite. L'onglet est retrouvé par son int grâce au data du QAction.
    *
    * \param a : QAction du menu de droite contenant dans son data l'id de l'onglet à fermer.
    */
    virtual void fermerTab(QAction*);
    /*!
    * \brief Ferme l'onglet par son id.
    *
    * \param i : int l'id de l'onglet à fermer.
    */
    virtual void fermerTab(int);

};
#endif // PAGE_H
