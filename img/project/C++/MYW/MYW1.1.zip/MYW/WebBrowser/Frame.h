#ifndef FRAME_H
#define FRAME_H

/*========================================================================
Nom: Frame.h           auteur: Maneschi Romain
Maj: 17.05.2009        Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWebPage.
=========================================================================*/

/*!
* \file Frame.h
* \brief Classe qui réimplante QWebPage.
* \author Maneschi Romain
* \date 01.03.2009
*/

#include <QWebPage>
#include <QNetworkRequest>
#include <QFileDialog>
#include <QDir>
#include <QList>
#include <QNetworkCookie>
#include <QVariant>
#include <QNetworkReply>

class Page;

/*!
* \class Frame
* \brief Classe contenue dans Page permettant d'afficher les frames d'une page internet.
*
* Cette classe est une classe très importante car elle permet d'intéragir avec les éléments d'une page
* internet notamment pour les cookies, java-script ou encore les formulaires...
*
*/
class Frame : public virtual QWebPage
{
    Q_OBJECT

private:
    Page * parent;/*!< Le parent de la classe.*/

protected:
    /*!
    * \brief Méthode obligatoire dû à l'héritage de QWebPage
    *
    * \param frame : QWebFrame frame demandant l'action
    * \param request : QNetworkRequest la demande du réseau
    * \param type : NavigationType donne le type de la navigation
    * \return true si la demande de navigation est réalisable, false si non
    */
    virtual bool acceptNavigationRequest(QWebFrame*, const QNetworkRequest&, NavigationType);//A FINIR POUR COOKIE
    /*!
    * \brief Méthode obligatoire dû à l'héritage de QWebPage permet d'afficher une fenêtre pour choisir un fichier notamment utilisée dans les formulaires
    *
    * \param frame : QWebFrame frame demandant l'action
    * \param suggestedFile : QString le fichier suggéré
    * \return sous forme de QString le chemin du fichier choisi
    */
    virtual QString chooseFile(QWebFrame*, const QString&);
    /*!
    * \brief Méthode obligatoire dû à l'héritage de QWebPage permet d'afficher une fenêtre pour les erreurs java-script de la frame
    *
    * \param message : QString message d'erreur
    * \param lineNumber : int le numéro de la ligne générant l'erreur
    * \param sourceID : QString
    */
    virtual void javaScriptConsoleMessage(const QString&, int, const QString&);//A FER

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe Frame
    *
    * \param parent : Page parent de la frame
    */
    Frame(Page*);


};
#endif // FRAME_H
