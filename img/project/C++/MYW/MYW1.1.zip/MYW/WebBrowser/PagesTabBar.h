#ifndef PAGESTABBAR_H
#define PAGESTABBAR_H

/*========================================================================
Nom: PagesTabBar.h           auteur: Maneschi Romain
Maj: 17.05.2009              Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QTarBar pour les onglets des pages.
=========================================================================*/

/*!
* \file PagesTabBar.h
* \brief Classe qui réimplante QTarBar pour les onglets des pages.
* \author Maneschi Romain
* \date 01.03.2009
*/

#include <QTabBar>
#include <QLabel>

class Pages;

/*!
* \class PagesTabBar
* \brief Classe qui réimplante QTarBar pour les onglets des pages.
*/
class PagesTabBar : public virtual QTabBar
{
    Q_OBJECT

private:
    Pages * parent;/*!< Le parent de la classe*/
    QLabel * label_indication_favoris;/*!< Bouton pour ajouter aux favoris le site de la page courrante*/

protected:
    /*!
    * \brief Lance un drag permettant d'ajouter la page de l'onglet dans les marques-pages
    *
    * \param event : QMouseEvent événement déclanchant cette méthode si l'utilisateur à suffisament déplacé la souris
    */
    virtual void startDrag(QMouseEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur déplace la souris
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mouseMoveEvent(QMouseEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur double click sur un marque-page pour lancer startDrag
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mouseDoubleClickEvent(QMouseEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe PagesTabBar
    *
    * \param parent : Pages parent des tabulations des pages
    */
    PagesTabBar(Pages*);
};

#endif // PAGESTABBAR_H
