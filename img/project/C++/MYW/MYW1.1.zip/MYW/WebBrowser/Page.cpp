/*========================================================================
Nom: Page.cpp           auteur: Maneschi Romain
Maj: 17.05.2009         Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWebView.
=========================================================================*/

#include <iostream>
using namespace std;

#include "Page.h"
#include "Pages.h"

#include "../mesConfigs.h"
#include "Historique.h"
#include "HistoriqueWidget.h"

Page::Page(Pages * p) : QWebView(p)
{
    parent = p;
    lien_pointe = 0;
    lien_est_pointe = false;

    this->setPage(new Frame(this));

    connect(this->page(), SIGNAL(linkHovered(QString, QString, QString)), this, SLOT(lienPointe(QString, QString, QString)));

    action_fermer_page = new QAction(this);
    action_fermer_page->setIcon(QIcon(":/temp/images/page_cross.gif"));
    action_fermer_page->setText(tr("Fermer cet onglet"));
    connect(action_fermer_page, SIGNAL(triggered()), this, SLOT(fermerTab()));

    action_fermer_page_s = new QAction(this);
    action_fermer_page_s->setIcon(QIcon(":/temp/images/page_delete.gif"));
    action_fermer_page_s->setText(tr("Fermer tous les onglets"));
    action_fermer_page_s->setData(-1);
    connect(action_fermer_page_s, SIGNAL(triggered()), this, SLOT(fermerTabS()));

    connect(this, SIGNAL(loadFinished(bool)), this, SLOT(chargementTermine(bool)));
    connect(this, SIGNAL(titleChanged(QString)), this, SLOT(titreCharge(QString)));

    this->setAttribute(Qt::WA_DeleteOnClose);
}

void Page::mousePressEvent(QMouseEvent * event)
{
    if(event->button() == Qt::MidButton && lien_est_pointe)
    {
        parent->getParent()->chargerPage(*lien_pointe, 1);
        event->accept();
    }
    else if(event->button() == Qt::LeftButton && lien_est_pointe)
    {
        parent->getParent()->chargerPage(*lien_pointe, 0);
        event->accept();
    }
    QWebView::mousePressEvent(event);
}

void Page::contextMenuEvent(QContextMenuEvent * event)
{
    QMenu * menu = new QMenu();
    menu->setAttribute(Qt::WA_DeleteOnClose);
    QAction * action;

    if(history()->canGoBack())
    {
        action = pageAction(QWebPage::Back);
        action->setText(tr("Retour"));
        menu->addAction(action);
    }

    action = pageAction(QWebPage::Reload);
    action->setText(tr("Recharger"));
    menu->addAction(action);

    if(history()->canGoForward())
    {
        action = pageAction(QWebPage::Forward);
        action->setText(tr("Avancer"));
        menu->addAction(action);
    }

    action = pageAction(QWebPage::OpenFrameInNewWindow);
    action->setIcon(QIcon(":/temp/images/note_new.gif"));
    action->setText(tr("Charger cette page dans un nouvel onglet"));
    menu->addAction(action);

    menu->addSeparator();

    if(this->page()->currentFrame()->hitTestContent(event->pos()).imageUrl().isValid())
    {
        action = pageAction(QWebPage::OpenImageInNewWindow);
        action->setText(tr("Ouvrir l'image dans un nouvel onglet"));
        action->setIcon(QIcon(":/temp/images/tables.gif"));
        menu->addAction(action);

        action = pageAction(QWebPage::CopyImageToClipboard);
        action->setText(tr("Copier"));
        action->setIcon(QIcon(":/temp/images/copy.gif"));
        menu->addAction(action);

        action = pageAction(QWebPage::DownloadImageToDisk);
        action->setText(tr("Enregistrer l'image (non fonctionel)"));
        action->setIcon(QIcon(":/temp/images/action_save.gif"));
        menu->addAction(action);
    }

    menu->addSeparator();

    if(lien_est_pointe)
    {
        menu->addSeparator();

        action = pageAction(QWebPage::CopyLinkToClipboard);
        action->setText(tr("Copier l'url du lien"));
        action->setIcon(QIcon(":/temp/images/copy.gif"));
        menu->addAction(action);

        action = pageAction(QWebPage::OpenLink);
        action->setIcon(QIcon(":/temp/images/note.gif"));
        action->setText(tr("Ouvrir"));
        menu->addAction(action);

        action = pageAction(QWebPage::OpenLinkInNewWindow);
        action->setIcon(QIcon(":/temp/images/note_new.gif"));
        action->setText(tr("Ouvrir dans un nouvel onglet"));
        menu->addAction(action);
    }

    menu->addSeparator();

    if(this->page()->currentFrame()->hitTestContent(event->pos()).isContentSelected())
    {
        action = pageAction(QWebPage::Copy);
        action->setIcon(QIcon(":/temp/images/copy.gif"));
        action->setText(tr("Copier"));
        menu->addAction(action);
    }
    if(this->page()->currentFrame()->hitTestContent(event->pos()).isContentEditable())
    {
        action = pageAction(QWebPage::Cut);
        action->setIcon(QIcon(":/temp/images/cut.gif"));
        action->setText(tr("Couper"));
        menu->addAction(action);

        action = pageAction(QWebPage::Paste);
        action->setIcon(QIcon(":/temp/images/action_paste.gif"));
        action->setText(tr("Coller"));
        menu->addAction(action);
    }

    menu->addSeparator();

    action_fermer_page->setData(parent->currentIndex());
    menu->addAction(action_fermer_page);
    if(parent->count() > 1)
    {
        menu->addAction(action_fermer_page_s);
    }

    menu->addSeparator();

    action = pageAction(QWebPage::InspectElement);
    action->setIcon(QIcon(":/temp/images/page_code.gif"));
    action->setText(tr("Voir le code source de la page (non fonctionel)"));
    menu->addAction(action);

    menu->move(event->globalPos());
    menu->show();

    event->accept();
}

void Page::lienPointe(QString lien, QString /*titre*/, QString /*description*/)
{
    if(lien != "")
    {
        lien_pointe = new QUrl(lien);
        lien_est_pointe = true;
    }
    else
    {
        lien_est_pointe = false;
    }
}

QWebView* Page::createWindow(QWebPage::WebWindowType)
{
    if(lien_est_pointe)
    {
        parent->charger(*lien_pointe);
    }
    else
    {
        parent->charger(QUrl());
    }
    return parent->getPageCourante();
}

void Page::fermerTab()
{
    parent->fermerTab(action_fermer_page);
}

void Page::fermerTabS()
{
    parent->fermerTab(action_fermer_page_s);
}

void Page::chargementTermine(bool b)
{
    if(b)
    {
        toImage(this->url().host().prepend("WebBrowser/Images/historique/").append(".png").prepend(systeme_relation_fichier));
        parent->getParent()->getHistorique()->getHistoriqueWidget()->mettreAJour();
    }
}

void Page::titreCharge(QString s)
{
    if(!s.isEmpty())
    {
        parent->getParent()->ajouterEntreeHistorique(this->url().toString(), s);
    }
}

void Page::toImage(const QString emplacement)
{
    if(!QFile(emplacement).exists())
    {
        QPixmap pixmap(this->size());
        this->render(&pixmap,
                     QPoint(0, 0),
                     QRegion (0, 0, this->width(), this->height()),
                     RenderFlags());
        QPixmap pixmap_bonne_taille = pixmap.scaled(500, 300, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        pixmap_bonne_taille.save(emplacement);
    }
}

bool Page::estCopiable()
{
    return this->page()->currentFrame()->hitTestContent(this->cursor().pos()).isContentSelected();
}

bool Page::estEditable()
{
    return this->page()->currentFrame()->hitTestContent(this->cursor().pos()).isContentEditable();
}
