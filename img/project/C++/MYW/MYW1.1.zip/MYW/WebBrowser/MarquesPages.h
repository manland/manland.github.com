#ifndef MARQUESPAGES_H
#define MARQUESPAGES_H

/*========================================================================
Nom: MarquesPages.h           auteur: Maneschi Romain
Maj: 17.05.2009               Creation: 05.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe contenant les QPushButton des marques-pages. Définition de la structure struct_marque_page.
=========================================================================*/

/*!
* \file MarquesPages.h
* \brief Classe contenant les QPushButton des marques-pages. Définition de la structure struct_marque_page.
* \author Maneschi Romain
* \date 05.05.2009
*/

#include <QToolBar>
#include <QSettings>
#include <QList>
#include <QPushButton>
#include <QPointer>
#include <QMenu>
#include <QVBoxLayout>
#include <QPainter>
#include <QComboBox>
#include <QTreeWidget>
#include <QStringList>
#include <QHeaderView>

#include "MarquePage.h"
#include "MarquePageFleches.h"
#include "MarquePageMenu.h"

class WebBrowser;
class Pages;

/*!
* \struct struct_marque_page
*
* \param titre : QString le nom du marque page
* \param urls : QMap<QString titre, QString urls> Si le titre du map est le même que le titre alors c'est un marque page sinon c'est un dossier de marques pages
*/
struct struct_marque_page
{
    QString titre;
    QMap<QString/*titre*/, QVariant/*url*/> urls;//QVariant = QString c'est pour QSettings
    void getUrls();
};

/*!
* \class MarquesPages
* \brief Classe réalisant les actions du C dans le pattern MVC. Elle gère donc l'insertion et le retrait d'un marque_page ou d'un
*        dossier de marques-pages
*
* Classe appelant Marque-Page pour l'affichage et permettant la gestion complète des marques-pages. De plus elle se charge
* de sauvegarder, restaurer les marques-pages de l'utilisateur.
*/
class MarquesPages : public virtual QToolBar
{
    Q_OBJECT

private:
    WebBrowser * parent;/*!< Le parent de la classe*/
    QList<struct struct_marque_page> * list_marques;/*!< Liste de marque-page qu'il soit simple ou en menu*/
    /*!
    * \brief Restaure les marques-pages grâce aux qsettings
    */
    virtual void restaurer();
    /*!
    * \brief Enregistre les marques-pages grâce aux qsettings
    */
    virtual void enregistrer();
    /*!
    * \brief Créer les marques-pages en construisant des MarquePage
    */
    virtual void creerBoutons();
    QList<MarquePage*> * list_marques_boutons;/*!< Liste des boutons de marque-page qu'il soit simple ou en menu*/
    /*!
    * \brief Insère un MarquePageFleches à l'endroit où est la souris
    *
    * \param point : QPoint de la souris au moment du drag
    */
    virtual void insererWidgetFleche(QPoint);
    QAction * action_fleche;/*!< Contient les flêches lors d'un drag*/
    QWidget * widget_fleche;/*!< Contient les flêches lors d'un drag*/
    //---------------AJOUTER DOSSIER---------------
    QWidget * widgetAjouterDossier;/*!< Fenêtre pour ajouter un dossier de marques-pages*/
    QWidget * widgetSuppression;/*!< Fenêtre pour supprimer un ou plusieurs marques-pages*/
    QLineEdit * edit;/*!< Permet d'inscrir le nom du marque-page à créer*/
    QComboBox * cb;/*!< Permet de sélectionner la position du marque-page à créer*/
    //---------------SUPPRESSION---------------
    QTreeWidget * mes_marques_pages;/*!< Représente un marque-page ou un dossier de marques-pages*/
    QList<QTreeWidgetItem*> mp_a_supprimer;/*!< Représente l'arborescence des marques-pages*/

private slots:
    /*!
    * \brief Charge une action donc un marque-page contenue dans un dossier
    *
    * \param action : QAction contenant l'url de la page à charger dans le WebBrowser
    */
    virtual void charger(QAction*);
    /*!
    * \brief Méthode créant le dossier aprés avoir valider ajouterDossier()
    */
    virtual void ajouterDossierOk();
    /*!
    * \brief Ajoute à mp_a_supprimer le marque-page sélectionné
    *
    * \param item : QTreeWidgetItem représente un marque-page dans un QTreeView
    * \param i : int ça place dans le QTreeView
    */
    virtual void selectionItem(QTreeWidgetItem*, int);
    /*!
    * \brief Méthode supprimant les marques-pages de mp_a_supprimer aprés avoir valider suppression()
    */
    virtual void suppressionOk();

protected:
    /*!
    * \brief Permet la coloration du conteneur des marques-pages
    *
    * \param event : QPaintEvent événement déclanchant cette méthode
    */
    virtual void paintEvent(QPaintEvent*);
    /*!
    * \brief Permet de savoir si un drag passe dessus le conteneur des marques-pages
    *
    * \param event : QDragEnterEvent événement déclanchant cette méthode
    */
    virtual void dragEnterEvent(QDragEnterEvent*);
    /*!
    * \brief Permet de savoir si un drag passe dessus le conteneur des marques-pages
    *
    * \param event : QDragMoveEvent événement déclanchant cette méthode
    */
    virtual void dragMoveEvent(QDragMoveEvent*);
    /*!
    * \brief Réalise un drop sur le conteneur des marques-pages
    *
    * \param event : QDropEvent événement déclanchant cette méthode
    */
    virtual void dropEvent(QDropEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe MarquesPages
    *
    * \param parent : WebBrowser parent des marques-pages
    */
    MarquesPages(WebBrowser * p);
    /*!
    * \brief Ajoute un marque-page ou un dossier de marques-pages
    *
    * \param i : int position du marque-page
    * \param titre : QString titre du marque-page
    * \param url : QString url du marque-page
    * \param est_dossier : bool true si c'est un dossier, false sinon
    */
    virtual void ajouter(int, QString, QString = QString(""),  bool = true);
    /*!
    * \brief Charge la page internet d'un marque-page dans le WebBrowser
    *
    * \param url : QString url du marque-page
    * \param mode : int mode=0 dans l'onglet en cours mode=1 dans u nouvel onglet
    */
    virtual void charger(QUrl, int);
    /*!
    * \brief Met à jour les marques-pages
    */
    virtual void mettreAJour();
    /*!
    * \brief Supprime les flêches apparu lors d'un drag
    */
    virtual void supprimerFleche();
    /*!
    * \brief Supprime un marque-page ou un dossier
    *
    * \param i : int numéro du marque-page dans la liste list_marques
    */
    virtual void supprimerMarquePage(int);
    /*!
    * \brief Supprime un marque-page qui se trouve dans un dossier
    *
    * \param pere : int numéro du dossier dans la liste list_marques
    * \param titre : QString titre du marque-page à supprimer
    */
    virtual void supprimerAction(int, QString);
    /*!
    * \brief Supprime un marque-page qui se trouve dans un dossier
    *
    * \param pere : int numéro du dossier dans la liste list_marques
    * \param place : int numéro du marque-page à supprimer
    */
    virtual void supprimerAction(int, int);
    /*!
    * \brief Permet d'accéder au parent
    *
    * \return WebBrowser* le pointeur vers le mainwindow de WebBrowser
    */
    virtual WebBrowser* getParent();
    /*!
    * \brief Retourne le nombre de marque-page hors dossier + le nombre de dossiers
    *
    * \return int : le nombre de marque-page
    */
    virtual int getNbMarques();
    /*!
    * \brief Permet de savoir si un marque-page est déjà enregistrer
    *
    * \param url : QString url du marque-page à vérifier
    * \return true si le marque-page est déjà présent, false sinon
    */
    virtual bool contient(QString);
    /*!
    * \brief Supprime tous les marques-pages
    */
    virtual void toutSupprimer();
    /*!
    * \brief Supprime tous les marques-pages puis ajoute les marques-pages par défaut
    */
    virtual void defaut();
    /*!
    * \brief Accesseur des marques-pages
    *
    * \return QList<struct struct_marque_page>
    */
    virtual QList<struct struct_marque_page>* getListMarquesPages();
    /*!
    * \brief Créer une fenêtre pour ajouter un dossier de marques-pages
    */
    virtual void ajouterDossier();
    /*!
    * \brief Créer une fenêtre pour supprimer un ou plusieurs marques-pages
    */
    virtual void suppression();

};
#endif // MARQUESPAGES_H
