#ifndef HISTORIQUEWIDGET_H
#define HISTORIQUEWIDGET_H

/*========================================================================
Nom: HistoriqueWidget.h           auteur: Maneschi Romain
Maj: 17.05.2009                   Creation: 12.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe contenant l'interface graphique de l'historique. Correspond au V du pattern MVC.
=========================================================================*/

/*!
* \file HistoriqueWidget.h
* \brief Classe contenant l'interface graphique de l'historique. Correspond au V du pattern MVC.
* \author Maneschi Romain
* \date 12.04.2009
*/

#include <QWidget>
#include <QDir>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QSlider>
#include <QLabel>
#include <QPixmap>
#include <QStringList>
#include <QPainter>
#include <QPushButton>
#include <QAction>
#include <QUrl>
#include <QComboBox>

#include "HistoriqueLabel.h"

class Historique;

/*!
* \class HistoriqueWidget
* \brief Classe contenant et affichant les HistoriqueLabel. Correspond au V dans le pattern MVC.
*
* Classe affichant sous forme d'icones l'historique de l'utilisateur. Il peut accéder, au travers de boutons, au site préalablement
* visité, et peut classer les liens de diverses façons.
*/
class HistoriqueWidget : public virtual QWidget
{
    Q_OBJECT

private:
    int nb_miniatures;/*!< A PARAMETRER nombre de miniatures affichées*/
    Historique * parent;/*!< Le parent de la classe*/
    QHBoxLayout * layout_general;/*!< Layout general du widget*/
    QVBoxLayout * layout_gauche;/*!< Layout contenant les icones*/
    QComboBox * tri;/*!< Choix de la façon d'afficher les icones de l'historique*/
    /*!
    * \brief  Créer les miniatures de l'historique
    *
    * \return le QWidget conteneur des icones
    */
    virtual QWidget* creerMiniatures();
    int premiere_miniature_en_cours;/*!< Permet de savoir qu'elle est la première miniature à s'afficher dans le cadre de droite*/
    QWidget * miniature_widget;/*!< Pointeur sur le widget contenant les miniatures de l'historique*/
    QList<HistoriqueLabel*> * list_miniatures;/*!< Liste des icones*/
    QHBoxLayout * h_layout_miniatures;/*!< Layout horizontal des icones*/
    QPushButton * retour;/*!< Bouton pour reculer dans les icones*/
    QPushButton * avancer;/*!< Bouton pour avancer dans les icones*/
    /*!
    * \brief Fonction modifiant list_miniatures afin de les afficher par date
    */
    virtual void creerListeParDate();
    /*!
    * \brief Fonction modifiant list_miniatures afin de les afficher par date en enlevant les sites visités plusieurs fois daffiler
    */
    virtual void creerListeParDateFiltre();
    /*!
    * \brief Fonction modifiant list_miniatures afin de les afficher du plus visité au moins visité
    */
    virtual void creerListeParPlusVisite();
    /*!
    * \brief Fonction inversant list_miniatures
    */
    virtual void retournerList();
    QList<struct struct_historique> * date_s;/*!< Liste de l'historique contenant une seule date pour une icone*/
    /*!
    * \brief Fonction affichant les miniatures à ne pas confondre avec show() d'un qwidget
    */
    virtual void afficherMiniatures();
    /*!
    * \brief Fonction permettant de modifier les miniatures affichées
    *
    * \param depart : int depuis le départ
    * \param arrivee : int jusqu'à l'arrivée
    */
    virtual void modifierMiniatures(int, int);
    /*!
    * \brief Met à jour les boutons avancer, reculer en fonctions des sites affichés
    */
    virtual void mettreAJourBoutons();
    /*!
    * \brief Fonction créant la partie droite
    *
    * \return le QLabel représentant l'image de prévisualisation
    */
    virtual QLabel* creerPrevisualisation();
    QLabel * previsualisation;/*!< Prévisualisation de gauche*/

private slots:
    /*!
    * \brief Action appelée lors du click sur retour
    */
    virtual void actionRetour();
    /*!
    * \brief Action appelée lors du click sur avancer
    */
    virtual void actionAvancer();
    /*!
    * \brief Action appelée lors d'un choix de tri de l'historique
    */
    virtual void selectionFiltre(int);

protected:
    /*!
    * \brief Gère la taille des images lors d'un agrandissement
    *
    * \param event : QResizeEvent événement déclanchant cette méthode
    */
    virtual void resizeEvent(QResizeEvent*);
    /*!
    * \brief Permet la coloration du widget conteneur
    *
    * \param event : QPaintEvent événement déclanchant cette méthode
    */
    virtual void paintEvent(QPaintEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe HistoriqueWidget
    *
    * \param parent : Historique parent de l'HistoriqueWidget
    */
    HistoriqueWidget(Historique * p);
    /*!
    * \brief Permet de changer la prévisualisation
    *
    * \param pixmap : QPixmap image de la prévisualisation
    */
    virtual void changerPrevisualisation(const QPixmap*);
    /*!
    * \brief Permet d'accéder au parent
    *
    * \return Historique* le pointeur de l'historique
    */
    virtual Historique* getParent();
    /*!
    * \brief Met à jour les boutons avancer et reculer
    */
    virtual void mettreAJour();
    /*!
    * \brief Permet d'accéder aux date_s
    *
    * \return QList<struct_historique>* le pointeur vers la liste des date_s
    */
    virtual QList<struct_historique>* getUrlS();
};
#endif // HISTORIQUEWIDGET_H
