/*========================================================================
Nom: WebBrowser.cpp           auteur: Maneschi Romain
Maj: 17.05.2009               Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe principale du module.
=========================================================================*/

#include <iostream>
using namespace std;

#include "WebBrowser.h"
#include "Pages.h"
#include "Historique.h"
#include "MarquesPages.h"
#include "WebBrowserMenuBar.h"
#include "../mesConfigs.h"

WebBrowser::WebBrowser(QUrl url, QWidget * parent) : QMainWindow(parent)
{
    url_par_default = QUrl("http://projet.lydiman.net");

    QWebSettings::setIconDatabasePath(QString("WebBrowser/Images/favicon/").prepend(systeme_relation_fichier));
    historique = new Historique(this);
    historique->getHistorique()->hide();

    multi_pages = new Pages(QUrl(), this);

    this->setCentralWidget(multi_pages);

    this->creerPanneauCommandes();
    this->creerPanneauRecherche();
    this->creerPanneauUrl();
    this->addToolBarBreak(Qt::TopToolBarArea);//pour ne pas ajouter de QToolBar aprs
    this->creerStatusBar();

    chargerPage(url, 0);

    menu_bar = 0;//pour que getMenuBar() renvoie 0 dans MarquesPages::mettreAJour()
    marques_pages = new MarquesPages(this);

    menu_bar = new WebBrowserMenuBar(this);
    this->setMenuBar(menu_bar);

    marques_pages->mettreAJour();

    this->setWindowIcon(QIcon(":/WebBrowser/icone_principale"));
    this->setWindowTitle("WebBrowser Editor");
    this->setGeometry(0, 0, 1200, 700);
}

WebBrowser::~WebBrowser()
{

}

void WebBrowser::closeEvent(QCloseEvent * event)
{
    event->accept();
}

void WebBrowser::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
//    QLinearGradient gradient(this->width()/2, 0, this->width()/2, this->height());
//    gradient.setColorAt(0.0, Qt::darkGray);
//    gradient.setColorAt(0.45, Qt::black);
//    gradient.setColorAt(0.5, Qt::lightGray);
//    gradient.setColorAt(0.55, Qt::black);
//    gradient.setColorAt(1.0, Qt::darkGray);
    painter.setPen(Qt::darkGray);
    painter.setPen(QColor(0, 153, 0, 255));
//    painter.setBrush(gradient);
    painter.drawRect(0, 0, this->width(), this->height());
    painter.end();
    event->accept();
}

void WebBrowser::keyPressEvent(QKeyEvent * event)
{
    //menu fichier
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_T)//nouvel onglet
    {
        this->chargerPage(url_par_default, 1);
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_U)//ouvrir adress
    {
        edition_url->selectAll();
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_O)//ouvrir fichier
    {
        this->ouvrirFichier();
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_P)//imprimer
    {
        menu_bar->imprimer();
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_F)//fermer onglet
    {
        multi_pages->fermerTab(multi_pages->getIdPageCourante());
    }
    if(event->modifiers() == Qt::ControlModifier && event->modifiers() == Qt::ShiftModifier && event->key() == Qt::Key_F)//fermer ongletS
    {
        for(int i=0; i<multi_pages->count(); i++)
        {
            multi_pages->fermerTab(i);
        }
    }
    //menu edition
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_C)//copier
    {
        getPageCourante()->triggerPageAction(QWebPage::Copy);
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_X)//couper
    {
        getPageCourante()->triggerPageAction(QWebPage::Cut);
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_V)//coller
    {
        getPageCourante()->triggerPageAction(QWebPage::Paste);
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_A)//copier
    {
        getPageCourante()->triggerPageAction(QWebPage::SelectAll);
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_F)//rechercher
    {

    }
    if(false/*EXISTE DEJA CTRL+P event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_P*/)//prfrences
    {

    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_Up)//zoom+
    {
        getPageCourante()->setZoomFactor(getPageCourante()->zoomFactor() + 0.1);
    }
    if(event->modifiers() == Qt::ControlModifier && event->key() == Qt::Key_Down)//zoom-
    {
        getPageCourante()->setZoomFactor(getPageCourante()->zoomFactor() - 0.1);
    }

}

void WebBrowser::ouvrirFichier()
{
    QFileDialog * choisir_fichier = new QFileDialog(this);
    choisir_fichier->show();
    connect(choisir_fichier, SIGNAL(fileSelected(QString)), this, SLOT(ouvrirFichier(QString)));
}

void WebBrowser::ouvrirFichier(QString s)
{
    if(!s.isEmpty())
    {
        chargerPage(QUrl(s.prepend("file://")), 1);
    }
}

void WebBrowser::chargerPage(QUrl u, int mode)
{
    if(mode == 0)
    {
        edition_url->setText(u.toString());
        actionCharger();//pour v�rifier la syntaxe avec les site "? : recherche"
    }
    else
    {
        multi_pages->charger(u);
        edition_url->setText(u.toString());
        actionCharger();//pour v�rifier la syntaxe avec les site "? : recherche"
    }
}

void WebBrowser::creerPanneauCommandes()
{
    panneau_commandes = this->addToolBar(tr("&Actions"));

    action_reculer = new QAction(tr("&Reculer"), this);
    action_reculer->setEnabled(false);
    action_reculer->setIcon(QIcon(QString(":/WebBrowser/precedent")));
    action_reculer->setShortcut(tr("Ctrl+R"));
    action_reculer->setStatusTip(tr("Reculer d'une page"));
    connect(action_reculer, SIGNAL(triggered()), this, SLOT(actionRetour()));
    panneau_commandes->addAction(action_reculer);

    action_recharger = new QAction(tr("&Recharger"), this);
    action_recharger->setIcon(QIcon(QString(":/WebBrowser/recharger")));
    action_recharger->setShortcut(tr("Ctrl+R"));
    action_recharger->setStatusTip(tr("Recharger la page"));
    connect(action_recharger, SIGNAL(triggered()), this, SLOT(actionCharger()));
    panneau_commandes->addAction(action_recharger);

    action_avancer = new QAction(tr("&Avancer"), this);
    action_avancer->setIcon(QIcon(QString(":/WebBrowser/suivant")));
    action_avancer->setShortcut(tr("Ctrl+A"));
    action_avancer->setStatusTip(tr("Avancer d'une page"));
    connect(action_avancer, SIGNAL(triggered()), this, SLOT(actionAvancer()));
    panneau_commandes->addAction(action_avancer);

    action_stop = new QAction(tr("&Arr�ter"), this);
    action_stop->setIcon(QIcon(":/WebBrowser/arreter"));
    action_stop->setShortcut(tr("Ctrl+S"));
    action_stop->setStatusTip(tr("Arr�ter le chargement de la page"));
    connect(action_stop, SIGNAL(triggered()), multi_pages->getPageCourante(), SLOT(stop()));
    panneau_commandes->addAction(action_stop);

    action_accueil = new QAction(tr("&Accueil"), this);
    action_accueil->setIcon(QIcon(":/WebBrowser/accueil"));
    action_accueil->setShortcut(tr("Ctrl+H"));
    action_accueil->setStatusTip(tr("Retour � la page d'accueil"));
    connect(action_accueil, SIGNAL(triggered()), this, SLOT(actionChargerAccueil()));
    panneau_commandes->addAction(action_accueil);

}

void WebBrowser::mettreAJourCommandes()
{
    if(multi_pages->getPageCourante()->page()->history()->canGoBack())
    {
        action_reculer->setEnabled(true);
    }
    else
    {
        action_reculer->setEnabled(false);
    }
    if(multi_pages->getPageCourante()->page()->history()->canGoForward())
    {
        action_avancer->setEnabled(true);
    }
    else
    {
        action_avancer->setEnabled(false);
    }
}

void WebBrowser::chargementDemarrage()
{
    QApplication::setOverrideCursor(QCursor(Qt::BusyCursor));
    progress_bar->setValue(0);
    progress_bar->show();
    status_bar_messages->setText(tr("Attente des donn�es..."));
    action_stop->setEnabled(true);
}

void WebBrowser::chargementEnCours(int i)
{
    if(progress_bar->isHidden())
    {
        progress_bar->show();
    }
    if(!action_stop->isEnabled())
    {
        action_stop->setEnabled(true);
    }
    progress_bar->setValue(i);
    status_bar_messages->setText(tr("T�l�chargement des donn�es en cours..."));
}

void WebBrowser::chargementTermine(bool b)
{
    QApplication::restoreOverrideCursor();
    if(b)//si tout c'est bien pass�
    {
        status_bar_messages->setText(tr("T�l�chargement des donn�es termin�."));
    }

    else
    {
        status_bar_messages->setText(tr("T�l�chargement des donn�es �chou�."));
    }

    action_stop->setEnabled(false);
    progress_bar->hide();
    int i = protocol->findText(multi_pages->getPageCourante()->page()->currentFrame()->url().scheme().append("://"));
    if(i != -1)
    {
            protocol->setCurrentIndex(i);
    }
    edition_url->setText(multi_pages->getPageCourante()->page()->currentFrame()->url().toString());
    mettreAJourCommandes();
    //permet d'ajouter les action dan le boutton fermer
    multi_pages->mettreAJourBouttonFermer();
}

void WebBrowser::creerPanneauRecherche()
{
    panneau_recherche = addToolBar("Recherches");

    protocol = new QComboBox();
    protocol->insertItem(1, tr("http://"), "http://");
    protocol->insertItem(2, tr("file://"), "file://");
    protocol->insertSeparator(3);
    protocol->insertItem(4, QIcon(QString("WebBrowser/Images/favicon/google.ico").prepend(systeme_relation_fichier)), tr("Google"), "google:");
    protocol->insertItem(5, QIcon(QString("WebBrowser/Images/favicon/exalead.ico").prepend(systeme_relation_fichier)), tr("Exalead"), "exalead:");
    protocol->insertItem(6, QIcon(QString("WebBrowser/Images/favicon/wikipedia.ico").prepend(systeme_relation_fichier)), tr("Wikipedia"), "wikipedia:");
    protocol->insertItem(7, QIcon(QString("WebBrowser/Images/favicon/sdz.jpg").prepend(systeme_relation_fichier)), tr("SiteDuZ�ro"), "sdz:");
    protocol->insertItem(8, QIcon(QString("WebBrowser/Images/favicon/cs.ico").prepend(systeme_relation_fichier)), tr("Codes-Sources"), "cs:");
    protocol->insertSeparator(9);
    protocol->insertItem(10, QIcon(QString("WebBrowser/Images/favicon/php.png").prepend(systeme_relation_fichier)), tr("php"), "php:");
    protocol->insertItem(11, QIcon(QString("WebBrowser/Images/favicon/javascript.png").prepend(systeme_relation_fichier)), tr("JavaScript"), "js:");
    protocol->insertSeparator(12);
    protocol->insertItem(13, tr("Aide..."));
    panneau_recherche->addWidget(protocol);

    connect(protocol, SIGNAL(activated(int)), this, SLOT(editionUrl(int)));

    panneau_recherche->setMovable(false);
}

void WebBrowser::creerPanneauUrl()
{
    panneau_url = addToolBar("Url");

    edition_url = new QLineEdit(multi_pages->getPageCourante()->page()->currentFrame()->url().toString());
    panneau_url->addWidget(edition_url);

    QAction * action_charger = new QAction(tr("&Envoyer"), this);
    action_charger->setIcon(QIcon(QString(":/WebBrowser/valider.png")));
    action_charger->setShortcut(tr("Ctrl+R"));
    action_charger->setStatusTip(tr("Charger l'url"));
    connect(action_charger, SIGNAL(triggered()), this, SLOT(actionCharger()));
    panneau_url->addAction(action_charger);
    
    connect(edition_url, SIGNAL(returnPressed()), this, SLOT(actionCharger()));
    panneau_url->setMovable(false);
}

void WebBrowser::editionUrl(int i)
{
    if(protocol->itemData(i) != QVariant::Invalid)
    {
        edition_url->setText(protocol->itemData(i).toString());
    }
    else if(protocol->itemData(i)==QVariant::Invalid)
    {
        QString aide("");
        aide = aide + tr("Ce panneau vous permet de rechercher simplement et efficacement sur le web.\n\n")
               + tr("Voici une courte explication sur les diff�rentes options : \n")
               + tr("ChoixX : en cliquant sur ce choix vous verrez appara�tre 'ChoixX : ' dans la barre des ")
               + tr("liens. En y ajoutant votre recherche et ensuite en pressant 'Entr�e' vous serez redirig� ")
               + tr("sur le site X avec la recherche que vous aviez demand�.\n\n")
               + tr("Sites et raccourccis :\n")
               + tr("- G�n�ral (les espaces) :\n")
               + tr("          \"X:recherche\" = \"X : recherche\" \n")
               + tr("- G�n�ral (les majusucles) :\n")
               + tr("          \"X:recherche\" = \"x:recherche\" \n")
               + tr("- Google (www.google.fr) :\n")
               + tr("          \"Google:recherche\" = \"google:recherche\" = \"?:recherche\"\n")
               + tr("- Exalead (www.exalead.fr) :\n")
               + tr("          \"Exalead:recherche\" = \"exa:recherche\" = \"??:recherche\" \n")
               + tr("- Wikip�dia (http://fr.wikipedia.org) :\n")
               + tr("          \"Wikipedia:recherche\" = \"wiki:recherche\" = \"!:recherche\" \n")
               + tr("- SiteDuZ�ro (www.siteduzero.com) :\n")
               + tr("          \"SDZ:recherche\" = \"�:recherche\" \n")
               + tr("- Codes-Sources (www.codes-sources.com) :\n")
               + tr("          \"codes-sources:recherche\" = \"cs:recherche\" = \"*:recherche\" \n")
               + tr("- Php (www.manuelphp.com) :\n")
               + tr("          \"php:recherche\" = \"$:recherche\" \n")
               + tr("- JavaScript (developer.mozilla.org) :\n")
               + tr("          \"JavaScript:recherche\" = \"js:recherche\" \n");

        if(okPourContinuer(tr("Aide..."), aide, 1, false))
        {
            int i = protocol->findText(multi_pages->getPageCourante()->page()->currentFrame()->url().scheme().append("://"));
            if(i != -1)
            {
                    protocol->setCurrentIndex(i);
            }
            edition_url->setText(multi_pages->getPageCourante()->page()->currentFrame()->url().toString());
        }
    }
}

void WebBrowser::actionCharger()
{
    QString s(edition_url->text());
    if(s.startsWith("http://") ||
            s.startsWith("https://"))
    {
        multi_pages->getPageCourante()->load(QUrl(s));
    }
    else if(s.startsWith("file://"))
    {
        if(s.contains(QRegExp("^file://.:/")))
        {
            s.remove(7, 2);
        }
        multi_pages->getPageCourante()->load(QUrl(s));
    }
    else if(s.startsWith("Google : ", Qt::CaseInsensitive) || s.startsWith("Google:", Qt::CaseInsensitive) ||
       s.startsWith("? : ") || s.startsWith("?:"))
    {
        s = s.section(":", 1, 1);
        multi_pages->getPageCourante()->load(QUrl(s.prepend("http://google.fr/search?q=")));
    }
    else if(s.startsWith("Exalead : ", Qt::CaseInsensitive) || s.startsWith("Exalead:", Qt::CaseInsensitive) ||
            s.startsWith("Exa : ", Qt::CaseInsensitive) || s.startsWith("Exa:", Qt::CaseInsensitive) ||
            s.startsWith("?? : ") || s.startsWith("??:"))
    {
        s = s.section(":", 1, 1);
        multi_pages->getPageCourante()->load(QUrl(s.prepend("http://www.exalead.fr/search/results?q=")));
    }
    else if(s.startsWith("Wikipedia : ", Qt::CaseInsensitive) || s.startsWith("Wikipedia:", Qt::CaseInsensitive) ||
            s.startsWith("Wiki : ", Qt::CaseInsensitive) || s.startsWith("Wiki:", Qt::CaseInsensitive) ||
            s.startsWith("! : ") || s.startsWith("!:"))
    {
        s = s.section(":", 1, 1);
        multi_pages->getPageCourante()->load(QUrl(s.prepend("http://fr.wikipedia.org/wiki/")));
    }
    else if(s.startsWith("SDZ : ", Qt::CaseInsensitive) || s.startsWith("SDZ:", Qt::CaseInsensitive) ||
            s.startsWith("� : ") || s.startsWith("�:"))
    {
        s = s.section(":", 1, 1);
        s.prepend("http://www.siteduzero.com/recherche.html?src=");
        multi_pages->getPageCourante()->load(QUrl(s.append("&c=3")));
    }
    else if(s.startsWith("codes-sources : ", Qt::CaseInsensitive) || s.startsWith("codes-sources:", Qt::CaseInsensitive) ||
            s.startsWith("cs : ", Qt::CaseInsensitive) || s.startsWith("cs:", Qt::CaseInsensitive) ||
            s.startsWith("* : ") || s.startsWith("*:"))
    {
        s = s.section(":", 1, 1);
        s.prepend("http://www.codes-sources.com/recherche.aspx?r=");
        multi_pages->getPageCourante()->load(QUrl(s));
    }
    else if(s.startsWith("php : ", Qt::CaseInsensitive) || s.startsWith("php:", Qt::CaseInsensitive) ||
            s.startsWith("$ : ") || s.startsWith("$:"))
    {
        s = s.section(":", 1, 1);
        s.prepend("http://www.manuelphp.com/rechercher.php?rechercher=");
        multi_pages->getPageCourante()->load(QUrl(s.append("&fonctions=1&concepts=1&mysql=1&html=1&cours=1&scripts=1")));
    }
    else if(s.startsWith("js : ", Qt::CaseInsensitive) || s.startsWith("js:", Qt::CaseInsensitive) ||
            s.startsWith("javascript : ", Qt::CaseInsensitive) || s.startsWith("javascript : ", Qt::CaseInsensitive))
    {
        s = s.section(":", 1, 1);
        s.prepend("https://developer.mozilla.org/index.php?title=Special:Search&search=");
        multi_pages->getPageCourante()->load(QUrl(s.append("&language=fr&fulltext=Search")));
    }
    else if(s.startsWith("www.", Qt::CaseInsensitive))
    {
        multi_pages->getPageCourante()->load(QUrl(s.prepend("http://")));
    }
    else
    {
        multi_pages->getPageCourante()->load(QUrl(s.prepend("http://google.fr/search?q=")));
    }
}

void WebBrowser::actionRetour()
{
    multi_pages->getPageCourante()->back();
}

void WebBrowser::actionAvancer()
{
    multi_pages->getPageCourante()->forward();
}

void WebBrowser::actionChargerAccueil()
{
    this->chargerPage(url_par_default, 0);
}

void WebBrowser::actionProprietes()
{

}

void WebBrowser::creerStatusBar()
{
    status_bar_messages = new QLabel(tr(" Messages... "));
    statusBar()->addWidget(status_bar_messages);

    progress_bar = new QProgressBar();
    progress_bar->setMaximumWidth(150);
    progress_bar->setMaximumWidth(150);
    progress_bar->setAlignment(Qt::AlignRight);
    statusBar()->addPermanentWidget(progress_bar);
}

void WebBrowser::changementTab(int)
{
    edition_url->setText(multi_pages->getPageCourante()->url().toString());
    mettreAJourCommandes();
}

void WebBrowser::sourisSurLien(QString lien, QString /*titre*/, QString /*description*/)
{
    status_bar_messages->setText(lien);
}

void WebBrowser::ajouterEntreeHistorique(QString url, QString titre)
{
    historique->ajouterEntree(url, titre);
}

QUrl WebBrowser::getUrlParDefaut()
{
    return url_par_default;
}

MarquesPages* WebBrowser::getMarquesPages()
{
    return marques_pages;
}

Historique* WebBrowser::getHistorique()
{
    return historique;
}

QLineEdit* WebBrowser::getEditionUrl()
{
    return edition_url;
}

void WebBrowser::fermerOngletCourant()
{
    multi_pages->fermerTab(multi_pages->getIdPageCourante());
}

void WebBrowser::fermerOngletS()
{
    for(int i=0; i<multi_pages->count(); i++)
    {
        multi_pages->fermerTab(i);
    }
}

Page* WebBrowser::getPageCourante()
{
    return multi_pages->getPageCourante();
}

QWidget* WebBrowser::getPanneauCommandes()
{
    return this->panneau_commandes;
}

QWidget* WebBrowser::getPanneauUrl()
{
    return this->panneau_url;
}

QWidget* WebBrowser::getPanneauRecherches()
{
    return this->panneau_recherche;
}

QComboBox* WebBrowser::getRecherches()
{
    return this->protocol;
}

QWidget* WebBrowser::getBarreEtat()
{
    return this->statusBar();
}

Pages* WebBrowser::getPages()
{
    return multi_pages;
}

void WebBrowser::setPages(Pages * p)
{
    multi_pages = p;
    setCentralWidget(multi_pages);
}

WebBrowserMenuBar* WebBrowser::getMenuBar()
{
    return menu_bar;
}


bool WebBrowser::okPourContinuer(QString titre, QString message, int icon, bool deux_button)
{
    QMessageBox msg(this);
    msg.setWindowTitle(titre);
    msg.setText(message);
    if(icon == 0)
    {
        msg.setIcon(QMessageBox::Question);
    }
    else if(icon == 1)
    {
        msg.setIcon(QMessageBox::Information);
    }
    else if(icon == 2)
    {
        msg.setIcon(QMessageBox::Warning);
    }
    else if(icon == 3)
    {
        msg.setIcon(QMessageBox::Critical);
    }
    else
    {
        msg.setIcon(QMessageBox::NoIcon);
    }

    if(deux_button)
    {
        QPushButton * annuler = new QPushButton(QIcon(":/temp/images/flag_red.gif"), tr("Annuler"));
        msg.addButton(annuler, QMessageBox::RejectRole);
    }

    QPushButton * accepter = new QPushButton(QIcon(":/temp/images/flag_green.gif"), tr("Accepter"));
    msg.addButton(accepter, QMessageBox::AcceptRole);

    int r = msg.exec();
    if(r==QMessageBox::AcceptRole)
    {
        return true;
    }
    else
    {
        return false;
    }
}
