/*========================================================================
Nom: Frame.cpp           auteur: Maneschi Romain
Maj: 17.05.2009          Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWebPage.
=========================================================================*/

#include <iostream>
using namespace std;

#include "Frame.h"

#include "Page.h"

Frame::Frame(Page * p) : QWebPage(p)
{
    parent = p;
}

bool Frame::acceptNavigationRequest(QWebFrame * frame, const QNetworkRequest& request, NavigationType type)
{
    QNetworkAccessManager * manager = new QNetworkAccessManager(this);
    QNetworkReply * reply = manager->get(request);
    if(reply->hasRawHeader("Cookie"))
    {
        cout<<"cookie"<<endl;
    }
    if(reply->hasRawHeader("Set-Cookie"))
    {
        cout<<"set-cookie"<<endl;
    }
    return true;
}

QString Frame::chooseFile(QWebFrame *, const QString & suggestedFile)
{
    return QFileDialog::getOpenFileName(0, tr("Choisir un fichier"), QDir::homePath(), suggestedFile);
}

void Frame::javaScriptConsoleMessage(const QString & message, int lineNumber, const QString & sourceID)
{

}
