#ifndef HISTORIQUE_H
#define HISTORIQUE_H

/*========================================================================
Nom: Historique.h           auteur: Maneschi Romain
Maj: 17.05.2009             Creation: 12.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWebHistoryInterface correspond au MC du pattern MVC. Définition de la structure struct_historique.
=========================================================================*/

/*!
* \file Historique.h
* \brief Classe qui réimplante QWebHistoryInterface correspond au MC du pattern MVC. Définition de la structure struct_historique.
* \author Maneschi Romain
* \date 12.04.2009
*/

#include <QWebHistoryInterface>
#include <QList>
#include <QStandardItemModel>
#include <QTreeView>
#include <QVBoxLayout>
#include <QTime>
#include <QDateTime>
#include <QSettings>
#include <QDockWidget>
#include <QThread>
#include <QApplication>

class WebBrowser;
class HistoriqueWidget;

/*!
* \struct struct_historique
*
* \param url : QString l'url du site visité
* \param titre : QString le nom du site visité
* \param date : QList<QVariant> list des dates de visite du site
*/
struct struct_historique
{
    QString url;
    QString titre;
    QList<QVariant> date;//QVariant = QDateTime c'est pour QSettings
};

/*!
* \class Historique
* \brief Classe principale de l'historique. Correspond au C dans le modèle MVC.
*
* Classe réalisant l'insertion d'un nouveau site visité, la supression de tous les sites et construit la vue en appellant
* HistoriqueWidget. De plus elle se charge d'enregistrer et de restaurer la liste de struct_historique contenant les sites visités.
*
*
*/
class Historique : public virtual QWebHistoryInterface
{
    Q_OBJECT

private:
    WebBrowser * parent;/*!< Le parent de la classe*/
    QDockWidget * bar;/*!< Représente le conteneur graphique de l'historique*/
    QList<struct struct_historique> * url_s;/*!< Liste de l'historique*/
    HistoriqueWidget * historique;/*!< Pointeur vers la représentation graphique de l'historique*/
    /*!
    * \brief Enregistre les url_s grâce aux qsettings
    */
    virtual void enregistrer();
    /*!
    * \brief Restaure les url_s grâce aux qsettings
    */
    virtual void restaurer();

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe Historique
    *
    * \param parent : WebBrowser parent de l'historique
    */
    Historique(WebBrowser * p);
    /*!
    * \brief Ajouter une page internet à l'historique
    *
    * \param url : QString url de la page
    * \param titre : QString titre de la page
    */
    virtual void ajouterEntree(QString, QString);
    /*!
    * \brief Méthode obligatoire mais non utilisée dû à l'héritage de QWebHistoryInterface
    *
    * \param url : QString url de la page
    */
    virtual void addHistoryEntry(const QString&);//pas intéressant
    /*!
    * \brief Méthode obligatoire dû à l'héritage de QWebHistoryInterface permet de savoir si une page est déjà dans l'historique
    *
    * \param url : QString url de la page
    * \return true si l'historique contient la page, false sinon
    */
    virtual bool historyContains(const QString&) const;
    /*!
    * \brief Permet de supprimer tout l'historique appel supprimerIcones() et supprimerLiens() avant de rafraichir HistoriqueWidget
    */
    virtual void toutSupprimer();
    /*!
    * \brief Supprime toutes les icones des sites visités contenues dans executable/WebBrowser/Images/historique
    */
    virtual void supprimerIcones();
    /*!
    * \brief Supprime toutes les entrées des sites visités en vidant url_s et en appelant enregistrer()
    */
    virtual void supprimerLiens();
    /*!
    * \brief Permet d'accéder à url_s
    *
    * \return QList<struct_historique>* le pointeur de la liste des url_s
    */
    virtual QList<struct_historique>* getUrlS();
    /*!
    * \brief Permet d'accéder au dock contenant le widget contenant un HistoriqueWidget de l'historique
    *
    * \return QWidget* le pointeur du widget de l'historique
    */
    virtual QWidget* getHistorique();
    /*!
    * \brief Permet d'accéder au widget de l'historique
    *
    * \return HistoriqueWidget* le pointeur du widget de l'historique
    */
    virtual HistoriqueWidget* getHistoriqueWidget();//le widget de l'historique
    /*!
    * \brief Permet d'accéder au parent
    *
    * \return WebBrowser* le pointeur du mainwindow du WebBrowser
    */
    virtual WebBrowser* getParent();

};
#endif // HISTORIQUE_H
