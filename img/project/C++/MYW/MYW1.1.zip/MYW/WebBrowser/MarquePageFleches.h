#ifndef MARQUEPAGEFLECHES_H
#define MARQUEPAGEFLECHES_H

/*========================================================================
Nom: MarquePageFleches.h           auteur: Maneschi Romain
Maj: 17.05.2009                    Creation: 10.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWidget pour les marques-pages afin d'insérer des flèches lors d'un drag&drop.
=========================================================================*/

/*!
* \file MarquePageFleches.h
* \brief Classe qui réimplante QWidget pour les marques-pages afin d'insérer des flèches lors d'un drag&drop.
* \author Maneschi Romain
* \date 10.05.2009
*/

#include <QWidget>
#include <QLabel>

class MarquesPages;

/*!
* \class MarquePageFleches
* \brief Classe réimplantant QWidget pour les marques-pages afin d'insérer des flèches lors d'un drag&drop.
*/
class MarquePageFleches : public QWidget
{
    Q_OBJECT

private:
    MarquesPages * parent;/*!< Le parent de la classe*/
    int place_dans_liste;/*!< Sa place dans la liste des marques-pages*/

protected:
    /*!
    * \brief Permet de savoir si un drag passe dessus les flèches
    *
    * \param event : QDragEnterEvent événement déclanchant cette méthode
    */
    virtual void dragEnterEvent(QDragEnterEvent*);
    /*!
    * \brief Permet de savoir si un drag passe dessus les flèches
    *
    * \param event : QDragEnterEvent événement déclanchant cette méthode
    */
    virtual void dragMoveEvent(QDragMoveEvent*);
    /*!
    * \brief Réalise un drop sur des flêches
    *
    * \param event : QDropEvent événement déclanchant cette méthode
    */
    virtual void dropEvent(QDropEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe MarquePageFleches
    *
    * \param parent : MarquesPages parent du marque-page
    * \param place_liste : int place dans la liste des marques-pages
    */
    MarquePageFleches(MarquesPages*, int);

};

#endif // MARQUEPAGEFLECHES_H
