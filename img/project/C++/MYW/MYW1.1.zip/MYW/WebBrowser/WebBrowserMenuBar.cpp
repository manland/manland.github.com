/*========================================================================
Nom: WebBrowserMenuBar.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                      Creation: 15.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui r�implante QMenuBar pour l'explorateur web.
=========================================================================*/

#include <iostream>
using namespace std;

#include "WebBrowserMenuBar.h"

#include "WebBrowser.h"
#include "Page.h"
#include "MarquesPages.h"
#include "Historique.h"
#include "HistoriqueWidget.h"
#include "Pages.h"

WebBrowserMenuBar::WebBrowserMenuBar(WebBrowser * p) : QMenuBar(p)
{
    parent = p;

    menus = new QList<QMenu*>;

    creerFichier();
    creerEdition();
    creerAffichage();
    creerHistorique();
    creerMarquesPages();
    creerOutils();
    creerAide();
}

//-----------------FICHIER---------------------------

void WebBrowserMenuBar::creerFichier()
{
    QMenu * menu = this->addMenu(tr("Fichier"));
    QAction * action;
    menu->addAction(QIcon(":/WebBrowser/nouveau"), tr("Ouvrir nouvel ongle&t"), this, "1nouvelOnglet()", QKeySequence(Qt::CTRL | Qt::Key_T));
    menu->addAction(QIcon(), tr("Ouvrir adresse"), this, "1ouvrirAdresse()", QKeySequence(Qt::CTRL | Qt::Key_U));
    menu->addAction(QIcon(), tr("Ouvrir fichier"), this, "1ouvrirFichier()", QKeySequence(Qt::CTRL | Qt::Key_O));
    menu->addAction(QIcon(), tr("Ouvrir fichiers"), this, "1ouvrirFichierS()", QKeySequence());
    menu->addSeparator();
    menu->addAction(QIcon(":/WebBrowser/imprimer"), tr("Im&primer"), this, "1imprimer()", QKeySequence(Qt::CTRL | Qt::Key_P));
    menu->addSeparator();
    menu->addAction(QIcon(), tr("&Fermer onglet"), this, "1fermerOnglet()", QKeySequence(Qt::CTRL | Qt::Key_F));
    menu->addAction(QIcon(), tr("&Fermer tous les onglets"), this, "1fermerOngletS()", QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_F));
    menu->addAction(QIcon(":/WebBrowser/quitter"), tr("Fermer fen�tre"), this, "1fermer()", QKeySequence());
    menus->append(menu);
}

void WebBrowserMenuBar::nouvelOnglet()
{
    parent->chargerPage(parent->getUrlParDefaut(), 1);
}

void WebBrowserMenuBar::ouvrirAdresse()
{
    parent->getEditionUrl()->selectAll();
}

void WebBrowserMenuBar::ouvrirFichier()
{
    parent->ouvrirFichier();
}

void WebBrowserMenuBar::ouvrirFichierS()
{
    QStringList list = QFileDialog::getOpenFileNames(parent, "Ouvrez un ou plusieurs fichiers");

    for(int i=0; i<list.count(); i++) {
        parent->chargerPage(list.value(i).prepend("file://"), 1);
    }
}

void WebBrowserMenuBar::imprimer()
{
    QPrintPreviewDialog * avant_imprimer = new QPrintPreviewDialog(parent);
    connect(avant_imprimer, SIGNAL(paintRequested(QPrinter*)), this, SLOT(imprimerOk(QPrinter*)));
    avant_imprimer->exec();
}

void WebBrowserMenuBar::imprimerOk(QPrinter * p)
{
    parent->getPageCourante()->print(p);
}

void WebBrowserMenuBar::fermerOnglet()
{
    parent->fermerOngletCourant();
}

void WebBrowserMenuBar::fermerOngletS()
{
    parent->fermerOngletS();
    parent->chargerPage(parent->getUrlParDefaut(), 0);
}

void WebBrowserMenuBar::fermer()
{
    parent->hide();
}

//-----------------EDITION---------------------------

void WebBrowserMenuBar::creerEdition()
{
    QMenu * menu = this->addMenu(tr("Edition"));
    QAction * action;
    menu->addAction(QIcon(":/WebBrowser/copier"), tr("&Copier"), this, "1copier()", QKeySequence(Qt::CTRL | Qt::Key_C));
    menu->addAction(QIcon(":/WebBrowser/couper"), tr("Couper"), this, "1couper()", QKeySequence(Qt::CTRL | Qt::Key_X));
    menu->addAction(QIcon(":/WebBrowser/coller"), tr("Coller"), this, "1coller()", QKeySequence(Qt::CTRL | Qt::Key_V));
    menu->addAction(QIcon(), tr("Supprimer NF"), this, "1supprimer()", QKeySequence());
    menu->addSeparator();
    menu->addAction(QIcon(), tr("Tout s�lectionner"), this, "1toutSelectionner()", QKeySequence(Qt::CTRL | Qt::Key_A));
    menu->addSeparator();
    menu->addAction(QIcon(":/WebBrowser/rechercher"), tr("Rechercher NF"), this, "1rechercher()", QKeySequence(Qt::CTRL | Qt::Key_F));
    menu->addSeparator();
    menu->addAction(QIcon(":/WebBrowser/preferences"), tr("Pr�f�rences NF"), this, "1preferences()", QKeySequence(Qt::CTRL | Qt::Key_P));
    menus->append(menu);
}

void WebBrowserMenuBar::copier()
{
    if(!parent->getPageCourante()->selectedText().isEmpty() && parent->getPageCourante()->estCopiable())
    {
        parent->getPageCourante()->triggerPageAction(QWebPage::Copy);
    }
}

void WebBrowserMenuBar::couper()
{
    if(parent->getPageCourante()->estEditable())
    {
        parent->getPageCourante()->triggerPageAction(QWebPage::Cut);
    }
}

void WebBrowserMenuBar::coller()
{
    if(parent->getPageCourante()->estEditable())
    {
        parent->getPageCourante()->triggerPageAction(QWebPage::Paste);
    }
}

void WebBrowserMenuBar::supprimer()
{
    if(parent->getPageCourante()->estEditable())
    {

    }
}

void WebBrowserMenuBar::toutSelectionner()
{
    parent->getPageCourante()->triggerPageAction(QWebPage::SelectAll);
}

void WebBrowserMenuBar::rechercher()
{

}

void WebBrowserMenuBar::preferences()
{

}

//-----------------AFFICHAGE---------------------------

void WebBrowserMenuBar::creerAffichage()
{
    QMenu * menu = this->addMenu(tr("Affichage"));
    QAction * action;
    QMenu * menu_barres_outils = menu->addMenu(QIcon(), tr("Barre d'outils"));
        action_commandes = menu_barres_outils->addAction(QIcon(), tr("Commandes"), this, "1commandes()", QKeySequence());
        action_commandes->setCheckable(true);
        action_commandes->setChecked(true);
        action_url = menu_barres_outils->addAction(QIcon(), tr("Url"), this, "1url()", QKeySequence());
        action_url->setCheckable(true);
        action_url->setChecked(true);
        action_recherches = menu_barres_outils->addAction(QIcon(), tr("Recherche"), this, "1recherche()", QKeySequence());
        action_recherches->setCheckable(true);
        action_recherches->setChecked(true);
        menu_barres_outils->addSeparator();
        action_tous_panneaux = menu_barres_outils->addAction(QIcon(), tr("Tout afficher"), this, "1tousPanneaux()", QKeySequence());
        action_tous_panneaux->setCheckable(true);
        action_tous_panneaux->setChecked(true);
    action = menu->addAction(QIcon(), tr("Barre d'�tat"), this, "1barreEtat(bool)", QKeySequence());
    action->setCheckable(true);
    action->setChecked(true);
    QMenu * menu_panneau = menu->addMenu(QIcon(), tr("Panneaux"));
        action = menu_panneau->addAction(QIcon(), tr("Marques-Pages"), this, "1marquesPages(bool)", QKeySequence());
        action->setCheckable(true);
        action->setChecked(true);
        action = menu_panneau->addAction(QIcon(), tr("Historique"), this, "1afficherHistorique(bool)", QKeySequence());
        action->setCheckable(true);
    menu->addSeparator();
    menu->addAction(QIcon(":/WebBrowser/arreter"), tr("Arr�ter"), this, "1arreter()", QKeySequence());
    menu->addAction(QIcon(":/WebBrowser/recharger"), tr("Actualiser"), this, "1actualiser()", QKeySequence());
    menu->addSeparator();
    menu->addAction(QIcon(), tr("Zoom +"), this, "1zoomPlus()", QKeySequence(Qt::CTRL | Qt::Key_Up));
    menu->addAction(QIcon(), tr("Zoom -"), this, "1zoomMoins()", QKeySequence(Qt::CTRL | Qt::Key_Down));
    menu->addAction(QIcon(), tr("Encodage NF"), this, "1encodage()", QKeySequence());
    menus->append(menu);
}

void WebBrowserMenuBar::commandes()
{
    if(action_commandes->isChecked())
    {
        parent->getPanneauCommandes()->show();
        if(action_url->isChecked() && action_recherches->isChecked())
        {
            action_tous_panneaux->setChecked(true);
        }
    }
    else
    {
        parent->getPanneauCommandes()->hide();
        action_tous_panneaux->setChecked(false);
    }
}

void WebBrowserMenuBar::url()
{
    if(action_url->isChecked())
    {
        parent->getPanneauUrl()->show();
        if(action_commandes->isChecked() && action_recherches->isChecked())
        {
            action_tous_panneaux->setChecked(true);
        }
    }
    else
    {
        parent->getPanneauUrl()->hide();
        action_tous_panneaux->setChecked(false);
    }
}

void WebBrowserMenuBar::recherche()
{
    if(action_recherches->isChecked())
    {
        parent->getPanneauRecherches()->show();
        if(action_commandes->isChecked() && action_url->isChecked())
        {
            action_tous_panneaux->setChecked(true);
        }
    }
    else
    {
        parent->getPanneauRecherches()->hide();
        action_tous_panneaux->setChecked(false);
    }
}

void WebBrowserMenuBar::tousPanneaux()
{
    if(action_tous_panneaux->isChecked())
    {
        parent->getPanneauRecherches()->show();
        parent->getPanneauCommandes()->show();
        parent->getPanneauUrl()->show();
        action_commandes->setChecked(true);
        action_url->setChecked(true);
        action_recherches->setChecked(true);
    }
    else
    {
        parent->getPanneauRecherches()->hide();
        parent->getPanneauCommandes()->hide();
        parent->getPanneauUrl()->hide();
        action_commandes->setChecked(false);
        action_url->setChecked(false);
        action_recherches->setChecked(false);
    }
}

void WebBrowserMenuBar::barreEtat(bool b)
{
    parent->getBarreEtat()->setVisible(b);
}

void WebBrowserMenuBar::marquesPages(bool b)
{
    parent->getMarquesPages()->setVisible(b);
}

void WebBrowserMenuBar::afficherHistorique(bool b)
{
    /*WebBrowser->Historique->widgetHistorique*/
    parent->getHistorique()->getHistorique()->setVisible(b);
}

void WebBrowserMenuBar::arreter()
{
    parent->getPageCourante()->stop();
}

void WebBrowserMenuBar::actualiser()
{
    parent->getPageCourante()->reload();
}

void WebBrowserMenuBar::zoomPlus()
{
    parent->getPageCourante()->setZoomFactor(parent->getPageCourante()->zoomFactor() + 0.1);
}

void WebBrowserMenuBar::zoomMoins()
{
    parent->getPageCourante()->setZoomFactor(parent->getPageCourante()->zoomFactor() - 0.1);
}

void WebBrowserMenuBar::encodage()
{

}


//-----------------HISTORIQUE---------------------------

void WebBrowserMenuBar::creerHistorique()
{
    QMenu * menu = this->addMenu(tr("Historique"));
    QAction * action;
    action_reculer = menu->addAction(QIcon(":/WebBrowser/annuler"), tr("Reculer"), this, "1reculer()", QKeySequence());
    action_avancer = menu->addAction(QIcon(":/WebBrowser/retablir"), tr("Avancer"), this, "1avancer()", QKeySequence());
    menu->addAction(QIcon(":/WebBrowser/accueil"), tr("Accueil"), this, "1accueil()", QKeySequence());
    action = menu->addAction(QIcon(), tr("Afficher historique"), this, "1afficherHistorique(bool)", QKeySequence());
    action->setCheckable(true);
    menu->addSeparator();
    QMenu * menu_supprimer = menu->addMenu(tr("Supprimer"));
        menu_supprimer->addAction(QIcon(), tr("Les icones de l'historique (relancement obligatoire)"), this, "1supprimerHistoriqueIcones()", QKeySequence());
        menu_supprimer->addAction(QIcon(), tr("Les liens de l'historique"), this, "1supprimerHistoriqueLiens()", QKeySequence());
        menu_supprimer->addSeparator();
        menu_supprimer->addAction(QIcon(), tr("Tout l'historique"), this, "1supprimerHistorique()", QKeySequence());
    menu->addSeparator();
    menu_historique = menu->addMenu(tr("10 derniers sites visit�s"));
        mettreAJourHistorique();
    menus->append(menu);
}

void WebBrowserMenuBar::avancer()
{
    parent->getPageCourante()->forward();
}

void WebBrowserMenuBar::reculer()
{
    parent->getPageCourante()->back();
}

void WebBrowserMenuBar::accueil()
{
    parent->chargerPage(parent->getUrlParDefaut(), 0);
}

void WebBrowserMenuBar::supprimerHistorique()
{
    parent->getHistorique()->toutSupprimer();
}

void WebBrowserMenuBar::supprimerHistoriqueIcones()
{
    parent->getHistorique()->supprimerIcones();
    parent->getHistorique()->getHistoriqueWidget()->mettreAJour();
}

void WebBrowserMenuBar::supprimerHistoriqueLiens()
{
    parent->getHistorique()->supprimerLiens();
}

void WebBrowserMenuBar::historique(QAction * a)
{
    if(!a->data().toString().isEmpty())
    {
        parent->chargerPage(a->data().toString(), 0);
    }
}

void WebBrowserMenuBar::mettreAJourHistorique()
{
    menu_historique->clear();
    QList<struct_historique> * tmp = parent->getHistorique()->getHistoriqueWidget()->getUrlS();/*historique->historiqueWidget*/
    QAction * action;
    for(int i=0; i<10 && i<tmp->count(); i++)
    {
        action = menu_historique->addAction(QWebSettings::iconForUrl(tmp->value(i).url), tmp->value(i).titre);
        action->setData(QVariant(tmp->value(i).url));
        connect(menu_historique, SIGNAL(triggered(QAction*)), this, SLOT(historique(QAction*)));
    }
}

//-----------------MARQUE-PAGE---------------------------

void WebBrowserMenuBar::creerMarquesPages()
{
    QMenu * menu = this->addMenu(tr("Marques-Pages"));
    menu->addAction(QIcon(), tr("Marquer cette page"), this, "1marquerPage()", QKeySequence());
    menu->addAction(QIcon(), tr("Marquer tous les onglets"), this, "1marquerPageS()", QKeySequence());
    menu->addAction(QIcon(), tr("Ajouter un dossier..."), this, "1ajouterDossier()", QKeySequence());
    menu->addAction(QIcon(), tr("Suppression..."), this, "1suppression()", QKeySequence());
    menu->addSeparator();
    menu->addAction(QIcon(), tr("Supprimer tous mes Marques-Pages"), this, "1supprimerMarquesPages()", QKeySequence());
    menu->addAction(QIcon(), tr("Revenir aux Marques-Pages par d�faut"), this, "1defautMarquesPages()", QKeySequence());
    menu->addSeparator();
    menu_marques_pages = menu->addMenu(tr("Marques-Pages"));
    mettreAJourMarquesPages();
    menus->append(menu);
}

void WebBrowserMenuBar::marquerPage()
{
    if(!parent->getMarquesPages()->contient(parent->getPageCourante()->url().toString()))
    {
        parent->getMarquesPages()->ajouter(-1, parent->getPageCourante()->title(), parent->getPageCourante()->url().toString());
    }
    else
    {
        cout<<"erreur marque page d�j�  pr�sent"<<endl;
    }
}

void WebBrowserMenuBar::marquerPageS()
{
    for(int i=0; i<parent->getPages()->count(); i++)
    {
        if(!parent->getMarquesPages()->contient(parent->getPages()->getPage(i)->url().toString()))
        {
            parent->getMarquesPages()->ajouter(-1, parent->getPages()->getPage(i)->title(), parent->getPages()->getPage(i)->url().toString());
        }
        else
        {
            cout<<"erreur marque page d�j�  pr�sent"<<endl;
        }
    }
}

void WebBrowserMenuBar::supprimerMarquesPages()
{
    parent->getMarquesPages()->toutSupprimer();
}

void WebBrowserMenuBar::defautMarquesPages()
{
    parent->getMarquesPages()->defaut();
}

void WebBrowserMenuBar::mettreAJourMarquesPages()
{
    QAction * action;
    menu_marques_pages->clear();
    QList<struct struct_marque_page> * mp = parent->getMarquesPages()->getListMarquesPages();
    for(int i=0; i<mp->count(); i++)
    {
        if(mp->value(i).urls.keys().contains(mp->value(i).titre))//si c'est un marque page
        {
            action = menu_marques_pages->addAction(QIcon(QWebSettings::iconForUrl(mp->value(i).urls.value(0).toString())),
                                                   mp->value(i).titre);
            action->setData(mp->value(i).urls.value(mp->value(i).urls.keys().value(0)).toString());
            connect(menu_marques_pages, SIGNAL(triggered(QAction*)), this, SLOT(chargerMarquePage(QAction*)));
        }
        else//sinon c'est un dossier de marque page
        {
            QMenu * menu = menu_marques_pages->addMenu(QIcon(":/temp/images/folder.gif"), mp->value(i).titre);
            for(int m=0; m<mp->value(i).urls.keys().count(); m++)
            {
                action = menu->addAction(QIcon(QWebSettings::iconForUrl(mp->value(i).urls.value(mp->value(i).urls.keys().value(m)).toString())),
                                            mp->value(i).urls.keys().value(m));
                action->setData(QString(mp->value(i).urls.value(mp->value(i).urls.keys().value(m)).toString()));
            }
            connect(menu, SIGNAL(triggered(QAction*)), this, SLOT(chargerMarquePage(QAction*)));
        }
    }
}

void WebBrowserMenuBar::chargerMarquePage(QAction * action)
{
    parent->chargerPage(action->data().toString(), 0);
}

void WebBrowserMenuBar::ajouterDossier()
{
    parent->getMarquesPages()->ajouterDossier();
}

void WebBrowserMenuBar::suppression()
{
    parent->getMarquesPages()->suppression();
}

//-----------------OUTILS---------------------------

void WebBrowserMenuBar::creerOutils()
{
    QMenu * menu = this->addMenu(tr("Outils"));
    menu->addAction(QIcon(), tr("Rechercher sur..."), this, "1rechercherSur()", QKeySequence());
    menu->addSeparator();
    menu->addAction(tr("User Agent NF"));
    menu->addAction(tr("Console d'erreur javascript NF"));
    menu->addSeparator();
    menu->addAction(tr("Effacer mes traces NF"));
    menus->append(menu);
}

void WebBrowserMenuBar::rechercherSur()
{
    parent->getRecherches()->showPopup();
}

//-----------------OUTILS---------------------------

void WebBrowserMenuBar::creerAide()
{
    QMenu * menu = this->addMenu(tr("Aide"));
    menu->addAction(QIcon(":/WebBrowser/aide"), tr("Aide"));
    menu->addAction(tr("Notes de versions"));
    menu->addSeparator();
    menu->addAction(tr("Signaler un bug"));
    menu->addAction(tr("Traduire cette application"));
    menu->addSeparator();
    menu->addAction(tr("A propos de Qt"));
    menu->addAction(tr("A propos de WebBrowser"));
    menus->append(menu);
}

void WebBrowserMenuBar::paintEvent(QPaintEvent * event)
{
//    QPainter painter(this);
//    QLinearGradient gradient(this->width()/2, 0, this->width()/2, this->height());
//    gradient.setColorAt(0.0, Qt::black);
//    gradient.setColorAt(0.45, Qt::darkGray);
//    gradient.setColorAt(0.55, Qt::darkGray);
//    gradient.setColorAt(1.0, Qt::black);
//    painter.setPen(Qt::darkGray);
//    painter.setBrush(gradient);
//    painter.drawRect(0, 0, this->width(), this->height());
//
//    int x = 0;
//    for(int i=0; i<this->menus->count(); i++)
//    {
//        if(i!=0)
//        {
//            x = x + menus->value(i-1)->width();
//        }
//        painter.setPen(Qt::red);
//        painter.drawText(x, 0, menus->value(i)->width(), menus->value(i)->height(), Qt::AlignCenter, menus->value(i)->title());
//    }
//
//    painter.end();
//    event->accept();

    QMenuBar::paintEvent(event);
}
