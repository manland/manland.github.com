#ifndef WEBBROWSER_H
#define WEBBROWSER_H

/*========================================================================
Nom: WebBrowser.h           auteur: Maneschi Romain
Maj: 17.05.2009             Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe principale du module.
=========================================================================*/

/*!
* \file WebBrowser.h
* \brief Classe principale du module.
* \author Maneschi Romain
* \date 01.03.2009
*/

#include <QtGui/QWidget>
#include <QWebView>
#include <QWebHistory>
#include <QProgressBar>
#include <QToolBar>
#include <QAction>
#include <QLineEdit>
#include <QWebFrame>
#include <QMainWindow>
#include <QLabel>
#include <QStatusBar>
#include <QComboBox>
#include <QPushButton>
#include <QApplication>
#include <QMessageBox>
#include <QFileDialog>

class Page;
class Pages;
class Historique;
class MarquesPages;
class WebBrowserMenuBar;

/*!
* \class WebBrowser
* \brief Classe principale du module.
*
* Appelez cette classe par WebBrowser w(QUrl("http://google.fr"));
* pensez à show() la fenêtre par w.show();
* elle ne s'affiche pas automatiquement car on pourrait vouloir attendre que la première page soit chargée pour l'afficher
* ainsi l'utilisateur n'atend pas.
* Pour se faire il suffit de connecter loadFinished de la page courante avec un slot affiche() par<br />
* connect(w.getPageCourante(), SIGNAL(loadFinished(bool)), this, SLOT(affiche(bool)));<br />
* avec<br />
* void THIS::affiche(bool b)<br />
* {<br />
*   if(b)//tout s'est bien passé la page est arrivée<br />
*   {<br />
*       w.show();<br />
*   }<br />
*   else<br />
*   {<br />
*       cout<<"erreur : page non chargée [THIS][l.X]"<<endl;<br />
*   }<br />
* }<br />
* Pour charger plusieurs pages à la foi il suffit d'appeler chargerParge(QUrl, int mode=0);<br />
* par exemple w.chargerParge(QUrl("http://monadresse.fr"), 0);
* le mode permet de dire si on ouvre la page dans un nouvel onglet mode=1 ou si on l'ouvre dans l'onglet courant mode=0
* par défault c'est le mode=0<br />
* synthaxe :<br />
* - si QUrl("X") == "?:recherche" ça renvoie sur google pour rechercher "recherche"
* - == "!:recherche" sur wikipédia
* - == "??:recherche" sur exalead (petit clein d'oeuil au google français)
* - == "sdz:recherche" sur le site du zéro
* - == "cs:recherche" sur code-sources
* - == "$:recherche" sur le manuel php
* - == "js:recherche" sur le manuel javascript<br />
* me demander pour en ajouter je réfléchit sur un truc pour que l'utilisateur puisse le fair lui même
*
*/
class WebBrowser : public virtual QMainWindow
{
    Q_OBJECT

private:
    QUrl url_par_default;/*!< a définir dans le constructeuret dans le constructeur de Pages.cpp, s'ouvre quand on ferme tout, la dernière page ou click sur Home*/
    QProgressBar * progress_bar;/*!< la barre de progression afficher dans la statuBar*/
    Pages * multi_pages;/*!< contient les pages web en cours QTabWidget*/
    WebBrowserMenuBar * menu_bar;/*!< Pointeur vers le menu du WebBrowser*/

    /*!
    * \brief Crée le Widget Panneau de Commande contenant les bouttons pour reculer avancer stopper et reloader
    */
    virtual void creerPanneauCommandes();
    QToolBar * panneau_commandes;/*!< contient les actions de navigation avancer reculer reloader stopper*/
    QAction * action_reculer;
    QAction * action_recharger;
    QAction * action_avancer;
    QAction * action_stop;
    QAction * action_accueil;
    /*!
    * \brief Met à jour les bouttons pour reculer avancer stopper et reloader
    */
    virtual void mettreAJourCommandes();
    QToolBar * panneau_recherche;/*!< Contient la liste des sites sur lesquels on peut faire une recherche*/
    /*!
    * \brief Crée le Widget Panneau de Recherche contenant le choix des protocols de recherche
    */
    virtual void creerPanneauRecherche();
    QComboBox * protocol;/*!< choix du protocol de recherche*/
    /*!
    * \brief Crée le Widget des URL contenant l'url rentré
    */
    virtual void creerPanneauUrl();
    QToolBar * panneau_url;/*!< contient la 2eme toolBar pour écrire les adresses et choisir le protocol*/
    QLineEdit * edition_url;/*!< la ou on écrit l'adresse*/

    /*!
    * \brief Crée le Widget stauBar contenant les messages et la barre de progression
    */
    virtual void creerStatusBar();
    QLabel * status_bar_messages;/*!< les messages de la statuBar*/

    Historique * historique;/*!< l'historique représente le M dans le MVC*/
    MarquesPages * marques_pages;/*!< les marques pages*/

    /*!
    * \brief Crée un QDialog avec Titre, Message, icon, nb_button
    *
    * \param titre : QString
    * \param message : QString la question posée
    * \param i : int si =0 question, =1 information, =2 warning, =3 critic, =4 sans icone
    * \param deux_button : si = true valeur par défault il y aura 2 bouttons annuler et valider donc true et false si=false alor il n'y aura qu'un boutton valider donc return toujours true
    * \return true si valider, false si annuler
    */
    virtual bool okPourContinuer(QString, QString, int i = 0, bool deux_button = true);

private slots:
    /*!
    * \brief SLOT est activé lorsqu'une page charge une url
    */
    virtual void chargementDemarrage();
    /*!
    * \brief SLOT permet de mettre à jours la la barre de progression de la statuBar
    *
    * \param int : Chiffre en pourcentage du niveau de charement de la page
    */
    virtual void chargementEnCours(int);
    /*!
    * \brief SLOT est appelé lorsque la page est entièrement chargée
    *
    * \param bool : true si tout c'est bien passé false si sa a planté
    */
    virtual void chargementTermine(bool);

    /*!
    * \brief SLOT Permet d'analyser le protocole et de l'ajouter à l'url ou de l'afficher si c'est l'aide
    *
    * \param int : id du protocol dans la comboBox
    */
    virtual void editionUrl(int);

    virtual void actionCharger();
    virtual void actionRetour();
    virtual void actionAvancer();
    virtual void actionChargerAccueil();
    virtual void actionProprietes();

    /*!
    * \brief SLOT est activé par la page (QWebView) lorque la souris pass sur un lien on récupère ainsi le lien, la description et le titre
    *
    * \param lien : QString url
    * \param titre : QString mot pointé
    * \param description : QString description
    */
    virtual void sourisSurLien(QString, QString, QString);

protected:
    /*!
    * \brief Réimplante event close
    *
    * \param event : QCLoseEvent
    */
    virtual void closeEvent(QCloseEvent*);
    /*!
    * \brief Permet la coloration du WebBrowser
    *
    * \param event : QPaintEvent événement déclanchant cette méthode
    */
    virtual void paintEvent(QPaintEvent*);
    /*!
    * \brief Déclenche les racourcis du WebBrowser
    *
    * \param event : QPaintEvent événement déclanchant cette méthode
    */
    virtual void keyPressEvent(QKeyEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe WebBrowser
    *
    * \param url : QUrl à charger valeure par défault QUrl("http://projet.lydiman.net")
    * \param parent : QWidget parent s'il en a un =0 par défault donc QMainWindow de premier niveau
    */
    WebBrowser(QUrl url=QUrl("http://projet.lydiman.net"), QWidget *parent = 0);
    /*!
    * \brief  Destructeur
    *
    * Destructeur de la classe WebBrowser ne fait rien !
    */
    virtual ~WebBrowser();
    /*!
    * \brief Permet de charger une page
    *
    * Pour charger plusieurs pages à la foi il suffit d'appeler chargerParge(QUrl, int mode=0);
    * par exemple w.chargerParge(QUrl("http://monadresse.fr"), 0);
    * le mode permet de dire si on ouvre la page dans un nouvel onglet mode=1 ou si on l'ouvre dans l'onglet courant mode=0
    * par défault c'est le mode=0
    * synthaxe :
    * - si QUrl("X") == "?:recherche" sa renvoie sur google pour rechercher "recherche"
    * - == "!:recherche" sur wikipédia
    * - == "??:recherche" sur exalead petit clein d'oeuil au google français
    * - == "sdz:recherche" sur le site du zéro
    * - == "cs:recherche" sur code-sources
    * - == "$:recherche" sur le manuel php
    * me demander pour en ajouter je réfléchit sur un truc pour que l'utilisateur puisse le fair lui même
    *
    * \param url : QUrl l'url à charger
    * \param mode : int mode=0 onglet en cours mode=1 pour un nouvel onglet
    */
    virtual void chargerPage(QUrl, int mode=0);//0 sur la page en cours - 1 sur une nouvelle fenêtre
    /*!
    * \brief Permet d'ajouter une entrée dans l'historique ne devrait pas vous servir
    *
    * \param url : QString l'url du site
    * \param titre : QString le titre du site
    */
    virtual void ajouterEntreeHistorique(QString, QString);
    /*!
    * \brief Permet de connaitre l'url du site par défaut
    *
    * \return url : QString l'url du site par défaut
    */
    virtual QUrl getUrlParDefaut();
    /*!
    * \brief Permet d'accéder aux marques pages
    *
    * \return marques_pages : MarquesPages le widget des marques pages
    */
    virtual MarquesPages* getMarquesPages();
    /*!
    * \brief Permet d'accéder à l'historique
    *
    * \return Historique gérant l'historique du WebBrowser
    */
    virtual Historique* getHistorique();
    /*!
    * \brief Permet à l'édition de l'url par l'utilisateur
    *
    * \return QLineEdit pour récupérer l'url entré par l'utilisateur
    */
    virtual QLineEdit* getEditionUrl();
    /*!
    * \brief Ferme l'onglet courant
    */
    virtual void fermerOngletCourant();
    /*!
    * \brief Ferme tous les onglets et réouvre la page par défaut pour l'onglet restant
    */
    virtual void fermerOngletS();
    /*!
    * \brief Retourne la page courante
    */
    virtual Page* getPageCourante();
    /*!
    * \brief Lance une fenêtre permettant de sélectionner une fichier
    */
    virtual void ouvrirFichier();
    /*!
    * \brief Retourne le widget contenant les commandes avancer, reculer...
    */
    virtual QWidget* getPanneauCommandes();
    /*!
    * \brief Retourne le widget contenant l'édition de l'url par l'utilisateur
    */
    virtual QWidget* getPanneauUrl();
    /*!
    * \brief Retourne le widget contenant les recherches
    */
    virtual QWidget* getPanneauRecherches();
    /*!
    * \brief Retourne le combobox contenant les recherches
    */
    virtual QComboBox* getRecherches();
    /*!
    * \brief Retourne la barre d'état (tout en bas de l'appication)
    */
    virtual QWidget* getBarreEtat();
    /*!
    * \brief Retourne les Pages qui contient les pages en cours de visite
    */
    virtual Pages* getPages();
    /*!
    * \brief Permet de setter les Pages (pour animationBranch)
    *
    * \param pages : Pages permettait à l'animationBranch de metre un QGraphicsView à la place d'un QWebView
    */
    virtual void setPages(Pages*);
    /*!
    * \brief Retourne le menu génral du WebBrowser
    */
    virtual WebBrowserMenuBar* getMenuBar();

public slots:
    /*!
    * \brief Permet de connecter le changement de tab du multi_pages avec l'edition url
    *
    * \param i : int l'id de la page en cours dans multi_pages
    */
    virtual void changementTab(int);
    /*!
    * \brief Ouvre un fichier en local
    *
    * \param url : QString le path du fichier à ouvrir
    */
    void ouvrirFichier(QString);

};
#endif // WEBBROWSER_H
