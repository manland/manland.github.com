#ifndef WEBBROWSERMENUBAR_H
#define WEBBROWSERMENUBAR_H

/*========================================================================
Nom: WebBrowserMenuBar.h           auteur: Maneschi Romain
Maj: 17.05.2009                    Creation: 15.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QMenuBar pour l'explorateur web.
=========================================================================*/

/*!
* \file WebBrowserMenuBar.h
* \brief Classe qui réimplante QMenuBar pour l'explorateur web.
* \author Maneschi Romain
* \date 15.03.2009
*/

#include <QMenuBar>
#include <QPainter>
#include <QPaintEvent>
#include <QFileDialog>
#include <QApplication>
#include <QClipboard>
#include <QPrinter>
#include <QPrintPreviewDialog>

class WebBrowser;

/*!
* \class WebBrowserMenuBar
* \brief Classe qui réimplante QMenuBar pour l'explorateur web.
*/
class WebBrowserMenuBar : public QMenuBar
{
    Q_OBJECT

private:
    WebBrowser * parent;/*!< Le parent de la classe*/
    QList<QMenu*> * menus;/*!< Liste des sous menus*/
    /*!
    * \brief Créer le menu Fichier
    */
    virtual void creerFichier();
    /*!
    * \brief Créer le menu Edition
    */
    virtual void creerEdition();
    /*!
    * \brief Créer le menu Affichage
    */
    virtual void creerAffichage();
    /*!
    * \brief Créer le menu Historique
    */
    virtual void creerHistorique();
    /*!
    * \brief Créer le menu MarquesPages
    */
    virtual void creerMarquesPages();
    /*!
    * \brief Créer le menu Outil
    */
    virtual void creerOutils();
    /*!
    * \brief Créer le menu Aide
    */
    virtual void creerAide();

    //-----------------AFFICHAGE---------------------------
    QAction * action_commandes;/*!< Permet de cacher/afficher la boite à outils des commandes du WebBrowser*/
    QAction * action_url;/*!< Permet de cacher/afficher l'emplacement pour inscrir l'url un site du WebBrowser*/
    QAction * action_recherches;/*!< Permet de cacher/afficher la boite à outils des recherches du WebBrowser*/
    QAction * action_tous_panneaux;/*!< Permet de cacher/afficher les boites à outils du WebBrowser*/
    //-----------------HISTORIQUE---------------------------
    QAction * action_reculer;/*!< Permet de reculer dans les pages de la session en cours du WebBrowser*/
    QAction * action_avancer;/*!< Permet d'avancer dans les pages de la session en cours du WebBrowser*/
    QMenu * menu_historique;/*!< contient les 10 derniers historiques*/
    //-----------------MARQUE-PAGE--------------------------
    QMenu * menu_marques_pages;/*!< contient les marques-pages*/

protected:
    /*!
    * \brief Permet la coloration du menu général
    *
    * \param event : QPaintEvent événement déclanchant cette méthode
    */
    virtual void paintEvent(QPaintEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe WebBrowserMenuBar
    *
    * \param parent : WebBrowser parent du menu
    */
    WebBrowserMenuBar(WebBrowser*);

public slots:
    //-----------------FICHIER---------------------------
    /*!
    * \brief Déclenche l'ouverture d'un nouveau onglet
    */
    void nouvelOnglet();
    /*!
    * \brief Déclenche la sélection de l'édition d'url par l'utilisateur
    */
    void ouvrirAdresse();
    /*!
    * \brief Déclenche l'ouverture d'une fenêtre permettant d'ouvrir un fichier
    */
    void ouvrirFichier();
    /*!
    * \brief Déclenche l'ouverture d'une fenêtre permettant d'ouvrir des fichiers
    */
    void ouvrirFichierS();
    /*!
    * \brief Déclenche l'ouverture d'une fenêtre permettant d'imprimer la page courante
    */
    void imprimer();
    /*!
    * \brief Déclenche l'impression de la page courante
    */
    void imprimerOk(QPrinter*);
    /*!
    * \brief Déclenche l'ouverture du menu de droite des pages permettant de fermer un onglet
    */
    void fermerOnglet();
    /*!
    * \brief Déclenche la fermeture de tous les onglets
    */
    void fermerOngletS();
    /*!
    * \brief permer de fair disparaitre la fenêtre
    *
    * Réaliser un close() pour la fermer diffinitivement car elle réalise un hide() à l'appel du closeEvent()
    */
    void fermer();
    //-----------------EDITION---------------------------
    /*!
    * \brief Permet de copier la sélection en cours, accessible seulement si c'est possible
    */
    void copier();
    /*!
    * \brief Permet de couper la sélection en cours, accessible seulement si c'est possible
    */
    void couper();
    /*!
    * \brief Permet de coller la sélection en cours, accessible seulement si c'est possible
    */
    void coller();
    /*!
    * \brief Permet de supprimer la sélection en cours, accessible seulement si c'est possible
    */
    void supprimer();
    /*!
    * \brief Permet de sélectionner tout le texte de la page en cours
    */
    void toutSelectionner();
    /*!
    * \brief Permet de rechercher parmis le texte de la page en cours
    */
    void rechercher();
    /*!
    * \brief Permet d'afficher les préférences
    */
    void preferences();
    //-----------------AFFICHAGE---------------------------
    /*!
    * \brief Permet d'afficher ou de cacher le panneau des commandes avancer, reculer...
    */
    void commandes();
    /*!
    * \brief Permet d'afficher ou de cacher le panneau de saisie d'une url par l'utilisateur
    */
    void url();
    /*!
    * \brief Permet d'afficher ou de cacher le panneau permettant de sélectionner un site sur lequel effectuer une recherche
    */
    void recherche();
    /*!
    * \brief Permet d'afficher ou de cacher les trois panneaux commandes, url et recherche
    */
    void tousPanneaux();
    /*!
    * \brief Permet d'afficher ou de cacher la barre d'état
    */
    void barreEtat(bool);
    /*!
    * \brief Permet d'afficher ou de cacher les marques-pages
    */
    void marquesPages(bool);
    /*!
    * \brief Permet d'afficher ou de cacher l'historique
    */
    void afficherHistorique(bool);
    /*!
    * \brief Permet de stopper le chargement de la page en cours
    */
    void arreter();
    /*!
    * \brief Permet d'actualiser la page courante
    */
    void actualiser();
    /*!
    * \brief Permet de zoomer sur la page courante
    */
    void zoomPlus();
    /*!
    * \brief Permet de dézoomer sur la page courante
    */
    void zoomMoins();
    /*!
    * \brief Permet de changer l'encodage de la page courante
    */
    void encodage();
    //-----------------HISTORIQUE---------------------------
    /*!
    * \brief Permet de reculer d'une page dans l'historique de la page en cours
    */
    void reculer();
    /*!
    * \brief Permet d'avancer d'une page dans l'historique de la page en cours
    */
    void avancer();
    /*!
    * \brief Permet de revenir à la page par défaut dans la page courante
    */
    void accueil();
    /*!
    * \brief Permet de supprimer l'historique
    */
    void supprimerHistorique();
    /*!
    * \brief Permet de supprimer les icones de l'historique
    */
    void supprimerHistoriqueIcones();
    /*!
    * \brief Permet de supprimer les liens de l'historique
    */
    void supprimerHistoriqueLiens();
    /*!
    * \brief Permet de supprimer l'historique
    */
    void historique(QAction*);
    /*!
    * \brief Permet de mettre à jour l'historique
    */
    void mettreAJourHistorique();
    //-----------------MARQUE-PAGE---------------------------
    /*!
    * \brief Permet d'ajouter la page courante aux marques-pages
    */
    void marquerPage();
    /*!
    * \brief Permet d'ajouter toutes les pages ouvertes aux marques-pages
    */
    void marquerPageS();
    /*!
    * \brief Permet de supprimer les marques-pages
    */
    void supprimerMarquesPages();
    /*!
    * \brief Permet de remettre les marques par défaut
    */
    void defautMarquesPages();
    /*!
    * \brief Permet de mettre a jour les marques pages
    */
    void mettreAJourMarquesPages();
    /*!
    * \brief Permet de charger la page du marque-page sélectionné
    */
    void chargerMarquePage(QAction*);
    /*!
    * \brief Permet d'ajouter un dossier de marques-pages
    */
    void ajouterDossier();
    /*!
    * \brief Permet de supprimer les marques-pages
    */
    void suppression();
    //-----------------OUTILS---------------------------
    /*!
    * \brief Ouvre le panneau de recherche
    */
    void rechercherSur();

};

#endif // WEBBROWSERMENUBAR_H
