/*========================================================================
Nom: Pages.cpp           auteur: Maneschi Romain
Maj: 17.05.2009          Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui r�implante QTabWidget contenant les pages internet.
=========================================================================*/

#include <iostream>
using namespace std;

#include "Pages.h"
#include "WebBrowser.h"

#include "PagesTabBar.h"

Pages::Pages(QUrl url, WebBrowser * p) : QTabWidget(p)
{
    this->setTabBar(new PagesTabBar(this));

    url_par_default = QUrl("http://projet.lydiman.net");
    parent = p;
    pages = new QVector<Page*>;
    this->setElideMode(Qt::ElideRight);//pour les titres trop grands

    //boutton �  droite des onglets permettant de fermer un onglet ou d'ouvrir un nouvel onglet
    QWidget * w = new QWidget(this);
    w->setMinimumSize(50, 35);
    QHBoxLayout * l = new QHBoxLayout();
    l->setSpacing(0);
    w->setLayout(l);

    boutton_nouvel_onglet = new QPushButton(this);
    boutton_nouvel_onglet->setAttribute(Qt::WA_DeleteOnClose);
    boutton_nouvel_onglet->setFlat(true);
    boutton_nouvel_onglet->setIcon(QIcon(":/temp/images/note_new.gif"));
    connect(boutton_nouvel_onglet, SIGNAL(clicked()), this, SLOT(nouvelOnglet()));
    l->addWidget(boutton_nouvel_onglet, 0);

    boutton_fermer = new QPushButton(this);
    boutton_fermer->setMaximumSize(15, 35);
    boutton_fermer->setAttribute(Qt::WA_DeleteOnClose);
    boutton_fermer->setFlat(true);
    boutton_fermer_menu = new QMenu("Fermer page ...", boutton_fermer);
    connect(boutton_fermer_menu, SIGNAL(triggered(QAction*)), this, SLOT(fermerTab(QAction*)));
    boutton_fermer->setMenu(boutton_fermer_menu);
    l->addWidget(boutton_fermer, 0);

    this->setCornerWidget(w);
    //boutton �  droite des onglets permettant de fermer un onglet ou d'ouvrir un nouvel onglet

    urls_en_cours = new QVector<QAction*>;

    charger(url);
    this->setAttribute(Qt::WA_DeleteOnClose);
    this->setTabsClosable (true);
    connect(this, SIGNAL(tabCloseRequested(int)), this, SLOT(fermerTab(int)));
    this->setMovable(false);
}

void Pages::mettreAJourBouttonFermer()
{
    if(urls_en_cours->count() > 0)
    {
        urls_en_cours->clear();//efface tout ce qui �tait dedans
        boutton_fermer_menu->clear();
    }

    for(int i=0; i<pages->count(); i++)
    {
        QString s(pages->value(i)->url().toString());
        QAction * action = new QAction(s, this);
        action->setData(i);
        action->setText(s);
        s.prepend(tr("Fermer l'url "));
        action->setStatusTip(s);
        action->setIcon(pages->value(i)->icon());

        urls_en_cours->append(action);
        boutton_fermer_menu->addAction(urls_en_cours->value(i));
    }

    if(urls_en_cours->count() != 1)
    {
        boutton_fermer_menu->addSeparator();

        QAction * action = boutton_fermer_menu->addAction(QIcon(":/temp/images/page_cross.gif"), tr("Tout fermer"));
        action->setData(-1);
        urls_en_cours->append(action);
    }
}

Page* Pages::getPage(int i)
{
    return pages->value(i);
}

void Pages::charger(QUrl u)
{
    Page * page = new Page(this);//la nouvelle page
    pages->append(page);//sauvegarde dans le vector
    
    page->load(u);//charge l'url
    page_courante = this->addTab(page, page->icon(), "");//ajoute un onglet et retient le num de la page courante
    this->setCurrentIndex(page_courante);//met la derni�re page en page courante

    //connect de la page avec le WebBrowser parent
    connect(page, SIGNAL(loadStarted()), parent, SLOT(chargementDemarrage()));
    connect(page, SIGNAL(loadProgress(int)), parent, SLOT(chargementEnCours(int)));
    connect(page, SIGNAL(loadFinished(bool)), parent, SLOT(chargementTermine(bool)));
    connect(page->page(), SIGNAL(linkHovered(QString, QString, QString)), parent, SLOT(sourisSurLien(QString, QString, QString)));
    connect(this, SIGNAL(currentChanged(int)), parent, SLOT(changementTab(int)));

    //connect de la page avec les onglets
    connect(page, SIGNAL(titleChanged(QString)), this, SLOT(actionTitrePage(QString)));
    connect(this, SIGNAL(currentChanged(int)), this, SLOT(changementTab(int)));
    connect(page, SIGNAL(iconChanged()), this, SLOT(chargementIcon()));
    connect(page, SIGNAL(loadFinished(bool)), this, SLOT(chargementTermine(bool)));
}

Page* Pages::getPageCourante()
{
    return pages->value(page_courante);
}

int Pages::getIdPageCourante()
{
    return page_courante;
}

WebBrowser* Pages::getParent()
{
    return parent;
}

void Pages::actionTitrePage(QString s)
{
    bool trouve = false;
    for(int i=0; i<pages->count(); i++)
    {
        if(pages->value(i)->title() == s)
        {
            this->setTabText(i, s);
            trouve = true;
        }
    }
    if(!trouve)
    {
        cout<<"Erreur : nom de la page introuvable Pages.cpp ligne:108"<<endl;
    }
}

void Pages::changementTab(int i)
{
    page_courante = i;
}

void Pages::fermerTab(QAction * a)
{
    if(a->data().toInt() == -1)
    {
        for(int i=pages->count()-1; i>0; i--)
        {
            this->removeTab(i);
            pages->remove(i);
        }
        pages->value(page_courante)->load(url_par_default);
    }
    else
    {
        if(pages->count()<=1)
        {
            pages->value(page_courante)->load(url_par_default);
        }
        else
        {
            this->removeTab(a->data().toInt());
            pages->remove(a->data().toInt());
        }
    }
    mettreAJourBouttonFermer();
}

void Pages::fermerTab(int i)
{
    if(pages->count()<=1)
    {
        pages->value(page_courante)->load(url_par_default);
    }
    else
    {
        this->removeTab(i);
        pages->remove(i);
    }
    mettreAJourBouttonFermer();
}

void Pages::chargementIcon()
{
    mettreAJourBouttonFermer();
    for(int i=0; i<this->count(); i++)
    {
        if(!QWebSettings::iconForUrl(this->pages->value(i)->url()).isNull())
        {
            this->setTabIcon(i, QWebSettings::iconForUrl(this->pages->value(i)->url()));
        }
        else
        {
            this->setTabIcon(i, QIcon(":/temp/images/icon_favourites.gif"));
        }
    }
}

void Pages::chargementTermine(bool b)
{
    if(b)
    {
        actionTitrePage(pages->value(page_courante)->title());
        chargementIcon();
    }
}

void Pages::nouvelOnglet()
{
    parent->chargerPage(url_par_default, 1);
}
