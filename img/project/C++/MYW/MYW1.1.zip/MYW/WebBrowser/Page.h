#ifndef PAGE_H
#define PAGE_H

/*========================================================================
Nom: Page.h           auteur: Maneschi Romain
Maj: 17.05.2009       Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWebView.
=========================================================================*/

/*!
* \file Page.h
* \brief Classe qui réimplante QWebView.
* \author Maneschi Romain
* \date 01.03.2009
*/

#include <QWebView>
#include <QContextMenuEvent>
#include <QWebHistory>
#include <QPainter>
#include <QFile>

#include "WebBrowser.h"
#include "Frame.h"

class Pages;

/*!
* \class Page
* \brief Classe qui réimplante QWebView une page internet.
*
* Cette classe est un QWebView donc le V dans le pattern MVC du module QWebKit.
* Elle se charge d'ouvrir une nouvelle fenêtre en cas de demande de la page en cours (popup). Et toutes les actions possibles sur un click droit.
*
*/
class Page : public virtual QWebView
{
    Q_OBJECT

private:
    Pages * parent;/*!< le parent de cette page*/
    QUrl * lien_pointe;/*!< garde le dernier lien pointé par la souris*/
    bool lien_est_pointe;/*!< vrai si un lien est pointé en ce moment, faux sinon*/
    QAction * action_fermer_page;/*!< action permettant de fermer l'onglet en cours sur un click droit*/
    QAction * action_fermer_page_s;/*!< action permettant de fermer tous les onglets en cours sur un click droit*/

private slots:
    /*!
    * \brief Est appelée l'orsque la souris survol un lien, et l'orsqu'elle en sort.
    *
    * \param lien : QString l'url de la page pointée QString.isEmpty si aucun lien survolé
    * \param titre : QString titre de la page pointée QString.isEmpty si aucun lien survolé
    * \param description : QString description de la page pointée QString.isEmpty si aucun lien survolé
    */
    virtual void lienPointe(QString, QString, QString);
    /*!
    * \brief Est appelé par action_fermer_page et ferme la page en cours
    */
    virtual void fermerTab();
    /*!
    * \brief Est appelé par action_fermer_page_s et ferme toutes les pages en cours
    */
    virtual void fermerTabS();
    /*!
    * \brief Est appelée l'orsque la page est finie de charger et appelle toImage()
    *
    * \param b : booléen si true alors tout c'est bien passé sinon false
    */
    virtual void chargementTermine(bool);
    /*!
    * \brief Est appelée l'orsque la page a chargée son titre pour ajouter l'entrée à l'historique
    *
    * \param s : QString titre de la page en cours
    */
    virtual void titreCharge(QString);

protected:
    /*!
    * \brief Réimplante l'évènement du click de la souris
    *
    * \param e : QMouseEvent
    */
    virtual void mousePressEvent(QMouseEvent*);
    /*!
    * \brief Réimplante l'évènement du click droit de la souris
    *
    * \param e : QContextMenuEvent
    */
    virtual void contextMenuEvent(QContextMenuEvent*);
    /*!
    * \brief Réimplante le fait d'ouvrir une nouvelle page lorsque cette page le souhaite (popup)
    *
    * \param QWebPage::WebWindowType
    */
    virtual QWebView* createWindow(QWebPage::WebWindowType);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe Page
    *
    * \param parent : Pages obligatoire car on a besoins d'appeler des méthodes
    */
    Page(Pages * parent);
    /*!
    * \brief Sauvegarde une image PNG de la page si cela n'est pas déjà fait pour l'historique.
    *
    * \param emplacement : QString url où sauvegarder l'image
    */
    virtual void toImage(const QString);
    /*!
    * \brief Retourne vrai si l'utilisateur est sur une partie copiable de la page; false si non
    */
    virtual bool estCopiable();
    /*!
    * \brief Retourne vrai si l'utilisateur est sur une partie editable de la page; false si non
    */
    virtual bool estEditable();

};
#endif // PAGE_H
