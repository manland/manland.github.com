#ifndef MARQUEPAGEMENU_H
#define MARQUEPAGEMENU_H

/*========================================================================
Nom: MarquePageMenu.h           auteur: Maneschi Romain
Maj: 17.05.2009                 Creation: 05.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QMenu pour les marques-pages.
=========================================================================*/

/*!
* \file MarquePageMenu.h
* \brief Classe qui réimplante QMenu pour les marques-pages.
* \author Maneschi Romain
* \date 05.05.2009
*/

#include <QMenu>
#include <QMouseEvent>
#include <QPoint>

class MarquePage;

/*!
* \class MarquePageMenu
* \brief Classe contenue dans MarquesPages réimplantant un QMenu.
*/
class MarquePageMenu : public QMenu
{
    Q_OBJECT
private:
    MarquePage * parent;/*!< Le parent de la classe*/
    QPoint startPos;/*!< Position du marque-page clické qui est contenue dans un dossier des marques-pages*/
    bool est_deplace;/*!< True si le marque page est déplacé qui est contenue dans un dossier des marques-pages, false sinon*/
    bool est_clicke;/*!< True si le marque page est clické qui est contenue dans un dossier des marques-pages, false sinon*/

protected:
    /*!
    * \brief Permet de savoir si l'utilisateur click sur un marque-page contenue dans un dossier
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mousePressEvent(QMouseEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur relache la souris aprés un click sur un marque-page contenue dans un dossier
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mouseReleaseEvent(QMouseEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur déplace la souris
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mouseMoveEvent(QMouseEvent*);
    /*!
    * \brief Lance un drag
    *
    * \param event : QMouseEvent événement déclanchant cette méthode si l'utilisateur à suffisament déplacé la souris
    */
    virtual void startDrag(QMouseEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe MarquePageMenu
    *
    * \param parent : MarquePage parent du menu des marques-pages
    */
    MarquePageMenu(MarquePage*);
};

#endif // MARQUEPAGEMENU_H
