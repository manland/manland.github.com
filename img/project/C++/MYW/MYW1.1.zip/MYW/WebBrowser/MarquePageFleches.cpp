/*========================================================================
Nom: MarquePageFleches.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                      Creation: 10.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QWidget pour les marques-pages afin d'insérer des flèches lors d'un drag&drop.
=========================================================================*/

#include <iostream>
using namespace std;

#include "MarquePageFleches.h"
#include "MarquesPages.h"

MarquePageFleches::MarquePageFleches(MarquesPages * p, int i) : QWidget(p)
{
    parent = p;
    place_dans_liste = i;

    QLabel * fleche_1 = new QLabel(this);
    QLabel * fleche_2 = new QLabel(this);

    QBoxLayout * l;
    if(p->orientation() == Qt::Horizontal)//si la ToolBar est horizontale
    {
        l = new QVBoxLayout(this);
        fleche_1->setPixmap(QPixmap(":/temp/images/arrow_down.gif"));
        fleche_2->setPixmap(QPixmap(":/temp/images/arrow_up.gif"));
    }
    else//si la ToolBar est verticale
    {
        l = new QHBoxLayout(this);
        fleche_1->setPixmap(QPixmap(":/temp/images/arrow_right.gif"));
        fleche_2->setPixmap(QPixmap(":/temp/images/arrow_left.gif"));
    }
    setLayout(l);
    l->addWidget(fleche_1);
    l->addWidget(fleche_2);
    setAttribute(Qt::WA_DeleteOnClose);
    setAcceptDrops(true);
}

void MarquePageFleches::dragEnterEvent(QDragEnterEvent * event)
{
    event->accept();
}

void MarquePageFleches::dragMoveEvent(QDragMoveEvent * event)
{
    event->accept();
}

void MarquePageFleches::dropEvent(QDropEvent * event)
{
    if (event->mimeData()->hasFormat("text/html"))
    {
        QByteArray itemData = event->mimeData()->data("text/html");
        QDataStream dataStream(&itemData, QIODevice::ReadOnly);

        QString titre;
        QString url;
        int mp_place_dans_liste;
        dataStream >> titre >> url >> mp_place_dans_liste/*place de l'ancien bouton, ou nouveau bouton < 0*/;

        if(mp_place_dans_liste >= 0)
        {
            parent->supprimerMarquePage(mp_place_dans_liste);
        }
        parent->ajouter(place_dans_liste, titre, url, false);
        parent->supprimerFleche();//si il y a des flêches on les enlèves sinon ne fait rien

        event->setDropAction(Qt::CopyAction);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}
