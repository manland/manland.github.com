#ifndef HISTORIQUELABEL_H
#define HISTORIQUELABEL_H

/*========================================================================
Nom: HistoriqueLabel.h           auteur: Maneschi Romain
Maj: 17.05.2009                  Creation: 12.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QLabel pour l'historique.
=========================================================================*/

/*!
* \file HistoriqueLabel.h
* \brief Classe qui réimplante QLabel pour l'historique.
* \author Maneschi Romain
* \date 12.04.2009
*/

#include <QLabel>
#include <QApplication>
#include <QMouseEvent>
#include <QBrush>
#include <QMenu>

#include "Historique.h"
#include "WebBrowser.h"

class HistoriqueWidget;

/*!
* \class HistoriqueLabel
* \brief Classe contenue dans HistoriqueWidget permettant d'afficher sous forme d'icônes les sites visités en réimplantant QLabel.
*
* Classe affichant sous forme d'une icone un site visité par l'utilisateur.
*/
class HistoriqueLabel : virtual public QLabel
{
    Q_OBJECT

private:
    HistoriqueWidget * parent;/*!< Le parent appelant cette classe*/
    QString url_icone;/*!< L'url de l'icone*/
    QString url_page;/*!< L'url de la page internet*/
    QString date;/*!< La date de la visite de la page*/
    QString titre;/*!< Le titre de la page visité*/
    bool vide;/*!< True pour ne pas l'afficher, false sinon*/

protected:
    /*!
    * \brief Méthode héritée de QWidget permetant de savoir lorsqu'un utilisateur click sur une icone de l'historique
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mousePressEvent(QMouseEvent*);
    /*!
    * \brief Méthode héritée de QWidget permetant de savoir lorsqu'un utilisateur click droit sur une icone de l'historique
    *
    * \param event : QContextMenuEvent événement déclanchant cette méthode
    */
    virtual void contextMenuEvent(QContextMenuEvent*);
    /*!
    * \brief Méthode héritée de QWidget permetant de savoir lorsqu'un utilisateur passe la souris sur une icone de l'historique
    *
    * \param event : QEvent événement déclanchant cette méthode
    */
    virtual void enterEvent(QEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe HistoriqueLabel
    *
    * \param url_image : QString url de l'image
    * \param url_page : QString url de la page internet
    * \param date : QString date de visite de la page
    * \param titre : QString titre de la page internet
    * \param parent : HistoriqueWidget parent de l'HistoriqueLabel
    */
    HistoriqueLabel(QString, QString, QString, QString, HistoriqueWidget * p);
    /*!
    * \brief Permet d'agrandir la première miniature les autres seront gérés par enterEvent()
    *
    */
    virtual void premiereMiniature();//appel juste enterEvent
    /*!
    * \brief Permet de modifier tous les paramètres d'une icone
    *
    * \param url_image : QString url de l'image
    * \param url_page : QString url de la page internet
    * \param date : QString date de visite de la page
    * \param titre : QString titre de la page internet
    */
    virtual void setAll(QString, QString, QString, QString);
    /*!
    * \brief Permet de modifier tous les paramètres d'une icone en lui signalant qu'elle est vide (sans image)
    *
    * \param url_image : QString url de l'image par défaut
    * \param url_page : QString url de la page internet
    * \param date : QString date de visite de la page
    * \param titre : QString titre de la page internet
    */
    virtual void setAllSansImage(QString, QString, QString, QString);
    /*!
    * \brief Permet de signaler à l'icone qu'elle n'est là que pour combler les trous
    *
    * Cette méthode permet de colorier l'icone de la même couleure que le fond afin de ne pas la voir. De plus aucune action
    * n'est réalisable donc aucun click, aucun agrandissement au passage de la souris.
    */
    virtual void setVide();
};
#endif // HISTORIQUELABEL_H
