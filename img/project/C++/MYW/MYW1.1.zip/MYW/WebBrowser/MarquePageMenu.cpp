/*========================================================================
Nom: MarquePageMenu.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                   Creation: 05.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QMenu pour les marques-pages.
=========================================================================*/

#include <iostream>
using namespace std;

#include "MarquePageMenu.h"

#include "MarquesPages.h"
#include "MarquePage.h"

MarquePageMenu::MarquePageMenu(MarquePage * p) : QMenu(p)
{
    parent = p;
    est_deplace = false;
    est_clicke = false;
}

void MarquePageMenu::mousePressEvent(QMouseEvent * event)
{
    startPos = event->pos();
    est_clicke = true;
    if(!this->rect().contains(event->pos()))
    {
        this->hide();
        est_clicke = false;
    }
}

void MarquePageMenu::mouseReleaseEvent(QMouseEvent * event)
{
    if(!est_deplace && event->button() == Qt::LeftButton)//si la souris n'a presque pas bouger c'est un click
    {
        QAction * action = actionAt(event->pos());
        if(action && event->button() == Qt::LeftButton)
        {
            parent->getParent()->charger(QUrl(action->data().toString()), 0);
            event->accept();
        }
        else if(action && event->button() == Qt::MidButton)
        {
            parent->getParent()->charger(QUrl(action->data().toString()), 1);
            event->accept();
        }
        else
        {
            event->ignore();
        }
    }
    else
    {
        event->ignore();
    }
    est_clicke = false;
}

void MarquePageMenu::mouseMoveEvent(QMouseEvent * event)
{
    if(est_clicke && this->rect().contains(event->pos()))
    {
        est_deplace = true;
        startDrag(event);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void MarquePageMenu::startDrag(QMouseEvent * event)
{
    QAction * action = actionAt(event->pos());
    if(action)
    {
        QByteArray itemData;
        QDataStream dataStream(&itemData, QIODevice::WriteOnly);

        dataStream << action->text() << action->data().toString() << -1/*pour ne pas le supprimer au moment du drop*/;

        QMimeData * mimeData = new QMimeData;
        mimeData->setData("text/html", itemData);

        QDrag *drag = new QDrag(this);
        drag->setMimeData(mimeData);

        QPushButton * p = new QPushButton(action->icon(), action->text(), this);
        p->setAttribute(Qt::WA_DeleteOnClose);
        QPixmap pixmap(p->size());
        p->render(&pixmap, QPoint(0, 0), QRegion (0, 0, this->width(), this->height()), RenderFlags());
        p->close();

        drag->setPixmap(pixmap);
        drag->setHotSpot(event->pos());

        if (drag->exec(Qt::CopyAction, Qt::IgnoreAction) == Qt::CopyAction)
        {
            this->removeAction(action);
            this->parent->getParent()->supprimerAction(parent->getPlaceDansListe(), action->text());
        }
        else
        {
            parent->getParent()->supprimerFleche();
        }
        est_clicke = false;
        est_deplace = false;
    }
    else
    {
        event->ignore();
    }
}
