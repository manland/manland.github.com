/*========================================================================
Nom: PagesTabBar.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                Creation: 01.03.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QTarBar pour les onglets des pages.
=========================================================================*/

#include <iostream>
using namespace std;

#include "PagesTabBar.h"

#include "Pages.h"
#include "MarquesPages.h"

PagesTabBar::PagesTabBar(Pages * p) : QTabBar()
{
    parent = p;
    this->setMouseTracking(true);
}

void PagesTabBar::mouseMoveEvent(QMouseEvent * event)
{
    if(tabAt(event->pos()) == parent->getIdPageCourante())
    {
        int avant = 0;
        if(tabAt(event->pos()) == 0)
        {
            avant = 0;
        }
        else
        {
            for(int i=1; i<=tabAt(event->pos()); i++)
            {
                avant = avant + this->tabRect(tabAt(event->pos())-i).width();
            }
        }
        if(QRect(avant, 0, 20, this->height()).contains(event->pos()))
        {
            this->setTabToolTip(parent->getIdPageCourante(), tr("Double cliquez sans relacher pour ajouter aux favoris"));
            if(this->cursor().shape() == Qt::ArrowCursor)
            {
                this->setCursor(Qt::OpenHandCursor);
            }
        }
        else
        {
            this->setTabToolTip(parent->getIdPageCourante(), parent->getPageCourante()->title());
            if(this->cursor().shape() == Qt::OpenHandCursor)
            {
                this->setCursor(Qt::ArrowCursor);
            }
        }
    }
    else
    {
        if(this->cursor().shape() == Qt::OpenHandCursor)
        {
            this->setCursor(Qt::ArrowCursor);
        }
    }
}

void PagesTabBar::mouseDoubleClickEvent(QMouseEvent * event)
{
    if(tabAt(event->pos()) == parent->getIdPageCourante())
    {
        startDrag(event);
    }
}

void PagesTabBar::startDrag(QMouseEvent * event)
{
    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);

    dataStream << parent->getPageCourante()->title() << parent->getPageCourante()->url().toString() << -1;

    QMimeData * mimeData = new QMimeData;
    mimeData->setData("text/html", itemData);

    QDrag *drag = new QDrag(this);
    drag->setMimeData(mimeData);

    QPushButton * p = new QPushButton(this->tabIcon(this->currentIndex()), parent->getPageCourante()->title());
    QPixmap pixmap(p->sizeHint());
    p->render(&pixmap);
    p->close();

    drag->setPixmap(pixmap);
    drag->setHotSpot(event->pos());

    if(drag->exec(Qt::CopyAction, Qt::IgnoreAction) == Qt::CopyAction)
    {
        ;
    }
    else
    {
        parent->getParent()->getMarquesPages()->supprimerFleche();
    }
}
