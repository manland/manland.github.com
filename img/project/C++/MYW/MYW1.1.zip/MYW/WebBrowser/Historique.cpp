/*========================================================================
Nom: Historique.cpp           auteur: Maneschi Romain
Maj: 17.05.2009               Creation: 12.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui r�implante QWebHistoryInterface correspond au MC du pattern MVC. D�finition de la structure struct_historique.
=========================================================================*/

#include <iostream>
using namespace std;

#include "Historique.h"

#include "WebBrowser.h"
#include "HistoriqueWidget.h"
#include "../mesConfigs.h"
#include "../Erreurs/erreur.h"
#include "WebBrowserMenuBar.h"

Historique::Historique(WebBrowser * p) : QWebHistoryInterface(p)
{
    parent = p;
    url_s = new QList<struct struct_historique>;

    QWebHistoryInterface::setDefaultInterface(this);

    restaurer();

    historique = new HistoriqueWidget(this);

    bar = new QDockWidget(tr("Historique"), parent);
    parent->addDockWidget(Qt::BottomDockWidgetArea, bar);
    bar->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    bar->setWidget(historique);
}

void Historique::ajouterEntree(QString url, QString titre)
{
    if(!historyContains(url))
    {
        struct_historique temp;
        temp.url = url;
        temp.titre = titre;
        temp.date.append(QDateTime::currentDateTime());
        url_s->append(temp);
    }
    else
    {
        bool trouve = false;
        for(int i=0; i<url_s->count() && !trouve; i++)
        {
            if(url_s->value(i).url == url)
            {
                struct_historique temp;
                temp.url = url_s->value(i).url;
                temp.titre = url_s->value(i).titre;
                temp.date = url_s->value(i).date;
                temp.date.append(QDateTime::currentDateTime());
                url_s->removeAt(i);
                url_s->append(temp);
                trouve = true;
            }
        }
    }
    enregistrer();
    historique->mettreAJour();
    parent->getMenuBar()->mettreAJourHistorique();
}

void Historique::addHistoryEntry(const QString&)
{
    //rien car pas int�ressant par rapport au titre de la page
}

bool Historique::historyContains(const QString& url) const
{
    for(int i=0; i<url_s->count(); i++)
    {
        if(url_s->value(i).url == url)
        {
            return true;
        }
    }
    return false;
}

void Historique::enregistrer()
{
    QSettings settings("MYW", "WebBrowser");

    settings.beginWriteArray("Historique");
    for(int i=0; i<url_s->count(); i++)
    {
        if(!url_s->value(i).url.isEmpty())
        {
            settings.setArrayIndex(i);
            settings.setValue(QString("url"), url_s->value(i).url);
            settings.setValue(QString("titre"), url_s->value(i).titre);
            settings.setValue(QString("date"), url_s->value(i).date);
        }
    }
    settings.endArray();
    settings.sync();
}

void Historique::restaurer()
{
    QSettings settings("MYW", "WebBrowser");

    int size = settings.beginReadArray("Historique");

    for(int i=0; i<size; i++)
    {
        settings.setArrayIndex(i);
        struct_historique temp;
        temp.url = settings.value(QString("url")).toString();
        temp.titre = settings.value(QString("titre")).toString();
        temp.date = settings.value(QString("date")).toList();
        url_s->append(temp);
    }
    settings.endArray();
}

void Historique::toutSupprimer()
{
    QSettings settings("MYW", "WebBrowser");

    settings.beginGroup("Historique");
    settings.remove("");
    settings.endGroup();
    settings.sync();


    QDir * dir = new QDir(QString("WebBrowser/images/historique").prepend(systeme_relation_fichier));
    QStringList l = dir->entryList();
    for(int i=0; i<l.count(); i++)
    {
        if(l.value(i) != "historique_vide.png")
        {
            if(!dir->remove(l.value(i)))
            {
                Erreur::ecritErreurWebBrowser("Historique", "toutSuprimer()", 134);
            }
        }
    }

    url_s->clear();
    historique->mettreAJour();
}

void Historique::supprimerIcones()
{
    QDir * dir = new QDir(QString("WebBrowser/images/historique").prepend(systeme_relation_fichier));
    QStringList l = dir->entryList();
    for(int i=0; i<l.count(); i++)
    {
        if(l.value(i) != "historique_vide.png")
        {
            dir->remove(l.value(i));
        }
    }
}

void Historique::supprimerLiens()
{
    QSettings settings("MYW", "WebBrowser");

    settings.beginGroup("Historique");
    settings.remove("");
    settings.endGroup();
    settings.sync();

    url_s->clear();
    historique->mettreAJour();
}


QList<struct_historique>* Historique::getUrlS()
{
    return url_s;
}

QWidget* Historique::getHistorique()
{
    return bar;
}

HistoriqueWidget* Historique::getHistoriqueWidget()
{
    return historique;
}

WebBrowser* Historique::getParent()
{
    return parent;
}


