/*========================================================================
Nom: HistoriqueWidget.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                     Creation: 12.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe contenant l'interface graphique de l'historique. Correspond au V du pattern MVC.
=========================================================================*/

#include <iostream>
using namespace std;

#include "HistoriqueWidget.h"

#include "Historique.h"

#include "../mesConfigs.h"

HistoriqueWidget::HistoriqueWidget(Historique * p) : QWidget()
{
    nb_miniatures = 5;
    parent = p;
    premiere_miniature_en_cours = 0;
    creerListeParDateFiltre();

    layout_general = new QHBoxLayout(this);

    layout_gauche = new QVBoxLayout();

    tri = new QComboBox();
    tri->insertItem(0, tr("Du plus visit� au moins visit�"));
    tri->insertItem(1, tr("D'aujourd'hui jusqu'au premier jour"));
    tri->insertItem(2, tr("D'aujourd'hui jusqu'au premier jour avec toutes les entr�es"));
    tri->insertSeparator(3);
    tri->insertItem(4, tr("Du moins visit� au plus visit�"));
    tri->insertItem(5, tr("Du premier jour � aujourd'hui"));
    tri->insertItem(6, tr("Du premier jour � aujourd'hui avec toutes les entr�es"));
    tri->setCurrentIndex(1);
    layout_gauche->addWidget(tri);
    connect(tri, SIGNAL(activated(int)), this, SLOT(selectionFiltre(int)));

    list_miniatures = new QList<HistoriqueLabel*>;
    miniature_widget = creerMiniatures();
    layout_gauche->addWidget(miniature_widget);

    layout_general->addLayout(layout_gauche);

    layout_general->addWidget(creerPrevisualisation());

    mettreAJourBoutons();

    this->setAttribute(Qt::WA_DeleteOnClose);
}

void HistoriqueWidget::selectionFiltre(int)
{
    mettreAJour();
}

QWidget* HistoriqueWidget::creerMiniatures()
{
    QWidget * w = new QWidget(this);
    w->setAttribute(Qt::WA_DeleteOnClose);

    h_layout_miniatures = new QHBoxLayout();

    retour = new QPushButton(QIcon(":/WebBrowser/precedent.png"), "", this);
    retour->setFlat(true);
    connect(retour, SIGNAL(clicked()), this, SLOT(actionRetour()));

    h_layout_miniatures->addWidget(retour);

    afficherMiniatures();

    avancer = new QPushButton(QIcon(":/WebBrowser/suivant.png"), "", this);
    avancer->setFlat(true);
    connect(avancer, SIGNAL(clicked()), this, SLOT(actionAvancer()));

    h_layout_miniatures->addWidget(avancer);

    w->setLayout(h_layout_miniatures);
    return w;
}

void HistoriqueWidget::afficherMiniatures()
{
    for(int i=0; i<nb_miniatures; i++)
    {
        HistoriqueLabel * l = new HistoriqueLabel("", "", "", "", this);
        l->setVide();
        h_layout_miniatures->insertWidget(1, l, 100, Qt::AlignHCenter);
        list_miniatures->append(l);
    }
}

void HistoriqueWidget::modifierMiniatures(int depart, int arrivee)
{
    if(date_s->count()>0)
    {
        for(int i=0; i<list_miniatures->count() && depart<date_s->count() && depart<arrivee; i++)
        {
            QUrl u(date_s->value(depart).url);
            QPixmap pixmap(u.host().prepend(QString("WebBrowser/Images/historique/").prepend(systeme_relation_fichier)));
            if(!pixmap.isNull())
            {
                list_miniatures->value(i)->setAll
                        (u.host().prepend("WebBrowser/Images/historique/").prepend(systeme_relation_fichier),
                         date_s->value(depart).url,
                         date_s->value(depart).date.value(0).toDateTime().toString("hh:mm:ss dddd d MMMM yyyy"),
                         date_s->value(depart).titre);
                list_miniatures->value(i)->show();
            }
            else
            {
                list_miniatures->value(i)->setAllSansImage
                        (QString(":/historique/historique_vide.png").prepend(systeme_relation_fichier),
                         date_s->value(depart).url,
                         date_s->value(depart).date.value(0).toDateTime().toString("hh:mm:ss dddd d MMMM yyyy"),
                         date_s->value(depart).titre);
                list_miniatures->value(i)->show();
            }
            depart++;
        }
        if(depart < arrivee && list_miniatures->count()-(arrivee-depart)>0)//pour les labels en surplus d� �  afficherMiniatures()
        {
            for(int i=list_miniatures->count()-(arrivee-depart); i<list_miniatures->count(); i++)
            {
                list_miniatures->value(i)->setVide();
            }
        }
    }
    else//date_s==0
    {
        for(int i=0; i<list_miniatures->count(); i++)
        {
            list_miniatures->value(i)->setVide();
        }
    }
}

QLabel* HistoriqueWidget::creerPrevisualisation()
{
    previsualisation = new QLabel();
    previsualisation->setAttribute(Qt::WA_DeleteOnClose);
    if(list_miniatures->count() > 0)
    {
        list_miniatures->first()->premiereMiniature();
    }
    return previsualisation;
}

void HistoriqueWidget::changerPrevisualisation(const QPixmap * p)
{
    previsualisation->setPixmap(*p);
}

void HistoriqueWidget::creerListeParDate()
{
    QList<struct struct_historique> * url_s = parent->getUrlS();
    date_s = new QList<struct struct_historique>;

    for(int i=0; i<url_s->count(); i++)
    {
        for(int d=0; d<url_s->value(i).date.count(); d++)
        {
            struct_historique temp;
            temp.url = url_s->value(i).url;
            temp.titre = url_s->value(i).titre;
            temp.date.append(url_s->value(i).date.value(d));

            bool trouve = false;

            if(date_s->count() == 0)
            {
                date_s->append(temp);
                trouve = true;
            }

            int h=0;
            while(h < date_s->count() && !trouve)
            {
                //0 car toujours 1 seule date dans date_s ---------------------------------!
                if(url_s->value(i).date.value(d).toDateTime() < date_s->value(h).date.value(0).toDateTime())
                {
                    h++;
                }
                else
                {
                    date_s->insert(h, temp);
                    trouve = true;
                }
            }
            if(!trouve)
            {
                date_s->append(temp);
            }
        }
    }
}

void HistoriqueWidget::creerListeParDateFiltre()
{
    QList<struct struct_historique> * url_s = parent->getUrlS();
    date_s = new QList<struct struct_historique>;

    for(int i=0; i<url_s->count(); i++)
    {
        for(int d=0; d<url_s->value(i).date.count(); d++)
        {
            struct_historique temp;
            temp.url = url_s->value(i).url;
            temp.titre = url_s->value(i).titre;
            temp.date.append(url_s->value(i).date.value(d));

            bool trouve = false;

            if(date_s->count() == 0)
            {
                date_s->append(temp);
                trouve = true;
            }

            int h=0;
            while(h < date_s->count() && !trouve)
            {
                if(url_s->value(i).url == date_s->value(h).url &&
                   url_s->value(i).date.value(d).toDateTime().date() == date_s->value(h).date.value(0).toDateTime().date())
                {
                    //rien
                    h = date_s->count();
                }
                //0 car toujours 1 seule date dans date_s ---------------------------------!
                else if(url_s->value(i).date.value(d).toDateTime() < date_s->value(h).date.value(0).toDateTime())
                {
                    h++;
                }
                else
                {
                    date_s->insert(h, temp);
                    trouve = true;
                }
            }
            if(!trouve)
            {
                date_s->append(temp);
            }
        }
    }
}

void HistoriqueWidget::creerListeParPlusVisite()
{
    QList<struct struct_historique> * url_s = parent->getUrlS();
    date_s = new QList<struct struct_historique>;

    for(int i=0; i<url_s->count(); i++)
    {
        struct_historique temp;
        temp.url = url_s->value(i).url;
        temp.titre = url_s->value(i).titre;
        temp.date.append(url_s->value(i).date.last());

        if(date_s->count() == 0)
        {
            date_s->append(temp);
        }
        else
        {
            bool trouve = false;
            int d=0;
            while(d < date_s->count() && !trouve)
            {
                if(url_s->value(i).date.count() > date_s->value(d).date.count())
                {
                    d++;
                }
                else
                {
                    date_s->insert(d, temp);
                    trouve = true;
                }
            }
            if(!trouve)
            {
                date_s->prepend(temp);
            }
        }
    }
}

void HistoriqueWidget::retournerList()
{
    QList<struct_historique> * temp = new QList<struct_historique>;
    for(int i=0; i<date_s->count(); i++)
    {
        temp->prepend(date_s->value(i));
    }
    date_s = temp;
}

void HistoriqueWidget::actionRetour()
{
    modifierMiniatures(premiere_miniature_en_cours+nb_miniatures, premiere_miniature_en_cours+(nb_miniatures*2));
    premiere_miniature_en_cours = premiere_miniature_en_cours+nb_miniatures;

    mettreAJourBoutons();
}

void HistoriqueWidget::actionAvancer()
{
    modifierMiniatures(premiere_miniature_en_cours-nb_miniatures, premiere_miniature_en_cours);
    premiere_miniature_en_cours = premiere_miniature_en_cours-nb_miniatures;

    mettreAJourBoutons();
}

void HistoriqueWidget::mettreAJourBoutons()
{
    if(premiere_miniature_en_cours > date_s->count() || premiere_miniature_en_cours + nb_miniatures >= date_s->count())
    {
        retour->setEnabled(false);
    }
    else
    {
        retour->setEnabled(true);
    }
    if(premiere_miniature_en_cours <= 0)
    {
        avancer->setEnabled(false);
    }
    else
    {
        avancer->setEnabled(true);
    }
}

void HistoriqueWidget::resizeEvent(QResizeEvent*)
{
    if(list_miniatures->count() > 0)
    {
        list_miniatures->first()->premiereMiniature();
    }
}

void HistoriqueWidget::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
    QLinearGradient gradient(this->width()/2, 0, this->width()/2, this->height());
    gradient.setColorAt(0.0, Qt::black);
//    gradient.setColorAt(0.45, Qt::black);
//    gradient.setColorAt(0.5, Qt::lightGray);
    gradient.setColorAt(0.55, Qt::black);
    gradient.setColorAt(1.0, Qt::darkGray);
    painter.setPen(Qt::darkGray);
//    painter.setPen(QColor(0, 153, 0, 255));
    painter.setBrush(gradient);
    painter.drawRect(0, 0, this->width(), this->height());
    painter.end();
    event->accept();
}

Historique* HistoriqueWidget::getParent()
{
    return parent;
}

void HistoriqueWidget::mettreAJour()
{
    int i = tri->currentIndex();
    if(i == 0)
    {
        creerListeParPlusVisite();
    }
    else if(i == 1)
    {
        creerListeParDateFiltre();
    }
    else if(i == 2)
    {
        creerListeParDate();
    }
    else if(i == 4)
    {
        creerListeParPlusVisite();
        retournerList();
    }
    else if(i == 5)
    {
        creerListeParDateFiltre();
        retournerList();
    }
    else if(i == 6)
    {
        creerListeParDate();
        retournerList();
    }
    modifierMiniatures(0, nb_miniatures);
    list_miniatures->first()->premiereMiniature();
}

QList<struct_historique>* HistoriqueWidget::getUrlS()
{
    return date_s;
}
