#ifndef MARQUEPAGE_H
#define MARQUEPAGE_H

/*========================================================================
Nom: MarquePage.h           auteur: Maneschi Romain
Maj: 17.05.2009             Creation: 05.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QPushButton pour les marques-pages.
=========================================================================*/

/*!
* \file MarquePage.h
* \brief Classe qui réimplante QPushButton pour les marques-pages.
* \author Maneschi Romain
* \date 05.05.2009
*/

#include <QPushButton>
#include <QUrl>
#include <QVariant>
#include <QMouseEvent>
#include <QWebSettings>
#include <QPicture>

class MarquesPages;

/*!
* \class MarquePage
* \brief Classe contenue dans MarquesPages et permettant sur un click d'aller sur la page représenté par l'utilisateur.
*
* Classe affichant sous forme d'un bouton le marque-page. Il permet en outre le drag&drop, et le fait de clicker dessus pour
* se rendre sur une page préalablement sauvegardée.
*/
class MarquePage : public QPushButton
{
    Q_OBJECT

private:
    MarquesPages * parent;/*!< Le parent de la classe*/
    bool estDeplace;/*!< True si le marque page est déplacé, false sinon*/
    bool estClicke;/*!< True si le marque page est clické, false sinon*/
    int place_dans_liste;/*!< Entier représentant la place du marque-page*/
    QPoint startPos;/*!< Position du marque page lorsqu'il est clické*/

protected:
    /*!
    * \brief Permet la coloration du marque-page
    *
    * \param event : QPaintEvent événement déclanchant cette méthode
    */
    virtual void paintEvent(QPaintEvent*);
    /*!
    * \brief Permet de savoir si un drag sort du marque-page
    *
    * \param event : QDragLeaveEvent événement déclanchant cette méthode
    */
    virtual void dragLeaveEvent(QDragLeaveEvent*);
    /*!
    * \brief Permet de savoir si un drag passe dessus le marque-page
    *
    * \param event : QDragEnterEvent événement déclanchant cette méthode
    */
    virtual void dragEnterEvent(QDragEnterEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur click sur un marque-page
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mousePressEvent(QMouseEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur relache la souris aprés un click sur un marque-page
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mouseReleaseEvent(QMouseEvent*);
    /*!
    * \brief Permet de savoir si l'utilisateur déplace la souris
    *
    * \param event : QMouseEvent événement déclanchant cette méthode
    */
    virtual void mouseMoveEvent(QMouseEvent*);
    /*!
    * \brief Lance un drag
    *
    * \param event : QMouseEvent événement déclanchant cette méthode si l'utilisateur à suffisament déplacé la souris
    */
    virtual void startDrag(QMouseEvent*);
    /*!
    * \brief Réalise un drop sur un dossier de marques-pages
    *
    * \param event : QDropEvent événement déclanchant cette méthode
    */
    virtual void dropEvent(QDropEvent*);

public:
    /*!
    * \brief Constructeur
    *
    * Constructeur de la classe MarquePage
    *
    * \param titre : QString titre du marque-page
    * \param parent : MarquesPages parent du marque-page
    * \param place_liste : int place dans la liste des marques-pages
    */
    MarquePage(QString, MarquesPages*, int);
    /*!
    * \brief Retourne la place du marque-page dans la liste des marques-pages
    *
    * return place_liste : int place dans la liste des marques-pages
    */
    virtual int getPlaceDansListe();
    /*!
    * \brief Permet d'accéder au parent
    *
    * \return MarquesPages* le pointeur des marques-pages
    */
    virtual MarquesPages* getParent();
};

#endif // MARQUEPAGE_H
