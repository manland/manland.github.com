/*========================================================================
Nom: HistoriqueLabel.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                    Creation: 12.04.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe qui réimplante QLabel pour l'historique.
=========================================================================*/

#include <iostream>
using namespace std;

#include "HistoriqueLabel.h"
#include "HistoriqueWidget.h"

HistoriqueLabel::HistoriqueLabel(QString urlI, QString urlP, QString d, QString t, HistoriqueWidget * p) : QLabel(p)
{
    parent = p;
    url_icone = urlI;
    url_page = urlP;
    date = d;
    titre = t;
    vide = false;

    if(!url_icone.isEmpty())
    {
        QPixmap pixmap(url_icone);
        QPixmap pixmap_bonne_taille = pixmap.scaled(100, 60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        setPixmap(pixmap_bonne_taille);
    }
    setToolTip(titre);

    this->setCursor(QCursor(Qt::PointingHandCursor));
    this->setAttribute(Qt::WA_DeleteOnClose);
}

void HistoriqueLabel::mousePressEvent(QMouseEvent * event)
{
    if(event->button() == Qt::LeftButton && !vide)
    {
        //HistoriqueWidget //Historique //WebBrowser
        parent->getParent()->getParent()->chargerPage(url_page);//historique
    }
    else if(event->button() == Qt::MidButton && !vide)
    {
        //HistoriqueWidget //Historique //WebBrowser
        parent->getParent()->getParent()->chargerPage(url_page, 1);//historique
    }
}

void HistoriqueLabel::contextMenuEvent(QContextMenuEvent * event)
{
    QMenu * menu = new QMenu(this);

    QAction * action = new QAction(tr("Trier..."), this);
    menu->addAction(action);
    menu->addSeparator();
    action = new QAction(tr("Supprimer cette image"), this);
    menu->addAction(action);
    action = new QAction(tr("Supprimer"), this);
    menu->addAction(action);
    menu->addSeparator();
    action = new QAction(tr("Tout Supprimer"), this);
    menu->addAction(action);

    menu->move(event->globalPos());
    menu->show();

    event->accept();
}

void HistoriqueLabel::enterEvent(QEvent *)
{
    if(!vide)
    {
        QPixmap p(url_icone);
        QPixmap pixmap_bonne_taille = p.scaled(300, 120, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        QPainter painter(&pixmap_bonne_taille);
        painter.drawText(pixmap_bonne_taille.rect(), Qt::AlignHCenter, date);
        parent->changerPrevisualisation(&pixmap_bonne_taille);
    }
}

void HistoriqueLabel::premiereMiniature()
{
    enterEvent(new QEvent(QEvent::None));
}

void HistoriqueLabel::setAll(QString urlI, QString urlP, QString d, QString t)
{
    url_icone = urlI;
    url_page = urlP;
    date = d;
    titre = t;
    vide = false;

    QPixmap pixmap(url_icone);
    QPixmap pixmap_bonne_taille = pixmap.scaled(100, 60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    setPixmap(pixmap_bonne_taille);
    setToolTip(titre.append(" - ").append(url_page));
}

void HistoriqueLabel::setAllSansImage(QString urlI, QString urlP, QString d, QString t)
{
    url_icone = urlI;
    url_page = urlP;
    date = d;
    titre = t;
    vide = false;

    QPixmap pixmap(url_icone);
    QPainter painter(&pixmap);
    painter.drawText(pixmap.rect(), Qt::AlignCenter, tr("Vide"));
    QPixmap pixmap_bonne_taille = pixmap.scaled(100, 60, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    setPixmap(pixmap_bonne_taille);
    setToolTip(titre);
}

void HistoriqueLabel::setVide()
{
    vide = true;

    QPixmap pixmap(100, 60);
    QPainter painter(&pixmap);
    QBrush brush(QColor(0, 0, 0, 255));
    painter.setBrush(brush);
    painter.drawRect(pixmap.rect());

    setPixmap(pixmap);
    setToolTip(tr("Vide"));
}
