/*========================================================================
Nom: MarquesPages.cpp           auteur: Maneschi Romain
Maj: 17.05.2009                 Creation: 05.05.2009
Projet: MYW
--------------------------------------------------------------------------
Specification:
Classe contenant les QPushButton des marques-pages. D�finition de la structure struct_marque_page.
=========================================================================*/

#include <iostream>
using namespace std;

#include "MarquesPages.h"
#include "WebBrowser.h"
#include "WebBrowserMenuBar.h"
#include "Pages.h"

MarquesPages::MarquesPages(WebBrowser * p) : QToolBar(tr("Marques-Pages"), p)
{
    parent = p;
    action_fleche = new QAction(this);

    list_marques = new QList<struct struct_marque_page>;
    list_marques_boutons = new QList<MarquePage*>;
    restaurer();
    if(list_marques->count()==0)//s'il n'y a pas de marques pages
    {
        defaut();
    }
    else
    {
        creerBoutons();
    }

    parent->addToolBar(Qt::TopToolBarArea, this);
    show();
    setAttribute(Qt::WA_DeleteOnClose);
    setAttribute(Qt::WA_LayoutOnEntireRect);
    setAcceptDrops(true);
    if(list_marques_boutons->count()>0)
    {
        setMinimumHeight(list_marques_boutons->value(0)->height());
    }
}

void MarquesPages::paintEvent(QPaintEvent * event)
{
    QPainter painter(this);
//    QLinearGradient gradient(this->width()/2, 0, this->width()/2, this->height());
//    gradient.setColorAt(0.0, Qt::black);
//    gradient.setColorAt(0.45, Qt::darkGray);
//    gradient.setColorAt(0.55, Qt::darkGray);
//    gradient.setColorAt(1.0, Qt::black);
    QLinearGradient gradient(0, 0, this->width(), (this->height()/2)-5);
    gradient.setColorAt(0.0, QColor(100, 100, 100));
    gradient.setColorAt(1.0, QColor(80, 80, 80));
    painter.setPen(QColor(80, 80, 80));
    painter.setBrush(gradient);
    painter.drawRect(0, 0, this->width(), (this->height()/2)-5);

    QLinearGradient gradient2(0, (this->height()/2)-5, this->width(), this->height());
    gradient2.setColorAt(0.0, QColor(70, 70, 70));
    gradient2.setColorAt(1.0, QColor(40, 40, 40));
    painter.setPen(QColor(40, 40, 40));
    painter.setBrush(gradient2);
    painter.drawRect(0, (this->height()/2)-5, this->width(), this->height());
    painter.end();
    event->accept();
}

void MarquesPages::enregistrer()
{
    QSettings settings("MYW", "WebBrowser");

    settings.beginWriteArray("Marques-Pages");
    for(int i=0; i<list_marques->count(); i++)
    {
        settings.setArrayIndex(i);
        settings.setValue(QString("titre"), list_marques->value(i).titre);
        settings.setValue(QString("urls"), list_marques->value(i).urls);
    }
    settings.endArray();
    settings.sync();
}

void MarquesPages::restaurer()
{
    QSettings settings("MYW", "WebBrowser");

    int size = settings.beginReadArray("Marques-Pages");

    for(int i=0; i<size; i++)
    {
        settings.setArrayIndex(i);
        struct_marque_page temp;
        temp.titre = settings.value(QString("titre")).toString();
        temp.urls = settings.value(QString("urls")).toMap();
        list_marques->append(temp);
    }
    settings.endArray();
}

void MarquesPages::creerBoutons()
{
    for(int i=0; i<list_marques->count(); i++)
    {
        MarquePage * p = new MarquePage(list_marques->value(i).titre, this, i);
        if(list_marques->value(i).urls.keys().contains(list_marques->value(i).titre))//si le titre est le m�me que le titre du lien c'est un marque page
        {
            p->setAccessibleDescription(list_marques->value(i).urls[list_marques->value(i).titre].toString());
            if(!QWebSettings::iconForUrl(QUrl(p->accessibleDescription())).isNull())
            {
                p->setIcon(QWebSettings::iconForUrl(QUrl(p->accessibleDescription())));
            }
            else
            {
                p->setIcon(QIcon(":/temp/images/page_bookmark.gif"));
            }
        }
        else//sinon c'est un dossier
        {
            MarquePageMenu * menu = new MarquePageMenu(p);
            p->setIcon(QIcon(":/temp/images/folder.gif"));
            for(int m=0; m<list_marques->value(i).urls.keys().count(); m++)
            {
                QAction * action = menu->addAction(list_marques->value(i).urls.keys().value(m));
                action->setData(list_marques->value(i).urls.value(list_marques->value(i).urls.keys().value(m)));
                action->setIcon(QWebSettings::iconForUrl(action->data().toUrl()));
            }
            connect(menu, SIGNAL(triggered(QAction*)), this, SLOT(charger(QAction*)));
            p->setMenu(menu);
        }
        list_marques_boutons->append(p);
        addWidget(p);
    }
}

void MarquesPages::ajouter(int i, QString t, QString l, bool est_dans_dossier)
{
    struct_marque_page temp;
    if(!l.isEmpty())//s'il y a un lien c'est un marque-page
    {
        if(i == -1 && !est_dans_dossier)//nouvelle marque hor dossier en dernier
        {
            temp.titre = t;
            temp.urls[t] = l;//le titre est pareil car le marque page sera son propre dossier
            list_marques->append(temp);
        }
        else if(est_dans_dossier)//nouvelle marque page dans dossier
        {
            if(i>=0 && i<list_marques->count())
            {
                temp.titre = list_marques->value(i).titre;
                temp.urls.unite(list_marques->value(i).urls);
                temp.urls.insertMulti(t, QVariant(l));
                list_marques->replace(i, temp);
            }
            else
            {
                cout<<"Erreur d'insertion de page "<<i<<"[MarquesPages.cpp] [void ajouter(int, QString, QString)] [l.116]"<<endl;
            }
        }
        else//nouvelle marque page hors dossier mais avec une position
        {
            if(i>=0 && i<=list_marques->count())
            {
                temp.titre = t;
                temp.urls[t] = l;//le titre est pareil car le marque page sera son propre dossier
                list_marques->insert(i, temp);
//                cout<<"ajout dans la liste �  la position"<<i<<" : [MarquesPages.cpp] [void ajouter(int, QString, QString)] [l.126]"<<endl;
            }
            else
            {
                cout<<"Erreur d'insertion de page "<<i<<" au lieu de 0 jusqu'�  "<<list_marques->count()<<" : [MarquesPages.cpp] [void ajouter(int, QString, QString)] [l.130]"<<endl;
            }
        }
    }
    else//c'est un dossier
    {
        temp.titre = t;
        if(i == 0)
        {
            list_marques->prepend(temp);
        }
        else if(i == -1)
        {
            list_marques->append(temp);
        }
        else
        {
            list_marques->insert(i, temp);
        }
    }
    enregistrer();
    mettreAJour();
}

void MarquesPages::mettreAJour()
{
    for(int i=0; i<list_marques->count(); i++)
    {
        MarquePage * p = new MarquePage(list_marques->value(i).titre, this, i);
        if(list_marques->value(i).urls.keys().contains(list_marques->value(i).titre))//si c'est un marque page
        {
            p->setAccessibleDescription(list_marques->value(i).urls[list_marques->value(i).titre].toString());
            if(!QWebSettings::iconForUrl(QUrl(p->accessibleDescription())).isNull())
            {
                p->setIcon(QWebSettings::iconForUrl(QUrl(p->accessibleDescription())));
            }
            else
            {
                p->setIcon(QIcon(":/temp/images/page_bookmark.gif"));
            }
        }
        else//sinon c'est un dossier de marques pages
        {
            MarquePageMenu * menu = new MarquePageMenu(p);
            p->setIcon(QIcon(":/temp/images/folder.gif"));
            for(int m=0; m<list_marques->value(i).urls.keys().count(); m++)
            {
//                cout<<list_marques->value(i).urls.keys().value(m)<<endl;
                QAction * action = menu->addAction(list_marques->value(i).urls.keys().value(m));
                action->setData(list_marques->value(i).urls.value(list_marques->value(i).urls.keys().value(m)));
                action->setIcon(QWebSettings::iconForUrl(action->data().toUrl()));
            }
            connect(menu, SIGNAL(triggered(QAction*)), this, SLOT(charger(QAction*)));
            p->setMenu(menu);
        }
        if(i<list_marques_boutons->count())//si il y a de quoi le placer
        {
            layout()->removeWidget(list_marques_boutons->value(i));
            list_marques_boutons->value(i)->hide();
            list_marques_boutons->value(i)->close();
            list_marques_boutons->replace(i, p);
            addWidget(p);
        }
        else//sinon on l'ajoute
        {
            addWidget(p);
            list_marques_boutons->append(p);
        }
    }
    if(parent->getMenuBar())
    {
        parent->getMenuBar()->mettreAJourMarquesPages();
    }
}

void MarquesPages::charger(QAction * action)
{
    if(false)//pour charger click milieu il fo r�implanter le QMenu du button ki � le p�re de l'action
    {
        parent->chargerPage(QUrl(action->data().toString()), 1);
    }
    else
    {
        parent->chargerPage(QUrl(action->data().toString()), 0);
    }
}

void MarquesPages::charger(QUrl u, int mode)
{
    parent->chargerPage(u, mode);
}

void MarquesPages::dragEnterEvent(QDragEnterEvent * event)
{
    if(event->mimeData()->hasFormat("text/html"))
    {
        insererWidgetFleche(event->pos());
        event->accept();
    }
    else
    {
        event->ignore();
    }
//    cout<<"Drag enter event : [MarquesPages.cpp][void dragEnterEvent(QDragMoveEvent)][l.220]"<<endl;
}

void MarquesPages::dragMoveEvent(QDragMoveEvent * event)
{
    if (event->mimeData()->hasFormat("text/html"))
    {
        MarquePage * mp = static_cast<MarquePage*>(childAt(event->pos()));
        if(mp)
        {
            if(!mp->accessibleDescription().isEmpty())
            {
                event->ignore();
            }
        }
        else
        {
            event->accept();
        }
    }
    else
    {
        event->ignore();
    }
//    cout<<"Drag move event : [MarquesPages.cpp][void dragMoveEvent(QDragMoveEvent)][l.259]"<<endl;
}

void MarquesPages::dropEvent(QDropEvent * event)
{
    if (event->mimeData()->hasFormat("text/html"))
    {
        QByteArray itemData = event->mimeData()->data("text/html");
        QDataStream dataStream(&itemData, QIODevice::ReadOnly);

        QString titre;
        QString url;
        int mp_place_dans_liste;
        dataStream >> titre >> url >> mp_place_dans_liste/*place de l'ancien bouton ou du nouvo si <0*/;

        if(mp_place_dans_liste > 0)
        {
            supprimerMarquePage(mp_place_dans_liste);
        }
        ajouter(-1, titre, url, false);
        supprimerFleche();//si il y a des fl�ches on les enl�ves sinon ne fait rien

        event->setDropAction(Qt::CopyAction);
        event->accept();
    }
    else
    {
        event->ignore();
    }
}

void MarquesPages::insererWidgetFleche(QPoint pos)
{
    MarquePageFleches * mpf = static_cast<MarquePageFleches*>(childAt(pos));
    if(!mpf)
    {
        QPoint cherche = pos;
        bool trouve = false;
        int place_dans_liste = 0;

        if(this->orientation() == Qt::Horizontal)//si la ToolBar est horizontale
        {
            while(!trouve && cherche.x()>=0 && cherche.x()<this->size().width())
            {
                if(cherche.y()>=this->y()-this->size().height())
                {
                    cherche.setY(cherche.y()-10);
                }
                MarquePage * mp = static_cast<MarquePage*>(childAt(cherche));
                if(mp)
                {
                    place_dans_liste = mp->getPlaceDansListe();
                    trouve = true;
                }
                else
                {
                    cherche = QPoint(cherche.x() + 1, cherche.y());
                }
            }
        }
        else//si la ToolBar est verticale
        {
            while(!trouve && cherche.y()>=0 && cherche.y()<this->size().height())
            {
                if(cherche.x()>=this->x()-this->size().width())
                {
                    cherche.setX(cherche.x()-10);
                }
                MarquePage * mp = static_cast<MarquePage*>(childAt(cherche));
                if(mp)
                {
                    place_dans_liste = mp->getPlaceDansListe();
                    trouve = true;
                }
                else
                {
                    cherche = QPoint(cherche.x(), cherche.y() + 1);
                }
            }
        }
        QWidget * w = new MarquePageFleches(this, place_dans_liste);

        if(trouve)//il y a un boutton en dessous de la position
        {
            QAction * before = static_cast<QAction*>(actionAt(cherche));
            if(before)
            {
                supprimerFleche();
                action_fleche = new QAction(this->insertWidget(before, w));
                widget_fleche = w;
                widget_fleche->setAttribute(Qt::WA_DeleteOnClose);
                action_fleche->setData(QVariant("action_fleche"));
            }
            else
            {
                cout<<"Erreur QAction : [MarquesPages.cpp][void insererWidgetFleche(QPoint)][l.352]"<<endl;
            }
        }
        else//il est en dessous de tout
        {
            supprimerFleche();
            action_fleche = new QAction(this->addWidget(w));
            widget_fleche = w;
            widget_fleche->setAttribute(Qt::WA_DeleteOnClose);
            action_fleche->setData(QVariant("action_fleche"));
        }
    }
}

void MarquesPages::supprimerFleche()
{
    if(action_fleche->data().toString() == "action_fleche")
    {
        this->removeAction(action_fleche);
        widget_fleche->close();
    }
    action_fleche->setData(QVariant(""));
}

WebBrowser* MarquesPages::getParent()
{
    return parent;
}

void MarquesPages::supprimerMarquePage(int i)
{
    this->layout()->removeWidget(list_marques_boutons->value(i));
    list_marques_boutons->removeAt(i);
    list_marques->removeAt(i);
    enregistrer();
}

void MarquesPages::supprimerAction(int pere, QString title)
{
    struct_marque_page temp;
    temp.titre = list_marques->value(pere).titre;
    temp.urls.unite(list_marques->value(pere).urls);
    temp.urls.remove(title);
    list_marques->replace(pere, temp);
    enregistrer();
    mettreAJour();
}

void MarquesPages::supprimerAction(int pere, int place)
{
    struct_marque_page temp;
    temp.titre = list_marques->value(pere).titre;
    temp.urls.unite(list_marques->value(pere).urls);
    temp.urls.remove(temp.urls.keys().value(place));
    list_marques->replace(pere, temp);
    enregistrer();
    mettreAJour();
}

int MarquesPages::getNbMarques()
{
    return list_marques->count();
}

bool MarquesPages::contient(QString url)
{
    for(int i=0; i<list_marques->count(); i++)
    {
        for(int u=0; u<list_marques->value(i).urls.keys().count(); u++)
        {
            if(url == list_marques->value(i).urls.value(list_marques->value(i).urls.keys().value(u)).toString())
            {
                cout<<list_marques->value(i).urls.value(list_marques->value(i).urls.keys().value(u)).toString().toStdString()<<endl;
                return true;
            }
        }
    }
    return false;
}

void MarquesPages::toutSupprimer()
{
    QSettings settings("MYW", "WebBrowser");

    settings.beginGroup("Marques-Pages");
    settings.remove("");
    settings.endGroup();
    settings.sync();

    int total = list_marques_boutons->count();
    for(int i=0; i<total; i++)
    {
        this->layout()->removeWidget(list_marques_boutons->value(0));
        list_marques_boutons->removeAt(0);
        list_marques->removeAt(0);
    }

    mettreAJour();
}

void MarquesPages::defaut()
{
    if(list_marques->count() > 0)
    {
        toutSupprimer();
    }

    ajouter(-1, "Projet");
    ajouter(0, "projet", "http://projet.lydiman.net", true);
    ajouter(-1, "Programmation");
    ajouter(1, "SDZ", "http://www.siteduzero.com", true);
    ajouter(1, "CS", "http://www.codes-sources.com", true);
    ajouter(-1, "Manuels");
    ajouter(2, "php", "http://www.manuelphp.com", true);
    ajouter(2, "java", "https://developer.mozilla.org", true);
    ajouter(-1, "Recherches");
    ajouter(3, "Google", "http://google.fr", true);
    ajouter(3, "Exalead", "http://exalead.fr", true);
    ajouter(3, "Wikip�dia", "http://wikipedia.fr", true);
    ajouter(1, "?:UM1", "?:UM1", false);
    ajouter(3, "?:UM2", "?:UM2", false);
    ajouter(-1, "?:UM3", "?:UM3", false);
}

QList<struct struct_marque_page>* MarquesPages::getListMarquesPages()
{
    return list_marques;
}

void MarquesPages::ajouterDossier()
{
    widgetAjouterDossier = new QWidget(0/*, Qt::FramelessWindowHint*/);
    QVBoxLayout * layout = new QVBoxLayout(widgetAjouterDossier);
    widgetAjouterDossier->setWindowIcon(QIcon(":/temp/images/folder.gif"));
    widgetAjouterDossier->setWindowTitle(tr("Ajouter un dossier..."));
    QLabel * l = new QLabel(tr("Entrez le titre puis l'emplacement de votre nouveau dossier."));
    layout->addWidget(l);
    QHBoxLayout * ssl = new QHBoxLayout();
    l = new QLabel(tr("Nom : "));
    ssl->addWidget(l);
    edit = new QLineEdit();
    ssl->addWidget(edit);
    layout->addLayout(ssl);
    ssl = new QHBoxLayout();
    l = new QLabel(tr("Position : "));
    ssl->addWidget(l);
    cb = new QComboBox();

    for(int i=0; i<list_marques->count(); i++)
    {
        if(!list_marques->value(i).urls.keys().contains(list_marques->value(i).titre))//si c'est un dossier (non marque-page)
        {
            cb->insertItem(i, QIcon(":/WebBrowser/retablir.png"), list_marques->value(i).titre.prepend(tr("Avant ")), QVariant(list_marques->value(i).titre));
        }
        if(i+1 == list_marques->count())
        {
            cb->insertItem(i, QIcon(":/WebBrowser/retablir.png"), tr("En dernier"), QVariant(list_marques->value(i).titre));
        }
    }
    ssl->addWidget(cb, 500);
    layout->addLayout(ssl);
    ssl = new QHBoxLayout();
    QPushButton * bouton = new QPushButton(QIcon(":/WebBrowser/quitter.png"), "Annuler");
    bouton->setMaximumWidth(100);
    ssl->addWidget(bouton, 0);
    connect(bouton, SIGNAL(clicked()), widgetAjouterDossier, SLOT(close()));
    bouton = new QPushButton(QIcon(":/WebBrowser/valider.png"), "Ok");
    bouton->setMaximumWidth(100);
    ssl->addWidget(bouton, 0);
    connect(bouton, SIGNAL(clicked()), this, SLOT(ajouterDossierOk()));
    layout->addLayout(ssl);
    widgetAjouterDossier->show();
}

void MarquesPages::ajouterDossierOk()
{
    if(!edit->text().isEmpty())
    {
        for(int i=0; i<cb->count(); i++)
        {
            if(cb->itemData(cb->currentIndex()) == list_marques->value(i).titre)
            {
                ajouter(i, edit->text());
                break;
            }
            else if(cb->currentText() == tr("En dernier"))
            {
                ajouter(-1, edit->text());
                break;
            }
        }
    }
    widgetAjouterDossier->setAttribute(Qt::WA_DeleteOnClose);
    widgetAjouterDossier->close();
}

void MarquesPages::suppression()
{
    mp_a_supprimer.clear();

    widgetSuppression = new QWidget();
    QVBoxLayout * layout = new QVBoxLayout(widgetSuppression);
    widgetSuppression->setWindowIcon(QIcon(parent->windowIcon()));
    widgetSuppression->setWindowTitle(tr("Suppression..."));
    QLabel * l = new QLabel(tr("Cochez le(s) marque(s)-page(s) ou dosier(s) de marques-pages �  supprimer."));
    layout->addWidget(l);
    //QTREEVIEW---------------------------------------------
    mes_marques_pages = new QTreeWidget(widgetSuppression);
    mes_marques_pages->setAnimated(true);
//    mes_marques_pages->setFirstColumnSpanned(0, mes_marques_pages->model()->index(0, 0), true);
    for(int i=0; i<list_marques->count(); i++)
    {
        if(list_marques->value(i).urls.keys().contains(list_marques->value(i).titre))//si c'est un marque-page
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(mes_marques_pages);
            item->setText(0, list_marques->value(i).titre);
            item->setData(0, Qt::UserRole, QVariant(i));
            item->setIcon(0, QWebSettings::iconForUrl(list_marques->value(i).urls.value(0).toString()));
            item->setCheckState(0, Qt::Unchecked);
        }
        else//si c'est un dossier
        {
            QTreeWidgetItem * item = new QTreeWidgetItem(mes_marques_pages);
            item->setText(0, list_marques->value(i).titre);
            item->setData(0, Qt::UserRole, QVariant(i));
            item->setIcon(0, QIcon(":/temp/images/folder.gif"));
            item->setCheckState(0, Qt::Unchecked);
            for(int m=0; m<list_marques->value(i).urls.keys().count(); m++)
            {
                QTreeWidgetItem * ss_item = new QTreeWidgetItem(item);
                ss_item->setText(0, list_marques->value(i).urls.keys().value(m));
                ss_item->setData(0, Qt::UserRole, QVariant(-1));
                ss_item->setIcon(0, QWebSettings::iconForUrl(list_marques->value(i).urls.value(list_marques->value(i).urls.keys().value(m)).toString()));
                ss_item->setCheckState(0, Qt::Unchecked);

                ss_item->setText(1, list_marques->value(i).urls.keys().value(m));
            }
        }
    }
    connect(mes_marques_pages, SIGNAL(itemChanged(QTreeWidgetItem*,int)), this, SLOT(selectionItem(QTreeWidgetItem*,int)));
    layout->addWidget(mes_marques_pages);
    //QTREEVIEW---------------------------------------------
    QHBoxLayout * ssl = new QHBoxLayout();
    QPushButton * bouton = new QPushButton(QIcon(":/WebBrowser/quitter.png"), "Annuler");
    bouton->setMaximumWidth(100);
    ssl->addWidget(bouton, 0);
    connect(bouton, SIGNAL(clicked()), widgetSuppression, SLOT(close()));
    bouton = new QPushButton(QIcon(":/WebBrowser/valider.png"), "Ok");
    bouton->setMaximumWidth(100);
    ssl->addWidget(bouton, 0);
    connect(bouton, SIGNAL(clicked()), this, SLOT(suppressionOk()));
    layout->addLayout(ssl);
    widgetSuppression->show();
}

void MarquesPages::selectionItem(QTreeWidgetItem * item, int colonne)
{
    if(item->childCount()!=0)//si c'est un dossier
    {
        for(int i=0; i<item->childCount(); i++)
        {
            item->child(i)->setCheckState(0, Qt::Checked);
        }
    }
    else
    {
        QTreeWidgetItem * pere_item = dynamic_cast<QTreeWidgetItem*>(item->parent());
        if(pere_item)//si c'est un mp dans dossier
        {
            if(pere_item->checkState(0) == Qt::Checked)
            {
                item->setCheckState(0, Qt::Checked);
            }
        }
    }
    if(item->checkState(0) == Qt::Checked)
    {
        mp_a_supprimer.insert(item->data(0, Qt::UserRole).toInt(), item);
    }
    else
    {
        mp_a_supprimer.removeOne(item);
    }
}

void MarquesPages::suppressionOk()
{
    for(int i=0; i<mp_a_supprimer.count(); i++)
    {
        mp_a_supprimer.insert(mp_a_supprimer.count() - i, mp_a_supprimer.takeFirst());
    }
    for(int i=0; i<mp_a_supprimer.count(); i++)
    {
        if(mp_a_supprimer.value(i)->data(0, Qt::UserRole).toInt() != -1)//c'est un mp de premier niveau (pas contenue dans un dossier)
        {
            supprimerMarquePage(mp_a_supprimer.value(i)->data(0, Qt::UserRole).toInt());
        }
        else//c'est un mp dans un dossier
        {
            supprimerAction(mp_a_supprimer.value(i)->parent()->data(0, Qt::UserRole).toInt(), mp_a_supprimer.value(i)->text(0));
        }
    }
    widgetSuppression->setAttribute(Qt::WA_DeleteOnClose);
    widgetSuppression->close();
}
