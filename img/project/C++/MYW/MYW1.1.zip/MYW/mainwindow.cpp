#include "mainwindow.h"
#include "validation.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    validation = new Validation(this);
    this->hide();
    setWindowIcon(QIcon(":/Menu/webBrowser.png"));

    // Principal
    menu_bar = new QMenuBar();
    tool_bar = new QToolBar();
    status_bar = new QStatusBar();
    central_widget = new QWidget();

    //central_widget->setStyleSheet("background-image: url(':/Autres/fond3');");
    //central_widget->setStyleSheet("background: lightgrey;");
    central_widget_haut = new QWidget(this);
    rechercher_remplacer = new FindDialog(this); //PLUS
    w = new WebBrowser();

    QVBoxLayout *l1 = new QVBoxLayout(central_widget);
    //l1->setMargin(0);
    l1->setSpacing(0);
    l1->addWidget(central_widget_haut);
    l1->addWidget(rechercher_remplacer);

    tab_widget = new QTabWidget(central_widget_haut);
    interieur_onglet = new WidgetDansOnglet(tab_widget);

    gestionMenu();
    gestionBarreOutils();
    gestionMenuBarre();
    gestionMenuActions();
    gestionMenuItems();
    gestionBarreOutilsItems();
    gestionOnglets();


    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    this->setMenuBar(menu_bar);
    this->setStatusBar(status_bar);
    this->setCentralWidget(central_widget);
    this->setWindowTitle(tr("MYW"));
    this->setGeometry(100, 100, mainWindow_WIDTH, mainWindow_HEIGHT);

    restaurer();
    if(workspace.isEmpty())
    {
        dock_projet = 0;
        widgetChoisirWorkspace();
    }
    else
    {
        dock_projet = 0;
        constructeurApresWorkspace();
    }
}

void MainWindow::constructeurApresWorkspace()
{
    restaurer();
    this->show();
    gestionDocks();
    ftp = new FTPBrowser(QDir(workspace));
    mes_preferences = new Preferences(this);
    //validation = new Validation(this);
    outilsValidateurOnOff(false);//peut pas valider si le fichier n'est pas enregistr� ou html ou css
}

MainWindow::~MainWindow()
{
}

/***************************** ASSESSEURS *********************************/
    // ACCESSEURS
    QWidget* MainWindow::getCentralWidget() { return central_widget; }
    QMenuBar* MainWindow::getMenuBar() { return menu_bar; }
    QToolBar* MainWindow::getToolBar() { return tool_bar; }
    QStatusBar* MainWindow::getStatusBar() { return status_bar; }
    Preferences* MainWindow::getMesPreferences() { return mes_preferences; }
    FindDialog* MainWindow::getRechercherRemplacer() { return rechercher_remplacer; }
    WebBrowser* MainWindow::getWebBrowser() { return w; }
    FTPBrowser* MainWindow::getFtpBrowser() { return ftp; }

    // Menu
    QMenu* MainWindow::getMenuFichier() { return menu_fichier; }
    QMenu* MainWindow::getMenuEdition() { return menu_edition; }
    QMenu* MainWindow::getMenuAffichage() { return menu_affichage; }
    QMenu* MainWindow::getMenuAide() { return menu_aide; }
    QMenu* MainWindow::getSousMenuOutil() { return sous_menu_outil; }

    // Actions Menu
    //-> Fichier
    QAction* MainWindow::getActionMenuNouveau() { return action_menu_nouveau; }
    QAction* MainWindow::getActionMenuOuvrir() { return action_menu_ouvrir; }
    QAction* MainWindow::getActionMenuEnregistrer() { return action_menu_enregistrer; }
    QAction* MainWindow::getActionMenuEnregistrerSous() { return action_menu_enregistrer_sous; }
    QAction* MainWindow::getActionMenuEnregistrerTout() { return action_menu_enregistrer_tout; }
    QAction* MainWindow::getActionMenuImprimer() { return action_menu_imprimer; }
    QAction* MainWindow::getActionMenuWebBrowser() { return action_menu_web_browser; }
    QAction* MainWindow::getActionMenuQuitter() { return action_menu_quitter; }
    //-> Edition
    QAction* MainWindow::getActionMenuAnnuler() { return action_menu_annuler; }
    QAction* MainWindow::getActionMenuRetablir() { return action_menu_retablir; }
    QAction* MainWindow::getActionMenuCouper() { return action_menu_couper; }
    QAction* MainWindow::getActionMenuCopier() { return action_menu_copier; }
    QAction* MainWindow::getActionMenuColler() { return action_menu_coller; }
    QAction* MainWindow::getActionMenuSelectTout() { return action_menu_select_tout; }
    QAction* MainWindow::getActionMenuZoomPlus() { return action_menu_zoom_plus; }
    QAction* MainWindow::getActionMenuZoomMoins() { return action_menu_zoom_moins; }
    QAction* MainWindow::getActionMenuPreferences() { return action_menu_preferences; }
    QAction* MainWindow::getActionMenuRechercherRemplacer() { return action_menu_rechercher_remplacer; }
	
    //-> Affichage
    QAction* MainWindow::getActionMenuAfficherCacherNumLigne() { return action_menu_afficher_cacher_num_ligne; }
    QAction* MainWindow::getActionMenuPleinEcran() { return action_menu_plein_ecran; }
        //SousMenuOutil
        QAction* MainWindow::getActionMenuOutilFichier() { return action_menu_outil_fichier; }
        QAction* MainWindow::getActionMenuOutilEdition() { return action_menu_outil_edition; }
                QAction* MainWindow::getActionMenuOutilProjet() { return action_menu_outil_projet; }

    // Outils
    QToolBar* MainWindow::getToolFichier() { return tool_fichier; }
    QToolBar* MainWindow::getToolEdition() { return tool_edition; }
    QToolBar* MainWindow::getToolAffichage() { return tool_affichage; }
    QToolBar* MainWindow::getToolAide() { return tool_aide; }

    // Dans central_widget
    QTabWidget* MainWindow::getTabWidget(int i) { if(i!=-1) return &(tab_widget[i]); else return tab_widget; }
    WidgetDansOnglet* MainWindow::getInterieurOnglet() { return interieur_onglet; } // contient qwidget(contient QLabel et QLabel) et QTextEdit

    // Docks
    QDockWidget* MainWindow::getDock_projet() { return dock_projet; }
    Hierarchie* MainWindow::getHierarchie() { return hierarchie; }

        // Dans status_bar
    QLabel* MainWindow::getLabel_nb_lignes() { return label_nb_lignes; }
    QLabel* MainWindow::getLabel_nb_caracteres() { return label_nb_caracteres; }

    /**************************************** FIN ACCESSEURS ******************************************/

void MainWindow::gestionMenuBarre() {
    menu_bar->addMenu(menu_fichier);
    menu_bar->addMenu(menu_edition);
    menu_bar->addMenu(menu_affichage);
    menu_bar->addMenu(menu_outils);
    menu_bar->addMenu(menu_aide);
    menu_bar->show();
    setMenuBar(menu_bar);
}

void MainWindow::gestionMenu() {
    menu_fichier = new QMenu(tr("Fichier"));
    menu_edition = new QMenu(tr("Edition"));
    menu_affichage = new QMenu(tr("Affichage"));
    menu_outils = new QMenu(tr("Outils"));
    menu_aide = new QMenu(tr("Aide"));
    sous_menu_outil = new QMenu(tr("Barre d'outils"));
}

void MainWindow::gestionBarreOutils() {
    tool_fichier = new QToolBar(tr("Fichier"));
    tool_edition = new QToolBar(tr("Edition"));
    tool_affichage = new QToolBar(tr("Affichage"));
    tool_aide = new QToolBar(tr("Aide"));
    this->addToolBar(tool_fichier);
    this->addToolBar(tool_edition);
}

void MainWindow::gestionMenuActions() {
    // FICHIER
    action_menu_nouveau = new QAction(QIcon(":/Menu/nouveau.png"), tr("Nouveau"), menu_fichier);
    action_menu_nouveau->setShortcut(QKeySequence("Ctrl+N"));
    QObject::connect(action_menu_nouveau, SIGNAL(triggered()), this, SLOT(fichierNouveau()));

    action_menu_nouveau_projet = new QAction(QIcon(":/Menu/nouveau.png"), tr("Nouveau Projet"), menu_fichier);
    QObject::connect(action_menu_nouveau_projet, SIGNAL(triggered()), this, SLOT(fichierNouveauProjet()));

    action_menu_ouvrir = new QAction(QIcon(":/Menu/ouvrir.png"), tr("Ouvrir..."), menu_fichier);
    action_menu_ouvrir->setShortcut(QKeySequence("Ctrl+O"));
    QObject::connect(action_menu_ouvrir, SIGNAL(triggered()), this, SLOT(fichierOuvrir()));

    action_menu_enregistrer = new QAction(QIcon(":/Menu/enregistrer.png"), tr("Enregistrer"), menu_fichier);
    action_menu_enregistrer->setShortcut(QKeySequence("Ctrl+S"));
    QObject::connect(action_menu_enregistrer, SIGNAL(triggered()), this, SLOT(fichierEnregistrer()));

    action_menu_enregistrer_sous = new QAction(QIcon(":/Menu/enregistrer_sous.png"), tr("Enregistrer Sous..."), menu_fichier);
    QObject::connect(action_menu_enregistrer_sous, SIGNAL(triggered()), this, SLOT(fichierEnregistrerSous()));

    action_menu_enregistrer_tout = new QAction(QIcon(":/Menu/enregistrer_tout.png"), tr("Enregistrer Tout"), menu_fichier);
    action_menu_enregistrer_tout->setShortcut(QKeySequence("Ctrl+Shift+S"));
    QObject::connect(action_menu_enregistrer_tout, SIGNAL(triggered()), this, SLOT(fichierEnregistrerTout()));

    action_menu_imprimer = new QAction(QIcon(":/Menu/imprimer"), tr("Imprimer..."), menu_fichier);
    action_menu_imprimer->setShortcut(QKeySequence("Ctrl+P"));
    QObject::connect(action_menu_imprimer, SIGNAL(triggered()), this, SLOT(fichierImprimer()));

    action_menu_quitter = new QAction(QIcon(":/Menu/quitter.png"), tr("Quitter"), menu_fichier);
    action_menu_quitter->setShortcut(QKeySequence("Ctrl+Q"));
    QObject::connect(action_menu_quitter, SIGNAL(triggered()), this, SLOT(close()));

    // EDITION
    action_menu_annuler = new QAction(QIcon(":/Menu/annuler.png"), tr("Annuler"), menu_edition);
    action_menu_annuler->setShortcut(QKeySequence("Ctrl+Z"));
    QObject::connect(action_menu_annuler, SIGNAL(triggered()), this, SLOT(editionAnnuler()));

    action_menu_retablir = new QAction(QIcon(":/Menu/retablir.png"), tr("Retablir"), menu_edition);
    action_menu_retablir->setShortcut(QKeySequence("Ctrl+Y"));
    QObject::connect(action_menu_retablir, SIGNAL(triggered()), this, SLOT(editionRetablir()));

    action_menu_couper = new QAction(QIcon(":/Menu/couper.png"), tr("Couper"), menu_edition);
    action_menu_couper->setShortcut(QKeySequence("Ctrl+X"));
    QObject::connect(action_menu_couper, SIGNAL(triggered()), this, SLOT(editionCouper()));

    action_menu_copier = new QAction(QIcon(":/Menu/copier.png"), tr("Copier"), menu_edition);
    action_menu_copier->setShortcut(QKeySequence("Ctrl+C"));
    QObject::connect(action_menu_copier, SIGNAL(triggered()), this, SLOT(editionCopier()));

    action_menu_coller = new QAction(QIcon(":/Menu/coller.png"), tr("Coller"), menu_edition);
    action_menu_coller->setShortcut(QKeySequence("Ctrl+V"));
    QObject::connect(action_menu_coller, SIGNAL(triggered()), this, SLOT(editionColler()));

    action_menu_select_tout = new QAction(tr("Selectionner Tout"), menu_edition);
    action_menu_select_tout->setShortcut(QKeySequence("Ctrl+A"));
    QObject::connect(action_menu_select_tout, SIGNAL(triggered()), this, SLOT(editionSelectTout()));

    action_menu_zoom_plus = new QAction(QIcon(":/Menu/zoom_plus.png"), tr("Zoom plus"), menu_edition);
    QObject::connect(action_menu_zoom_plus, SIGNAL(triggered()), this, SLOT(editionZoomPlus()));

    action_menu_zoom_moins = new QAction(QIcon(":/Menu/zoom_moins.png"), tr("Zoom Moins"), menu_edition);
    QObject::connect(action_menu_zoom_moins, SIGNAL(triggered()), this, SLOT(editionZoomMoins()));
	
    action_menu_rechercher_remplacer = new QAction(QIcon(":/Menu/rechercher.png"), tr("Rechercher/Remplacer"), menu_edition);
    action_menu_rechercher_remplacer->setShortcut(QKeySequence("Ctrl+F"));
    QObject::connect(action_menu_rechercher_remplacer, SIGNAL(triggered()), this, SLOT(editionRechercherRemplacer()));

    // Affichage
    action_menu_afficher_cacher_num_ligne = new QAction(tr("Numero de Ligne"), menu_affichage);
    action_menu_afficher_cacher_num_ligne->setCheckable(true);
    action_menu_afficher_cacher_num_ligne->setChecked(true);
    action_menu_afficher_cacher_num_ligne->setShortcut(QKeySequence("F5"));
    QObject::connect(action_menu_afficher_cacher_num_ligne, SIGNAL(triggered()), this, SLOT(affichageNumLigne()));

    action_menu_plein_ecran = new QAction(tr("Plein Ecran"), menu_affichage);
    action_menu_plein_ecran->setShortcut(QKeySequence("F11"));
    action_menu_plein_ecran->setCheckable(true);
    action_menu_plein_ecran->setChecked(false);
    QObject::connect(action_menu_plein_ecran, SIGNAL(triggered()), this, SLOT(affichagePleinEcran()));

    action_menu_outil_fichier = new QAction(tr("Nouveau, enregistrer..."), sous_menu_outil);
    action_menu_outil_fichier->setCheckable(true);
    action_menu_outil_fichier->setChecked(true);
    QObject::connect(action_menu_outil_fichier, SIGNAL(triggered()), this, SLOT(affichageOutilFichier()));

    action_menu_outil_edition = new QAction(tr("Couper, copier..."), sous_menu_outil);
    action_menu_outil_edition->setCheckable(true);
    action_menu_outil_edition->setChecked(true);
    QObject::connect(action_menu_outil_edition, SIGNAL(triggered()), this, SLOT(affichageOutilEdition()));

    action_menu_preferences = new QAction(QIcon(":/Menu/preferences.png"), tr("Pr�f�rences..."), menu_edition);
    QObject::connect(action_menu_preferences, SIGNAL(triggered()), this, SLOT(editionPreferences()));

    action_menu_outil_projet = new QAction(tr("Projet"), sous_menu_outil);
    action_menu_outil_projet->setCheckable(true);
    action_menu_outil_projet->setChecked(true);
    QObject::connect(action_menu_outil_projet, SIGNAL(triggered()), this, SLOT(affichageOutilProjet()));

    // Outils
    action_menu_web_browser = new QAction(QIcon(":/Menu/webBrowser.png"), tr("Web Browser..."), menu_outils);
    QObject::connect(action_menu_web_browser, SIGNAL(triggered()), this, SLOT(outilsOuvrirWebBrowser()));

    action_menu_ftp_browser = new QAction(QIcon(":/Menu/webBrowser.png"), tr("FTP Browser..."), menu_outils);
    QObject::connect(action_menu_ftp_browser, SIGNAL(triggered()), this, SLOT(outilsOuvrirFtpBrowser()));

    action_menu_validateur = new QAction(QIcon(":/Menu/valider.png"), tr("Valider la page courante..."), menu_outils);
    QObject::connect(action_menu_validateur, SIGNAL(triggered()), this, SLOT(outilsValidateur()));

    // Aide
    action_menu_aide = new QAction(QIcon(""), tr("A propos"), menu_aide);
    QObject::connect(action_menu_aide, SIGNAL(triggered()), this, SLOT(apropos()));
}

void MainWindow::gestionMenuItems() {
    // FICHIER
    menu_fichier->addAction(action_menu_nouveau);
    menu_fichier->addAction(action_menu_nouveau_projet);
    menu_fichier->addAction(action_menu_ouvrir);
    menu_fichier->addSeparator();
    menu_fichier->addAction(action_menu_enregistrer);
    menu_fichier->addAction(action_menu_enregistrer_sous);
    menu_fichier->addAction(action_menu_enregistrer_tout);
    menu_fichier->addSeparator();
    menu_fichier->addAction(action_menu_imprimer);
    menu_fichier->addSeparator();
    menu_fichier->addAction(action_menu_quitter);

    // EDITION
    menu_edition->addAction(action_menu_annuler);
    menu_edition->addAction(action_menu_retablir);
    menu_edition->addSeparator();
    menu_edition->addAction(action_menu_couper);
    menu_edition->addAction(action_menu_copier);
    menu_edition->addAction(action_menu_coller);
    menu_edition->addAction(action_menu_select_tout);
    menu_edition->addSeparator();
    menu_edition->addAction(action_menu_zoom_plus);
    menu_edition->addAction(action_menu_zoom_moins);
    menu_edition->addAction(action_menu_rechercher_remplacer);
    menu_edition->addSeparator();
    menu_edition->addAction(action_menu_preferences);

    // AFFICHAGE
    menu_affichage->addAction(action_menu_afficher_cacher_num_ligne);
    menu_affichage->addAction(action_menu_plein_ecran);
    menu_affichage->addSeparator();
    sous_menu_outil->addAction(action_menu_outil_fichier);
    sous_menu_outil->addAction(action_menu_outil_edition);
    sous_menu_outil->addAction(action_menu_outil_projet);
    menu_affichage->addMenu(sous_menu_outil);

    // OUTILS
    menu_outils->addAction(action_menu_web_browser);
    menu_outils->addAction(action_menu_ftp_browser);
    menu_outils->addAction(action_menu_validateur);

    // AIDES
    menu_aide->addAction(action_menu_aide);
}

void MainWindow::gestionBarreOutilsItems() {
    // FICHIER
    tool_fichier->addAction(action_menu_nouveau);
    tool_fichier->addAction(action_menu_ouvrir);
    tool_fichier->addSeparator();
    tool_fichier->addAction(action_menu_enregistrer);
    tool_fichier->addAction(action_menu_enregistrer_sous);
    tool_fichier->addAction(action_menu_enregistrer_tout);
    tool_fichier->addSeparator();
    tool_fichier->addAction(action_menu_imprimer);

    // EDITION
    tool_edition->addAction(action_menu_annuler);
    tool_edition->addAction(action_menu_retablir);
    tool_edition->addSeparator();
    tool_edition->addAction(action_menu_couper);
    tool_edition->addAction(action_menu_copier);
    tool_edition->addAction(action_menu_coller);
    tool_edition->addSeparator();
    tool_edition->addAction(action_menu_zoom_plus);
    tool_edition->addAction(action_menu_zoom_moins);
    tool_edition->addAction(action_menu_rechercher_remplacer);
	
}

void MainWindow::paintEvent(QPaintEvent * event) {
    /*QPainter painter(this);
    QLinearGradient gradient(0, 0, this->width(), this->height());
    gradient.setColorAt(0.0, Qt::white);
    gradient.setColorAt(0.3, Qt::red);
    gradient.setColorAt(1.0, Qt::yellow);
    painter.setPen(QColor(0, 153, 0, 255));
    painter.setBrush(gradient);
    painter.drawRect(0, 0, this->width(), this->height());
    painter.end();
    event->accept();*/
    //taille QTextEdit
    this->tab_widget->setGeometry(0,0,this->central_widget_haut->width(),this->central_widget_haut->height());
    //this->rechercher_remplacer->setGeometry(0,0,this->central_widget_haut->width(),50);
}

void MainWindow::gestionOnglets() {
    // QTabWidget ou QToolBox
    tab_widget->setTabsClosable(true);
    tab_widget->setMovable(true);
    int page_courante = tab_widget->addTab(interieur_onglet,tr("Nouveau*", "Nouveau fichier titre de l'onglet"));
    tab_widget->setCurrentIndex(page_courante);
	
    this->action_menu_select_tout->setEnabled(false);
    gestionBarreStatus();
	
    QObject::connect(tab_widget, SIGNAL(currentChanged(int)), this, SLOT(quandChangeOngletCourant(int)));
    QObject::connect(this->interieur_onglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifNomTab()));
    QObject::connect(this->interieur_onglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifNbLignes()));
    QObject::connect(this->interieur_onglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifBarreStatus()));
    QObject::connect(tab_widget, SIGNAL(tabCloseRequested(int)), this, SLOT(fermerTab(int)));
}

void MainWindow::gestionDocks() {
    if(!dock_projet)
    {
        dock_projet = new QDockWidget(tr("Mes Projets"), this);
        dock_projet->setAllowedAreas(Qt::LeftDockWidgetArea);
        dock_projet->setMinimumWidth(100);
        dock_projet->setGeometry(0, 0, 100, 200);
        addDockWidget(Qt::LeftDockWidgetArea, dock_projet);
    }

    hierarchie = new Hierarchie(workspace,this);
    dock_projet->setWidget(hierarchie);
}

// SLOTS
void MainWindow::fichierNouveau() {
    QWidget * w = new QWidget(this, Qt::Dialog);
    w->setWindowTitle(tr("Document"));
    w->setWindowIcon(QIcon(":/Menu/Nouveau.png"));
    QVBoxLayout * layout = new QVBoxLayout(w);

    QLabel * l = new QLabel(tr("Veuillez s�lectionner le type de documents :"));
    layout->addWidget(l);

    cb = new QComboBox(w);
    cb->addItem(QIcon(":/Menu/Nouveau.png"), tr("Autre"));
    cb->addItem(QIcon(":/Types/php.png"), tr("Php"));
    cb->addItem(QIcon(":/Types/html.png"), tr("Html"));

    layout->addWidget(cb);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    QPushButton * ok = new QPushButton(QIcon(":/Menu/valider"), tr("Valider"), w);
    ok->setMaximumWidth(80);
    ss_layout->addWidget(ok);
    QPushButton * annuler = new QPushButton(QIcon(":/Menu/quitter"), tr("Annuler"), w);
    annuler->setMaximumWidth(80);
    ss_layout->addWidget(annuler);

    layout->addLayout(ss_layout);

    connect(ok, SIGNAL(clicked()), this, SLOT(fichierNouveauOk()));
    connect(ok, SIGNAL(clicked()), w, SLOT(close()));
    connect(annuler, SIGNAL(clicked()), w, SLOT(close()));

    w->show();
}

void MainWindow::fichierNouveauOk() {
    WidgetDansOnglet * newInterieurOnglet = new WidgetDansOnglet(tab_widget);
    QRegExp rx("Nouveau\\*|Nouveau\\([0-9]*\\)\\*");

    // je parcours tous les onglets ouverts
    int nbOnglets = tab_widget->count(); // Compte le nb d'onglets
    int nbNew = 0; // compteur du nb de nouveau fichier
    for(int i=0; i<nbOnglets; i++) {
        if(rx.exactMatch(tab_widget->tabText(i))) {
            nbNew++;
        }
    }
    // si aucun porte le nom "New*" alors
    if(nbOnglets==0) {
        tab_widget->addTab(newInterieurOnglet,tr("Nouveau*"));
    }
    else {
        cout<<"dans le else"<<endl;
        QString str;
        str.setNum(nbNew);
        int page_courante = tab_widget->addTab(newInterieurOnglet,tr("Nouveau(", "")+str+tr(")*"));
        tab_widget->setCurrentIndex(page_courante);
// ----------------------------Modifier par Audrey------------------------------
        newInterieurOnglet->getTextEdit()->getColoration()->setJavascript(mes_preferences->getChoisirLangage()->estJavascriptSelectionne());
        newInterieurOnglet->getTextEdit()->getColoration()->setCss(mes_preferences->getChoisirLangage()->estCssSelectionne());
        newInterieurOnglet->getTextEdit()->getColoration()->setPhp(mes_preferences->getChoisirLangage()->estPhpSelectionne());
        newInterieurOnglet->getTextEdit()->getColoration()->setAutomatique(mes_preferences->getChoisirLangage()->estAutomatiqueSelectionne());
// ----------------------------Modifier par Audrey fin------------------------------
    }
    QObject::connect(tab_widget, SIGNAL(currentChanged(int)), this, SLOT(quandChangeOngletCourant(int)));
    QObject::connect(newInterieurOnglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifNomTab()));
    QObject::connect(newInterieurOnglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifNbLignes()));
    QObject::connect(newInterieurOnglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifBarreStatus()));

    setNouvellePage(cb->currentIndex());
    this->interieur_onglet->getTextEdit()->changeNombreCaractere();
    this->modifBarreStatus();
}

void MainWindow::setNouvellePage(int mode)
{
    Editeur* e = this->getInterieurOnglet()->getTextEdit();

    QString s;
    if(mode == 1)
    {
        s.append("<?php\n\n");
        s.append("?>\n\n");
    }
    if(mode == 2 || mode==1)
    {
        s.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n");
        s.append("<html>\n");
        s.append("\t<head>\n");
        s.append("\t\t<title>Nom du site</title>\n");
        s.append("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n");
        s.append("\t\t<meta name=\"description\" content=\""+tr("Description de la page")+"\">\n");
        s.append("\t\t<meta name=\"generator\" content=\"MyW\">\n");
        s.append("\t\t<meta name=\"author\" content=\""+tr("Auteur")+"\">\n");
        s.append("\t\t<meta name=\"Identifier-URL\" content=\""+tr("Lien_du_site")+"\">\n");
        s.append("\t\t<link rel=\"stylesheet\" type=\"text/css\" href=\""+tr("chemin_fichier")+".css\">\n");
        s.append("\t</head>\n");
        s.append("\t<body>\n\n");
        s.append("\t</body>\n");
        s.append("</html>\n");
    }
    if(mode == 1)
    {
        s.append("\n<?php\n\n");
        s.append("?>\n");
    }
    e->setPlainText(s);
}

void MainWindow::fichierEnregistrer() {
    enregistrer();
}

void MainWindow::fichierEnregistrerSous() {
    enregistrerSous();
}

void MainWindow::fichierEnregistrerTout() {
    enregistrerTout();
}

void MainWindow::editionCouper() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    interieur_onglet->getTextEdit()->cut();
}

void MainWindow::editionCopier() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    interieur_onglet->getTextEdit()->copy();
}

void MainWindow::editionColler() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet->getTextEdit()->canPaste()) {
        interieur_onglet->getTextEdit()->paste();
    }
}

void MainWindow::editionAnnuler() {

    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet) {
        //cout<<"dedans"<<endl;
        this->interieur_onglet->getTextEdit()->undo();
    }
}

void MainWindow::editionRetablir() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet) {
        interieur_onglet->getTextEdit()->redo();
    }
}

void MainWindow::editionSelectTout() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet) {
        interieur_onglet->getTextEdit()->selectAll();
    }
}

void MainWindow::editionZoomPlus() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet) {
        interieur_onglet->getTextEdit()->zoomIn(1);
    }
}

void MainWindow::editionZoomMoins() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet) {
        interieur_onglet->getTextEdit()->zoomOut(1);
    }
}

void MainWindow::editionPreferences() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());

    if(mes_preferences->isHidden()) { this->mes_preferences->show(); }
    else { this->mes_preferences->hide(); }
}

void MainWindow::editionRechercherRemplacer() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());

    if(rechercher_remplacer->isHidden()) { this->rechercher_remplacer->show(); }
    else { this->rechercher_remplacer->hide(); }
}

void MainWindow::affichageNumLigne() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet->getMaWidgetLigne()->isHidden()) {
        interieur_onglet->getMaWidgetLigne()->show();
    }
    else {
        interieur_onglet->getMaWidgetLigne()->hide();
        interieur_onglet->getTextEdit()->setMargins(0,0,0,0);
    }
}

void MainWindow::modifNbLignes() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    //interieur_onglet->getTextEdit()->changeNombreCaractere();
}

void MainWindow::modifNomTab() {
    QRegExp monExp(".*\\*$");

    QString nom = tab_widget->tabText(tab_widget->currentIndex());
    if(!monExp.exactMatch(nom)) {
        tab_widget->setTabText(tab_widget->currentIndex(), nom+'*');
        interieur_onglet->setEnregistre(false);
    }
    else {
        interieur_onglet->setEnregistre(true);
    }
}

void MainWindow::quandChangeOngletCourant(int) {

    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    //Num Ligne
    if(interieur_onglet->getMaWidgetLigne()->isHidden()) {
        action_menu_afficher_cacher_num_ligne->setChecked(false);
    }
    else {
        action_menu_afficher_cacher_num_ligne->setChecked(true);
    }
    //Coller
    if(!interieur_onglet->getTextEdit()->canPaste()) {
        action_menu_coller->setEnabled(false);
    }
    else {
        action_menu_coller->setEnabled(true);
    }
    //Undo
    /*if(interieur_onglet->getTextEdit()->isUndoRedoEnabled()) {
        action_menu_retablir->setEnabled(true);
        action_menu_annuler->setEnabled(true);
	    }
	    else {
                action_menu_retablir->setEnabled(false);
                action_menu_annuler->setEnabled(false);
	    }*/
    // Selectionner Tout
    if(interieur_onglet->getTextEdit()->toPlainText()=="") {
        action_menu_select_tout->setEnabled(false);
    }
    else {
        action_menu_select_tout->setEnabled(true);
    }


    //Actualise Status Barre
    this->modifBarreStatus();
    //if(this->interieur_onglet->getEnregistre()) { this->action_menu_enregistrer->setEnabled(false); }

    if(interieur_onglet->getInfoFichier()->suffix() == "html" ||
       interieur_onglet->getInfoFichier()->suffix() == "htm" ||
       interieur_onglet->getInfoFichier()->suffix() == "css" ||
       interieur_onglet->getInfoFichier()->suffix() == "php")
    {
        outilsValidateurOnOff(true);
    }
    else
    {
        outilsValidateurOnOff(false);
    }

}


void MainWindow::fichierOuvrir() {
    QStringList list = QFileDialog::getOpenFileNames(
                         this,
                         "Ouvrez un ou plusieurs fichiers",
                         workspace);

    QStringList files = list;

    for(int i=0; i<files.count(); i++) {
        ouvreFichier(new QFileInfo(files.at(i)));
        this->interieur_onglet->getTextEdit()->changeNombreCaractere();
        this->modifBarreStatus();
    }
}


void MainWindow::closeEvent(QCloseEvent * event) {
    QRegExp rx("New\\*|New\\([0-9]*\\)\\*");

    // Je parcours tous les onglets
    int nbOnglets = tab_widget->count(); // Compte le nb d'onglets
    int nbNew = 0; // compteur du nb de nouveau fichier

    for(int i=0; i<nbOnglets; i++) {
        if(rx.exactMatch(tab_widget->tabText(i))) {
            nbNew++;
        }
    }


    // Si aucun fichier a enregistrer
   /* if(nbNew==0) {
        // On demande s'il veut quitter ou annuler
        messageQuitter(event);
    }
    else */
    if(nbNew>0) {
        // Si des fichiers ne sont pas enregistrer, on demande s'il veut les enregistrer
        QRegExp expreg(".*\\*$");

        for(int i=0; i<nbOnglets; i++) {
            this->tab_widget->setCurrentIndex(i);
            interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
            if(interieur_onglet) {
                if(!interieur_onglet->getTextEdit()->toPlainText().isEmpty()) {
                    QString nomFichier = tab_widget->tabText(i);

                    if(expreg.exactMatch(nomFichier)) {
                        //event->ignore();
                        messageEnregistrer(event, nomFichier);
                    }
                }
            }
        } // Fin FOR
    }

    // On demande s'il veut quitter ou annuler
    messageQuitter(event);
}

void MainWindow::messageQuitter(QCloseEvent * event) {
    QMessageBox msgBox;
    QPushButton *cancelButton = msgBox.addButton(QMessageBox::Cancel);
    QPushButton *okButton = msgBox.addButton(QMessageBox::Ok);

    msgBox.setText(tr("Etes-vous sur de vouloir quitter ?"));
    msgBox.setIcon(QMessageBox::Question);
    msgBox.exec();

    if(msgBox.clickedButton() == okButton) {
        // FERMER LA PAGE DU WEB BROWSER QUANT L'APPLICATION EST FERMEE
        this->getWebBrowser()->close();
        this->close();
    }
    else if(msgBox.clickedButton() == cancelButton) {
        event->ignore();
    }
}


void MainWindow::messageEnregistrer(QCloseEvent * event, QString nomFichier) {
    QMessageBox msgBox;
    QPushButton *cancelButton = msgBox.addButton(QMessageBox::Cancel);
    QPushButton *saveButton = msgBox.addButton(QMessageBox::Save);

    msgBox.setText(tr("Voulez-vous enregistrer le fichier \"")+nomFichier+tr("\" ?"));
    msgBox.setIcon(QMessageBox::Question);
    msgBox.exec();

    if(msgBox.clickedButton() == saveButton) {
        //event->accept();
        enregistrer();

    }
    else if(msgBox.clickedButton() == cancelButton) {
        event->accept();
    }
}

void MainWindow::enregistrer() {

    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet)
    {
        // On recupere le chemin du fichier pour voir si ce fichier a �t� import�
        QFileInfo* fichier = interieur_onglet->getInfoFichier();

        if(fichier != NULL && fichier->absoluteFilePath()!="") {
            QFile sauvegarde(fichier->absoluteFilePath());
            if(sauvegarde.open(QFile::WriteOnly | QIODevice::Text))
            {
                QTextStream out(&sauvegarde);
                out << interieur_onglet->getTextEdit()->toPlainText();
                // on eleve l'etoile car l'enregistrerment  reussi
                changeNom(QString());
                if(fichier->suffix() == "html" || fichier->suffix() == "htm" || fichier->suffix() == "css" || fichier->suffix() == "php")
                {
                    outilsValidateurOnOff(true);//si le fichier est du html ou du css on peut le faire valider
                }
                else
                {
                    outilsValidateurOnOff(false);
                }
                getHierarchie()->clear();
                getHierarchie()->parcours();
            }
        }
        else {
            enregistrerSous();
        }
    }
}


void MainWindow::enregistrerSous()
{

    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());


        //Choix du chemin d'enregistrement
        QString fichier = QFileDialog::getSaveFileName(this, tr("Enregistrer"), QString(), tr("Tout"));

        //Enregistrement
        QFile sauvegarde(fichier);
        if(sauvegarde.open(QFile::WriteOnly | QIODevice::Text))
        {
            QTextStream out(&sauvegarde);

            if(interieur_onglet->getTextEdit()) {
                out <<  interieur_onglet->getTextEdit()->toPlainText();
                // on met la nouvelle adresse dans le QUrl
                interieur_onglet->setInfoFichier(new QFileInfo(sauvegarde));
                changeNom(fichier);
                if(QFileInfo(fichier).suffix() == "html" || QFileInfo(fichier).suffix() == "htm" || QFileInfo(fichier).suffix() == "css" || QFileInfo(fichier).suffix() == "php")
                {
                    outilsValidateurOnOff(true);//si le fichier est du html ou du css on peut le faire valider
                }
                else
                {
                    outilsValidateurOnOff(false);
                }
                getHierarchie()->clear();
                getHierarchie()->parcours();
            }
        }
}



void MainWindow::enregistrerTout() {

    QRegExp expreg(".*\\*$");

    for(int i=0; i<this->tab_widget->count(); i++) {
        this->tab_widget->setCurrentIndex(i);
        this->enregistrer();
    }
}



void MainWindow::changeNom(QString chemin) {
    if(chemin.isEmpty()) {
        QString nouveau_nom = this->tab_widget->tabText(this->tab_widget->currentIndex());
        nouveau_nom.replace(QString("*"), QString(""));
        this->tab_widget->setTabText(this->tab_widget->currentIndex(),nouveau_nom);
    }
    else {
            QString nouveau_nom;
            if(QFileInfo(chemin).suffix().isEmpty()) {
                 nouveau_nom = QFileInfo(chemin).baseName();
            }
            else {
                 nouveau_nom = QFileInfo(chemin).baseName()+'.'+QFileInfo(chemin).suffix();
            }

        this->tab_widget->setTabText(this->tab_widget->currentIndex(),nouveau_nom);
        this->getTabWidget()->setTabIcon(this->tab_widget->currentIndex(), choixIcone(QFileInfo(chemin).suffix()));
    }
    interieur_onglet->setEnregistre(true);
}



void MainWindow::ouvreFichier(QFileInfo* cheminFichier, bool recharge)
{
    if(cheminFichier->isFile())
    {
        QFile file(cheminFichier->absoluteFilePath());
        int indexOnglet = ongletDejaOuvert(cheminFichier);
        bool pasOuvert = false;
        if(indexOnglet == -1)pasOuvert = true;//le fichier n'est pas deja ouvert dans les onglets
        if(pasOuvert)
        {
            interieur_onglet = new WidgetDansOnglet(tab_widget,cheminFichier);
            QString fichier = cheminFichier->baseName()+"."+cheminFichier->suffix();
            indexOnglet = tab_widget->addTab(interieur_onglet,choixIcone(cheminFichier->suffix()),fichier);
            // ---------------------Modifier par Audrey :----------------------------------------------
            if(cheminFichier->suffix()=="css")
            {
                interieur_onglet->getTextEdit()->getColoration()->setAutomatique(false);
                interieur_onglet->getTextEdit()->getColoration()->setFichierCss(true);
                outilsValidateurOnOff(true);//si le fichier est du html ou du css on peut le faire valider
            }
            else if(cheminFichier->suffix()=="js")
            {
                interieur_onglet->getTextEdit()->getColoration()->setAutomatique(false);
                interieur_onglet->getTextEdit()->getColoration()->setFichierJavascript(true);
            }
            else if(cheminFichier->suffix()=="html" || cheminFichier->suffix()=="htm" || cheminFichier->suffix()=="php")
            {
                interieur_onglet->getTextEdit()->getColoration()->setAutomatique(true);
                outilsValidateurOnOff(true);//si le fichier est du html ou du css on peut le faire valider
            }
            else
            {
                interieur_onglet->getTextEdit()->getColoration()->setAutomatique(true);
            }

            //------------------------ fin modif Audrey ----------------------------------------
            interieur_onglet->setInfoFichier(cheminFichier);
//            if(!this->hierarchie->contient(cheminFichier)) {
//                this->hierarchie->ajouteProjet(new Projet(cheminFichier, ""));
//            }
            QObject::connect(tab_widget, SIGNAL(currentChanged(int)), this, SLOT(quandChangeOngletCourant(int)));
            QObject::connect(interieur_onglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifNomTab()));
            QObject::connect(interieur_onglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifNbLignes()));
            QObject::connect(interieur_onglet->getTextEdit(), SIGNAL(textChanged()), this, SLOT(modifBarreStatus()));

        }
		
        if(pasOuvert || recharge )
        {
            file.open(QIODevice::ReadWrite);
            QTextStream in(&file);

            this->interieur_onglet->getTextEdit()->setPlainText(in.readAll());
            file.close();
        }
        tab_widget->setCurrentIndex(indexOnglet);
        this->interieur_onglet->getTextEdit()->changeNombreCaractere();
        this->modifBarreStatus();
    }
}

int MainWindow::ongletDejaOuvert(QFileInfo* onglet)
{
    int taille = this->tab_widget->count();
    for(int i=0; i<taille; i++)
    {
        WidgetDansOnglet* contenu = dynamic_cast<WidgetDansOnglet*> (tab_widget->widget(i));
        if(contenu)
        {
            if(contenu->getInfoFichier()->absoluteFilePath() == onglet->absoluteFilePath())//l'onglet est deja ouvert
            {
                return i;
            }
        }
    }
    return -1;
}


void MainWindow::fermerTab(int indice) {
    if(this->tab_widget->count()>1) {
        enregistrer();
        tab_widget->removeTab(indice);
    }
}

void MainWindow::affichagePleinEcran() {
    if(this->action_menu_plein_ecran->isChecked()) {
        this->showFullScreen();
    }
    else {
        this->showNormal();
    }
}

void MainWindow::affichageOutilFichier() {
    if(this->action_menu_outil_fichier->isChecked()) {
        this->tool_fichier->show();
    }
    else {
        this->tool_fichier->hide();
    }
}

void MainWindow::affichageOutilEdition() {
    if(this->action_menu_outil_edition->isChecked()) {
        this->tool_edition->show();
    }
    else {
        this->tool_edition->hide();
    }
}

void MainWindow::affichageOutilProjet() {
    if(this->action_menu_outil_projet->isChecked()) {
        this->dock_projet->show();
    }
    else {
        this->dock_projet->hide();
    }
}

void MainWindow::gestionBarreStatus() {

    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());

    if(interieur_onglet)
    {
        this->interieur_onglet->getTextEdit()->changeNombreCaractere();

        QString str;
        int nbLignes = this->interieur_onglet->getTextEdit()->getNombreLigne();
        int nbCaracteres = this->interieur_onglet->getTextEdit()->getNombreCaractereSansEspace();
        label_nb_lignes = new QLabel(tr("ligne(s): ")+str.setNum(nbLignes)+tr(" ;"));
        label_nb_caracteres = new QLabel(tr("caract�re(s): ")+str.setNum(nbCaracteres)+tr(" ;"));

        //QFont style_label_status
        //label_nb_caracteres->setFont();

        status_bar->addPermanentWidget(label_nb_lignes);
        status_bar->addPermanentWidget(label_nb_caracteres);
    }
}

void MainWindow::modifBarreStatus() {
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());

    if(interieur_onglet)
    {
        QString str;
        int nbLignes = this->interieur_onglet->getTextEdit()->getNombreLigne();
        int nbCaracteres = this->interieur_onglet->getTextEdit()->getNombreCaractereSansEspace();
        //this->interieur_onglet->getTextEdit()->changeNombreCaractere();
        label_nb_lignes->setText(tr("ligne(s): ")+str.setNum(nbLignes));
        label_nb_caracteres->setText(tr("caract�re(s): ")+str.setNum(nbCaracteres));
    }
}

QIcon MainWindow::choixIcone(QString extension) {
   if(extension=="php") { return QIcon(":/Types/php.png"); }
   else if(extension=="js") { return QIcon(":/Types/js.png"); }
   else if(extension=="sql") { return QIcon(":/Types/sql.png"); }
   else if(extension=="css") { return QIcon(":/Types/css.png"); }
   else if(extension=="html" || extension=="htm") { return QIcon(":/Types/html.png"); }
   else { return QIcon(); }
}

void MainWindow::fichierImprimer() {
    QPrintPreviewDialog *avant_imprimer = new QPrintPreviewDialog();
    connect(avant_imprimer, SIGNAL(paintRequested(QPrinter*)), this, SLOT(imprimerOk(QPrinter*)));
    avant_imprimer->exec();
}

void MainWindow::imprimerOk(QPrinter * p)
{
    interieur_onglet = dynamic_cast<WidgetDansOnglet*> (this->tab_widget->currentWidget());
    if(interieur_onglet) {
        this->getInterieurOnglet()->getTextEdit()->print(p);
    }
}

void MainWindow::outilsOuvrirWebBrowser()
{
    this->getWebBrowser()->show();
}

void MainWindow::outilsOuvrirFtpBrowser()
{
    this->getFtpBrowser()->show();
}

void MainWindow::outilsValidateur()
{
    if(getInterieurOnglet()->getInfoFichier()->suffix() == "html" ||
       getInterieurOnglet()->getInfoFichier()->suffix() == "htm" ||
       getInterieurOnglet()->getInfoFichier()->suffix() == "php")
    {
        validation->lancerValidation();
    }
    else if(getInterieurOnglet()->getInfoFichier()->suffix() == "css")
    {
        validation->lancerValidation(1);
    }
}

void MainWindow::outilsValidateurOnOff(bool b)
{
    if(b)
    {
        action_menu_validateur->setToolTip(tr("Valider la page courante aupr�s du W3C"));
    }
    else
    {
        action_menu_validateur->setToolTip(tr("Enregistrez la page courante pour la valider"));
    }
    action_menu_validateur->setEnabled(b);
}

void MainWindow::restaurer()
{
    QSettings settings("MYW", "MainWindow");

    settings.beginGroup("workspace");
        workspace = settings.value("url").toString();
    settings.endGroup();
}

void MainWindow::enregistrerSettings()
{
    QSettings settings("MYW", "MainWindow");

    settings.beginGroup("workspace");
        settings.setValue("url", QVariant(path_workspace->text()));
    settings.endGroup();
}

QWidget* MainWindow::widgetChoisirWorkspace(QWidget * parent, bool modifier)
{
    QWidget * widget;
    if(parent == 0)
    {
        widget = new QWidget(this, Qt::Dialog);
    }
    else
    {
        widget = new QWidget(parent);
    }
    widget->setWindowIcon(QIcon(":/Menu/webBrowser.png"));
    widget->setWindowModality(Qt::WindowModal);
    QVBoxLayout * layout = new QVBoxLayout(widget);

    QString s;
    if(!modifier)
    {
        s = tr("Bienvenue dans MYW !\n");
    }
    QLabel * l = new QLabel(s+tr("Choisissez votre espace de travail en s�lectionnant le r�pertoire o� seront cr��s vos projets."), widget);
    layout->addWidget(l);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    layout->addLayout(ss_layout);

    path_workspace = new QLineEdit(widget);
    connect(path_workspace, SIGNAL(textChanged(QString)), this, SLOT(workspaceClavier(QString)));
    if(modifier)
    {
        path_workspace->setText(workspace);
    }
    ss_layout->addWidget(path_workspace);

    chooseDir = new QFileDialog(widget, Qt::Dialog);
    chooseDir->setFileMode(QFileDialog::Directory);
    connect(chooseDir, SIGNAL(accepted()), this, SLOT(workspaceChoisi()));
    chooseDir->hide();

    QPushButton * bouton = new QPushButton(tr("S�lectionner..."), widget);
    connect(bouton, SIGNAL(clicked()), chooseDir, SLOT(show()));
    ss_layout->addWidget(bouton);

    ok_workspace = new QPushButton(tr("Valider"), widget);
    ok_workspace->setIcon(QIcon(""));
    ok_workspace->setEnabled(false);
    ok_workspace->setMaximumWidth(80);
    if(!modifier)
    {
        layout->addWidget(ok_workspace, 100, Qt::AlignHCenter);
    }
    else
    {
        layout->addWidget(ok_workspace, 100, Qt::AlignRight);
    }
    connect(ok_workspace, SIGNAL(clicked()), this, SLOT(enregistrerSettings()));
    if(!modifier)
    {
        connect(ok_workspace, SIGNAL(clicked()), widget, SLOT(close()));
    }
    connect(ok_workspace, SIGNAL(clicked()), this, SLOT(constructeurApresWorkspace()));
    widget->show();

    return widget;
}

void MainWindow::workspaceChoisi()
{
    path_workspace->clear();
    QDir dir = QDir(chooseDir->selectedFiles().value(0));
    QString nom = chooseDir->selectedFiles().value(0);
    if(dir.isReadable())
    {
        path_workspace->setText(nom);
        ok_workspace->setEnabled(true);
    }
}

void MainWindow::fichierNouveauProjet()
{
    QWidget * w = new QWidget(this, Qt::Dialog);
    QVBoxLayout * layout = new QVBoxLayout(w);

    QLabel * l = new QLabel(tr("Entrez le nom de votre nouveau projet."), w);
    layout->addWidget(l);

    nouveau_projet = new QLineEdit(tr("Mon Projet"), w);
    layout->addWidget(nouveau_projet);

    QHBoxLayout * ss_layout = new QHBoxLayout();
    QPushButton * ok = new QPushButton(QIcon(":/Menu/valider.png"), tr("Valider"));
    ss_layout->addWidget(ok);
    QPushButton * annuler = new QPushButton(QIcon(":/Menu/quitter.png"), tr("Annuler"));
    ss_layout->addWidget(annuler);

    layout->addLayout(ss_layout);

    connect(ok, SIGNAL(clicked()), w, SLOT(close()));
    connect(ok, SIGNAL(clicked()), this, SLOT(fichierNouveauProjetOk()));

    connect(annuler, SIGNAL(clicked()), w, SLOT(close()));

    w->show();
}

void MainWindow::fichierNouveauProjetOk()
{
    QDir temp(workspace);
    bool b = temp.mkdir(nouveau_projet->text());
    getHierarchie()->clear();
    getHierarchie()->parcours();

    if(!b)
        Erreur::ecritErreur("MainWindow", "fichierNouveauProjetOk()", 1218);
}

void MainWindow::workspaceClavier(QString s)
{
    QDir dir(s);
    if(dir.isReadable() && s!=workspace)
    {
        ok_workspace->setEnabled(true);
    }
    if(!dir.isReadable() && ok_workspace)
    {
        ok_workspace->setEnabled(false);
    }
}

void MainWindow::apropos()
{
    QMessageBox msgBox;
    QPushButton *okButton = msgBox.addButton(QMessageBox::Ok);

    msgBox.setText(tr("MakeYourWeb\nCreer par Maneschi Romain\nNovak Audrey\nSauvan William\nK�nig Melanie\nMaillet Laurent\nFhal Jonathan\nBalima Dietrich\n\nCopyright 2009"));
    msgBox.exec();

    if(msgBox.clickedButton() == okButton) {
        msgBox.close();
    }
}
