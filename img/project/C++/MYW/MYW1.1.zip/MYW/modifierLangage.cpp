#include <QString>
#include <QTextEdit>
#include <QWidget>
#include <QAction>
#include <QLabel>
#include <QPalette>
#include <QColor>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QActionGroup>
#include <QListWidget>
#include <QListWidgetItem>
#include <QFile>
#include <QHBoxLayout>
#include <QTextStream>
#include <iostream>
#include "modifierLangage.h"
#include "mesConfigs.h"
#include "Preferences.h"
#include <QTabWidget>
#include "widgetDansOnglet.h"
#include "mainwindow.h"
using namespace std;

ModifierLangage::ModifierLangage(Coloration * colo,Preferences *parent) : QWidget()
{
    this->parent = parent;

      QGridLayout *grille= new QGridLayout(this);
      QVBoxLayout *vbox1 = new QVBoxLayout;
      QVBoxLayout *vbox2 = new QVBoxLayout;
      QHBoxLayout *hbox1 = new QHBoxLayout;
      QHBoxLayout *hbox2 = new QHBoxLayout;
      QHBoxLayout *hbox3 = new QHBoxLayout;

      QLabel *texte_langage=new QLabel(tr("Modification des langages :"));
      langage = new QComboBox;
      langage->addItem(tr("Choississez le langage � modifier :"));
      langage->addItem("Php");
      langage->addItem("Css");
      langage->addItem("Javascript");
      langage->addItem("Html");
      langage->setCurrentIndex(0);

      fichier = new QComboBox;
      fichier->setEnabled(false);

      QLabel *texte_mots=new QLabel(tr("Entrez la liste des mots s�par�s par un | (altgr+6)"));
      edit_texte=new QLineEdit(this);

      parametre_default= new QPushButton(tr("R�initialiser"),this);
      ajouter_mot= new QPushButton(tr("Ajouter un mot"),this);
      suprimer= new QPushButton(tr("Supprimer"),this);

      parametre_default->setEnabled(true);
      ajouter_mot->setEnabled(false);
      suprimer->setEnabled(false);
      edit_texte->setEnabled(false);

      affichage_liste= new QListWidget(this);
      affichage_liste->setEnabled(false);

      QPushButton *appliquer=new QPushButton(tr("Appliquer"),this);

      explication=new QLabel;
      explication->setFixedSize(200,100);

      vbox1->addWidget(texte_mots);
      vbox1->addWidget(langage);
      vbox1->addWidget(fichier);
      vbox1->addWidget(texte_mots);
      hbox1->addWidget(edit_texte);
      hbox1->addWidget(ajouter_mot);
      vbox2->addWidget(explication);
      vbox2->addWidget(suprimer);
      hbox2->addWidget(affichage_liste);
      hbox2->addLayout(vbox2);
      hbox3->addWidget(appliquer);
      hbox3->addWidget(parametre_default);

      grille->addLayout(vbox1,1,0);
      grille->addLayout(hbox1,2,0);
      grille->addLayout(hbox2,3,0);
      grille->addLayout(hbox3,4,0);

      connect(ajouter_mot, SIGNAL(clicked()),this,SLOT(modifierFichierLangage()));
      connect(ajouter_mot, SIGNAL(clicked()),edit_texte,SLOT(clear()));
      connect(edit_texte,SIGNAL(textChanged(QString)),this,SLOT(afficherBoutonAjouter(QString)));
      connect(parametre_default, SIGNAL(clicked()),this,SLOT(reinitialiser()));
      connect(langage,SIGNAL(currentIndexChanged(int)),this,SLOT(modifierCombobox(int)));
      connect(fichier,SIGNAL(currentIndexChanged(int)),this,SLOT(afficherListe(int)));
      connect(suprimer,SIGNAL(clicked()),this,SLOT(supprimerMot()));
      connect(appliquer, SIGNAL(clicked()),this,SLOT(validerModifierLangage()));
      connect(appliquer, SIGNAL(clicked()),this,SLOT(recolorer()));
      connect(edit_texte,SIGNAL(returnPressed()),edit_texte,SLOT(clear()));
}


//// fonction a renommer en : modification des fichiers (par exmple)
QString ModifierLangage :: modifierFichierLangage()
{
    // on recupere le texte pass� dans le QLineEdit
    QString expression=edit_texte->text();
    int lang = langage->currentIndex();
    int fic = fichier->currentIndex();

  if(lang==1)
  {
      if(fic==0)
      {
           coloration->modifieFichier(QString("fichiers/mot_cle_php1.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
      }
      else if(fic==1)
      {
          coloration->modifieFichier(QString("fichiers/mot_cle_php2.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();

      }
       else if(fic==2)
      {
          coloration->modifieFichier(QString("fichiers/mot_cle_php3.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
      }
      else if(fic==3)
      {
          coloration->modifieFichier(QString("fichiers/mot_cle_php4.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
      }
       else if(fic==4)
      {
          coloration->modifieFichier(QString("fichiers/mot_cle_php5.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
      }
  }
  else if(lang==2)
  {
      if(fic==0)
      {
           coloration->modifieFichier(QString("fichiers/mot_cle_css1.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
       else if(fic==1)
       {
           coloration->modifieFichier(QString("fichiers/mot_cle_css2.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
  }
  else if(lang==3)
  {
      if(fic==0)
      {
           coloration->modifieFichier(QString("fichiers/mot_cle_javascript1.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
      else if(fic==1)
      {
           coloration->modifieFichier(QString("fichiers/mot_cle_javascript2.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
      else if(fic==2)
      {
           coloration->modifieFichier(QString("fichiers/mot_cle_javascript3.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
  }
  else if(lang==4)
  {
      if(fic==0)
      {
           coloration->modifieFichier(QString("fichiers/html_balises_fermantes.txt").prepend(systeme_relation_fichier),expression);
        //   coloration->initialisationHtml();
           miseAJourListe();
       }
      else if(fic==1)
      {
           coloration->modifieFichier(QString("fichiers/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
      else if(fic==2)
      {
           coloration->modifieFichier(QString("fichiers/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
      else if(fic==3)
      {
           coloration->modifieFichier(QString("fichiers/attributs_html.txt").prepend(systeme_relation_fichier),expression);
           miseAJourListe();
       }
    }
    return expression;
}

// fonction a renommer en : modification des fichiers (par exmple)
void ModifierLangage :: miseAJourListe()
{
    int lang = langage->currentIndex();
    int fic = fichier->currentIndex();
    affichage_liste->clear();
    affichage_liste->setEnabled(true);
    edit_texte->setEnabled(true);
    suprimer->setEnabled(true);

    if(lang==1)     //php
    {
      if(fic==0)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php1.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php2.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==2)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php3.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==3)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php4.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==4)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php5.txt").prepend(systeme_relation_fichier)));
      }
  }
  else if(lang==2)      // css
  {
      if(fic==0)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_css1.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_css2.txt").prepend(systeme_relation_fichier)));
      }
  }
  else if(lang==3)          // javascript
  {
      if(fic==0)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_javascript1.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_javascript2.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==2)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_javascript3.txt").prepend(systeme_relation_fichier)));
      }
  }
  else if(lang==4)          // html
  {
      if(fic==0)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/html_balises_fermantes.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==2)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==3)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/attribut_html.txt").prepend(systeme_relation_fichier)));
      }
  }
}


void ModifierLangage :: supprimerMot()
{
    int lang = langage->currentIndex();
    int fic = fichier->currentIndex();

    if(lang==1)
  {
      if(fic==0)
      {
          suprimerMotFichier(QString("fichiers/mot_cle_php1.txt").prepend(systeme_relation_fichier));
    //      coloration->initialisationPhp();
          miseAJourListe();
      }
      else if(fic==1)
      {
          suprimerMotFichier(QString("fichiers/mot_cle_php2.txt").prepend(systeme_relation_fichier));
     //     coloration->initialisationPhp();
          miseAJourListe();
      }
      else if(fic==2)
      {
           suprimerMotFichier(QString("fichiers/mot_cle_php3.txt").prepend(systeme_relation_fichier));
       //    coloration->initialisationPhp();
           miseAJourListe();
      }
      else if(fic==3)
      {
            suprimerMotFichier(QString("fichiers/mot_cle_php4.txt").prepend(systeme_relation_fichier));
         //   coloration->initialisationPhp();
            miseAJourListe();
      }
       else if(fic==4)
      {
          suprimerMotFichier(QString("fichiers/mot_cle_php5.txt").prepend(systeme_relation_fichier));
    //      coloration->initialisationPhp();
          miseAJourListe();
      }
  }
  else if(lang==2)
  {
      if(fic==0)
      {
           suprimerMotFichier(QString("fichiers/mot_cle_css1.txt").prepend(systeme_relation_fichier));
      //     coloration->initialisationCss();
           miseAJourListe();
      }
      else if(fic==1)
      {
          suprimerMotFichier(QString("fichiers/mot_cle_css2.txt").prepend(systeme_relation_fichier));
        //  coloration->initialisationCss();
          miseAJourListe();
      }
  }
  else if(lang==3)
  {//cout<<"eeee"<<endl;
      if(fic==0)
      {
           suprimerMotFichier(QString("fichiers/mot_cle_javascript1.txt").prepend(systeme_relation_fichier));
      //     coloration->initialisationJavascript();
           miseAJourListe();
      }
      else if(fic==1)
      {
          suprimerMotFichier(QString("fichiers/mot_cle_javascript2.txt").prepend(systeme_relation_fichier));
        //  coloration->initialisationJavascript();
          miseAJourListe();
      }
     else if(fic==2)
      {
         suprimerMotFichier(QString("fichiers/mot_cle_javascript3.txt").prepend(systeme_relation_fichier));
      //   coloration->initialisationJavascript();
         miseAJourListe();
      }
  }
  else if(lang==4)
  {
      if(fic==0)
      {
          suprimerMotFichier(QString("fichiers/html_balises_fermantes.txt").prepend(systeme_relation_fichier));
      //    coloration->initialisationHtml();
          miseAJourListe();
      }
      else if(fic==1)
      {
          suprimerMotFichier(QString("fichiers/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier));
      //    coloration->initialisationHtml();
          miseAJourListe();
      }
      else if(fic==2)
      {
          suprimerMotFichier(QString("fichiers/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier));
        //  coloration->initialisationHtml();
          miseAJourListe();
      }
      else if(fic==3)
      {
          suprimerMotFichier(QString("fichiers/attribut_html.txt").prepend(systeme_relation_fichier));
         // coloration->initialisationHtml();
          miseAJourListe();
      }
  }
}


void ModifierLangage :: reinitialiser()
{
    int lang = langage->currentIndex();
    int fic = fichier->currentIndex();

    if(lang==1)
  {
      if(fic==0)
      {
           ecrireFic(QString("fichiers/mot_cle_php1.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_php1.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==1)
      {
          ecrireFic(QString("fichiers/mot_cle_php2.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_php2.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==2)
      {
          ecrireFic(QString("fichiers/mot_cle_php3.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_php3.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==3)
      {
          ecrireFic(QString("fichiers/mot_cle_php4.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_php4.txt").prepend(systeme_relation_fichier)));
          miseAJourListe();
      }
       else if(fic==4)
      {
          ecrireFic(QString("fichiers/mot_cle_php5.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_php5.txt").prepend(systeme_relation_fichier)));
          miseAJourListe();
      }
  }
  else if(lang==2)
  {
      if(fic==0)
      {
          ecrireFic(QString("fichiers/mot_cle_css1.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_css1.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==1)
      {
         ecrireFic(QString("fichiers/mot_cle_css2.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_css2.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
  }
  else if(lang==3)
  {
      if(fic==0)
      {
           ecrireFic(QString("fichiers/mot_cle_javascript1.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_javascript1.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==1)
      {
          ecrireFic(QString("fichiers/mot_cle_javascript2.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_javascript2.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
     else if(fic==2)
      {
          ecrireFic(QString("fichiers/mot_cle_javascript3.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/mot_cle_javascript3.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
  }
  else if(lang==4)
  {
      if(fic==0)
      {
           ecrireFic(QString("fichiers/html_balises_fermantes.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/html_balises_fermantes.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==1)
      {
          ecrireFic(QString("fichiers/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==2)
      {
          ecrireFic(QString("fichiers/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
      else if(fic==3)
      {
          ecrireFic(QString("fichiers/attribut_html.txt").prepend(systeme_relation_fichier),ouvrirFic(QString("fichiers_initiaux/attribut_html.txt").prepend(systeme_relation_fichier)));
           miseAJourListe();
      }
  }

}


QString ModifierLangage :: ouvrirFic(const QString &chemin)
 {
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // Le fichier n'existe pas
        cout<< "le fichie n'existe pas." <<endl;
    }

  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice::ReadOnly) )
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }

    QString fic= fichier.readLine().trimmed();
    QStringList list = fic.split("|");
    QString ajout = "\\b";

    return fic;

     fichier.close();
 }


void ModifierLangage :: ecrireFic(const QString &chemin, QString chaine)
 {
    QFile fichier(chemin);
    if( !fichier.exists() )
    {
        // si le fichier n'existe pas :
        cout<< "le fichier n'existe pas." <<endl;
    }
  // si il existe, on l'ouvre
    if( !fichier.open(QIODevice :: WriteOnly))
    {
      // si on ne peut pas l'ouvrir :
      cout<< "impossible d'ouvrir ce fichier." <<endl;
    }


    QTextStream flux(&fichier);
    flux<<chaine;
    fichier.close();
 }


void ModifierLangage :: modifierCombobox(int lang)
{
     if(lang==1)    //php
     {
         fichier->clear();
         fichier->setEnabled(true);
         fichier->addItem("Mots cl�s php 1");
         fichier->addItem("Mots cl�s php 2");
         fichier->addItem("Mots cl�s php 3");
         fichier->addItem("Mots cl�s php 4");
         fichier->addItem("Mots cl�s php 5");
     }
     else if(lang==2)   // css
     {
         fichier->clear();
         fichier->setEnabled(true);
         fichier->addItem("Mots cl�s css 1");
         fichier->addItem("Mots cl�s css 2");
     }
     else if(lang==3)   // javascript
     {
         fichier->clear();
         fichier->setEnabled(true);
         fichier->addItem("Mots cl�s javascript 1");
         fichier->addItem("Mots cl�s javascript 2");
         fichier->addItem("Mots cl�s javascript 3");
     }
     else if(lang==4)   // javascript
     {
         fichier->clear();
         fichier->setEnabled(true);
         fichier->addItem("Html balises fermantes");
         fichier->addItem("Html balises non fermantes");
         fichier->addItem("Html balises ouvrantes");
         fichier->addItem("Attributs");
     }
     else if(lang==0)
     {
         fichier->clear();
         fichier->setEnabled(false);
     }
}


void ModifierLangage :: afficherListe(int fic)
{
    int lang = langage->currentIndex();
    affichage_liste->clear();
    affichage_liste->setEnabled(true);
    edit_texte->setEnabled(true);
    suprimer->setEnabled(true);

    edit_texte->clear();
    ajouter_mot->setEnabled(false);
    explication->setText("");

    QPalette palette(edit_texte->palette());
    palette.setColor(QPalette::Base, Qt::white);
    edit_texte->setPalette(palette);

    if(lang==1)     //php
    {
      if(fic==0)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php1.txt").prepend(systeme_relation_fichier)));
     }
      else if(fic==1)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php2.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==2)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php3.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==3)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php4.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==4)
      {
         affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_php5.txt").prepend(systeme_relation_fichier)));
      }
  }
  else if(lang==2)      // css
  {
      if(fic==0)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_css1.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_css2.txt").prepend(systeme_relation_fichier)));
      }
  }
  else if(lang==3)          // javascript
  {
      if(fic==0)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_javascript1.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_javascript2.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==2)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/mot_cle_javascript3.txt").prepend(systeme_relation_fichier)));
      }
  }
  else if(lang==4)          // html
  {
      if(fic==0)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/html_balises_fermantes.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==1)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/html_balises_non_fermantes.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==2)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/html_balises_ouvrantes.txt").prepend(systeme_relation_fichier)));
      }
      else if(fic==3)
      {
          affichage_liste->addItems(coloration->recupererFichier(QString("fichiers/attribut_html.txt").prepend(systeme_relation_fichier)));
      }
  }
}

void ModifierLangage :: suprimerMotFichier(const QString &chemin)
{
            // supression du mot dans la liste
                affichage_liste->takeItem(affichage_liste->currentRow());

                QFile fichier2(chemin);

                // on recupere le texte pass� dans QListWidget
                QString chaine;
                QStringList liste;
                if( !fichier2.exists() )
                {
                    // si le fichier n'existe pas :
                    cout<< "le fichier n'existe pas." <<endl;
                }
              // si il existe, on l'ouvre
                if( !fichier2.open(QIODevice :: WriteOnly ))
                {
                  // si on ne peut pas l'ouvrir :
                  cout<< "impossible d'ouvrir ce fichier." <<endl;
                }
                else
                {
                    // si il est ouvert alors on fait les commandes (lecture du fichier et split)
                    QTextStream flux(&fichier2);
                   QString s;
                   int aa=affichage_liste->count();
                   QString dernier_mot_liste = affichage_liste->item(aa-1)->text();
                for(int i=0; i<affichage_liste->count()-1; i++)
                {
                    chaine=(affichage_liste->item(i)->text());
                    s=chaine;
                    s.replace(s,s+"|");
                   flux<<s;
                }
                    flux<<dernier_mot_liste;
                }
}


void ModifierLangage :: validerModifierLangage()
{

    for(int i=0;i<parent->getParent()->getTabWidget()->count();i++)
    {
        WidgetDansOnglet* interieurOnglet = dynamic_cast<WidgetDansOnglet*> (parent->getParent()->getTabWidget()->widget(i));
        if(interieurOnglet)
        {
           interieurOnglet->getTextEdit()->getColoration()->relancerInitialisationLangages();
       }
    }
}


void ModifierLangage :: afficherBoutonAjouter(QString texte)
{
    int lang = langage->currentIndex();
    int fic = fichier->currentIndex();

    QPalette palette( edit_texte->palette() );
    QColor rouge(255,0,0,100);
    QColor vert(0,255,0,100);



    if(lang==4)     // dans le cas de langage html     (^[^a-zA-Z0-9]*</[a-zA-Z0-9]*>[^a-zA-Z0-9]?$)|(\|[^a-zA-Z0-9]*</[a-zA-Z0-9]*>[^a-zA-Z0-9]*$?)
  {
      if(fic==0)    // balises fermantes    ^[^a-zA-Z0-9]*</[a-zA-Z0-9]*>                (^[^a-zA-Z0-9]*</[a-zA-Z0-9]*>)(\\|[^a-zA-Z0-9]*</[a-zA-Z0-9]*>)*
      {
          if(texte.contains(QRegExp("(^</[a-zA-Z0-9]*>$)|((</[a-zA-Z0-9]*>$)\\|{0,})")) && !texte.contains(QRegExp("([a-zA-Z0-9]<)")) && !texte.contains(QRegExp("\\s")))
          {
                ajouter_mot->setEnabled(true);
                palette.setColor( QPalette::Base, vert);
                edit_texte->setPalette(palette);
                explication->setText("");
            }
            else
            {
                explication->setText("Attention !\n Vous devez rentrer des mots de la forme :\n </[a-zA-Z0-9]*> \n et s�parer les mots par des |");
                ajouter_mot->setEnabled(false);
                 palette.setColor( QPalette::Base, rouge );
                edit_texte->setPalette(palette);
                if(texte.endsWith("|"))
                {
                    explication->setText("Attention !\n Veuillez supprimer le |,\n ou continuer � rentrer des mots cl�s");
                }

                if(texte.isEmpty())
                {
                    explication->setText("");
                     palette.setColor( QPalette::Base, Qt::white );
                    edit_texte->setPalette(palette);
                }
            }
      }
      else if(fic==1 || fic==2) // balises de type <[a-zA-Z0-9]
      {
//            if(texte.startsWith('<') && !texte.contains(QRegExp("(\\s)|(.<{2,})|(>)|(\\()|(\\))|(\\[)|(\\])|(\\{)|(\\})|(</)")) && !texte.contains(QRegExp("[^\\|]<")) && !texte.contains(QRegExp("(\\|[a-zA-Z0-9]<)")) && !texte.endsWith('<') && !texte.endsWith("|"))
            if(texte.contains(QRegExp("(^<[a-zA-Z0-9]*$)|((<[a-zA-Z0-9]*$)\\|{0,})")) && !texte.contains(QRegExp("(\\s)|(.<{2,})|(>)|(\\()|(\\))|(\\[)|(\\])|(\\{)|(\\})|(</)")) && !texte.contains(QRegExp("[^\\|]<")) && !texte.contains(QRegExp("(\\|[a-zA-Z0-9]<)")) && !texte.endsWith('<') && !texte.endsWith("|"))
          {
                ajouter_mot->setEnabled(true);
                palette.setColor( QPalette::Base, vert);
                edit_texte->setPalette(palette);
                explication->setText("");
            }
            else
            {
                explication->setText("Attention !\n Vous devez rentrer des mots de la forme :\n <[a-zA-Z0-9]* \n et s�parer les mots par des |");
                ajouter_mot->setEnabled(false);
                palette.setColor( QPalette::Base, rouge );
                edit_texte->setPalette(palette);
                if(texte.endsWith("|"))
                {
                    explication->setText("Attention !\n Veuillez supprimer le |,\n ou continuer � rentrer des mots cl�s");
                }
                if(texte.isEmpty())
                {
                     palette.setColor( QPalette::Base, Qt::white );
                    edit_texte->setPalette(palette);
                }
            }
      }
      else if(fic==3)       // cas des atributs
      {
          if(texte.contains(QRegExp("^[a-zA-Z0-9!_-]*")) && !texte.contains(QRegExp("(\\s)|(<)|(>)|(\\()|(\\))|(\\[)|(\\])|(\\{)|(\\})|(</)")) && !texte.endsWith("|"))
         {
             ajouter_mot->setEnabled(true);
             palette.setColor( QPalette::Base, vert);
             edit_texte->setPalette(palette);
             explication->setText("");
         }
         else
         {
             explication->setText("Attention !\n Vous devez rentrer des mots de la forme :\n [a-zA-Z0-9]\n qui ne contiennent pas de <>,[],(),{} \n et s�parer les mots par des |");
             ajouter_mot->setEnabled(false);
             palette.setColor( QPalette::Base, rouge );
             edit_texte->setPalette(palette);
             if(texte.endsWith("|"))
            {
                explication->setText("Attention !\n Veuillez supprimer le |,\n ou continuer � rentrer des mots cl�s");
            }
             if(texte.isEmpty())
             {
                 palette.setColor( QPalette::Base, Qt::white );
                 edit_texte->setPalette(palette);
             }
         }
      }
  }
    else
    {
        if(texte.contains(QRegExp("[a-zA-Z0-9!_-]*"))&& !texte.contains(QRegExp("(\\s)|(<)|(>)|(\\()|(\\))|(\\[)|(\\])|(\\{)|(\\})|(</)")) && !texte.endsWith("|"))
        {
            ajouter_mot->setEnabled(true);
            palette.setColor( QPalette::Base, vert);
            edit_texte->setPalette(palette);
            explication->setText("");
        }
        else
        {
            explication->setText("Attention !\n Vous devez rentrer des mots de la forme :\n [a-zA-Z0-9]\n qui ne contiennent pas de <>,[],(),{} \n et s�parer les mots par des |");
            ajouter_mot->setEnabled(false);
            palette.setColor( QPalette::Base, rouge );
            edit_texte->setPalette(palette);
            if(texte.endsWith("|"))
            {
                explication->setText("Attention !\n Veuillez supprimer le |,\n ou continuer � rentrer des mots cl�s");
            }
            if(texte.isEmpty())
            {
                palette.setColor( QPalette::Base, Qt::white );
                edit_texte->setPalette(palette);
            }
        }
    }
}


void ModifierLangage:: recolorer()
{
        for(int i=0;i<parent->getParent()->getTabWidget()->count();i++)
    {
         WidgetDansOnglet* interieurOnglet = dynamic_cast<WidgetDansOnglet*> (parent->getParent()->getTabWidget()->widget(i));
         if(interieurOnglet)
         {
             interieurOnglet->getTextEdit()->getColoration()->rehighlight();
         }
     }
}
