#include "editionwidgetliste.h"
#include "mesConfigs.h"
#include <QSettings>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QFileDialog>
#include <QDir>
#include <QFile>
#include <QPixmap>
#include <iostream>
using namespace std;

EditionWidgetListe::EditionWidgetListe(QWidget* parent) : QWidget(parent, Qt::Dialog)
{
    //QSettings settings("MYW", "WidgetListe");
   // settings.remove("widgetListe");

    texte_fiche = new QLabel(tr("Nom de la fiche"));
    texte_chemin_image = new QLabel(tr("Chemin de l'image"));
    
    texte_fiche->setAlignment(Qt::AlignCenter);
    texte_chemin_image->setAlignment(Qt::AlignCenter);
    etat = new QLabel (tr("Mise � jour des fiches, pour supprimer une fiche cliquer sur la case en face de la fiche"));
    etat->setAlignment(Qt::AlignCenter);
    taille_tableau_fiche = restaurer();
    affichage_fiche = new QLabel*[taille_tableau_fiche];
    fiche_a_supprimer = new QCheckBox[taille_tableau_fiche];
    bool b = false;
    int j = 0;
    for(int i=0; i<taille_tableau_fiche;i++)
    {
        if(QFile::exists(tableau_fiche[i][1]))
        {
            affichage_fiche[i] = new QLabel[2];
            affichage_fiche[i][0].setText(tableau_fiche[i][0]);
            affichage_fiche[i][0].show();

            QPixmap tmp(tableau_fiche[i][1]);
            affichage_fiche[i][1].setPixmap(tmp.scaled(TAILLE_IMAGE_LARGEUR,TAILLE_IMAGE_LONGUEUR));
            affichage_fiche[i][0].setAlignment(Qt::AlignCenter);
            affichage_fiche[i][1].setAlignment(Qt::AlignCenter);

        }
        else
        {
            affichage_fiche[i] = new QLabel[2];
            b = true;
            j = i;
        }
    }

    grille = new QGridLayout();
    sous_grille = new QGridLayout();
    texte = new QLineEdit();
    chemin_image = new QLineEdit();
    bouton_chemin_image = new QPushButton(tr("Parcourir"));
    ajouter = new QPushButton(tr("Ajouter"));

    QGridLayout *hbox = new QGridLayout;
    hbox->addWidget(texte_fiche,0,0);
    hbox->addWidget(texte_chemin_image,0,1,1,2);
    hbox->addWidget(texte,1,0);
    hbox->addWidget(chemin_image,1,1);
    hbox->addWidget(bouton_chemin_image,1,2);

    QHBoxLayout *hbox2 = new QHBoxLayout;
    hbox2->addWidget(ajouter);



    connect(bouton_chemin_image, SIGNAL(clicked()), this, SLOT(ouvreFenetreRechercheImage()));
    connect(ajouter, SIGNAL(clicked()), this, SLOT(ajoutFiche()));


    if(b)
        supprimer(j);
    else
    {
        for (int i=0; i<taille_tableau_fiche; i++)
        {
            sous_grille->addWidget(&affichage_fiche[i][0],i,0);
            sous_grille->addWidget(&affichage_fiche[i][1],i,1);
            sous_grille->addWidget(&fiche_a_supprimer[i],i,2);
            connect(&fiche_a_supprimer[i], SIGNAL(clicked()), this, SLOT(supprimer()));
        }
    }
    grille->addWidget(etat,0,0);
    grille->addLayout(hbox,1,0);
    grille->addLayout(hbox2,2,0);
    grille->addLayout(sous_grille, 3,0);
    setLayout(grille);
    //setFixedHeight(4*14 + taille_tableau_fiche * 50 + (taille_tableau_fiche+4)*12);

    //miseAJour();

}

void EditionWidgetListe::ouvreFenetreRechercheImage()
{
    nom_fichier= QFileDialog::getOpenFileName(this,
    tr("Ouvrir Image"), "", tr("Image (*.png *.jpg *.bmp *.jpeg *.gif)"));

    if(!nom_fichier.isEmpty())
       this->chemin_image->setText(nom_fichier);
}

void EditionWidgetListe::supprimer(int i)
{
    for(i; i<taille_tableau_fiche;i++)
    {
        if(i != taille_tableau_fiche-1)
        {
            tableau_fiche[i][0] = tableau_fiche[i+1][0];
            tableau_fiche[i][1] = tableau_fiche[i+1][1];
        }
    }
    taille_tableau_fiche--;
    QSettings settings("MYW", "WidgetListe");
    settings.remove("widgetListe");
    sauvegarder();

    taille_tableau_fiche++; //car on supprime les anciennes entr�es en premier dans MAJ
    miseAJour(1);
}

void EditionWidgetListe::sauvegarder()
{
    QSettings settings("MYW", "WidgetListe");
    settings.beginWriteArray("widgetListe");
    for (int i = 0; i < taille_tableau_fiche; i++) {
        settings.setArrayIndex(i);
        settings.setValue("texte", tableau_fiche[i][0]);
        settings.setValue("chemin_image", tableau_fiche[i][1]);
    }
    settings.endArray();
}

int EditionWidgetListe::restaurer()
{
    taille_tableau_fiche = 0;
    QSettings settings("MYW", "WidgetListe");
    int size = settings.beginReadArray("widgetListe");
    for (int i = 0; i < size; i++) {
        settings.setArrayIndex(i);
        tableau_fiche[i][0] = settings.value(QString("texte")).toString();
        tableau_fiche[i][1] = settings.value(QString("chemin_image")).toString();
        taille_tableau_fiche ++;
    }
    settings.endArray();
    return taille_tableau_fiche;
}

void EditionWidgetListe::ajoutFiche()
{
    if(taille_tableau_fiche >= MAX_NOMBRE_WIDGET_LISTE )
        return;
    if(texte->text().isEmpty())
        return;
    QFile fichier(nom_fichier);

    QString fichier_dst = QString(systeme_relation_fichier).append("Editeur/Images/");
    fichier_dst = fichier_dst.append(QDir(nom_fichier).dirName());

    if(QFile::exists(fichier_dst))
        return;

    for(int i=0; i<taille_tableau_fiche; i++)
    {
        if(tableau_fiche[i][0] == texte->text())
            return;
    }

    tableau_fiche[taille_tableau_fiche][0] = texte->text();
    tableau_fiche[taille_tableau_fiche][1] = fichier_dst;
    fichier.copy(fichier_dst);
    taille_tableau_fiche++;
    //tout est bon on peut �crire les settings
    QSettings settings("MYW", "WidgetListe");
    settings.remove("widgetListe");
    sauvegarder();
    taille_tableau_fiche--; //car on commence par supprimer les anciennes entr�es dans MAJ

    miseAJour(0);
}

void EditionWidgetListe::supprimer()
{
    for(int i=0; i<taille_tableau_fiche; i++)
    {
        if(fiche_a_supprimer[i].isChecked())
        {
            QString fichier = tableau_fiche[i][1];
            QFile(fichier).remove();
            supprimer(i);
        }
    }
}

//0 = ajout
//1 = suppression
void EditionWidgetListe::miseAJour(int mode)
{
    for(int i=0; i<taille_tableau_fiche;i++)
    {
        affichage_fiche[i][0].close();
        affichage_fiche[i][1].close();
        fiche_a_supprimer[i].close();

        affichage_fiche[i][0].hide();
        affichage_fiche[i][1].hide();
        fiche_a_supprimer[i].hide();
    }
    etat->close();

    grille->removeWidget(etat);
    grille->removeItem(sous_grille);
    sous_grille = new QGridLayout();

    restaurer();
    affichage_fiche = new QLabel*[taille_tableau_fiche];
    fiche_a_supprimer = new QCheckBox[taille_tableau_fiche];

    bool b = false;
    int j = 0;
    for(int i=0; i<taille_tableau_fiche;i++)
    {
        if(QFile::exists(tableau_fiche[i][1]))
        {
            affichage_fiche[i] = new QLabel[2];
            affichage_fiche[i][0].setText(tableau_fiche[i][0]);
            affichage_fiche[i][0].show();

            QPixmap tmp(tableau_fiche[i][1]);
            affichage_fiche[i][1].setPixmap(tmp.scaled(TAILLE_IMAGE_LARGEUR,TAILLE_IMAGE_LONGUEUR));
            affichage_fiche[i][0].setAlignment(Qt::AlignCenter);
            affichage_fiche[i][1].setAlignment(Qt::AlignCenter);
        }
        else
        {
            affichage_fiche[i] = new QLabel[2];
            b = true;
            j = i;
        }
    }
    


    if(b)
        supprimer(j);
    else
    {
        for (int i=0; i<taille_tableau_fiche; i++)
        {
            sous_grille->addWidget(&affichage_fiche[i][0],i,0);
            sous_grille->addWidget(&affichage_fiche[i][1],i,1);
            sous_grille->addWidget(&fiche_a_supprimer[i],i,2);
            connect(&fiche_a_supprimer[i], SIGNAL(clicked()), this, SLOT(supprimer()));
        }
    }
    if(mode == 0)
        etat = new QLabel(tr("Ajout effectu�"));
    else if(mode == 1)
        etat = new QLabel(tr("Suppression effectu�"));

    etat->setAlignment(Qt::AlignCenter);

    grille->addWidget(etat, 0,0);
    grille->addLayout(sous_grille, 3,0);
   //setFixedHeight(4*14 + taille_tableau_fiche * 50 + (taille_tableau_fiche+4)*12);
}
