#include "RechercherRemplacer/FindDialog.h"
#include "mainwindow.h"
#include "editeur.h"

FindDialog::FindDialog(MainWindow *par)
     : QWidget()
 {
     parent = par;
     labelRechercher = new QLabel(tr("Rechercher: "));
     lineEditRechercher = new QLineEdit;
     precedentRechercher = new QPushButton(QIcon(":/Menu/annuler"),"");
     suivantRechercher = new QPushButton(QIcon(":/Menu/retablir"),"");

     labelRemplacer = new QLabel(tr("Remplacer par: "));
     lineEditRemplacer = new QLineEdit;
     precedentRemplacer = new QPushButton(QIcon(":/Menu/annuler"),"");
     suivantRemplacer = new QPushButton(QIcon(":/Menu/retablir"),"");
     remplacerTout = new QPushButton(tr("Remplacer Tout"));

     fermer = new QPushButton(QIcon(":/Menu/quitter"),"");

     QObject::connect(lineEditRechercher, SIGNAL(textChanged(QString)), this, SLOT(rechercher(QString)));
     QObject::connect(suivantRechercher, SIGNAL(clicked()), this, SLOT(rechercherSuivant()));
     QObject::connect(precedentRechercher, SIGNAL(clicked()), this, SLOT(rechercherPrecedent()));
     QObject::connect(fermer, SIGNAL(clicked()), this, SLOT(hide()));
     QObject::connect(lineEditRemplacer, SIGNAL(textChanged(QString)), this, SLOT(color(QString)));
     QObject::connect(suivantRemplacer, SIGNAL(clicked()), this, SLOT(remplacerSuivant()));
     QObject::connect(precedentRemplacer, SIGNAL(clicked()), this, SLOT(remplacerPrecedent()));
     QObject::connect(remplacerTout, SIGNAL(clicked()), this, SLOT(remplacerDansTout()));

     QHBoxLayout *layoutHorizontal = new QHBoxLayout(this);
     layoutHorizontal->addWidget(labelRechercher);
     layoutHorizontal->addWidget(lineEditRechercher);
     layoutHorizontal->addWidget(precedentRechercher);
     layoutHorizontal->addWidget(suivantRechercher);
     layoutHorizontal->addWidget(labelRemplacer);
     layoutHorizontal->addWidget(lineEditRemplacer);
     layoutHorizontal->addWidget(precedentRemplacer);
     layoutHorizontal->addWidget(suivantRemplacer);
     layoutHorizontal->addWidget(remplacerTout);
     layoutHorizontal->addWidget(fermer);
     this->setLayout(layoutHorizontal);

     this->setMaximumHeight(40);
     this->hide();
     //this->setStyleSheet("background: grey;");
 }


// Accesseurs
MainWindow *FindDialog::getParent() { return parent; }

QLabel *FindDialog::getLabelRechercher() { return labelRechercher; }
QLineEdit *FindDialog::getLineEditRechercher() { return lineEditRechercher; }
QPushButton *FindDialog::getPrecedentRechercher() { return precedentRechercher; }
QPushButton *FindDialog::getSuivantRechercher() { return suivantRechercher; }

QLabel *FindDialog::getLabelRemplacer() { return labelRemplacer; }
QLineEdit *FindDialog::getLineEditRemplacer() { return lineEditRemplacer; }
QPushButton *FindDialog::getPrecedentRemplacer() { return precedentRemplacer; }
QPushButton *FindDialog::getSuivantRemplacer() { return suivantRemplacer; }
QPushButton *FindDialog::getRemplacerTout() { return remplacerTout; }

QPushButton *FindDialog::getFermer() { return fermer; }

// SLOTS
void FindDialog::rechercher(QString mot) {
    parent = dynamic_cast<MainWindow*> (this->getParent());
    if(parent) {
        parent->getInterieurOnglet()->getTextEdit()->moveCursor(QTextCursor::Start,QTextCursor::MoveAnchor);
        parent->getInterieurOnglet()->getTextEdit()->find(mot);
        //parent->getInterieurOnglet()->getTextEdit()->setFocus(Qt::MouseFocusReason);
    }

}

void FindDialog::rechercherSuivant() {
    parent = dynamic_cast<MainWindow*> (this->getParent());
    if(parent) {
        parent->getInterieurOnglet()->getTextEdit()->find(this->getLineEditRechercher()->text());
    }
}

void FindDialog::rechercherPrecedent() {
    parent = dynamic_cast<MainWindow*> (this->getParent());
    if(parent) {
          parent->getInterieurOnglet()->getTextEdit()->find(this->getLineEditRechercher()->text(), QTextDocument::FindBackward);
    }
}

void FindDialog::remplacer(QString mot) {
    if(this->getLineEditRechercher()->text()!="") {
        parent = dynamic_cast<MainWindow*> (this->getParent());
        if(parent) {
            QTextCursor curseur = QTextCursor(parent->getInterieurOnglet()->getTextEdit()->textCursor());
            if(curseur.hasSelection()) {
                curseur.select(QTextCursor::WordUnderCursor);
                curseur.removeSelectedText();
                curseur.insertText(mot);
            }
        }
    }
}

void FindDialog::remplacerSuivant() {
    parent = dynamic_cast<MainWindow*> (this->getParent());
    if(parent) {
        remplacer(this->getLineEditRemplacer()->text());
        rechercherSuivant();
    }

}

void FindDialog::remplacerPrecedent() {
    parent = dynamic_cast<MainWindow*> (this->getParent());
    if(parent) {
        remplacer(this->getLineEditRemplacer()->text());
        rechercherPrecedent();
    }
}

void FindDialog::remplacerDansTout() {
    parent = dynamic_cast<MainWindow*> (this->getParent());
    if(parent) {
        int i = 0;
        QTextCursor curseur =  QTextCursor(parent->getInterieurOnglet()->getTextEdit()->textCursor());
        parent->getInterieurOnglet()->getTextEdit()->moveCursor(QTextCursor::Start);
        while(parent->getInterieurOnglet()->getTextEdit()->find(this->getLineEditRechercher()->text())) {
            remplacer(this->getLineEditRemplacer()->text());
            i++;
        }

        QMessageBox msgBox;
        QPushButton *okButton = msgBox.addButton(QMessageBox::Ok);

        QString str;
        msgBox.setText(str.setNum(i)+tr(" mot(s) ont �t� remplac�(s) !"));
        msgBox.setIcon(QMessageBox::Information);
        msgBox.exec();

        if(msgBox.clickedButton() == okButton) {
            msgBox.close();
        }
    }
}

void FindDialog::color(QString mot) {

}


// Graphisme
void FindDialog::paintEvent(QPaintEvent * event) {
    //this->setGeometry(0,0,400,100);
    //this->setStyleSheet("background: darkgrey;");
}
