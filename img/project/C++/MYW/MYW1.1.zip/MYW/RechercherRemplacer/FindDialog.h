#ifndef FINDDIALOG_H
#define FINDDIALOG_H

#include <iostream>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QWidget>
#include <QVBoxLayout>

using namespace std;

class MainWindow;
class Editeur;

/*!
* \file FindDialog.h
* \brief QWidget permettant de faire une recherche dans l'onglet courant ainsi que de remplacer des mots
* \author FHAL Jonathan
* \date 25.05.2009
*/

/*!
* \class FindDialog
* \brief Classe permettant de faire une recherche dans l'onglet courant ainsi que de remplacer des mots
*/
class FindDialog : public QWidget
 {
     Q_OBJECT

 private:
     MainWindow *parent;

     QLabel *labelRechercher;
     QLineEdit *lineEditRechercher;
     QPushButton *precedentRechercher;
     QPushButton *suivantRechercher;

     QLabel *labelRemplacer;
     QLineEdit *lineEditRemplacer;
     QPushButton *precedentRemplacer;
     QPushButton *suivantRemplacer;
     QPushButton *remplacerTout;

     QPushButton *fermer;

 public:
     // Methodes
        /*!
        *  \brief Constructeur
        *
        *  Constructeur de la classe MainWindow
        *
        *  \param parent : parent de l'objet
        */
     FindDialog(MainWindow *parent=0);

     // Accesseurs
     /*! \return le MainWindow (parent) */
     MainWindow *getParent();
     /*! \return label de recherche */
     QLabel *getLabelRechercher();
     /*! \return QLineEdit de recherche */
     QLineEdit *getLineEditRechercher();
     /*! \return le bouton precedent de la recherche */
     QPushButton *getPrecedentRechercher();
     /*! \return le bouton suivant de la recherche */
     QPushButton *getSuivantRechercher();

     /*! \return label de remplacement */
     QLabel *getLabelRemplacer();
     /*! \return QLineEdit de remplacement */
     QLineEdit *getLineEditRemplacer();
     /*! \return le bouton precedent de la remplacer */
     QPushButton *getPrecedentRemplacer();
     /*! \return le bouton suivant de la remplacer */
     QPushButton *getSuivantRemplacer();
     /*! \return le bouton pour tout remplacer */
     QPushButton *getRemplacerTout();
     /*! \return le bouton fermer */
     QPushButton *getFermer();

 // SLOTS
 public slots:
     /*! \brief Recherche le mot pass� en parametre dans l'onglet courant
       * \param QString: mot que l'on recherche
     */
     void rechercher(QString);
     /*! \brief Recherche le mot suivant */
     void rechercherSuivant();
     /*! \brief Recherche le mot precedent */
     void rechercherPrecedent();
     /*! \brief Remplace le mot pass� en parametre dans l'onglet courant
       * \param QString: mot que l'on remplace
     */
     void remplacer(QString);
     /*! \brief Remplace le mot suivant */
     void remplacerSuivant();
     /*! \brief Remplace le mot precedent */
     void remplacerPrecedent();
     /*! \brief Remplace le mot dans tout le fichier */
     void remplacerDansTout();

     void color(QString mot);

 // Methodes
  public:
     void paintEvent(QPaintEvent *event);

 };
#endif // FINDDIALOG_H
