<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ChangerColoration</name>
    <message>
        <location filename="../changerColoration.cpp" line="69"/>
        <source>Mots clés php1 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="70"/>
        <source>Mots clés php2 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="71"/>
        <source>Mots clés php3 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="72"/>
        <source>Variables :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="148"/>
        <source>Mots clés javascript1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="149"/>
        <source>Mots clés javascript2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="150"/>
        <source>Mots clés javascript3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="208"/>
        <source>Mots clés css1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="209"/>
        <source>Mots clés css2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="254"/>
        <source>Mots clés html :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="255"/>
        <source>Attributs :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="296"/>
        <source>Général :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="302"/>
        <source>Commentaires simples :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="303"/>
        <source>Commentaires multiples :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="304"/>
        <source>Quotes :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../changerColoration.cpp" line="305"/>
        <source>Fonction :</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChoisirLangage</name>
    <message>
        <location filename="../choisirLangage.cpp" line="20"/>
        <source>Automatique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../choisirLangage.cpp" line="23"/>
        <source>Personnalisée</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../choisirLangage.cpp" line="26"/>
        <source>Php</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../choisirLangage.cpp" line="29"/>
        <source>Css</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../choisirLangage.cpp" line="32"/>
        <source>Javascript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../choisirLangage.cpp" line="35"/>
        <source>Html</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CommandesToolBar</name>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="15"/>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="170"/>
        <source>Connection Serveur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="27"/>
        <source>Uploader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="35"/>
        <source>Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="45"/>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="121"/>
        <source>Vider les messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="67"/>
        <source>Ajouter un serveur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="69"/>
        <source>Modifier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="132"/>
        <source>Stopper Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/CommandesToolBar.cpp" line="162"/>
        <source>Déconnection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DossiersDistants</name>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="17"/>
        <source>Nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="17"/>
        <source>Taille</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="17"/>
        <source>Propriétaire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="17"/>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="17"/>
        <source>Dernière modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="50"/>
        <source>Connexion impossible : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="50"/>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="78"/>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="89"/>
        <source>Erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="78"/>
        <source>Déplacement dans un dossier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="89"/>
        <source>Récupération d&apos;un fichier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="128"/>
        <source>Non connecté.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="138"/>
        <source>Vérification du serveur.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="143"/>
        <source>Connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="148"/>
        <source>Connecté.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="153"/>
        <source>Loggé.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="165"/>
        <source>Connextion en pause.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="355"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;/&lt;/b&gt;&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="359"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="359"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="397"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="398"/>
        <source>Renommer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="400"/>
        <source>Nouveau dossier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="401"/>
        <source>Recharger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="405"/>
        <source>Downloader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="426"/>
        <source>Suppression de </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="426"/>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="472"/>
        <source>Distant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="443"/>
        <source>Renommer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="446"/>
        <source>Fichier : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="450"/>
        <source>Nouveau nom : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="457"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="459"/>
        <source>Valider</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersDistants.cpp" line="472"/>
        <source> renommé en </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DossiersLocaux</name>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="17"/>
        <source>Nom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="17"/>
        <source>Taille</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="17"/>
        <source>Propriétaire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="17"/>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="17"/>
        <source>Dernière modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="184"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="184"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="221"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="222"/>
        <source>Renommer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="224"/>
        <source>Nouveau dossier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="225"/>
        <source>Recharger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="229"/>
        <source>Uploader</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="250"/>
        <source>Suppression de : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="250"/>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="296"/>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="267"/>
        <source>Renommer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="270"/>
        <source>Fichier : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="274"/>
        <source>Nouveau nom : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="281"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="283"/>
        <source>Valider</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/DossiersLocaux.cpp" line="296"/>
        <source> renommé en </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditionWidgetListe</name>
    <message>
        <location filename="../editionwidgetliste.cpp" line="101"/>
        <source>Ouvrir Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../editionwidgetliste.cpp" line="101"/>
        <source>Image (*.png *.jpg *.bmp *.jpeg *.gif)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FTPBrowser</name>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="85"/>
        <source>Modifier un serveur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="90"/>
        <source>Ajouter un serveur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="95"/>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="175"/>
        <source>URL : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="110"/>
        <source>Login : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="124"/>
        <source>Mot de Passe : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="140"/>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="189"/>
        <source>Port : </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="154"/>
        <source>Dossier de départ : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="167"/>
        <source>Utiliser un proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="210"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/FTPBrowser.cpp" line="212"/>
        <source>Valider</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="../WebBrowser/Frame.cpp" line="30"/>
        <source>Choisir un fichier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Historique</name>
    <message>
        <location filename="../WebBrowser/Historique.cpp" line="23"/>
        <source>Historique</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoriqueLabel</name>
    <message>
        <location filename="../WebBrowser/HistoriqueLabel.cpp" line="46"/>
        <source>Trier...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/HistoriqueLabel.cpp" line="49"/>
        <source>Supprimer cette image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/HistoriqueLabel.cpp" line="51"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/HistoriqueLabel.cpp" line="54"/>
        <source>Tout Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/HistoriqueLabel.cpp" line="104"/>
        <location filename="../WebBrowser/HistoriqueLabel.cpp" line="121"/>
        <source>Vide</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoriqueWidget</name>
    <message utf8="true">
        <location filename="../WebBrowser/HistoriqueWidget.cpp" line="22"/>
        <source>Du plus visité au moins visité</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/HistoriqueWidget.cpp" line="23"/>
        <source>D&apos;aujourd&apos;hui jusqu&apos;au premier jour</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/HistoriqueWidget.cpp" line="24"/>
        <source>D&apos;aujourd&apos;hui jusqu&apos;au premier jour avec toutes les entrées</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/HistoriqueWidget.cpp" line="26"/>
        <source>Du moins visité au plus visité</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/HistoriqueWidget.cpp" line="27"/>
        <source>Du premier jour à aujourd&apos;hui</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/HistoriqueWidget.cpp" line="28"/>
        <source>Du premier jour à aujourd&apos;hui avec toutes les entrées</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MarquesPages</name>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="9"/>
        <source>Marques-Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="511"/>
        <source>Ajouter un dossier...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="512"/>
        <source>Entrez le titre puis l&apos;emplacement de votre nouveau dossier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="515"/>
        <source>Nom : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="521"/>
        <source>Position : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="529"/>
        <source>Avant </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="533"/>
        <location filename="../WebBrowser/MarquesPages.cpp" line="562"/>
        <source>En dernier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/MarquesPages.cpp" line="580"/>
        <source>Suppression...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/MarquesPages.cpp" line="581"/>
        <source>Cochez le(s) marque(s)-page(s) ou dosier(s) de marques-pages à supprimer.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessagesToolBar</name>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="13"/>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="204"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="14"/>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="205"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="15"/>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="206"/>
        <source>Autre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="17"/>
        <source>!! Bienvenue sur FTPBrowser !!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="89"/>
        <source>Upload </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="89"/>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="104"/>
        <source> : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="104"/>
        <source>Download </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="189"/>
        <source>Toutes opérations stoppées.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="189"/>
        <source>Erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/MessagesToolBar.cpp" line="208"/>
        <source>!! Nettoyage terminé !!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModifierLangage</name>
    <message>
        <location filename="../modifierLangage.cpp" line="39"/>
        <source>Modification des langages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../modifierLangage.cpp" line="52"/>
        <source>Entrez la liste des mots séparés par un | (altgr+6)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../modifierLangage.cpp" line="55"/>
        <source>Réinitialiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../modifierLangage.cpp" line="56"/>
        <source>Ajouter un mot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../modifierLangage.cpp" line="57"/>
        <source>Supprimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../modifierLangage.cpp" line="67"/>
        <source>Appliquer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Page</name>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="23"/>
        <source>Fermer cet onglet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="28"/>
        <source>Fermer tous les onglets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="62"/>
        <source>Retour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="67"/>
        <source>Recharger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="73"/>
        <source>Avancer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="79"/>
        <source>Charger cette page dans un nouvel onglet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="87"/>
        <source>Ouvrir l&apos;image dans un nouvel onglet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="92"/>
        <location filename="../WebBrowser/Page.cpp" line="130"/>
        <source>Copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="97"/>
        <source>Enregistrer l&apos;image (non fonctionel)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="109"/>
        <source>Copier l&apos;url du lien</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="115"/>
        <source>Ouvrir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="120"/>
        <source>Ouvrir dans un nouvel onglet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="137"/>
        <source>Couper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="142"/>
        <source>Coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Page.cpp" line="159"/>
        <source>Voir le code source de la page (non fonctionel)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Pages</name>
    <message>
        <location filename="../WebBrowser/Pages.cpp" line="67"/>
        <source>Fermer l&apos;url </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/Pages.cpp" line="79"/>
        <source>Tout fermer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagesTabBar</name>
    <message>
        <location filename="../WebBrowser/PagesTabBar.cpp" line="33"/>
        <source>Double clickez sans relacher pour ajouter aux favoris</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebBrowser</name>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="169"/>
        <source>&amp;Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="171"/>
        <source>&amp;Reculer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="174"/>
        <location filename="../WebBrowser/WebBrowser.cpp" line="181"/>
        <location filename="../WebBrowser/WebBrowser.cpp" line="312"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="175"/>
        <source>Reculer d&apos;une page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="179"/>
        <source>&amp;Recharger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="182"/>
        <source>Recharger la page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="186"/>
        <source>&amp;Avancer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="188"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="189"/>
        <source>Avancer d&apos;une page</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="193"/>
        <source>&amp;Arréter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="195"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="196"/>
        <source>Arréter le chargement de la page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="200"/>
        <source>&amp;Accueil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="202"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="203"/>
        <source>Retour   la page d&apos;accueil</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="234"/>
        <source>Attente des données...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="249"/>
        <source>Téléchargement des données en cours...</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="257"/>
        <source>Téléchargement des données terminé.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="262"/>
        <source>Téléchargement des données échoué.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="283"/>
        <source>http://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="284"/>
        <source>file://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="286"/>
        <source>Google</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="287"/>
        <source>Exalead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="288"/>
        <source>Wikipedia</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="289"/>
        <source>SiteDuZéro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="290"/>
        <source>Codes-Sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="292"/>
        <source>php</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="293"/>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="295"/>
        <source>Aide...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="310"/>
        <source>&amp;Envoyer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="313"/>
        <source>Charger l&apos;url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="330"/>
        <source>Ce panneau vous permet de rechercher simplement et efficacement sur le web.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="331"/>
        <source>Voici une courte explication sur les différentes options : 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="332"/>
        <source>ChoixX : en clickant sur ce choix vous verez apparaitre &apos;ChoixX : &apos; dans la barre des </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="333"/>
        <source>liens. En y ajoutant votre recherche et enssuite en pressant &apos;Enter&apos; vous serez redirigé </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="334"/>
        <source>sur le site X avec la recherche que vous aviez demandé.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="335"/>
        <source>Sites et raccourccis :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="336"/>
        <source>- Général (les espaces) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="337"/>
        <source>          &quot;X:recherche&quot; = &quot;X : recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="338"/>
        <source>- Général (les majusucles) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="339"/>
        <source>          &quot;X:recherche&quot; = &quot;x:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="340"/>
        <source>- Google (www.google.fr) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="341"/>
        <source>          &quot;Google:recherche&quot; = &quot;google:recherche&quot; = &quot;?:recherche&quot;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="342"/>
        <source>- Exalead (www.exalead.fr) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="343"/>
        <source>          &quot;Exalead:recherche&quot; = &quot;exa:recherche&quot; = &quot;??:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="344"/>
        <source>- Wikipédia (http://fr.wikipedia.org) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="345"/>
        <source>          &quot;Wikipedia:recherche&quot; = &quot;wiki:recherche&quot; = &quot;!:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="346"/>
        <source>- SiteDuZéro (www.siteduzero.com) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowser.cpp" line="347"/>
        <source>          &quot;SDZ:recherche&quot; = &quot;§:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="348"/>
        <source>- Codes-Sources (www.codes-sources.com) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="349"/>
        <source>          &quot;codes-sources:recherche&quot; = &quot;cs:recherche&quot; = &quot;*:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="350"/>
        <source>- Php (www.manuelphp.com) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="351"/>
        <source>          &quot;php:recherche&quot; = &quot;$:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="352"/>
        <source>- JavaScript (developer.mozilla.org) :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="353"/>
        <source>          &quot;JavaScript:recherche&quot; = &quot;js:recherche&quot; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowser.cpp" line="457"/>
        <source> Messages... </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebBrowserMenuBar</name>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="32"/>
        <source>Fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="34"/>
        <source>Ouvrir nouvel ongle&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="35"/>
        <source>Ouvrir adresse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="36"/>
        <source>Ouvrir fichier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="37"/>
        <source>Ouvrir fichiers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="39"/>
        <source>Im&amp;primer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="41"/>
        <source>&amp;Fermer onglet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="42"/>
        <source>&amp;Fermer tous les onglets</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="43"/>
        <source>Fermer fenêtre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="103"/>
        <source>Edition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="105"/>
        <source>&amp;Copier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="106"/>
        <source>Couper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="107"/>
        <source>Coller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="108"/>
        <source>Supprimer NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="110"/>
        <source>Tout sélectionner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="112"/>
        <source>Rechercher NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="114"/>
        <source>Préférences NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="169"/>
        <source>Affichage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="171"/>
        <source>Barre d&apos;outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="172"/>
        <source>Commandes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="175"/>
        <source>Url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="178"/>
        <source>Recherche</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="182"/>
        <source>Tout afficher</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="185"/>
        <source>Barre d&apos;état</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="188"/>
        <source>Panneaux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="189"/>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="398"/>
        <source>Marques-Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="192"/>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="323"/>
        <source>Historique</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="195"/>
        <source>Arréter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="196"/>
        <source>Actualiser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="198"/>
        <source>Zoom +</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="199"/>
        <source>Zoom -</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="200"/>
        <source>Encodage NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="325"/>
        <source>Reculer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="326"/>
        <source>Avancer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="327"/>
        <source>Accueil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="328"/>
        <source>Afficher historique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="332"/>
        <source>Les icones de l&apos;historique (relancement obligatoire)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="333"/>
        <source>Les liens de l&apos;historique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="335"/>
        <source>Tout l&apos;historique</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="337"/>
        <source>10 derniers sites visités</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="399"/>
        <source>Marquer cette page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="400"/>
        <source>Marquer tous les onglets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="401"/>
        <source>Ajouter un dossier...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="402"/>
        <source>Suppression...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="404"/>
        <source>Supprimer tous mes Marques-Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="405"/>
        <source>Revenir aux Marques-Pages par défaut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="496"/>
        <source>Outils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="497"/>
        <source>Rechercher sur...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="499"/>
        <source>User Agent NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="500"/>
        <source>Console d&apos;erreur javascript NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="502"/>
        <source>Effacer mes traces NF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="515"/>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="516"/>
        <source>Aide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="517"/>
        <source>Notes de versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="519"/>
        <source>Signaler un bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="520"/>
        <source>Traduire cette application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="522"/>
        <source>Apropos de Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../WebBrowser/WebBrowserMenuBar.cpp" line="523"/>
        <source>Apropos de WebBrowser</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetDistant</name>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="25"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="303"/>
        <source>Répertoir parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="42"/>
        <source>Accueil</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="50"/>
        <source>Créer Dossier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="58"/>
        <source>Recharger</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="128"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="318"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;/&lt;/b&gt;&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="132"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="322"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="132"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="322"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="149"/>
        <source>Ajouter un dossier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="153"/>
        <source>Emplacement : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="170"/>
        <source>Nom : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="178"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="430"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="180"/>
        <source>Valider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="195"/>
        <source>Dossier </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="195"/>
        <source> ajouté.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="296"/>
        <source>Aller à</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="355"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="387"/>
        <source>Vous n&apos;êtes connectez à aucun serveur.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="355"/>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="387"/>
        <source>Erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="412"/>
        <source>Fichier existant !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="424"/>
        <source>Le fichier &lt;b&gt;&lt;font color=&quot;#FFF000000&quot;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="424"/>
        <source>&lt;/font&gt;&lt;/b&gt; existe déjà voulez-vous le remplacer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="426"/>
        <source>Toujours remplacer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetDistant.cpp" line="433"/>
        <source>Accepter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetLigne</name>
    <message>
        <location filename="../Editeur/widgetLigne.cpp" line="136"/>
        <source>Inverser les icones et les lignes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetLocal</name>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="21"/>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="228"/>
        <source>Répertoir parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="38"/>
        <source>Accueil</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="46"/>
        <source>Créer Dossier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="54"/>
        <source>Recharger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="69"/>
        <source>Ajouter un dossier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="73"/>
        <source>Emplacement : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="81"/>
        <source>Nom : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="89"/>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="276"/>
        <source>Annuler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="91"/>
        <source>Valider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="107"/>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="111"/>
        <source>Dossier </source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="107"/>
        <source> ajouté.</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="111"/>
        <source> non ajouté.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="111"/>
        <source>Erreur</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="122"/>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="242"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="122"/>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="242"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="221"/>
        <source>Aller à</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="258"/>
        <source>Fichier existant !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="270"/>
        <source>Le fichier &lt;b&gt;&lt;font color=&quot;#FFF000000&quot;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="270"/>
        <source>&lt;/font&gt;&lt;/b&gt; existe déjà voulez-vous le remplacer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="272"/>
        <source>Toujours remplacer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FTPBrowser/WidgetLocal.cpp" line="279"/>
        <source>Accepter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
