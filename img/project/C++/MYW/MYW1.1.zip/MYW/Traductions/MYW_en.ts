<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_GB" sourcelanguage="fr_FR">
<context>
    <name>ChangerColoration</name>
    <message>
        <location filename="changerColoration.cpp" line="36"/>
        <source>Appliquer</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="37"/>
        <source>Réinitialiser</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="74"/>
        <source>Mots clés php1 :</source>
        <translation>Php keywords 1 :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="75"/>
        <source>Mots clés php2 :</source>
        <translation>Php keywords 2 :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="76"/>
        <source>Mots clés php3 :</source>
        <translation>Php keywords 3 :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="77"/>
        <source>Variables :</source>
        <translation>Variables :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="79"/>
        <location filename="changerColoration.cpp" line="81"/>
        <location filename="changerColoration.cpp" line="83"/>
        <location filename="changerColoration.cpp" line="85"/>
        <location filename="changerColoration.cpp" line="168"/>
        <location filename="changerColoration.cpp" line="170"/>
        <location filename="changerColoration.cpp" line="172"/>
        <location filename="changerColoration.cpp" line="238"/>
        <location filename="changerColoration.cpp" line="240"/>
        <location filename="changerColoration.cpp" line="290"/>
        <location filename="changerColoration.cpp" line="292"/>
        <location filename="changerColoration.cpp" line="349"/>
        <location filename="changerColoration.cpp" line="351"/>
        <location filename="changerColoration.cpp" line="353"/>
        <location filename="changerColoration.cpp" line="355"/>
        <location filename="changerColoration.cpp" line="357"/>
        <source>G</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="80"/>
        <location filename="changerColoration.cpp" line="82"/>
        <location filename="changerColoration.cpp" line="84"/>
        <location filename="changerColoration.cpp" line="86"/>
        <location filename="changerColoration.cpp" line="169"/>
        <location filename="changerColoration.cpp" line="171"/>
        <location filename="changerColoration.cpp" line="173"/>
        <location filename="changerColoration.cpp" line="239"/>
        <location filename="changerColoration.cpp" line="241"/>
        <location filename="changerColoration.cpp" line="291"/>
        <location filename="changerColoration.cpp" line="293"/>
        <location filename="changerColoration.cpp" line="350"/>
        <location filename="changerColoration.cpp" line="352"/>
        <location filename="changerColoration.cpp" line="354"/>
        <location filename="changerColoration.cpp" line="356"/>
        <location filename="changerColoration.cpp" line="358"/>
        <source>I</source>
        <translation>I</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="164"/>
        <source>Mots clés javascript1</source>
        <translation>Javascript keywords 1</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="165"/>
        <source>Mots clés javascript2</source>
        <translation>Javascript keywords 2</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="166"/>
        <source>Mots clés javascript3</source>
        <translation>Javascript keywords 3</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="235"/>
        <source>Mots clés css1</source>
        <translation>Css keywords 1</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="236"/>
        <source>Mots clés css2</source>
        <translation>Css keywords 2</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="287"/>
        <source>Mots clés html :</source>
        <translation>Html keywords :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="288"/>
        <source>Attributs :</source>
        <translation>Attributes :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="336"/>
        <source>Général :</source>
        <translation>General :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="343"/>
        <source>Commentaires simples :</source>
        <translation>Simple comments :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="344"/>
        <source>Commentaires multiples :</source>
        <translation>Multiple comments :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="345"/>
        <source>Quotes :</source>
        <translation>Strings :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="346"/>
        <source>Fonction :</source>
        <translation>Function :</translation>
    </message>
    <message>
        <location filename="changerColoration.cpp" line="347"/>
        <source>&amp; (é commercial):</source>
        <translation>&amp; (ampersand) :</translation>
    </message>
</context>
<context>
    <name>ChoisirLangage</name>
    <message>
        <location filename="choisirLangage.cpp" line="26"/>
        <source>Choisissez le type de coloration que vous souhaitez : </source>
        <translation>Choose the kind of highlighting that you want :</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="28"/>
        <source>Automatique</source>
        <translation>Highlight by tag</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="31"/>
        <source>Personnalisée</source>
        <translation>Customize</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="34"/>
        <source>Php</source>
        <translation>Php</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="37"/>
        <source>Css</source>
        <translation>Css</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="40"/>
        <source>Javascript</source>
        <translation>Javascript</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="43"/>
        <source>Html</source>
        <translation>Html</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="58"/>
        <source>Appliquer</source>
        <translation>Apply</translation>
    </message>
    <message>
        <location filename="choisirLangage.cpp" line="63"/>
        <source>Ici vous pouvez choisir une coloration des mots clés 
reconnus par leurs balises, 
ou choisir une coloration personnalisée 
c&apos;est à dire, colorer les mots clés d&apos;un langage en particulier. 
Vous avez aussi la possibilité de colorer automatiquement 
et de rajouter une coloration personnalisée afin de mieux 
voir les parties de votre code. 
Pour que ces modifications s&apos;appliquent à l&apos;onglet courant, 
vous devez appuyer sur appliquer (ci-dessous) </source>
        <translation>Here, you can choose diferent kind of highlighting, 
you can choose an automatic highlight,
which means by tag, or a customize one. 
Thus, you could highlight a specific language like php,
or choose to highlight php and javascript. 
To apply this modification, 
you have to click on the apply button below.</translation>
    </message>
    <message>
        <source>Ici vous pouvez choisir une coloration des mots clés 
 reconnus par leurs balises, 
 ou choisir une coloration personnalisée 
 c&apos;est à dire, colorer les mots clés d&apos;un langage en particulier. 
 Vous avez aussi la possibilité de colorer automatiquement 
 et de rajouter une coloration personnalisée afin de mieux 
 voir les parties de votre code. 
 Pour que ces modifications s&apos;appliquent à l&apos;onglet courant, 
 vous devez appuyer sur appliquer (ci-dessous) </source>
        <translation type="obsolete">Here, you can choose diferent kind of highlighting, you can choose an automatic highlight, which means by tag, or a customize one. Thus, you could highlight a specific language like php, or choose to highlight php and javascript. To apply this modification, you have to click on the apply button below.</translation>
    </message>
</context>
<context>
    <name>CommandesToolBar</name>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="24"/>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="179"/>
        <source>Connexion Serveur</source>
        <oldsource>Connection Serveur</oldsource>
        <translation>Connect to server</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="36"/>
        <source>Uploader</source>
        <translation>Upload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="44"/>
        <source>Downloader</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="54"/>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="130"/>
        <source>Vider les messages</source>
        <translation>Delete messages</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="76"/>
        <source>Ajouter un serveur</source>
        <translation>Add a server</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="78"/>
        <source>Modifier</source>
        <translation>Change</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="141"/>
        <source>Stopper Actions</source>
        <translation>Stop actions</translation>
    </message>
    <message>
        <location filename="FTPBrowser/CommandesToolBar.cpp" line="171"/>
        <source>Déconnexion</source>
        <oldsource>Déconnection</oldsource>
        <translation>Disconnect</translation>
    </message>
</context>
<context>
    <name>DossiersDistants</name>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="26"/>
        <source>Nom</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="26"/>
        <source>Taille</source>
        <translation>Size</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="26"/>
        <source>Propriétaire</source>
        <translation>Owner</translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="obsolete">Group</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="26"/>
        <source>Dernière modification</source>
        <translation>Last change</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="26"/>
        <source>Groupe</source>
        <translation>Group</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="59"/>
        <source>Connexion impossible : </source>
        <translation>Unable to connect :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="59"/>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="87"/>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="98"/>
        <source>Erreur</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="87"/>
        <source>Déplacement dans un dossier.</source>
        <translation>Move into a directory.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="98"/>
        <source>Récupération d&apos;un fichier.</source>
        <translation>Upload a file.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="137"/>
        <source>Non connecté.</source>
        <translation>No connected.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="147"/>
        <source>Vérification du serveur.</source>
        <translation>Check on the server.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="152"/>
        <source>Connexion.</source>
        <oldsource>Connection.</oldsource>
        <translation>Connection.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="157"/>
        <source>Connecté.</source>
        <translation>Connected.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="162"/>
        <source>Loggé.</source>
        <translation>Logged in.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="174"/>
        <source>Connexion en pause.</source>
        <oldsource>Connextion en pause.</oldsource>
        <translation>Connection in pause.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="364"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;/&lt;/b&gt;&lt;/i&gt;</source>
        <translation>Move into the directory &lt;i&gt;&lt;b&gt;/&lt;/b&gt;&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="368"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation>Move into the directory &lt;i&gt;&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="368"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation>&lt;/b&gt;&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="406"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="407"/>
        <source>Renommer...</source>
        <translation>Rename...</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="409"/>
        <source>Nouveau dossier</source>
        <translation>New directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="410"/>
        <source>Recharger</source>
        <translation>Reload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="414"/>
        <source>Downloader</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="435"/>
        <source>Suppression de </source>
        <translation>Delete from</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="435"/>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="481"/>
        <source>Distant</source>
        <translation>Distant</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="452"/>
        <source>Renommer</source>
        <translation>Rename</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="455"/>
        <source>Fichier : </source>
        <translation>File :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="459"/>
        <source>Nouveau nom : </source>
        <translation>New name :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="466"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="468"/>
        <source>Valider</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersDistants.cpp" line="481"/>
        <source> renommé en </source>
        <translation>Renamed in </translation>
    </message>
</context>
<context>
    <name>DossiersLocaux</name>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="26"/>
        <source>Nom</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="26"/>
        <source>Taille</source>
        <translation>Size</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="26"/>
        <source>Propriétaire</source>
        <translation>Owner</translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="obsolete">Group</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="26"/>
        <source>Dernière modification</source>
        <translation>Last change</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="26"/>
        <source>Groupe</source>
        <translation>Group</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="193"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation>Move into a directory &lt;i&gt;&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="193"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation>&lt;/b&gt;&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="230"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="231"/>
        <source>Renommer...</source>
        <translation>Rename...</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="233"/>
        <source>Nouveau dossier</source>
        <translation>New directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="234"/>
        <source>Recharger</source>
        <translation>Reload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="238"/>
        <source>Uploader</source>
        <translation>Upload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="259"/>
        <source>Suppression de : </source>
        <translation>Delete from: </translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="259"/>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="305"/>
        <source>Local</source>
        <translation>Local</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="276"/>
        <source>Renommer</source>
        <translation>Rename</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="279"/>
        <source>Fichier : </source>
        <translation>File :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="283"/>
        <source>Nouveau nom : </source>
        <translation>New name :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="290"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="292"/>
        <source>Valider</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="FTPBrowser/DossiersLocaux.cpp" line="305"/>
        <source> renommé en </source>
        <translation>Renamed in </translation>
    </message>
</context>
<context>
    <name>EditionWidgetListe</name>
    <message>
        <location filename="editionwidgetliste.cpp" line="18"/>
        <source>Nom de la fiche</source>
        <translation>Bookmark name</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="19"/>
        <source>Chemin de l&apos;image</source>
        <translation>Picture path</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="23"/>
        <source>Mise à jour des fiches, pour supprimer une fiche cliquer sur la case en face de la fiche</source>
        <translation>Bookmark update, to delete a bookmark, click next to it</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="56"/>
        <source>Parcourir</source>
        <translation>Browse</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="57"/>
        <source>Ajouter</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="101"/>
        <source>Ouvrir Image</source>
        <translation>Open picture</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="101"/>
        <source>Image (*.png *.jpg *.bmp *.jpeg *.gif)</source>
        <translation>Picture (*.png *.jpg *.bmp *.jpeg *.gif)</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="261"/>
        <source>Ajout effectué</source>
        <translation>Addition achieved</translation>
    </message>
    <message>
        <location filename="editionwidgetliste.cpp" line="263"/>
        <source>Suppression effectuée</source>
        <oldsource>Suppression effectué</oldsource>
        <translation>Removal achieved</translation>
    </message>
</context>
<context>
    <name>FTPBrowser</name>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="93"/>
        <source>Modifier un serveur</source>
        <translation>Change a server</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="98"/>
        <source>Ajouter un serveur</source>
        <translation>Add a server</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="103"/>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="183"/>
        <source>URL : </source>
        <translation>URL :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="118"/>
        <source>Login : </source>
        <translation>Login :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="132"/>
        <source>Mot de Passe : </source>
        <translation>Password :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="148"/>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="197"/>
        <source>Port : </source>
        <translation>Port :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="162"/>
        <source>Dossier de départ : </source>
        <oldsource>Dossier de dÃ©part : </oldsource>
        <translation>Directory of departure :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="175"/>
        <source>Utiliser un proxy</source>
        <translation>Use a proxy</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="218"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="FTPBrowser/FTPBrowser.cpp" line="220"/>
        <source>Valider</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="WebBrowser/Frame.cpp" line="39"/>
        <source>Choisir un fichier</source>
        <translation>Choose a file</translation>
    </message>
</context>
<context>
    <name>Historique</name>
    <message>
        <location filename="WebBrowser/Historique.cpp" line="32"/>
        <source>Historique</source>
        <translation>Historic</translation>
    </message>
</context>
<context>
    <name>HistoriqueLabel</name>
    <message>
        <location filename="WebBrowser/HistoriqueLabel.cpp" line="55"/>
        <source>Trier...</source>
        <translation>Sort...</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueLabel.cpp" line="58"/>
        <source>Supprimer cette image</source>
        <translation>Delete this picture</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueLabel.cpp" line="60"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueLabel.cpp" line="63"/>
        <source>Tout Supprimer</source>
        <translation>Delete everything</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueLabel.cpp" line="113"/>
        <location filename="WebBrowser/HistoriqueLabel.cpp" line="130"/>
        <source>Vide</source>
        <translation>Empty</translation>
    </message>
</context>
<context>
    <name>HistoriqueWidget</name>
    <message>
        <location filename="WebBrowser/HistoriqueWidget.cpp" line="31"/>
        <source>Du plus visité au moins visité</source>
        <translation>From the most visited to the less visited</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueWidget.cpp" line="32"/>
        <source>D&apos;aujourd&apos;hui jusqu&apos;au premier jour</source>
        <translation>From today until the first day</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueWidget.cpp" line="33"/>
        <source>D&apos;aujourd&apos;hui jusqu&apos;au premier jour avec toutes les entrées</source>
        <translation>From today until the first day, with all the entries</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueWidget.cpp" line="35"/>
        <source>Du moins visité au plus visité</source>
        <translation>From the less visited to the most visited</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueWidget.cpp" line="36"/>
        <source>Du premier jour à aujourd&apos;hui</source>
        <translation>From the first day until today</translation>
    </message>
    <message>
        <location filename="WebBrowser/HistoriqueWidget.cpp" line="37"/>
        <source>Du premier jour à aujourd&apos;hui avec toutes les entrées</source>
        <translation>From the first day until today, with all the entries</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Mon Projet</source>
        <translation type="obsolete">My project</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="44"/>
        <source>MYW</source>
        <translation>MYW</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="154"/>
        <location filename="mainwindow.cpp" line="163"/>
        <source>Fichier</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="155"/>
        <location filename="mainwindow.cpp" line="164"/>
        <source>Edition</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="156"/>
        <location filename="mainwindow.cpp" line="165"/>
        <source>Affichage</source>
        <translation>Display</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="157"/>
        <source>Outils</source>
        <translation>Tools</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="158"/>
        <location filename="mainwindow.cpp" line="166"/>
        <source>Aide</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="159"/>
        <source>Barre d&apos;outils</source>
        <translation>Tool bar</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="173"/>
        <source>Nouveau</source>
        <translation>New</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="177"/>
        <source>Ouvrir...</source>
        <translation>Open...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="181"/>
        <location filename="mainwindow.cpp" line="710"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="185"/>
        <source>Enregistrer Sous...</source>
        <translation>Save as...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="188"/>
        <source>Enregistrer Tout</source>
        <translation>Save all</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="192"/>
        <source>Imprimer...</source>
        <translation>Print...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="196"/>
        <source>Quitter</source>
        <translation>Exit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="201"/>
        <source>Annuler</source>
        <translation>Undo</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="205"/>
        <source>Retablir</source>
        <translation>Redo</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="209"/>
        <source>Couper</source>
        <translation>Cut</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="213"/>
        <source>Copier</source>
        <translation>Copy</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="217"/>
        <source>Coller</source>
        <translation>Paste</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Selectionner Tout</source>
        <translation>Select all</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="225"/>
        <source>Zoom plus</source>
        <translation>Zoom +</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="228"/>
        <source>Zoom Moins</source>
        <translation>Zoom -</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="231"/>
        <source>Rechercher/Remplacer</source>
        <translation>Find/ Replace</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="236"/>
        <source>Numero de Ligne</source>
        <translation>Line number</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="242"/>
        <source>Plein Ecran</source>
        <translation>Full screen</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="248"/>
        <source>Nouveau, enregistrer...</source>
        <translation>New, Save...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="253"/>
        <source>Couper, copier...</source>
        <translation>Cut, Copy...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="258"/>
        <source>Préférences...</source>
        <translation>Options...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="261"/>
        <source>Projet</source>
        <translation>Project</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="267"/>
        <source>Web Browser...</source>
        <translation>Web Browser...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="270"/>
        <source>FTP Browser...</source>
        <translation>FTP Browser...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="273"/>
        <source>Valider la page courante...</source>
        <translation>Validate the current page...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="365"/>
        <location filename="mainwindow.cpp" line="407"/>
        <source>Nouveau*</source>
        <comment>Nouveau fichier titre de l&apos;onglet</comment>
        <translation>New*</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="381"/>
        <source>Mes Projets</source>
        <translation>My Projects</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="412"/>
        <source>Nouveau(</source>
        <translation>New(</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="412"/>
        <source>)*</source>
        <translation>)*</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="645"/>
        <source>Etes-vous sur de vouloir quitter ?</source>
        <translation>Are you sure to quit MYW ?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="665"/>
        <source>Voulez-vous enregistrer le fichier &quot;</source>
        <translation>Do you want to save &quot;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="665"/>
        <source>&quot; ?</source>
        <translation>&quot; ?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="710"/>
        <source>Tout</source>
        <translation>All</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="900"/>
        <location filename="mainwindow.cpp" line="920"/>
        <source>ligne(s): </source>
        <translation>line(s) :</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="900"/>
        <location filename="mainwindow.cpp" line="901"/>
        <source> ;</source>
        <translation> ;</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="901"/>
        <location filename="mainwindow.cpp" line="921"/>
        <source>caractère(s): </source>
        <translation>character(s):</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="973"/>
        <source>Valider la page courante auprès du W3C</source>
        <translation>Validate the current page by using W3C</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="977"/>
        <source>Enregistrez la page courante pour la valider</source>
        <translation>To validate the current page, save it first</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1018"/>
        <source>Bienvenue dans MYW !
</source>
        <translation>Welcome in MYW !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1020"/>
        <source>Choisissez votre espace de travail en sélectionnant le répertoire où seront créés vos projets.</source>
        <translation>Choose your workspace, by choosing the directory where your project will be created.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1039"/>
        <source>Sélectionner...</source>
        <translation>Select...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1043"/>
        <source>Valider</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>MarquesPages</name>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="18"/>
        <source>Marques-Pages</source>
        <translation>Bookmarks</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="530"/>
        <source>Ajouter un dossier...</source>
        <translation>Add a directory...</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="531"/>
        <source>Entrez le titre puis l&apos;emplacement de votre nouveau dossier.</source>
        <translation>Add the title and the path of your new directory.</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="534"/>
        <source>Nom : </source>
        <translation>Name :</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="540"/>
        <source>Position : </source>
        <translation>Location :</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="548"/>
        <source>Avant </source>
        <translation>Before</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="552"/>
        <location filename="WebBrowser/MarquesPages.cpp" line="581"/>
        <source>En dernier</source>
        <translation>Last</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="599"/>
        <source>Suppression...</source>
        <translation>Removal...</translation>
    </message>
    <message>
        <location filename="WebBrowser/MarquesPages.cpp" line="600"/>
        <source>Cochez le(s) marque(s)-page(s) ou dosier(s) de marques-pages à  supprimer.</source>
        <oldsource>Cochez le(s) marque(s)-page(s) ou dosier(s) de marques-pages à supprimer.</oldsource>
        <translation>Check bookmark(s) or directory(ies) of bookmarks to be deleted.</translation>
    </message>
</context>
<context>
    <name>MessagesToolBar</name>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="213"/>
        <source>Icon</source>
        <translation>Icon</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="23"/>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="214"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="22"/>
        <source>Icone</source>
        <translation>Icon</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="24"/>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="215"/>
        <source>Autre</source>
        <translation>Other</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="26"/>
        <source>!! Bienvenue sur FTPBrowser !!</source>
        <translation>!! Welcome on FTPBrowser !!</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="98"/>
        <source>Upload </source>
        <translation>Upload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="98"/>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="113"/>
        <source> : </source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="113"/>
        <source>Download </source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="198"/>
        <source>Toutes opérations stoppées.</source>
        <translation>All operations are stopped.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="198"/>
        <source>Erreur</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="FTPBrowser/MessagesToolBar.cpp" line="217"/>
        <source>!! Nettoyage terminé !!</source>
        <translation>!! Cleanup is over !!</translation>
    </message>
</context>
<context>
    <name>ModifierLangage</name>
    <message>
        <location filename="modifierLangage.cpp" line="39"/>
        <source>Modification des langages :</source>
        <translation>Change the list of keywords :</translation>
    </message>
    <message>
        <location filename="modifierLangage.cpp" line="41"/>
        <source>Choississez le langage à modifier :</source>
        <translation>Choose the language you want to change :</translation>
    </message>
    <message>
        <location filename="modifierLangage.cpp" line="51"/>
        <source>Entrez la liste des mots séparés par un | (altgr+6)</source>
        <translation>Put a list of key words, split by a |</translation>
    </message>
    <message>
        <location filename="modifierLangage.cpp" line="54"/>
        <source>Réinitialiser</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="modifierLangage.cpp" line="55"/>
        <source>Ajouter un mot</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="modifierLangage.cpp" line="56"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="modifierLangage.cpp" line="66"/>
        <source>Appliquer</source>
        <translation>Apply</translation>
    </message>
</context>
<context>
    <name>Page</name>
    <message>
        <location filename="WebBrowser/Page.cpp" line="32"/>
        <source>Fermer cet onglet</source>
        <translation>Close this tab</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="37"/>
        <source>Fermer tous les onglets</source>
        <translation>Close all tabs</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="71"/>
        <source>Retour</source>
        <translation>Back</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="76"/>
        <source>Recharger</source>
        <translation>Reload</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="82"/>
        <source>Avancer</source>
        <translation>Move</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="88"/>
        <source>Charger cette page dans un nouvel onglet</source>
        <translation>Load this page in a new tab</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="96"/>
        <source>Ouvrir l&apos;image dans un nouvel onglet</source>
        <translation>Open the picture in a new tab</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="101"/>
        <location filename="WebBrowser/Page.cpp" line="139"/>
        <source>Copier</source>
        <translation>Copy</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="106"/>
        <source>Enregistrer l&apos;image (non fonctionel)</source>
        <translation>Save the picture (unusable)</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="118"/>
        <source>Copier l&apos;url du lien</source>
        <translation>Copy the link URL</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="124"/>
        <source>Ouvrir</source>
        <translation>Open</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="129"/>
        <source>Ouvrir dans un nouvel onglet</source>
        <translation>Open in a new tab</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="146"/>
        <source>Couper</source>
        <translation>Cut</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="151"/>
        <source>Coller</source>
        <translation>Paste</translation>
    </message>
    <message>
        <location filename="WebBrowser/Page.cpp" line="168"/>
        <source>Voir le code source de la page (non fonctionel)</source>
        <translation>See the source code of this page</translation>
    </message>
</context>
<context>
    <name>Pages</name>
    <message>
        <location filename="WebBrowser/Pages.cpp" line="76"/>
        <source>Fermer l&apos;url </source>
        <translation>Close URL</translation>
    </message>
    <message>
        <location filename="WebBrowser/Pages.cpp" line="88"/>
        <source>Tout fermer</source>
        <translation>Close everything</translation>
    </message>
</context>
<context>
    <name>PagesTabBar</name>
    <message>
        <location filename="WebBrowser/PagesTabBar.cpp" line="42"/>
        <source>Double cliquez sans relacher pour ajouter aux favoris</source>
        <oldsource>Double clickez sans relacher pour ajouter aux favoris</oldsource>
        <translation>Double clic without any release to add to bookmarks</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="Preferences.cpp" line="16"/>
        <source>Langages</source>
        <translation>Languages </translation>
    </message>
    <message>
        <location filename="Preferences.cpp" line="17"/>
        <source>Choisir type coloration</source>
        <translation>Change kind of hilighting</translation>
    </message>
    <message>
        <location filename="Preferences.cpp" line="18"/>
        <source>Changer couleur</source>
        <translation>Change color</translation>
    </message>
    <message>
        <location filename="Preferences.cpp" line="19"/>
        <source>Signets</source>
        <translation>Bookmarks</translation>
    </message>
    <message>
        <location filename="Preferences.cpp" line="23"/>
        <source>Tout Appliquer</source>
        <translation>Apply all</translation>
    </message>
    <message>
        <location filename="Preferences.cpp" line="24"/>
        <source>Quitter</source>
        <translation>Exit</translation>
    </message>
</context>
<context>
    <name>WebBrowser</name>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="178"/>
        <source>&amp;Actions</source>
        <translation>&amp;Actions</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="180"/>
        <source>&amp;Reculer</source>
        <translation>Move back</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="183"/>
        <location filename="WebBrowser/WebBrowser.cpp" line="190"/>
        <location filename="WebBrowser/WebBrowser.cpp" line="321"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="184"/>
        <source>Reculer d&apos;une page</source>
        <translation>Move back of a page</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="188"/>
        <source>&amp;Recharger</source>
        <translation>&amp;Reload</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="191"/>
        <source>Recharger la page</source>
        <translation>Reload the page</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="195"/>
        <source>&amp;Avancer</source>
        <translation>Move forw&amp;ard</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="197"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="198"/>
        <source>Avancer d&apos;une page</source>
        <translation>Move forward of a page</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="202"/>
        <source>&amp;Arrêter</source>
        <oldsource>&amp;Arréter</oldsource>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="204"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="205"/>
        <source>Arrêter le chargement de la page</source>
        <oldsource>Arréter le chargement de la page</oldsource>
        <translation>Stop the page loading</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="209"/>
        <source>&amp;Accueil</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="211"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="212"/>
        <source>Retour à la page d&apos;accueil</source>
        <oldsource>Retour   la page d&apos;accueil</oldsource>
        <translation>Back to home page</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="243"/>
        <source>Attente des données...</source>
        <translation>Waiting for data...</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="258"/>
        <source>Téléchargement des données en cours...</source>
        <translation>Downloading data...</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="266"/>
        <source>Téléchargement des données terminé.</source>
        <translation>Data downloading is over.</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="271"/>
        <source>Téléchargement des données échoué.</source>
        <translation>Data downloading failed.</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="292"/>
        <source>http://</source>
        <translation>http://</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="293"/>
        <source>file://</source>
        <translation>file://</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="295"/>
        <source>Google</source>
        <translation>Google</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="296"/>
        <source>Exalead</source>
        <translation>Exalead</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="297"/>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="298"/>
        <source>SiteDuZéro</source>
        <translation>SiteDuZéro</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="299"/>
        <source>Codes-Sources</source>
        <translation>Codes-Sources</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="301"/>
        <source>php</source>
        <translation>php</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="302"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="304"/>
        <source>Aide...</source>
        <translation>Help...</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="319"/>
        <source>&amp;Envoyer</source>
        <translation>S&amp;end</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="322"/>
        <source>Charger l&apos;url</source>
        <translation>Change URL</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="339"/>
        <source>Ce panneau vous permet de rechercher simplement et efficacement sur le web.

</source>
        <translation>This window allows you to find easily and efficiently, things on the web.</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="340"/>
        <source>Voici une courte explication sur les différentes options : 
</source>
        <translation>Here, you can find explanations to use those functions :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="341"/>
        <source>ChoixX : en cliquant sur ce choix vous verrez apparaître &apos;ChoixX : &apos; dans la barre des </source>
        <oldsource>ChoixX : en cliquant sur ce choix vous verez apparaitre &apos;ChoixX : &apos; dans la barre des </oldsource>
        <translation>ChoiceX : By clicking on this choice, you will see &apos;ChoiceX&apos; on the link bar.</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="342"/>
        <source>liens. En y ajoutant votre recherche et ensuite en pressant &apos;Entrée&apos; vous serez redirigé </source>
        <oldsource>liens. En y ajoutant votre recherche et enssuite en pressant &apos;Enter&apos; vous serez redirigé </oldsource>
        <translation>Then, you just have to add what you are looking for, and push the enter key, thus, you will be redirected </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="343"/>
        <source>sur le site X avec la recherche que vous aviez demandé.

</source>
        <translation>on the X site, with the search that you made.</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="344"/>
        <source>Sites et raccourccis :
</source>
        <translation>Site and Shortcuts :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="345"/>
        <source>- Général (les espaces) :
</source>
        <translation>- General (spaces ) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="346"/>
        <source>          &quot;X:recherche&quot; = &quot;X : recherche&quot; 
</source>
        <translation>&quot;X:search&quot; = &quot;X : &quot;search&quot;</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="347"/>
        <source>- Général (les majusucles) :
</source>
        <translation>- General (capital letters) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="348"/>
        <source>          &quot;X:recherche&quot; = &quot;x:recherche&quot; 
</source>
        <translation>&quot;X:search&quot; = &quot;x:serach&quot;</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="349"/>
        <source>- Google (www.google.fr) :
</source>
        <translation>- Google (www.google.fr) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="350"/>
        <source>          &quot;Google:recherche&quot; = &quot;google:recherche&quot; = &quot;?:recherche&quot;
</source>
        <translation>&quot;Google:search&quot; = &quot;google:search&quot; = &quot;?:search&quot;</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="351"/>
        <source>- Exalead (www.exalead.fr) :
</source>
        <translation>- Exalead (www.exalead.fr) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="352"/>
        <source>          &quot;Exalead:recherche&quot; = &quot;exa:recherche&quot; = &quot;??:recherche&quot; 
</source>
        <translation>&quot;Exalead:search&quot; = &quot;exa:search&quot; = &quot;??:search&quot; </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="353"/>
        <source>- Wikipédia (http://fr.wikipedia.org) :
</source>
        <translation>- Wikipédia (http://fr.wikipedia.org) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="354"/>
        <source>          &quot;Wikipedia:recherche&quot; = &quot;wiki:recherche&quot; = &quot;!:recherche&quot; 
</source>
        <translation>&quot;Wikipedia:search&quot; = &quot;wiki:search&quot; = &quot;!:search&quot; </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="355"/>
        <source>- SiteDuZéro (www.siteduzero.com) :
</source>
        <translation>- SiteDuZéro (www.siteduzero.com) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="356"/>
        <source>          &quot;SDZ:recherche&quot; = &quot;§:recherche&quot; 
</source>
        <oldsource>          &quot;SDZ:recherche&quot; = &quot;Â§:recherche&quot; 
</oldsource>
        <translation>&quot;SDZ:search&quot; = &quot;§:search&quot; </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="357"/>
        <source>- Codes-Sources (www.codes-sources.com) :
</source>
        <translation>- Codes-Sources (www.codes-sources.com) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="358"/>
        <source>          &quot;codes-sources:recherche&quot; = &quot;cs:recherche&quot; = &quot;*:recherche&quot; 
</source>
        <translation>&quot;codes-sources:search&quot; = &quot;cs:search&quot; = &quot;*:search&quot; </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="359"/>
        <source>- Php (www.manuelphp.com) :
</source>
        <translation>- Php (www.manuelphp.com) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="360"/>
        <source>          &quot;php:recherche&quot; = &quot;$:recherche&quot; 
</source>
        <translation>&quot;php:search&quot; = &quot;$:search&quot; </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="361"/>
        <source>- JavaScript (developer.mozilla.org) :
</source>
        <translation>- JavaScript (developer.mozilla.org) :</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="362"/>
        <source>          &quot;JavaScript:recherche&quot; = &quot;js:recherche&quot; 
</source>
        <translation> &quot;JavaScript:search&quot; = &quot;js:search&quot; </translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowser.cpp" line="466"/>
        <source> Messages... </source>
        <translation>Messages...</translation>
    </message>
</context>
<context>
    <name>WebBrowserMenuBar</name>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="41"/>
        <source>Fichier</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="43"/>
        <source>Ouvrir nouvel ongle&amp;t</source>
        <translation>Open a new &amp;tab</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="44"/>
        <source>Ouvrir adresse</source>
        <translation>Open link</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="45"/>
        <source>Ouvrir fichier</source>
        <translation>Open file</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="46"/>
        <source>Ouvrir fichiers</source>
        <translation>Open files</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="48"/>
        <source>Im&amp;primer</source>
        <translation>&amp;Print</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="50"/>
        <source>&amp;Fermer onglet</source>
        <translation>Close current tab</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="51"/>
        <source>&amp;Fermer tous les onglets</source>
        <translation>Close all tabs</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="52"/>
        <source>Fermer fenêtre</source>
        <oldsource>Fermer fenÃªtre</oldsource>
        <translation>Close window</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="112"/>
        <source>Edition</source>
        <translation>Edit</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="114"/>
        <source>&amp;Copier</source>
        <translation>&amp;Copy</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="115"/>
        <source>Couper</source>
        <translation>Cut</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="116"/>
        <source>Coller</source>
        <translation>Paste</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="117"/>
        <source>Supprimer NF</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="119"/>
        <source>Tout sélectionner</source>
        <oldsource>Tout sÃ©lectionner</oldsource>
        <translation>Select all</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="121"/>
        <source>Rechercher NF</source>
        <translation>Find</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="123"/>
        <source>Préférences NF</source>
        <oldsource>PrÃ©fÃ©rences NF</oldsource>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="178"/>
        <source>Affichage</source>
        <translation>Display</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="180"/>
        <source>Barre d&apos;outils</source>
        <translation>Tool bar</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="181"/>
        <source>Commandes</source>
        <translation>Controls</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="184"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="187"/>
        <source>Recherche</source>
        <translation>Find</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="191"/>
        <source>Tout afficher</source>
        <translation>Display all</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="194"/>
        <source>Barre d&apos;état</source>
        <oldsource>Barre d&apos;Ã©tat</oldsource>
        <translation>State bar</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="197"/>
        <source>Panneaux</source>
        <translation>Panels</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="198"/>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="407"/>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="416"/>
        <source>Marques-Pages</source>
        <translation>Bookmarks</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="201"/>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="332"/>
        <source>Historique</source>
        <translation>Historic</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="204"/>
        <source>Arréter</source>
        <oldsource>ArrÃ©ter</oldsource>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="205"/>
        <source>Actualiser</source>
        <translation>Refresh</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="207"/>
        <source>Zoom +</source>
        <translation>Zoom +</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="208"/>
        <source>Zoom -</source>
        <translation>Zoom -</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="209"/>
        <source>Encodage NF</source>
        <translation>Coding</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="334"/>
        <source>Reculer</source>
        <translation>Move back</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="335"/>
        <source>Avancer</source>
        <translation>Move forward</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="336"/>
        <source>Accueil</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="337"/>
        <source>Afficher historique</source>
        <translation>Display Historic</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="340"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="341"/>
        <source>Les icones de l&apos;historique (relancement obligatoire)</source>
        <translation>Historic&apos;s icons (refresh needed)</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="342"/>
        <source>Les liens de l&apos;historique</source>
        <translation>Historic &apos;s links</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="344"/>
        <source>Tout l&apos;historique</source>
        <translation>All historic</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="346"/>
        <source>10 derniers sites visités</source>
        <oldsource>10 derniers sites visitÃ©s</oldsource>
        <translation>10 last visited sites</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="408"/>
        <source>Marquer cette page</source>
        <translation>Bookmark this page</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="409"/>
        <source>Marquer tous les onglets</source>
        <translation>Bookmark all tabs</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="410"/>
        <source>Ajouter un dossier...</source>
        <translation>Add a directory...</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="411"/>
        <source>Suppression...</source>
        <translation>Removal...</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="413"/>
        <source>Supprimer tous mes Marques-Pages</source>
        <translation>Remove all the bookmarks</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="414"/>
        <source>Revenir aux Marques-Pages par défaut</source>
        <oldsource>Revenir aux Marques-Pages par dÃ©faut</oldsource>
        <translation>Get back to the default bookmarks</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="505"/>
        <source>Outils</source>
        <translation>Tools</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="506"/>
        <source>Rechercher sur...</source>
        <translation>Find on...</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="508"/>
        <source>User Agent NF</source>
        <translation>User Agent</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="509"/>
        <source>Console d&apos;erreur javascript NF</source>
        <translation>Javascript console</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="511"/>
        <source>Effacer mes traces NF</source>
        <translation>Delete my traces</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="524"/>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="525"/>
        <source>Aide</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="526"/>
        <source>Notes de versions</source>
        <translation>Versions notes</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="528"/>
        <source>Signaler un bug</source>
        <translation>Report bugs</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="529"/>
        <source>Traduire cette application</source>
        <translation>Translate this application</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="531"/>
        <source>A propos de Qt</source>
        <oldsource>Apropos de Qt</oldsource>
        <translation>About Qt</translation>
    </message>
    <message>
        <location filename="WebBrowser/WebBrowserMenuBar.cpp" line="532"/>
        <source>A propos de WebBrowser</source>
        <oldsource>Apropos de WebBrowser</oldsource>
        <translation>About WebBrowser</translation>
    </message>
</context>
<context>
    <name>WidgetDistant</name>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="34"/>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="312"/>
        <source>Répertoire parent</source>
        <oldsource>Répertoir parent</oldsource>
        <translation>Parent directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="51"/>
        <source>Accueil</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="59"/>
        <source>Créer Dossier</source>
        <translation>New directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="67"/>
        <source>Recharger</source>
        <translation>Reload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="137"/>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="327"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;/&lt;/b&gt;&lt;/i&gt;</source>
        <translation>Move into the directory &lt;i&gt;&lt;b&gt;/&lt;/b&gt;&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="141"/>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="331"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation>Move into the directory &lt;i&gt;&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="141"/>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="331"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation>&lt;/b&gt;&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="158"/>
        <source>Ajouter un dossier</source>
        <translation>Add a directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="162"/>
        <source>Emplacement : </source>
        <translation>Location :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="179"/>
        <source>Nom : </source>
        <translation>Name :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="187"/>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="439"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="189"/>
        <source>Valider</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="204"/>
        <source>Dossier </source>
        <translation>Directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="204"/>
        <source> ajouté.</source>
        <translation>added.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="305"/>
        <source>Aller à </source>
        <oldsource>Aller à</oldsource>
        <translation>Go to</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="364"/>
        <source>Vous n&apos;êtes connecté à aucun serveur.</source>
        <translation>You are not connected.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="396"/>
        <source>Vous n&apos;êtes connectez à  aucun serveur.</source>
        <oldsource>Vous n&apos;êtes connectez à aucun serveur.</oldsource>
        <translation>You are not connected.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="364"/>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="396"/>
        <source>Erreur</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="421"/>
        <source>Fichier existant !</source>
        <translation>File already exist !</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="433"/>
        <source>Le fichier &lt;b&gt;&lt;font color=&quot;#FFF000000&quot;&gt;</source>
        <translation>File &lt;b&gt;&lt;font color=&quot;#FFF000000&quot;&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="433"/>
        <source>&lt;/font&gt;&lt;/b&gt; existe déjà  voulez-vous le remplacer ?</source>
        <translation>&lt;/font&gt;&lt;/b&gt; already exist, do you want to replace it ?</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="435"/>
        <source>Toujours remplacer.</source>
        <translation>Always replace.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetDistant.cpp" line="442"/>
        <source>Accepter</source>
        <translation>Accept</translation>
    </message>
</context>
<context>
    <name>WidgetLigne</name>
    <message>
        <location filename="Editeur/widgetLigne.cpp" line="134"/>
        <source>Inverser les icones et les lignes</source>
        <translation>Reverse lines / icons</translation>
    </message>
</context>
<context>
    <name>WidgetLocal</name>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="31"/>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="238"/>
        <source>Répertoire parent</source>
        <oldsource>Répertoir parent</oldsource>
        <translation>Parent directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="48"/>
        <source>Accueil</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="56"/>
        <source>Créer Dossier</source>
        <translation>New directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="64"/>
        <source>Recharger</source>
        <translation>Reload</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="79"/>
        <source>Ajouter un dossier</source>
        <translation>Add a directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="83"/>
        <source>Emplacement : </source>
        <translation>Location :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="91"/>
        <source>Nom : </source>
        <translation>Name :</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="99"/>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="286"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="101"/>
        <source>Valider</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="117"/>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="121"/>
        <source>Dossier </source>
        <translation>Directory</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="117"/>
        <source> ajouté.</source>
        <translation>added.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="121"/>
        <source> non ajouté.</source>
        <translation>not added.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="121"/>
        <source>Erreur</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="132"/>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="252"/>
        <source>Déplacement dans le dossier &lt;i&gt;&lt;b&gt;</source>
        <translation>Move into the directory &lt;i&gt;&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="132"/>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="252"/>
        <source>&lt;/b&gt;&lt;/i&gt;</source>
        <translation>&lt;/b&gt;&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="231"/>
        <source>Aller à </source>
        <oldsource>Aller Ã </oldsource>
        <translation>Go to</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="268"/>
        <source>Fichier existant !</source>
        <translation>File already exist !</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="280"/>
        <source>Le fichier &lt;b&gt;&lt;font color=&quot;#FFF000000&quot;&gt;</source>
        <translation>File &lt;b&gt;&lt;font color=&quot;#FFF000000&quot;&gt;</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="280"/>
        <source>&lt;/font&gt;&lt;/b&gt; existe déjà voulez-vous le remplacer ?</source>
        <translation>&lt;/font&gt;&lt;/b&gt; already exist, do you want to replace it ?</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="282"/>
        <source>Toujours remplacer.</source>
        <translation>Always replace.</translation>
    </message>
    <message>
        <location filename="FTPBrowser/WidgetLocal.cpp" line="289"/>
        <source>Accepter</source>
        <translation>Accept</translation>
    </message>
</context>
</TS>
