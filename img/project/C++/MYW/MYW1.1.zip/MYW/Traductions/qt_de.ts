<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<defaultcodec></defaultcodec>
<context>
    <name>AudioOutput</name>
    <message>
        <location filename="../src/3rdparty/phonon/phonon/audiooutput.cpp" line="+374"/>
        <source>&lt;html&gt;The audio playback device &lt;b&gt;%1&lt;/b&gt; does not work.&lt;br/&gt;Falling back to &lt;b&gt;%2&lt;/b&gt;.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Das Audiogerät &lt;b&gt;%1&lt;/b&gt; funktioniert nicht.&lt;br/&gt;Es wird stattdessen &lt;b&gt;%2&lt;/b&gt; verwendet.&lt;/html&gt;</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which just became available and has higher preference.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Das Audiogerät &lt;b&gt;%1&lt;/b&gt; wurde aktiviert,&lt;br/&gt;da es gerade verfügbar und höher priorisiert ist.&lt;/html&gt;</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Revert back to device &apos;%1&apos;</source>
        <translation>Zurückschalten zum Gerät &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>CloseButton</name>
    <message>
        <location filename="../src/gui/widgets/qtabbar.cpp" line="+2217"/>
        <source>Close Tab</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>Phonon::</name>
    <message>
        <location filename="../src/3rdparty/phonon/phonon/phononnamespace.cpp" line="+55"/>
        <source>Notifications</source>
        <translation>Benachrichtungen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Music</source>
        <translation>Musik</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Communication</source>
        <translation>Kommunikation</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Games</source>
        <translation>Spiele</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Accessibility</source>
        <translation>Eingabehilfen</translation>
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::Backend</name>
    <message>
        <location filename="../src/3rdparty/phonon/gstreamer/backend.cpp" line="+171"/>
        <source>Warning: You do not seem to have the package gstreamer0.10-plugins-good installed.
          Some video features have been disabled.</source>
        <translation>Warnung: Das Paket  gstreamer0.10-plugins-good ist nicht installiert.
Einige Video-Funktionen stehen nicht zur  Verfügung.</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Warning: You do not seem to have the base GStreamer plugins installed.
          All audio and video support has been disabled</source>
        <translation>Warnung: Die grundlegenden GStreamer-plugins sind nicht installiert.￼
Die Audio- und Video-Unterstützung wurde abgeschaltet</translation>
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::MediaObject</name>
    <message>
        <location filename="../src/3rdparty/phonon/gstreamer/mediaobject.cpp" line="+88"/>
        <source>Cannot start playback. 

Check your Gstreamer installation and make sure you 
have libgstreamer-plugins-base installed.</source>
        <translation>Das Abspielen konnte nicht gestartet werden.
Bitte prüfen Sie die Gstreamer-Installation und stellen Sie sicher, dass das Paket libgstreamer-plugins-base installiert ist.</translation>
    </message>
    <message>
        <location line="+113"/>
        <source>A required codec is missing. You need to install the following codec(s) to play this content: %0</source>
        <translation>Es sind nicht alle erforderlichen Codecs installiert. Um diesen Inhalt abzuspielen, muss der folgende Codec installiert werden: %0</translation>
    </message>
    <message>
        <location line="+653"/>
        <location line="+9"/>
        <location line="+15"/>
        <location line="+7"/>
        <location line="+5"/>
        <location line="+20"/>
        <location line="+317"/>
        <location line="+24"/>
        <source>Could not open media source.</source>
        <translation>Die Medienquelle konnte nicht geöffnet werden.</translation>
    </message>
    <message>
        <location line="-381"/>
        <source>Invalid source type.</source>
        <translation>Ungültiger Typ der Medienquelle.</translation>
    </message>
    <message>
        <location line="+355"/>
        <source>Could not locate media source.</source>
        <translation>Die Medienquelle konnte nicht gefunden werden.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Could not open audio device. The device is already in use.</source>
        <translation>Das Audiogerät konnte nicht geöffnet werden, da es bereits in Benutzung ist.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Could not decode media source.</source>
        <translation>Die Medienquelle konnte nicht gefunden werden.</translation>
    </message>
</context>
<context>
    <name>Phonon::VolumeSlider</name>
    <message>
        <location filename="../src/3rdparty/phonon/phonon/volumeslider.cpp" line="+42"/>
        <location line="+18"/>
        <source>Volume: %1%</source>
        <translation>Lautstärke: %1%</translation>
    </message>
    <message>
        <location line="-15"/>
        <location line="+18"/>
        <location line="+54"/>
        <source>Use this slider to adjust the volume. The leftmost position is 0%, the rightmost is %1%</source>
        <translation>Die Regler wird zur Einstellung der Lautstärke benutzt. Die Position links entspricht 0%; die Position rechts entspricht %1%</translation>
    </message>
</context>
<context>
    <name>Q3Accel</name>
    <message>
        <location filename="../src/qt3support/other/q3accel.cpp" line="+451"/>
        <source>%1, %2 not defined</source>
        <translation>%1, %2 sind nicht definiert</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>Ambiguous %1 not handled</source>
        <translation>Mehrdeutige %1 können nicht verarbeitet werden</translation>
    </message>
</context>
<context>
    <name>Q3DataTable</name>
    <message>
        <location filename="../src/qt3support/sql/q3datatable.cpp" line="+253"/>
        <source>True</source>
        <translation>Wahr</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>False</source>
        <translation>Falsch</translation>
    </message>
    <message>
        <location line="+505"/>
        <source>Insert</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
</context>
<context>
    <name>Q3FileDialog</name>
    <message>
        <location filename="../src/qt3support/dialogs/q3filedialog.cpp" line="+834"/>
        <source>Copy or Move a File</source>
        <translation>Datei kopieren oder verschieben</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Read: %1</source>
        <translation>Lesen: %1</translation>
    </message>
    <message>
        <location line="+6"/>
        <location line="+30"/>
        <source>Write: %1</source>
        <translation>Schreiben: %1</translation>
    </message>
    <message>
        <location line="-22"/>
        <location line="+1575"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="-157"/>
        <location line="+49"/>
        <location line="+2153"/>
        <location filename="../src/qt3support/dialogs/q3filedialog_mac.cpp" line="+80"/>
        <source>All Files (*)</source>
        <translation>Alle Dateien (*)</translation>
    </message>
    <message>
        <location line="-2089"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Attributes</source>
        <translation>Attribute</translation>
    </message>
    <message>
        <location line="+35"/>
        <location line="+2031"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location line="-1991"/>
        <source>Look &amp;in:</source>
        <translation>Su&amp;chen in:</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+1981"/>
        <location line="+16"/>
        <source>File &amp;name:</source>
        <translation>Datei&amp;name:</translation>
    </message>
    <message>
        <location line="-1996"/>
        <source>File &amp;type:</source>
        <translation>Datei&amp;typ:</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>One directory up</source>
        <translation>Ein Verzeichnis zurück</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Create New Folder</source>
        <translation>Neuen Ordner erstellen</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>List View</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Detail View</source>
        <translation>Ausführlich</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Preview File Info</source>
        <translation>Voransicht der Datei-Information</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Preview File Contents</source>
        <translation>Voransicht des Datei-Inhalts</translation>
    </message>
    <message>
        <location line="+88"/>
        <source>Read-write</source>
        <translation>Lesen/Schreiben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Read-only</source>
        <translation>Nur Lesen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Write-only</source>
        <translation>Nur Schreiben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Inaccessible</source>
        <translation>Gesperrt</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Symlink to File</source>
        <translation>Verknüpfung mit Datei</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Symlink to Directory</source>
        <translation>Verknüpfung mit Verzeichnis</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Symlink to Special</source>
        <translation>Verknüpfung mit Spezialdatei</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Dir</source>
        <translation>Verzeichnis</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Special</source>
        <translation>Spezialattribut</translation>
    </message>
    <message>
        <location line="+704"/>
        <location line="+2100"/>
        <location filename="../src/qt3support/dialogs/q3filedialog_win.cpp" line="+307"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location line="-1990"/>
        <location filename="../src/qt3support/dialogs/q3filedialog_win.cpp" line="+84"/>
        <source>Save As</source>
        <translation>Speichern unter</translation>
    </message>
    <message>
        <location line="+642"/>
        <location line="+5"/>
        <location line="+355"/>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <location line="-357"/>
        <location line="+341"/>
        <source>&amp;Save</source>
        <translation>S&amp;peichern</translation>
    </message>
    <message>
        <location line="-334"/>
        <source>&amp;Rename</source>
        <translation>&amp;Umbenennen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>R&amp;eload</source>
        <translation>Erne&amp;ut laden</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Sort by &amp;Name</source>
        <translation>Nach &amp;Name sortieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Sort by &amp;Size</source>
        <translation>Nach &amp;Größe sortieren</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Sort by &amp;Date</source>
        <translation>Nach &amp;Datum sortieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Unsorted</source>
        <translation>&amp;Unsortiert</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Sort</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Show &amp;hidden files</source>
        <translation>&amp;Versteckte Dateien anzeigen</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>the file</source>
        <translation>die Datei</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>the directory</source>
        <translation>das Verzeichnis</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>the symlink</source>
        <translation>die Verknüpfung</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Delete %1</source>
        <translation>%1 löschen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&lt;qt&gt;Are you sure you wish to delete %1 &quot;%2&quot;?&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;Sind Sie sicher, dass Sie %1 &quot;%2&quot; löschen möchten?&lt;/qt&gt;</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;No</source>
        <translation>&amp;Nein</translation>
    </message>
    <message>
        <location line="+36"/>
        <source>New Folder 1</source>
        <translation>Neues Verzeichnis 1</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New Folder</source>
        <translation>Neues Verzeichnis</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>New Folder %1</source>
        <translation>Neues Verzeichnis %1</translation>
    </message>
    <message>
        <location line="+98"/>
        <source>Find Directory</source>
        <translation>Verzeichnis suchen</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+108"/>
        <source>Directories</source>
        <translation>Verzeichnisse</translation>
    </message>
    <message>
        <location line="-2"/>
        <source>Directory:</source>
        <translation>Verzeichnis:</translation>
    </message>
    <message>
        <location line="+40"/>
        <location line="+1110"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location line="-1109"/>
        <source>%1
File not found.
Check path and filename.</source>
        <translation>%1
Datei konnte nicht gefunden werden.
Überprüfen Sie Pfad und Dateinamen.</translation>
    </message>
    <message>
        <location filename="../src/qt3support/dialogs/q3filedialog_win.cpp" line="-289"/>
        <source>All Files (*.*)</source>
        <translation>Alle Dateien (*.*)</translation>
    </message>
    <message>
        <location line="+375"/>
        <source>Open </source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location line="+155"/>
        <source>Select a Directory</source>
        <translation>Wählen Sie ein Verzeichnis</translation>
    </message>
</context>
<context>
    <name>Q3LocalFs</name>
    <message>
        <location filename="../src/qt3support/network/q3localfs.cpp" line="+100"/>
        <location line="+10"/>
        <source>Could not read directory
%1</source>
        <translation>Konnte Verzeichnis nicht lesen
%1</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Could not create directory
%1</source>
        <translation>Konnte Verzeichnis nicht erstellen
%1</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Could not remove file or directory
%1</source>
        <translation>Konnte Datei oder Verzeichnis nicht löschen
%1</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Could not rename
%1
to
%2</source>
        <translation>Konnte nicht umbenannt werden:
%1
nach
%2</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Could not open
%1</source>
        <translation>Konnte nicht geöffnet werden:
%1</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>Could not write
%1</source>
        <translation>Konnte nicht geschrieben werden:
%1</translation>
    </message>
</context>
<context>
    <name>Q3MainWindow</name>
    <message>
        <location filename="../src/qt3support/widgets/q3mainwindow.cpp" line="+2021"/>
        <source>Line up</source>
        <translation>Ausrichten</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Customize...</source>
        <translation>Anpassen...</translation>
    </message>
</context>
<context>
    <name>Q3NetworkProtocol</name>
    <message>
        <location filename="../src/qt3support/network/q3networkprotocol.cpp" line="+824"/>
        <source>Operation stopped by the user</source>
        <translation>Operation von Benutzer angehalten</translation>
    </message>
</context>
<context>
    <name>Q3ProgressDialog</name>
    <message>
        <location filename="../src/qt3support/dialogs/q3progressdialog.cpp" line="+194"/>
        <location line="+61"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>Q3TabDialog</name>
    <message>
        <location filename="../src/qt3support/dialogs/q3tabdialog.cpp" line="+159"/>
        <location line="+814"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location line="-356"/>
        <source>Apply</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Defaults</source>
        <translation>Defaults</translation>
    </message>
    <message>
        <location line="+50"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>Q3TextEdit</name>
    <message>
        <location filename="../src/qt3support/text/q3textedit.cpp" line="+5399"/>
        <source>&amp;Undo</source>
        <translation>&amp;Rückgängig</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Redo</source>
        <translation>Wieder&amp;herstellen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Cu&amp;t</source>
        <translation>&amp;Ausschneiden</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Paste</source>
        <translation>Einf&amp;ügen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Clear</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location line="+4"/>
        <location line="+2"/>
        <source>Select All</source>
        <translation>Alles auswählen</translation>
    </message>
</context>
<context>
    <name>Q3TitleBar</name>
    <message>
        <location filename="../src/plugins/accessible/compat/q3complexwidgets.cpp" line="+216"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Restore up</source>
        <translation>Wiederherstellen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Minimize</source>
        <translation>Minimieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Restore down</source>
        <translation>Wiederherstellen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Maximize</source>
        <translation>Maximieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Contains commands to manipulate the window</source>
        <translation>Enthält Befehle zum Ändern der Fenstergröße </translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Puts a minimized back to normal</source>
        <translation>Stellt ein minimiertes Fenster wieder her</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Moves the window out of the way</source>
        <translation>Minimiert das Fenster</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Puts a maximized window back to normal</source>
        <translation>Stellt ein maximiertes Fenster wieder her</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Makes the window full screen</source>
        <translation>Vollbildmodus</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Closes the window</source>
        <translation>Schließt das Fenster</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Displays the name of the window and contains controls to manipulate it</source>
        <translation>Zeigt den Namen des Fensters und enthält Befehle zum Ändern</translation>
    </message>
</context>
<context>
    <name>Q3ToolBar</name>
    <message>
        <location filename="../src/qt3support/widgets/q3toolbar.cpp" line="+662"/>
        <source>More...</source>
        <translation>Mehr...</translation>
    </message>
</context>
<context>
    <name>Q3UrlOperator</name>
    <message>
        <location filename="../src/qt3support/network/q3urloperator.cpp" line="+356"/>
        <location line="+260"/>
        <location line="+4"/>
        <source>The protocol `%1&apos; is not supported</source>
        <translation>Das Protokoll `%1&apos; wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="-260"/>
        <source>The protocol `%1&apos; does not support listing directories</source>
        <translation>Das Protokoll `%1&apos; unterstützt nicht das Auflisten von Verzeichnissen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The protocol `%1&apos; does not support creating new directories</source>
        <translation>Das Protokoll `%1&apos; unterstützt nicht das Anlegen neuer Verzeichnisse</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The protocol `%1&apos; does not support removing files or directories</source>
        <translation>Das Protokoll `%1&apos; unterstützt nicht das Löschen von Dateien oder Verzeichnissen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The protocol `%1&apos; does not support renaming files or directories</source>
        <translation>Das Protokoll `%1&apos; unterstützt nicht das Umbenennen von Dateien oder Verzeichnissen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The protocol `%1&apos; does not support getting files</source>
        <translation>Das Protokoll `%1&apos; unterstützt nicht das Laden von Files</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The protocol `%1&apos; does not support putting files</source>
        <translation>Das Protokoll `%1&apos; unterstützt nicht das Speichern von Files</translation>
    </message>
    <message>
        <location line="+243"/>
        <location line="+4"/>
        <source>The protocol `%1&apos; does not support copying or moving files or directories</source>
        <translation> Das Protokoll `%1&apos; unterstützt nicht das Kopieren oder Verschieben von Dateien oder Verzeichnissen</translation>
    </message>
    <message>
        <location line="+237"/>
        <location line="+1"/>
        <source>(unknown)</source>
        <translation>(unbekannt)</translation>
    </message>
</context>
<context>
    <name>Q3Wizard</name>
    <message>
        <location filename="../src/qt3support/dialogs/q3wizard.cpp" line="+147"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Zurück</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Weiter &gt;</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Finish</source>
        <translation>Ab&amp;schließen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <location filename="../src/network/socket/qabstractsocket.cpp" line="+838"/>
        <location filename="../src/network/socket/qhttpsocketengine.cpp" line="+585"/>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="+627"/>
        <location line="+26"/>
        <source>Host not found</source>
        <translation>Rechner konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="+50"/>
        <location filename="../src/network/socket/qhttpsocketengine.cpp" line="+3"/>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="+4"/>
        <source>Connection refused</source>
        <translation>Verbindung verweigert</translation>
    </message>
    <message>
        <location line="+141"/>
        <source>Connection timed out</source>
        <translation>Das Zeitlimit für die Verbindung wurde überschritten</translation>
    </message>
    <message>
        <location line="-547"/>
        <location line="+787"/>
        <location line="+208"/>
        <source>Operation on socket is not supported</source>
        <translation>Diese Socketoperation wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+137"/>
        <source>Socket operation timed out</source>
        <translation>Das Zeitlimit für die Operation wurde überschritten</translation>
    </message>
    <message>
        <location line="+380"/>
        <source>Socket is not connected</source>
        <translation>Nicht verbunden</translation>
    </message>
    <message>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="-8"/>
        <source>Network unreachable</source>
        <translation>Das Netzwerk ist nicht erreichbar</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <location filename="../src/gui/widgets/qabstractspinbox.cpp" line="+1169"/>
        <source>&amp;Step up</source>
        <translation>&amp;Inkrementieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Step &amp;down</source>
        <translation>&amp;Dekrementieren</translation>
    </message>
    <message>
        <location line="-8"/>
        <source>&amp;Select All</source>
        <translation>&amp;Alles auswählen</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/gui/kernel/qapplication.cpp" line="+2212"/>
        <source>QT_LAYOUT_DIRECTION</source>
        <comment>Translate this string to the string &apos;LTR&apos; in left-to-right languages or to &apos;RTL&apos; in right-to-left languages (such as Hebrew and Arabic) to get proper widget layout.</comment>
        <translation>LTR</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qmessagebox.h" line="+322"/>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation>Die Anwendung &apos;%1&apos; benötigt Qt %2; es wurde aber Qt %3 gefunden.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Incompatible Qt Library Error</source>
        <translation>Qt Bibliothek ist inkompatibel</translation>
    </message>
    <message>
        <location filename="../src/gui/accessible/qaccessibleobject.cpp" line="+346"/>
        <source>Activate</source>
        <translation>Aktivieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Activates the program&apos;s main window</source>
        <translation>Aktiviert das Programmhauptfenster</translation>
    </message>
</context>
<context>
    <name>QAxSelect</name>
    <message>
        <location filename="../src/activeqt/container/qaxselect.ui"/>
        <source>Select ActiveX Control</source>
        <translation>ActiveX-Element auswählen</translation>
    </message>
    <message>
        <location/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location/>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <location/>
        <source>COM &amp;Object:</source>
        <translation>COM-&amp;Objekt:</translation>
    </message>
</context>
<context>
    <name>QCheckBox</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/simplewidgets.cpp" line="+84"/>
        <source>Uncheck</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Check</source>
        <translation>Ankreuzen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Toggle</source>
        <translation>Umschalten</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qcolordialog.cpp" line="+1219"/>
        <source>Hu&amp;e:</source>
        <translation>Farb&amp;ton:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Sat:</source>
        <translation>&amp;Sättigung:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Val:</source>
        <translation>&amp;Helligkeit:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Red:</source>
        <translation>&amp;Rot:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Green:</source>
        <translation>&amp;Grün:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bl&amp;ue:</source>
        <translation>Bla&amp;u:</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A&amp;lpha channel:</source>
        <translation>A&amp;lphakanal:</translation>
    </message>
    <message>
        <location line="+101"/>
        <source>Select Color</source>
        <translation>Farbauswahl</translation>
    </message>
    <message>
        <location line="+137"/>
        <source>&amp;Basic colors</source>
        <translation>Grundfar&amp;ben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Custom colors</source>
        <translation>&amp;Benutzerdefinierte Farben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Add to Custom Colors</source>
        <translation>Zu benutzerdefinierten Farben &amp;hinzufügen</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/complexwidgets.cpp" line="+1741"/>
        <location line="+65"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="../src/gui/itemviews/qitemeditorfactory.cpp" line="+514"/>
        <source>False</source>
        <translation>Falsch</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>True</source>
        <translation>Wahr</translation>
    </message>
    <message>
        <location filename="../src/plugins/accessible/widgets/complexwidgets.cpp" line="+0"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <location filename="../src/corelib/kernel/qsystemsemaphore_unix.cpp" line="+89"/>
        <source>%1: key is empty</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: Ungültige Schlüsselangabe (leer)</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>%1: unable to make key</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: Es kann kein Schlüssel erzeugt werden</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>%1: ftok failed</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: ftok-Aufruf schlug fehl</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <location filename="../src/sql/drivers/db2/qsql_db2.cpp" line="+1217"/>
        <source>Unable to connect</source>
        <translation>Es kann keine Verbindung aufgebaut werden</translation>
    </message>
    <message>
        <location line="+263"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Unable to set autocommit</source>
        <translation>&apos;autocommit&apos; konnte nicht aktiviert werden</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <location line="-986"/>
        <location line="+242"/>
        <source>Unable to execute statement</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="-206"/>
        <source>Unable to prepare statement</source>
        <translation>Der Befehl konnte nicht initialisiert werden</translation>
    </message>
    <message>
        <location line="+196"/>
        <source>Unable to bind variable</source>
        <translation>Die Variable konnte nicht gebunden werden</translation>
    </message>
    <message>
        <location line="+91"/>
        <source>Unable to fetch record %1</source>
        <translation>Der Datensatz %1 konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to fetch next</source>
        <translation>Der nächste Datensatz konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Unable to fetch first</source>
        <translation>Der erste Datensatz konnte nicht abgeholt werden</translation>
    </message>
</context>
<context>
    <name>QDateTimeEdit</name>
    <message>
        <location filename="../src/gui/widgets/qdatetimeedit.cpp" line="+2265"/>
        <source>AM</source>
        <translation>AM</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>am</source>
        <translation>am</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>PM</source>
        <translation>PM</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>pm</source>
        <translation>pm</translation>
    </message>
</context>
<context>
    <name>QDial</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="+921"/>
        <source>QDial</source>
        <translation>QDial</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>SpeedoMeter</source>
        <translation>Tachometer</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>SliderHandle</source>
        <translation>Schieberegler</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qdialog.cpp" line="+567"/>
        <source>What&apos;s This?</source>
        <translation>Direkthilfe</translation>
    </message>
    <message>
        <location line="-115"/>
        <source>Done</source>
        <translation>Fertig</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <location filename="../src/gui/dialogs/qmessagebox.cpp" line="+1830"/>
        <location line="+464"/>
        <location filename="../src/gui/widgets/qdialogbuttonbox.cpp" line="+531"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/gui/widgets/qdialogbuttonbox.cpp" line="+3"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Save</source>
        <translation>S&amp;peichern</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Close</source>
        <translation>Schl&amp;ießen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Apply</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Don&apos;t Save</source>
        <translation>Nicht speichern</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Discard</source>
        <translation>Verwerfen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Yes</source>
        <translation>&amp;Ja</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Yes to &amp;All</source>
        <translation>Ja, &amp;alle</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;No</source>
        <translation>&amp;Nein</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>N&amp;o to All</source>
        <translation>N&amp;ein, keine</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Save All</source>
        <translation>Alles speichern</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Abort</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Retry</source>
        <translation>Wiederholen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Ignore</source>
        <translation>Ignorieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Restore Defaults</source>
        <translation>Voreinstellungen</translation>
    </message>
    <message>
        <location line="-29"/>
        <source>Close without Saving</source>
        <translation>Schließen ohne Speichern</translation>
    </message>
    <message>
        <location line="-27"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
</context>
<context>
    <name>QDirModel</name>
    <message>
        <location filename="../src/gui/itemviews/qdirmodel.cpp" line="+423"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Art</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Typ</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Date Modified</source>
        <translation>Änderungsdatum</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/qaccessiblewidgets.cpp" line="+1209"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Dock</source>
        <translation>Andocken</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Float</source>
        <translation>Herauslösen</translation>
    </message>
</context>
<context>
    <name>QDoubleSpinBox</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="-537"/>
        <source>More</source>
        <translation>Mehr</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Less</source>
        <translation>Weniger</translation>
    </message>
</context>
<context>
    <name>QErrorMessage</name>
    <message>
        <location filename="../src/gui/dialogs/qerrormessage.cpp" line="+361"/>
        <source>&amp;Show this message again</source>
        <translation>Diese Meldung noch einmal an&amp;zeigen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location line="-200"/>
        <source>Debug Message:</source>
        <translation>Debug-Ausgabe:</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Warning:</source>
        <translation>Warnung:</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Fatal Error:</source>
        <translation>Fehler:</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <location filename="../src/corelib/io/qfile.cpp" line="+678"/>
        <location line="+130"/>
        <source>Destination file exists</source>
        <translation>Die Zieldatei existiert bereits</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Cannot open %1 for input</source>
        <translation>%1 konnte nicht zum Lesen geöffnet werden</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Cannot open for output</source>
        <translation>Das Öffnen zum Schreiben schlug fehl</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Failure to write block</source>
        <translation>Der Datenblock konnte nicht geschrieben werden</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Cannot create %1 for output</source>
        <translation>%1 kann nicht erstellt werden</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="+484"/>
        <location line="+423"/>
        <source>All Files (*)</source>
        <translation>Alle Dateien (*)</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.ui"/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>List View</source>
        <translation>Liste</translation>
    </message>
    <message>
        <location/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Detail View</source>
        <translation>Details</translation>
    </message>
    <message>
        <location filename="../src/gui/itemviews/qfileiconprovider.cpp" line="+384"/>
        <location line="+1"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="-440"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Save As</source>
        <translation>Speichern unter</translation>
    </message>
    <message>
        <location line="+653"/>
        <location line="+50"/>
        <location line="+1440"/>
        <location line="+75"/>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <location line="-1565"/>
        <location line="+50"/>
        <source>&amp;Save</source>
        <translation>S&amp;peichern</translation>
    </message>
    <message>
        <location line="+1790"/>
        <source>Recent Places</source>
        <translation>Zuletzt besucht</translation>
    </message>
    <message>
        <location line="-2464"/>
        <source>&amp;Rename</source>
        <translation>&amp;Umbenennen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show &amp;hidden files</source>
        <translation>&amp;Versteckte Dateien anzeigen</translation>
    </message>
    <message>
        <location line="+1908"/>
        <source>New Folder</source>
        <translation>Neues Verzeichnis</translation>
    </message>
    <message>
        <location line="-1943"/>
        <source>Find Directory</source>
        <translation>Verzeichnis suchen</translation>
    </message>
    <message>
        <location line="+660"/>
        <source>Directories</source>
        <translation>Verzeichnisse</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog_win.cpp" line="+130"/>
        <source>All Files (*.*)</source>
        <translation>Alle Dateien (*.*)</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="-619"/>
        <location line="+623"/>
        <source>Directory:</source>
        <translation>Verzeichnis:</translation>
    </message>
    <message>
        <location line="+807"/>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>Die Datei %1 existiert bereits.
Soll sie überschrieben werden?</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
Die Datei konnte nicht gefunden werden.
Stellen Sie sicher, dass der Dateiname richtig ist.</translation>
    </message>
    <message>
        <location filename="../src/gui/itemviews/qdirmodel.cpp" line="+402"/>
        <source>My Computer</source>
        <translation>Mein Computer</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.ui"/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Parent Directory</source>
        <translation>Übergeordnetes Verzeichnis</translation>
    </message>
    <message>
        <location/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Files of type:</source>
        <translation>Dateien des Typs:</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="-54"/>
        <location line="+851"/>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Das Verzeichnis konnte nicht gefunden werden.
Stellen Sie sicher, dass der Verzeichnisname richtig ist.</translation>
    </message>
    <message>
        <location line="-217"/>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>&apos;%1&apos; ist schreibgeschützt.
Möchten sie die Datei trotzdem löschen?</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Are sure you want to delete &apos;%1&apos;?</source>
        <translation>Sind Sie sicher, dass Sie %1 löschen möchten?</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Could not delete directory.</source>
        <translation>Konnte Verzeichnis nicht löschen.</translation>
    </message>
    <message>
        <location filename="../src/gui/itemviews/qfileiconprovider.cpp" line="-4"/>
        <source>Drive</source>
        <translation>Laufwerk</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="-2062"/>
        <source>Show </source>
        <translation>Anzeigen </translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.ui"/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Forward</source>
        <translation>Vorwärts</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="+7"/>
        <source>&amp;New Folder</source>
        <translation>&amp;Neues Verzeichnis</translation>
    </message>
    <message>
        <location line="+631"/>
        <location line="+38"/>
        <source>&amp;Choose</source>
        <translation>&amp;Auswählen</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qsidebar.cpp" line="+388"/>
        <source>Remove</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.cpp" line="-662"/>
        <location line="+627"/>
        <source>File &amp;name:</source>
        <translation>Datei&amp;name:</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfiledialog.ui"/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Look in:</source>
        <translation>Suche in:</translation>
    </message>
    <message>
        <location/>
        <location filename="../src/gui/dialogs/qfiledialog_wince.ui"/>
        <source>Create New Folder</source>
        <translation>Neuen Ordner erstellen</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <location filename="../src/gui/dialogs/qfilesystemmodel.cpp" line="+707"/>
        <source>%1 TB</source>
        <translation>%1 TB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>%1 bytes</source>
        <translation>%1 byte</translation>
    </message>
    <message>
        <location line="+77"/>
        <source>Invalid filename</source>
        <translation>Ungültiger Dateiname</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&lt;b&gt;The name &quot;%1&quot; can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation>&lt;b&gt;Der Name &quot;%1&quot; kann nicht verwendet werden.&lt;/b&gt;&lt;p&gt;Versuchen Sie, die Sonderzeichen zu entfernen oder einen kürzeren Namen zu verwenden.</translation>
    </message>
    <message>
        <location line="+63"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Art</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Typ</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Date Modified</source>
        <translation>Änderungsdatum</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qfilesystemmodel_p.h" line="+204"/>
        <source>My Computer</source>
        <translation>Mein Computer</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Computer</source>
        <translation>Computer</translation>
    </message>
</context>
<context>
    <name>QFontDatabase</name>
    <message>
        <location filename="../src/gui/text/qfontdatabase.cpp" line="+60"/>
        <location line="+1176"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location line="-1173"/>
        <location line="+12"/>
        <location line="+1149"/>
        <source>Bold</source>
        <translation>Fett</translation>
    </message>
    <message>
        <location line="-1158"/>
        <location line="+1160"/>
        <source>Demi Bold</source>
        <translation>Halbfett</translation>
    </message>
    <message>
        <location line="-1157"/>
        <location line="+18"/>
        <location line="+1135"/>
        <source>Black</source>
        <translation>Schwarz</translation>
    </message>
    <message>
        <location line="-1145"/>
        <source>Demi</source>
        <translation>Semi</translation>
    </message>
    <message>
        <location line="+6"/>
        <location line="+1145"/>
        <source>Light</source>
        <translation>Leicht</translation>
    </message>
    <message>
        <location line="-1004"/>
        <location line="+1007"/>
        <source>Italic</source>
        <translation>Kursiv</translation>
    </message>
    <message>
        <location line="-1004"/>
        <location line="+1006"/>
        <source>Oblique</source>
        <translation>Schräggestellt</translation>
    </message>
    <message>
        <location line="+705"/>
        <source>Any</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Latin</source>
        <translation>Lateinisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Greek</source>
        <translation>Griechisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cyrillic</source>
        <translation>Kyrillisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Armenian</source>
        <translation>Armenisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Hebrew</source>
        <translation>Hebräisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Arabic</source>
        <translation>Arabisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Syriac</source>
        <translation>Syrisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Thaana</source>
        <translation>Thaana</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Devanagari</source>
        <translation>Devanagari</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Bengali</source>
        <translation>Bengalisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Gurmukhi</source>
        <translation>Gurmukhi</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Tamil</source>
        <translation>Tamilisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Sinhala</source>
        <translation>Sinhala</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Thai</source>
        <translation>Thailändisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Lao</source>
        <translation>Laotisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Tibetan</source>
        <translation>Tibetisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Georgian</source>
        <translation>Georgisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Simplified Chinese</source>
        <translation>Vereinfachtes Chinesisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Traditional Chinese</source>
        <translation>Traditionelles Chinesisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Japanese</source>
        <translation>Japanisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Korean</source>
        <translation>Koreanisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Vietnamese</source>
        <translation>Vietnamesisch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Symbol</source>
        <translation>Symbol</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Ogham</source>
        <translation>Ogham</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Runic</source>
        <translation>Runen</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qfontdialog.cpp" line="+742"/>
        <source>&amp;Font</source>
        <translation>&amp;Schriftart</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Font st&amp;yle</source>
        <translation>Schrifts&amp;til</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Size</source>
        <translation>&amp;Größe</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Effects</source>
        <translation>Effekte</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Stri&amp;keout</source>
        <translation>Durch&amp;gestrichen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Underline</source>
        <translation>&amp;Unterstrichen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Sample</source>
        <translation>Beispiel</translation>
    </message>
    <message>
        <location line="-603"/>
        <location line="+247"/>
        <source>Select Font</source>
        <translation>Schriftart auswählen</translation>
    </message>
    <message>
        <location line="+357"/>
        <source>Wr&amp;iting System</source>
        <translation>&amp;Schriftsystem</translation>
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+2273"/>
        <source>Host %1 found</source>
        <translation>Rechner %1 gefunden</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Host found</source>
        <translation>Rechner gefunden</translation>
    </message>
    <message>
        <location filename="../src/network/access/qftp.cpp" line="+973"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="-1456"/>
        <location line="+1451"/>
        <source>Connected to host %1</source>
        <translation>Verbunden mit Rechner %1</translation>
    </message>
    <message>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+7"/>
        <source>Connected to host</source>
        <translation>Verbindung mit Rechner besteht</translation>
    </message>
    <message>
        <location line="-5"/>
        <source>Connection to %1 closed</source>
        <translation>Verbindung mit %1 beendet</translation>
    </message>
    <message>
        <location filename="../src/network/access/qftp.cpp" line="+1375"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="-243"/>
        <location line="+250"/>
        <source>Connection closed</source>
        <translation>Verbindung beendet</translation>
    </message>
    <message>
        <location line="-1487"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="-1566"/>
        <source>Host %1 not found</source>
        <translation>Rechner %1 konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+4"/>
        <source>Connection refused to host %1</source>
        <translation>Verbindung mit %1 verweigert</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Connection timed out to host %1</source>
        <translation>Das Zeitlimit für die Verbindung zu &apos;%1&apos; wurde überschritten</translation>
    </message>
    <message>
        <location line="+501"/>
        <location line="+29"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+458"/>
        <location line="+728"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
    <message>
        <location line="+889"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+77"/>
        <source>Connecting to host failed:
%1</source>
        <translation>Verbindung mit Rechner schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Login failed:
%1</source>
        <translation>Anmeldung schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Listing directory failed:
%1</source>
        <translation>Der Inhalt des Verzeichnisses kann nicht angezeigt werden:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Changing directory failed:
%1</source>
        <translation>Ändern des Verzeichnises schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Downloading file failed:
%1</source>
        <translation>Herunterladen der Datei schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Uploading file failed:
%1</source>
        <translation>Hochladen der Datei schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Removing file failed:
%1</source>
        <translation>Löschen der Datei schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Creating directory failed:
%1</source>
        <translation>Erstellen des Verzeichnises schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+3"/>
        <source>Removing directory failed:
%1</source>
        <translation>Löschen des Verzeichnises schlug fehl:
%1</translation>
    </message>
    <message>
        <location line="-1524"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="-1356"/>
        <source>Not connected</source>
        <translation>Keine Verbindung</translation>
    </message>
    <message>
        <location line="+396"/>
        <location filename="../src/qt3support/network/q3ftp.cpp" line="+332"/>
        <source>Connection refused for data connection</source>
        <translation>Verbindung für die Daten Verbindung verweigert</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <location filename="../src/network/kernel/qhostinfo_p.h" line="+153"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <location filename="../src/network/kernel/qhostinfo_unix.cpp" line="+148"/>
        <location line="+9"/>
        <location line="+64"/>
        <location line="+31"/>
        <location filename="../src/network/kernel/qhostinfo_win.cpp" line="+150"/>
        <location line="+9"/>
        <location line="+40"/>
        <location line="+27"/>
        <source>Host not found</source>
        <translation>Rechner konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="-44"/>
        <location line="+39"/>
        <location filename="../src/network/kernel/qhostinfo_win.cpp" line="-34"/>
        <location line="+29"/>
        <source>Unknown address type</source>
        <translation>Unbekannter Adresstyp</translation>
    </message>
    <message>
        <location line="+8"/>
        <location filename="../src/network/kernel/qhostinfo_win.cpp" line="-19"/>
        <location line="+27"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="+1712"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+1806"/>
        <source>Connection refused</source>
        <translation>Verbindung verweigert</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttp.cpp" line="+2597"/>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="-4"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+3"/>
        <source>Host %1 not found</source>
        <translation>Rechner %1 konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="-62"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="-45"/>
        <source>Wrong content length</source>
        <translation>Ungültige Längenangabe</translation>
    </message>
    <message>
        <location line="+82"/>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="+10"/>
        <location line="+19"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+48"/>
        <source>HTTP request failed</source>
        <translation>HTTP-Anfrage fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../src/qt3support/network/q3http.cpp" line="+450"/>
        <source>Host %1 found</source>
        <translation>Rechner %1 gefunden</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Host found</source>
        <translation>Rechner gefunden</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Connected to host %1</source>
        <translation>Verbunden mit Rechner %1</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Connected to host</source>
        <translation>Verbindung mit Rechner besteht</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>Connection to %1 closed</source>
        <translation>Verbindung mit %1 beendet</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="-22"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+14"/>
        <source>Connection closed</source>
        <translation>Verbindung beendet</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttp.cpp" line="-1073"/>
        <location line="+816"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="-1152"/>
        <location line="+567"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
    <message>
        <location line="-564"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="-370"/>
        <source>Request aborted</source>
        <translation>Anfrage wurde abgebrochen</translation>
    </message>
    <message>
        <location line="+575"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+381"/>
        <source>No server set to connect to</source>
        <translation>Für die Verbindung wurde kein Server-Rechner angegeben</translation>
    </message>
    <message>
        <location line="+168"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+60"/>
        <source>Server closed connection unexpectedly</source>
        <translation>Der Server hat die Verbindung unerwartet geschlossen</translation>
    </message>
    <message>
        <location line="+151"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+113"/>
        <source>Invalid HTTP response header</source>
        <translation>Der Kopfteil der HTTP-Antwort ist ungültig</translation>
    </message>
    <message>
        <location line="+120"/>
        <location line="+48"/>
        <location filename="../src/qt3support/network/q3http.cpp" line="+40"/>
        <location line="+47"/>
        <source>Invalid HTTP chunked body</source>
        <translation>Der Inhalt (chunked body) der HTTP-Antwort ist ungültig</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>Error writing response to device</source>
        <translation>Beim Schreiben der Antwort auf das Ausgabegerät ist ein Fehler aufgetreten</translation>
    </message>
    <message>
        <location line="-173"/>
        <source>Proxy authentication required</source>
        <translation>Proxy-Authentifizierung erforderlich</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Authentication required</source>
        <translation>Authentifizierung erforderlich</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttpnetworkconnection.cpp" line="+6"/>
        <source>Proxy requires authentication</source>
        <translation>Der Proxy-Server verlangt eine Authentifizierung</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Host requires authentication</source>
        <translation>Der Hostrechner verlangt eine Authentifizierung</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Data corrupted</source>
        <translation>Die Daten sind verfälscht</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>SSL handshake failed</source>
        <translation>Es trat ein Fehler im Ablauf des SSL-Protokolls auf.</translation>
    </message>
    <message>
        <location line="-3"/>
        <source>Unknown protocol specified</source>
        <translation>Es wurde ein unbekanntes Protokoll angegeben</translation>
    </message>
    <message>
        <location filename="../src/network/access/qhttp.cpp" line="-133"/>
        <source>Connection refused (or timed out)</source>
        <translation>Verbindung verweigert oder Zeitlimit überschritten</translation>
    </message>
    <message>
        <location line="-2259"/>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation>Die angeforderte HTTPS-Verbindung kann nicht aufgebaut werden, da keine SSL-Unterstützung vorhanden ist</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <location filename="../src/network/socket/qhttpsocketengine.cpp" line="-89"/>
        <source>Did not receive HTTP response from proxy</source>
        <translation>Keine HTTP-Antwort vom Proxy-Server</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Error parsing authentication request from proxy</source>
        <translation>Fehler beim Auswerten der Authentifizierungsanforderung des Proxy-Servers</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Authentication required</source>
        <translation>Authentifizierung erforderlich</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Proxy denied connection</source>
        <translation>Der Proxy-Server hat den Aufbau einer Verbindung verweigert</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Error communicating with HTTP proxy</source>
        <translation>Fehler bei der Kommunikation mit dem Proxy-Server</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Proxy server not found</source>
        <translation>Es konnte kein Proxy-Server gefunden werden</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Proxy connection refused</source>
        <translation>Der Proxy-Server hat den Aufbau einer Verbindung verweigert</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Proxy server connection timed out</source>
        <translation>Bei der Verbindung mit dem Proxy-Server wurde ein Zeitlimit überschritten</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Proxy connection closed prematurely</source>
        <translation>Der Proxy-Server hat die Verbindung vorzeitig beendet</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <location filename="../src/sql/drivers/ibase/qsql_ibase.cpp" line="+1378"/>
        <source>Error opening database</source>
        <translation>Die Datenbankverbindung konnte nicht geöffnet werden</translation>
    </message>
    <message>
        <location line="+54"/>
        <source>Could not start transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Unable to rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <location line="-1077"/>
        <source>Unable to create BLOB</source>
        <translation>Es konnte kein BLOB erzeugt werden</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to write BLOB</source>
        <translation>Der BLOB konnte nicht geschrieben werden</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Unable to open BLOB</source>
        <translation>Der BLOB konnte nicht geöffnet werden</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Unable to read BLOB</source>
        <translation>Der BLOB konnte nicht gelesen werden</translation>
    </message>
    <message>
        <location line="+124"/>
        <location line="+189"/>
        <source>Could not find array</source>
        <translation>Das Feld konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="-157"/>
        <source>Could not get array data</source>
        <translation>Die Daten des Feldes konnten nicht gelesen werden</translation>
    </message>
    <message>
        <location line="+212"/>
        <source>Could not get query info</source>
        <translation>Die erforderlichen Informationen zur Abfrage sind nicht verfügbar</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Could not start transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>Could not allocate statement</source>
        <translation>Die Allokation des Befehls schlug fehl</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Could not prepare statement</source>
        <translation>Der Befehl konnte nicht initalisiert werden</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+7"/>
        <source>Could not describe input statement</source>
        <translation>Es konnte keine Beschreibung des Eingabebefehls erhalten werden</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Could not describe statement</source>
        <translation>Es konnte keine Beschreibung des Befehls erhalten werden</translation>
    </message>
    <message>
        <location line="+115"/>
        <source>Unable to close statement</source>
        <translation>Der Befehl konnte nicht geschlossen werden</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Unable to execute query</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>Could not fetch next item</source>
        <translation>Das nächste Element konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+160"/>
        <source>Could not get statement info</source>
        <translation>Es ist keine Information zum Befehl verfügbar</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <location filename="../src/corelib/global/qglobal.cpp" line="+1830"/>
        <source>Permission denied</source>
        <translation>Zugriff verweigert</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Too many open files</source>
        <translation>Zu viele Dateien geöffnet</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>No such file or directory</source>
        <translation>Die Datei oder das Verzeichnis konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>No space left on device</source>
        <translation>Kein freier Speicherplatz auf dem Gerät vorhanden</translation>
    </message>
    <message>
        <location filename="../src/corelib/io/qiodevice.cpp" line="+1506"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
</context>
<context>
    <name>QInputContext</name>
    <message>
        <location filename="../src/gui/inputmethod/qinputcontextfactory.cpp" line="+212"/>
        <source>XIM</source>
        <translation>XIM</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>XIM input method</source>
        <translation>XIM-Eingabemethode</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Windows input method</source>
        <translation>Windows-Eingabemethode</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Mac OS X input method</source>
        <translation>Mac OS X-Eingabemethode</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qinputdialog.cpp" line="+193"/>
        <source>Enter a value:</source>
        <translation>Geben Sie einen Wert ein:</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <location filename="../src/corelib/plugin/qlibrary.cpp" line="+348"/>
        <source>Could not mmap &apos;%1&apos;: %2</source>
        <translation>Operation mmap fehlgeschlagen für &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>Plugin verification data mismatch in &apos;%1&apos;</source>
        <translation>Die Prüfdaten des Plugins &apos;%1&apos; stimmen nicht überein</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Could not unmap &apos;%1&apos;: %2</source>
        <translation>Operation unmap fehlgeschlagen für &apos;%1&apos;: %2</translation>
    </message>
    <message>
        <location line="+302"/>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>Das Plugin &apos;%1&apos; verwendet eine inkompatible Qt-Bibliothek. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. Expected build key &quot;%2&quot;, got &quot;%3&quot;</source>
        <translation>Das Plugin &apos;%1&apos; verwendet eine inkompatible Qt-Bibliothek. Erforderlicher build-spezifischer Schlüssel &quot;%2&quot;, erhalten &quot;%3&quot;</translation>
    </message>
    <message>
        <location line="+340"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
    <message>
        <location line="-377"/>
        <location filename="../src/corelib/plugin/qpluginloader.cpp" line="+250"/>
        <source>The shared library was not found.</source>
        <translation>Die dynamische Bibliothek konnte nicht gefunden werden.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>Die Datei &apos;%1&apos; ist kein gültiges Qt-Plugin.</translation>
    </message>
    <message>
        <location line="+43"/>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>Das Plugin &apos;%1&apos; verwendet eine inkompatible Qt-Bibliothek. (Im Debug- und Release-Modus erstellte Bibliotheken können nicht zusammen verwendet werden.)</translation>
    </message>
    <message>
        <location filename="../src/corelib/plugin/qlibrary_unix.cpp" line="+179"/>
        <location filename="../src/corelib/plugin/qlibrary_win.cpp" line="+69"/>
        <source>Cannot load library %1: %2</source>
        <translation>Die Library %1 kann nicht geladen werden: %2</translation>
    </message>
    <message>
        <location line="+16"/>
        <location filename="../src/corelib/plugin/qlibrary_win.cpp" line="+26"/>
        <source>Cannot unload library %1: %2</source>
        <translation>Die Library %1 kann nicht entladen werden: %2</translation>
    </message>
    <message>
        <location line="+31"/>
        <location filename="../src/corelib/plugin/qlibrary_win.cpp" line="+15"/>
        <source>Cannot resolve symbol &quot;%1&quot; in %2: %3</source>
        <translation>Das Symbol &quot;%1&quot; kann in %2 nicht aufgelöst werden: %3</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <location filename="../src/gui/widgets/qlineedit.cpp" line="+2679"/>
        <source>Select All</source>
        <translation>Alles auswählen</translation>
    </message>
    <message>
        <location line="-30"/>
        <source>&amp;Undo</source>
        <translation>&amp;Rückgängig</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Redo</source>
        <translation>Wieder&amp;herstellen</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Cu&amp;t</source>
        <translation>&amp;Ausschneiden</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Paste</source>
        <translation>Einf&amp;ügen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <location filename="../src/network/socket/qlocalserver.cpp" line="+196"/>
        <location filename="../src/network/socket/qlocalserver_unix.cpp" line="+201"/>
        <source>%1: Name error</source>
        <translation>%1: Fehlerhafter Name</translation>
    </message>
    <message>
        <location filename="../src/network/socket/qlocalserver_unix.cpp" line="-8"/>
        <source>%1: Permission denied</source>
        <translation>%1: Zugriff verweigert</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>%1: Address in use</source>
        <translation>%1: Die Adresse wird bereits verwendet</translation>
    </message>
    <message>
        <location line="+5"/>
        <location filename="../src/network/socket/qlocalserver_win.cpp" line="+127"/>
        <source>%1: Unknown error %2</source>
        <translation>%1: Unbekannter Fehler %2</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <location filename="../src/network/socket/qlocalsocket_tcp.cpp" line="+102"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+104"/>
        <source>%1: Connection refused</source>
        <translation>%1: Der Aufbau einer Verbindung wurde verweigert</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <source>%1: Remote closed</source>
        <translation>%1: Die Verbindung wurde von der Gegenseite geschlossen</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_win.cpp" line="+50"/>
        <location line="+43"/>
        <source>%1: Invalid name</source>
        <translation>%1: Ungültiger Name</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <source>%1: Socket access error</source>
        <translation>%1: Fehler beim Zugriff auf den Socket</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <source>%1: Socket resource error</source>
        <translation>%1: Socketfehler (Ressourcenproblem)</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <source>%1: Socket operation timed out</source>
        <translation>%1: Zeitüberschreitung bei Socketoperation</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <source>%1: Datagram too large</source>
        <translation>%1: Das Datagramm ist zu groß</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_win.cpp" line="-48"/>
        <source>%1: Connection error</source>
        <translation>%1: Verbindungsfehler</translation>
    </message>
    <message>
        <location line="+3"/>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+3"/>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: Diese Socketoperation wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>%1: Unknown error</source>
        <translation>%1: Unbekannter Fehler</translation>
    </message>
    <message>
        <location filename="../src/network/socket/qlocalsocket_unix.cpp" line="+4"/>
        <location filename="../src/network/socket/qlocalsocket_win.cpp" line="+10"/>
        <source>%1: Unknown error %2</source>
        <translation>%1: Unbekannter Fehler %2</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <location filename="../src/sql/drivers/mysql/qsql_mysql.cpp" line="+1200"/>
        <source>Unable to open database &apos;</source>
        <translation>Die Datenbankverbindung konnte nicht geöffnet werden &apos;</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Unable to connect</source>
        <translation>Es kann keine Verbindung aufgebaut werden</translation>
    </message>
    <message>
        <location line="+123"/>
        <source>Unable to begin transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <location line="-917"/>
        <source>Unable to fetch data</source>
        <translation>Es konnten keine Daten abgeholt werden</translation>
    </message>
    <message>
        <location line="+176"/>
        <source>Unable to execute query</source>
        <translation>Die Abfrage konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to store result</source>
        <translation>Das Ergebnis konnte nicht gespeichert werden</translation>
    </message>
    <message>
        <location line="+189"/>
        <location line="+8"/>
        <source>Unable to prepare statement</source>
        <translation>Der Befehl konnte nicht initialisiert werden</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>Unable to reset statement</source>
        <translation>Der Befehl konnte nicht zurückgesetzt werden</translation>
    </message>
    <message>
        <location line="+87"/>
        <source>Unable to bind value</source>
        <translation>Der Wert konnte nicht gebunden werden</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Unable to execute statement</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+14"/>
        <location line="+21"/>
        <source>Unable to bind outvalues</source>
        <translation>Die Ausgabewerte konnten nicht gebunden werden</translation>
    </message>
    <message>
        <location line="-12"/>
        <source>Unable to store statement results</source>
        <translation>Die Ergebnisse des Befehls konnten nicht gespeichert werden</translation>
    </message>
    <message>
        <location line="-253"/>
        <source>Unable to execute next query</source>
        <translation>Die folgende Abfrage kann nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Unable to store next result</source>
        <translation>Das folgende Ergebnis kann nicht gespeichert werden</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <location filename="../src/gui/widgets/qmdiarea.cpp" line="+260"/>
        <source>(Untitled)</source>
        <translation>(Unbenannt)</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <location filename="../src/gui/widgets/qmdisubwindow.cpp" line="+250"/>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <location line="+72"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="-18"/>
        <source>Minimize</source>
        <translation>Minimieren</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Restore Down</source>
        <translation>Wiederherstellen</translation>
    </message>
    <message>
        <location line="+707"/>
        <source>&amp;Restore</source>
        <translation>Wieder&amp;herstellen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Move</source>
        <translation>Ver&amp;schieben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Size</source>
        <translation>Größe ä&amp;ndern</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Mi&amp;nimize</source>
        <translation>M&amp;inimieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Stay on &amp;Top</source>
        <translation>Im &amp;Vordergrund bleiben</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>&amp;Close</source>
        <translation>Schl&amp;ießen</translation>
    </message>
    <message>
        <location line="-729"/>
        <source>Maximize</source>
        <translation>Maximieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unshade</source>
        <translation>Herabrollen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Shade</source>
        <translation>Aufrollen</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Restore</source>
        <translation>Wiederherstellen</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Menu</source>
        <translation>Menü</translation>
    </message>
    <message>
        <location line="-79"/>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
</context>
<context>
    <name>QMenu</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/qaccessiblemenu.cpp" line="+127"/>
        <location line="+225"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="-224"/>
        <location line="+225"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location line="-223"/>
        <location line="+225"/>
        <location line="+51"/>
        <source>Execute</source>
        <translation>Ausführen</translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <location filename="../src/gui/dialogs/qmessagebox.cpp" line="-1958"/>
        <location line="+852"/>
        <location filename="../src/gui/dialogs/qmessagebox.h" line="-52"/>
        <location line="+8"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location line="+503"/>
        <source>About Qt</source>
        <translation>Über Qt</translation>
    </message>
    <message>
        <location line="-502"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location line="+487"/>
        <source>&lt;p&gt;This program uses Qt version %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;Dieses Programm verwendet Qt-Version %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location line="-1584"/>
        <source>Show Details...</source>
        <translation>Details einblenden...</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Hide Details...</source>
        <translation>Details ausblenden...</translation>
    </message>
    <message>
        <location line="+1570"/>
        <source>&lt;h3&gt;About Qt&lt;/h3&gt;%1&lt;p&gt;Qt is a C++ toolkit for cross-platform application development.&lt;/p&gt;&lt;p&gt;Qt provides single-source portability across MS&amp;nbsp;Windows, Mac&amp;nbsp;OS&amp;nbsp;X, Linux, and all major commercial Unix variants. Qt is also available for embedded devices as Qt for Embedded Linux and Qt for Windows CE.&lt;/p&gt;&lt;p&gt;Qt is a Nokia product. See &lt;a href=&quot;http://qtsoftware.com/qt/&quot;&gt;qtsoftware.com/qt/&lt;/a&gt; for more information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+15"/>
        <source>&lt;p&gt;This program uses Qt Open Source Edition version %1.&lt;/p&gt;&lt;p&gt;Qt Open Source Edition is intended for the development of Open Source applications. You need a commercial Qt license for development of proprietary (closed source) applications.&lt;/p&gt;&lt;p&gt;Please see &lt;a href=&quot;http://qtsoftware.com/company/model/&quot;&gt;qtsoftware.com/company/model/&lt;/a&gt; for an overview of Qt licensing.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMultiInputContext</name>
    <message>
        <location filename="../src/plugins/inputmethods/imsw-multi/qmultiinputcontext.cpp" line="+58"/>
        <source>Select IM</source>
        <translation>Eingabemethode auswählen</translation>
    </message>
</context>
<context>
    <name>QMultiInputContextPlugin</name>
    <message>
        <location filename="../src/plugins/inputmethods/imsw-multi/qmultiinputcontextplugin.cpp" line="+65"/>
        <source>Multiple input method switcher</source>
        <translation>Umschalter für Eingabemethoden</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Multiple input method switcher that uses the context menu of the text widgets</source>
        <translation>Mehrfachumschalter für Eingabemethoden, der das Kontextmenü des Text-Widgets verwendet</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <location filename="../src/network/socket/qnativesocketengine.cpp" line="+176"/>
        <source>The remote host closed the connection</source>
        <translation>Der entfernte Rechner hat die Verbindung geschlossen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Network operation timed out</source>
        <translation>Das Zeitlimit für die Operation wurde überschritten</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Out of resources</source>
        <translation>Keine Resourcen verfügbar</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unsupported socket operation</source>
        <translation>Nichtunterstütztes Socket-Kommando</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Protocol type not supported</source>
        <translation>Das Protokoll wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Invalid socket descriptor</source>
        <translation>Ungültiger Socket-Deskriptor</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Network unreachable</source>
        <translation>Das Netzwerk ist nicht erreichbar</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Permission denied</source>
        <translation>Zugriff verweigert</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Connection timed out</source>
        <translation>Das Zeitlimit für die Verbindung wurde überschritten</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Connection refused</source>
        <translation>Verbindung verweigert</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The bound address is already in use</source>
        <translation>Die angegebene Adresse ist bereits in Gebrauch</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The address is not available</source>
        <translation>Die Adresse ist nicht verfügbar</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>The address is protected</source>
        <translation>Die Adresse ist geschützt</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to send a message</source>
        <translation>Die Nachricht konnte nicht gesendet werden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unable to receive a message</source>
        <translation>Die Nachricht konnte nicht empfangen werden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unable to write</source>
        <translation>Der Schreibvorgang konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Network error</source>
        <translation>Netzwerkfehler</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Another socket is already listening on the same port</source>
        <translation>Auf diesem Port hört bereits ein anderer Socket</translation>
    </message>
    <message>
        <location line="-66"/>
        <source>Unable to initialize non-blocking socket</source>
        <translation>Der nichtblockierende Socket konnte nicht initialisiert werden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Unable to initialize broadcast socket</source>
        <translation>Der Broadcast-Socket konnte nicht initialisiert werden</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>Es wurde versucht, einen IPv6-Socket auf einem System ohne IPv6-Unterstützung zu verwenden</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Host unreachable</source>
        <translation>Der Zielrechner kann nicht erreicht werden</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>Datagram was too large to send</source>
        <translation>Das Datagram konnte nicht gesendet werden, weil es zu groß ist</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Operation on non-socket</source>
        <translation>Operation kann nur auf einen Socket angewandt werden</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
    <message>
        <location line="-3"/>
        <source>The proxy type is invalid for this operation</source>
        <translation>Die Operation kann mit dem Proxy-Typ nicht durchgeführt werden</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <location filename="../src/network/access/qnetworkaccesscachebackend.cpp" line="+35"/>
        <source>Error opening %1</source>
        <translation>%1 konnte nicht geöffnet werden</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <location filename="../src/network/access/qnetworkaccessfilebackend.cpp" line="+69"/>
        <source>Request for opening non-local file %1</source>
        <translation>Anforderung zum Öffnen einer Datei über Netzwerk %1</translation>
    </message>
    <message>
        <location line="+42"/>
        <source>Error opening %1: %2</source>
        <translation>%1 konnte nicht geöffnet werden: %2</translation>
    </message>
    <message>
        <location line="+56"/>
        <source>Write error writing to %1: %2</source>
        <translation>Fehler beim Schreiben zur Datei %1: %2</translation>
    </message>
    <message>
        <location line="+33"/>
        <source>Cannot open %1: Path is a directory</source>
        <translation>%1 kann nicht geöffnet werden: Der Pfad spezifiziert ein Verzeichnis</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>Read error reading from %1: %2</source>
        <translation>Beim Lesen von der Datei %1 trat ein Fehler auf: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFtpBackend</name>
    <message>
        <location filename="../src/network/access/qnetworkaccessftpbackend.cpp" line="+135"/>
        <source>No suitable proxy found</source>
        <translation>Es konnte kein geeigneter Proxy-Server gefunden werden</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>Cannot open %1: is a directory</source>
        <translation>%1 kann nicht geöffnet werden: Es handelt sich um ein Verzeichnis</translation>
    </message>
    <message>
        <location line="+131"/>
        <source>Logging in to %1 failed: authentication required</source>
        <translation>Die Anmeldung bei %1 schlug fehl: Es ist eine Authentifizierung erforderlich</translation>
    </message>
    <message>
        <location line="+39"/>
        <source>Error while downloading %1: %2</source>
        <translation>Beim Herunterladen von %1 trat ein Fehler auf: %2</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Error while uploading %1: %2</source>
        <translation>Beim Hochladen von %1 trat ein Fehler auf: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessHttpBackend</name>
    <message>
        <location filename="../src/network/access/qnetworkaccesshttpbackend.cpp" line="+565"/>
        <source>No suitable proxy found</source>
        <translation>Es konnte kein geeigneter Proxy-Server gefunden werden</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <location line="+128"/>
        <source>Error downloading %1 - server replied: %2</source>
        <translation>Beim Herunterladen von %1 trat ein Fehler auf - Die Antwort des Servers ist: %2</translation>
    </message>
    <message>
        <location filename="../src/network/access/qnetworkreplyimpl.cpp" line="+37"/>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>Das Protokoll &quot;%1&quot; ist unbekannt</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <location line="+422"/>
        <location line="+22"/>
        <source>Operation canceled</source>
        <translation>Operation abgebrochen</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <location filename="../src/sql/drivers/oci/qsql_oci.cpp" line="+2027"/>
        <source>Unable to logon</source>
        <translation>Logon-Vorgang fehlgeschlagen</translation>
    </message>
    <message>
        <location line="-144"/>
        <source>Unable to initialize</source>
        <comment>QOCIDriver</comment>
        <translation>Initialisierung fehlgeschlagen</translation>
    </message>
    <message>
        <location line="+215"/>
        <source>Unable to begin transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Unable to rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <location line="-976"/>
        <location line="+161"/>
        <location line="+15"/>
        <source>Unable to bind column for batch execute</source>
        <translation>Die Spalte konnte nicht für den Stapelverarbeitungs-Befehl gebunden werden</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Unable to execute batch statement</source>
        <translation>Der Stapelverarbeitungs-Befehl konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+302"/>
        <source>Unable to goto next</source>
        <translation>Kann nicht zum nächsten Element gehen</translation>
    </message>
    <message>
        <location line="+59"/>
        <source>Unable to alloc statement</source>
        <translation>Die Allokation des Befehls schlug fehl</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Unable to prepare statement</source>
        <translation>Der Befehl konnte nicht initialisiert werden</translation>
    </message>
    <message>
        <location line="+29"/>
        <location line="+37"/>
        <source>Unable to bind value</source>
        <translation>Der Wert konnte nicht gebunden werden</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Unable to execute select statement</source>
        <translation>Die &apos;select&apos;-Abfrage konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Unable to execute statement</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <location filename="../src/sql/drivers/odbc/qsql_odbc.cpp" line="+1657"/>
        <source>Unable to connect</source>
        <translation>Es kann keine Verbindung aufgebaut werden</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Unable to connect - Driver doesn&apos;t support all needed functionality</source>
        <translation>Es kann keine Verbindung aufgebaut werden weil der Treiber die benötigte Funktionalität nicht vollständig unterstützt</translation>
    </message>
    <message>
        <location line="+234"/>
        <source>Unable to disable autocommit</source>
        <translation>&apos;autocommit&apos; konnte nicht deaktiviert werden</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Unable to enable autocommit</source>
        <translation>&apos;autocommit&apos; konnte nicht aktiviert werden</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <location line="-1204"/>
        <location line="+349"/>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: &apos;SQL_CURSOR_STATIC&apos; konnte nicht als Attribut des Befehls gesetzt werden. Bitte prüfen Sie die Konfiguration Ihres ODBC-Treibers</translation>
    </message>
    <message>
        <location line="-332"/>
        <location line="+625"/>
        <source>Unable to execute statement</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="-554"/>
        <source>Unable to fetch next</source>
        <translation>Der nächste Datensatz konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+279"/>
        <source>Unable to prepare statement</source>
        <translation>Der Befehl konnte nicht initialisiert werden</translation>
    </message>
    <message>
        <location line="+267"/>
        <source>Unable to bind variable</source>
        <translation>Die Variable konnte nicht gebunden werden</translation>
    </message>
    <message>
        <location filename="../src/sql/drivers/db2/qsql_db2.cpp" line="+194"/>
        <location filename="../src/sql/drivers/odbc/qsql_odbc.cpp" line="-474"/>
        <location line="+577"/>
        <source>Unable to fetch last</source>
        <translation>Der letzte Datensatz konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location filename="../src/sql/drivers/odbc/qsql_odbc.cpp" line="-671"/>
        <source>Unable to fetch</source>
        <translation>Es konnten keine Daten abgeholt werden</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Unable to fetch first</source>
        <translation>Der erste Datensatz konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Unable to fetch previous</source>
        <translation>Der vorangegangene Datensatz kann nicht abgeholt werden</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/gui/util/qdesktopservices_mac.cpp" line="+134"/>
        <source>Home</source>
        <translation>Pos1</translation>
    </message>
    <message>
        <location filename="../src/network/access/qnetworkaccessdatabackend.cpp" line="+44"/>
        <source>Operation not supported on %1</source>
        <translation>Diese Operation wird von %1 nicht unterstützt</translation>
    </message>
    <message>
        <location line="+53"/>
        <source>Invalid URI: %1</source>
        <translation>Ungültiger URI: %1</translation>
    </message>
    <message>
        <location filename="../src/network/access/qnetworkaccessdebugpipebackend.cpp" line="+145"/>
        <source>Write error writing to %1: %2</source>
        <translation>Fehler beim Schreiben zur Datei %1: %2</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>Read error reading from %1: %2</source>
        <translation>Beim Lesen von der Datei %1 trat ein Fehler auf: %2</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>Socket error on %1: %2</source>
        <translation>Socketfehler bei %1: %2</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>Der entfernte Rechner hat die Verbindung zu %1 vorzeitig beendet</translation>
    </message>
    <message>
        <location line="+53"/>
        <source>Protocol error: packet of size 0 received</source>
        <translation>Protokollfehler: Ein leeres Datenpaket wurde empfangen</translation>
    </message>
    <message>
        <location filename="../src/network/kernel/qhostinfo.cpp" line="+147"/>
        <location line="+57"/>
        <source>No host name given</source>
        <translation>Es wurde kein Hostname angegeben</translation>
    </message>
</context>
<context>
    <name>QPPDOptionsModel</name>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_unix.cpp" line="+1165"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <location filename="../src/sql/drivers/psql/qsql_psql.cpp" line="+732"/>
        <source>Unable to connect</source>
        <translation>Es kann keine Verbindung aufgebaut werden</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Could not begin transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Could not commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Could not rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+336"/>
        <source>Unable to subscribe</source>
        <translation>Die Registrierung schlug fehl</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Unable to unsubscribe</source>
        <translation>Die Registrierung konnte nicht aufgehoben werden</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <location line="-1035"/>
        <source>Unable to create query</source>
        <translation>Es konnte keine Abfrage erzeugt werden</translation>
    </message>
    <message>
        <location line="+373"/>
        <source>Unable to prepare statement</source>
        <translation>Der Befehl konnte nicht initialisiert werden</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <location filename="../src/gui/dialogs/qpagesetupdialog_unix.cpp" line="+274"/>
        <source>Centimeters (cm)</source>
        <translation>Zentimeter (cm)</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Millimeters (mm)</source>
        <translation>Millimeter (mm)</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Inches (in)</source>
        <translation>Zoll (in)</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Points (pt)</source>
        <translation>Punkte (pt)</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qpagesetupwidget.ui"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location/>
        <source>Paper</source>
        <translation>Papier</translation>
    </message>
    <message>
        <location/>
        <source>Page size:</source>
        <translation>Seitengröße:</translation>
    </message>
    <message>
        <location/>
        <source>Width:</source>
        <translation>Breite:</translation>
    </message>
    <message>
        <location/>
        <source>Height:</source>
        <translation>Höhe:</translation>
    </message>
    <message>
        <location/>
        <source>Paper source:</source>
        <translation>Papierquelle:</translation>
    </message>
    <message>
        <location/>
        <source>Orientation</source>
        <translation>Ausrichtung</translation>
    </message>
    <message>
        <location/>
        <source>Portrait</source>
        <translation>Hochformat</translation>
    </message>
    <message>
        <location/>
        <source>Landscape</source>
        <translation>Querformat</translation>
    </message>
    <message>
        <location/>
        <source>Reverse landscape</source>
        <translation>Umgekehrtes Querformat</translation>
    </message>
    <message>
        <location/>
        <source>Reverse portrait</source>
        <translation>Umgekehrtes Hochformat</translation>
    </message>
    <message>
        <location/>
        <source>Margins</source>
        <translation>Ränder</translation>
    </message>
    <message>
        <location/>
        <source>top margin</source>
        <translation>Oberer Rand</translation>
    </message>
    <message>
        <location/>
        <source>left margin</source>
        <translation>Linker Rand</translation>
    </message>
    <message>
        <location/>
        <source>right margin</source>
        <translation>Rechter Rand</translation>
    </message>
    <message>
        <location/>
        <source>bottom margin</source>
        <translation>Unterer Rand</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <location filename="../src/corelib/plugin/qpluginloader.cpp" line="+24"/>
        <source>Unknown error</source>
        <translation>Unbekannter Fehler</translation>
    </message>
    <message>
        <location line="-68"/>
        <source>The plugin was not loaded.</source>
        <translation>Das Plugin wurde nicht geladen.</translation>
    </message>
</context>
<context>
    <name>QPrintDialog</name>
    <message>
        <location filename="../src/gui/painting/qprinterinfo_unix.cpp" line="+68"/>
        <source>locally connected</source>
        <translation>direkt verbunden</translation>
    </message>
    <message>
        <location line="+23"/>
        <location line="+225"/>
        <source>Aliases: %1</source>
        <translation>Alias: %1</translation>
    </message>
    <message>
        <location line="+223"/>
        <location line="+199"/>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_win.cpp" line="+238"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_qws.cpp" line="+345"/>
        <source>Print all</source>
        <translation>Alles drucken</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Print range</source>
        <translation>Bereich drucken</translation>
    </message>
    <message>
        <location line="-48"/>
        <source>A0 (841 x 1189 mm)</source>
        <translation>A0 (841 x 1189 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A1 (594 x 841 mm)</source>
        <translation>A1 (594 x 841 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A2 (420 x 594 mm)</source>
        <translation>A2 (420 x 594 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A3 (297 x 420 mm)</source>
        <translation>A3 (297 x 420 mm)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>A5 (148 x 210 mm)</source>
        <translation>A5 (148 x 210 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A6 (105 x 148 mm)</source>
        <translation>A6 (105 x 148 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A7 (74 x 105 mm)</source>
        <translation>A7 (74 x 105 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A8 (52 x 74 mm)</source>
        <translation>A8 (52 x 74 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A9 (37 x 52 mm)</source>
        <translation>A9 (37 x 52 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B0 (1000 x 1414 mm)</source>
        <translation>B0 (1000 x 1414 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B1 (707 x 1000 mm)</source>
        <translation>B1 (707 x 1000 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B2 (500 x 707 mm)</source>
        <translation>B2 (500 x 707 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B3 (353 x 500 mm)</source>
        <translation>B3 (353 x 500 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B4 (250 x 353 mm)</source>
        <translation>B4 (250 x 353 mm)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>B6 (125 x 176 mm)</source>
        <translation>B6 (125 x 176 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B7 (88 x 125 mm)</source>
        <translation>B7 (88 x 125 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B8 (62 x 88 mm)</source>
        <translation>B8 (62 x 88 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B9 (44 x 62 mm)</source>
        <translation>B9 (44 x 62 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B10 (31 x 44 mm)</source>
        <translation>B10 (31 x 44 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>C5E (163 x 229 mm)</source>
        <translation>C5E (163 x 229 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>DLE (110 x 220 mm)</source>
        <translation>DLE (110 x 220 mm)</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Folio (210 x 330 mm)</source>
        <translation>Folio (210 x 330 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Ledger (432 x 279 mm)</source>
        <translation>Ledger (432 x 279 mm)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Tabloid (279 x 432 mm)</source>
        <translation>Tabloid (279 x 432 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>US Common #10 Envelope (105 x 241 mm)</source>
        <translation>US Common #10 Envelope (105 x 241 mm)</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>A4 (210 x 297 mm, 8.26 x 11.7 inches)</source>
        <translation>A4 (210 x 297 mm)</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>B5 (176 x 250 mm, 6.93 x 9.84 inches)</source>
        <translation>B5 (176 x 250 mm)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Executive (7.5 x 10 inches, 191 x 254 mm)</source>
        <translation>Executive (7,5 x 10 Zoll, 191 x 254 mm)</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Legal (8.5 x 14 inches, 216 x 356 mm)</source>
        <translation>Legal (8,5 x 14 Zoll, 216 x 356 mm)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Letter (8.5 x 11 inches, 216 x 279 mm)</source>
        <translation>Letter (8,5 x 11 Zoll, 216 x 279 mm)</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Print selection</source>
        <translation>Auswahl drucken</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qabstractprintdialog.cpp" line="+80"/>
        <location line="+13"/>
        <location filename="../src/gui/dialogs/qprintdialog_win.cpp" line="-2"/>
        <source>Print</source>
        <translation>Drucken</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_unix.cpp" line="-357"/>
        <source>Print To File ...</source>
        <translation>In Datei drucken</translation>
    </message>
    <message>
        <location line="+80"/>
        <source>File %1 is not writable.
Please choose a different file name.</source>
        <translation>Die Datei %1 ist schreibgeschützt.
Bitte wählen Sie einen anderen Dateinamen.</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>%1 already exists.
Do you want to overwrite it?</source>
        <translation>Die Datei %1 existiert bereits.
Soll sie überschrieben werden?</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_qws.cpp" line="-228"/>
        <source>File exists</source>
        <translation>Die Datei existiert bereits</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&lt;qt&gt;Do you want to overwrite it?&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;Soll sie überschrieben werden?&lt;/qt&gt;</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_unix.cpp" line="-8"/>
        <source>%1 is a directory.
Please choose a different file name.</source>
        <translation>%1 ist ein Verzeichnis.
Bitte wählen Sie einen anderen Dateinamen.</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_win.cpp" line="+1"/>
        <source>The &apos;From&apos; value cannot be greater than the &apos;To&apos; value.</source>
        <translation>Die Angabe für die erste Seite darf nicht größer sein als die für die letzte Seite.</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qpagesetupdialog_unix.cpp" line="-232"/>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B6</source>
        <translation>B6</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B7</source>
        <translation>B7</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B8</source>
        <translation>B8</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B9</source>
        <translation>B9</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>B10</source>
        <translation>B10</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>C5E</source>
        <translation>C5E</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>DLE</source>
        <translation>DLE</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Executive</source>
        <translation>Executive</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Folio</source>
        <translation>Folio</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Ledger</source>
        <translation>Ledger</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Legal</source>
        <translation>Legal</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Letter</source>
        <translation>Letter</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Tabloid</source>
        <translation>Tabloid</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>US Common #10 Envelope</source>
        <translation>US Common #10 Envelope</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Custom</source>
        <translation>Benutzerdefiniert</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qprintdialog_unix.cpp" line="-522"/>
        <location line="+68"/>
        <source>&amp;Options &gt;&gt;</source>
        <translation>&amp;Einstellungen &gt;&gt;</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Options &lt;&lt;</source>
        <translation>&amp;Einstellungen &lt;&lt; </translation>
    </message>
    <message>
        <location line="+253"/>
        <source>Print to File (PDF)</source>
        <translation>Druck in PDF-Datei</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Print to File (Postscript)</source>
        <translation>Druck in Postscript-Datei</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Local file</source>
        <translation>Lokale Datei</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Write %1 file</source>
        <translation>Schreiben der Datei %1</translation>
    </message>
    <message>
        <location line="-367"/>
        <source>&amp;Print</source>
        <translation>&amp;Drucken</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qprintpreviewdialog.cpp" line="+222"/>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
    <message>
        <location line="+79"/>
        <source>Print Preview</source>
        <translation>Druckvorschau</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>Next page</source>
        <translation>Nächste Seite</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Previous page</source>
        <translation>Vorige Seite</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>First page</source>
        <translation>Erste Seite</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Last page</source>
        <translation>Letzte Seite</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Fit width</source>
        <translation>Breite anpassen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Fit page</source>
        <translation>Seite anpassen</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Zoom in</source>
        <translation>Vergrößern</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Zoom out</source>
        <translation>Verkleinern</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Portrait</source>
        <translation>Hochformat</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Landscape</source>
        <translation>Querformat</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Show single page</source>
        <translation>Einzelne Seite anzeigen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show facing pages</source>
        <translation>Gegenüberliegende Seiten anzeigen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Show overview of all pages</source>
        <translation>Übersicht aller Seiten</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Print</source>
        <translation>Drucken</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Page setup</source>
        <translation>Seite einrichten</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="+151"/>
        <source>Export to PDF</source>
        <translation>PDF exportieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Export to PostScript</source>
        <translation>PostScript exportieren</translation>
    </message>
    <message>
        <location filename="../src/gui/dialogs/qabstractpagesetupdialog.cpp" line="+38"/>
        <location line="+12"/>
        <source>Page Setup</source>
        <translation>Seite einrichten</translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <location filename="../src/gui/dialogs/qprintpropertieswidget.ui"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location/>
        <source>Page</source>
        <translation>Seite</translation>
    </message>
    <message>
        <location/>
        <source>Advanced</source>
        <translation>Erweitert</translation>
    </message>
</context>
<context>
    <name>QPrintSettingsOutput</name>
    <message>
        <location filename="../src/gui/dialogs/qprintsettingsoutput.ui"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location/>
        <source>Copies</source>
        <translation>Anzahl Exemplare</translation>
    </message>
    <message>
        <location/>
        <source>Print range</source>
        <translation>Bereich drucken</translation>
    </message>
    <message>
        <location/>
        <source>Print all</source>
        <translation>Alles drucken</translation>
    </message>
    <message>
        <location/>
        <source>Pages from</source>
        <translation>Seiten von</translation>
    </message>
    <message>
        <location/>
        <source>to</source>
        <translation>bis</translation>
    </message>
    <message>
        <location/>
        <source>Selection</source>
        <translation>Auswahl</translation>
    </message>
    <message>
        <location/>
        <source>Output Settings</source>
        <translation>Ausgabeeinstellungen</translation>
    </message>
    <message>
        <location/>
        <source>Copies:</source>
        <translation>Anzahl Exemplare:</translation>
    </message>
    <message>
        <location/>
        <source>Collate</source>
        <translation>Sortieren</translation>
    </message>
    <message>
        <location/>
        <source>Reverse</source>
        <translation>Umgekehrt</translation>
    </message>
    <message>
        <location/>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <location/>
        <source>Color Mode</source>
        <translation>Farbmodus</translation>
    </message>
    <message>
        <location/>
        <source>Color</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <location/>
        <source>Grayscale</source>
        <translation>Graustufen</translation>
    </message>
    <message>
        <location/>
        <source>Duplex Printing</source>
        <translation>Duplexdruck</translation>
    </message>
    <message>
        <location/>
        <source>None</source>
        <translation>Kein</translation>
    </message>
    <message>
        <location/>
        <source>Long side</source>
        <translation>Lange Seite</translation>
    </message>
    <message>
        <location/>
        <source>Short side</source>
        <translation>Kurze Seite</translation>
    </message>
</context>
<context>
    <name>QPrintWidget</name>
    <message>
        <location filename="../src/gui/dialogs/qprintwidget.ui"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location/>
        <source>Printer</source>
        <translation>Drucker</translation>
    </message>
    <message>
        <location/>
        <source>&amp;Name:</source>
        <translation>&amp;Name:</translation>
    </message>
    <message>
        <location/>
        <source>P&amp;roperties</source>
        <translation>&amp;Eigenschaften</translation>
    </message>
    <message>
        <location/>
        <source>Location:</source>
        <translation>Standort:</translation>
    </message>
    <message>
        <location/>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <location/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location/>
        <source>Output &amp;file:</source>
        <translation>Ausgabe&amp;datei:</translation>
    </message>
    <message>
        <location/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <location filename="../src/corelib/io/qprocess_unix.cpp" line="+445"/>
        <location filename="../src/corelib/io/qprocess_win.cpp" line="+117"/>
        <source>Could not open input redirection for reading</source>
        <translation>Die Eingabeumleitung konnte nicht zum Lesen geöffnet werden</translation>
    </message>
    <message>
        <location line="+12"/>
        <location filename="../src/corelib/io/qprocess_win.cpp" line="+36"/>
        <source>Could not open output redirection for writing</source>
        <translation>Die Ausgabeumleitung konnte nicht zum Lesen geöffnet werden</translation>
    </message>
    <message>
        <location line="+235"/>
        <source>Resource error (fork failure): %1</source>
        <translation>Ressourcenproblem (&quot;fork failure&quot;): %1</translation>
    </message>
    <message>
        <location line="+259"/>
        <location line="+53"/>
        <location line="+74"/>
        <location line="+67"/>
        <location filename="../src/corelib/io/qprocess_win.cpp" line="+422"/>
        <location line="+50"/>
        <location line="+75"/>
        <location line="+42"/>
        <location line="+54"/>
        <source>Process operation timed out</source>
        <translation>Zeitüberschreitung</translation>
    </message>
    <message>
        <location filename="../src/corelib/io/qprocess.cpp" line="+503"/>
        <location line="+52"/>
        <location filename="../src/corelib/io/qprocess_win.cpp" line="-211"/>
        <location line="+50"/>
        <source>Error reading from process</source>
        <translation>Das Lesen vom Prozess schlug fehl</translation>
    </message>
    <message>
        <location line="+47"/>
        <location line="+779"/>
        <location filename="../src/corelib/io/qprocess_win.cpp" line="+140"/>
        <source>Error writing to process</source>
        <translation>Das Schreiben zum Prozess schlug fehl</translation>
    </message>
    <message>
        <location line="-709"/>
        <source>Process crashed</source>
        <translation>Der Prozess ist abgestürzt</translation>
    </message>
    <message>
        <location filename="../src/corelib/io/qprocess_win.cpp" line="-341"/>
        <source>Process failed to start</source>
        <translation>Das Starten des Prozesses schlug fehl</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <location filename="../src/gui/dialogs/qprogressdialog.cpp" line="+152"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>QPushButton</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/simplewidgets.cpp" line="-8"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
</context>
<context>
    <name>QRadioButton</name>
    <message>
        <location line="+12"/>
        <source>Check</source>
        <translation>Ankreuzen</translation>
    </message>
</context>
<context>
    <name>QRegExp</name>
    <message>
        <location filename="../src/corelib/tools/qregexp.cpp" line="+34"/>
        <source>no error occurred</source>
        <translation>kein Fehler</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>disabled feature used</source>
        <translation>deaktivierte Eigenschaft wurde benutzt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>bad char class syntax</source>
        <translation>falsche Syntax für Zeichenklasse</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>bad lookahead syntax</source>
        <translation>falsche Syntax für Lookahead</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>bad repetition syntax</source>
        <translation>falsche Syntax für Wiederholungen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>invalid octal value</source>
        <translation>ungültiger Oktal-Wert</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>missing left delim</source>
        <translation>fehlende linke Begrenzung</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>unexpected end</source>
        <translation>unerwartetes Ende</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>met internal limit</source>
        <translation>internes Limit erreicht</translation>
    </message>
</context>
<context>
    <name>QSQLite2Driver</name>
    <message>
        <location filename="../src/sql/drivers/sqlite2/qsql_sqlite2.cpp" line="+353"/>
        <source>Error to open database</source>
        <translation>Die Datenbankverbindung konnte nicht geöffnet werden</translation>
    </message>
    <message>
        <location line="+41"/>
        <source>Unable to begin transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Unable to rollback Transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
</context>
<context>
    <name>QSQLite2Result</name>
    <message>
        <location line="-310"/>
        <source>Unable to fetch results</source>
        <translation>Das Ergebnis konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+139"/>
        <source>Unable to execute statement</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <location filename="../src/sql/drivers/sqlite/qsql_sqlite.cpp" line="+498"/>
        <source>Error opening database</source>
        <translation>Die Datenbankverbindung konnte nicht geöffnet werden</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Error closing database</source>
        <translation>Die Datenbankverbindung konnte nicht geschlossen werden</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Unable to begin transaction</source>
        <translation>Es konnte keine Transaktion gestartet werden</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Unable to commit transaction</source>
        <translation>Die Transaktion konnte nicht durchgeführt werden (Operation &apos;commit&apos; fehlgeschlagen)</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Unable to rollback transaction</source>
        <translation>Die Transaktion konnte nicht rückgängig gemacht werden (Operation &apos;rollback&apos; fehlgeschlagen)</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <location line="-400"/>
        <location line="+66"/>
        <location line="+8"/>
        <source>Unable to fetch row</source>
        <translation>Der Datensatz konnte nicht abgeholt werden</translation>
    </message>
    <message>
        <location line="+63"/>
        <source>Unable to execute statement</source>
        <translation>Der Befehl konnte nicht ausgeführt werden</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Unable to reset statement</source>
        <translation>Der Befehl konnte nicht zurückgesetzt werden</translation>
    </message>
    <message>
        <location line="+45"/>
        <source>Unable to bind parameters</source>
        <translation>Die Parameter konnte nicht gebunden werden</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Parameter count mismatch</source>
        <translation>Die Anzahl der Parameter ist falsch</translation>
    </message>
    <message>
        <location line="-208"/>
        <source>No query</source>
        <translation>Kein Abfrage</translation>
    </message>
</context>
<context>
    <name>QScrollBar</name>
    <message>
        <location filename="../src/gui/widgets/qscrollbar.cpp" line="+419"/>
        <source>Scroll here</source>
        <translation>Hierher scrollen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Left edge</source>
        <translation>Linker Rand</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Top</source>
        <translation>Anfang</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Right edge</source>
        <translation>Rechter Rand</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Bottom</source>
        <translation>Ende</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Page left</source>
        <translation>Eine Seite nach links</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="+143"/>
        <source>Page up</source>
        <translation>Eine Seite nach oben</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Page right</source>
        <translation>Eine Seite nach rechts</translation>
    </message>
    <message>
        <location line="+0"/>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="+4"/>
        <source>Page down</source>
        <translation>Eine Seite nach unten</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Scroll left</source>
        <translation>Nach links scrollen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Scroll up</source>
        <translation>Nach oben scrollen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Scroll right</source>
        <translation>Nach rechts scrollen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Scroll down</source>
        <translation>Nach unten scrollen</translation>
    </message>
    <message>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="-6"/>
        <source>Line up</source>
        <translation>Ausrichten</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Line down</source>
        <translation>Eine Zeile nach unten</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <location filename="../src/corelib/kernel/qsharedmemory.cpp" line="+258"/>
        <source>%1: create size is less then 0</source>
        <translation>%1: Die Größenangabe für die Erzeugung ist kleiner als Null</translation>
    </message>
    <message>
        <location line="+168"/>
        <location filename="../src/corelib/kernel/qsharedmemory_p.h" line="+118"/>
        <source>%1: unable to lock</source>
        <translation>%1: Sperrung fehlgeschlagen</translation>
    </message>
    <message>
        <location line="+22"/>
        <source>%1: unable to unlock</source>
        <translation>%1: Die Sperrung konnte nicht aufgehoben werden</translation>
    </message>
    <message>
        <location filename="../src/corelib/kernel/qsharedmemory_unix.cpp" line="+48"/>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="+57"/>
        <source>%1: permission denied</source>
        <translation>%1: Zugriff verweigert</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="-22"/>
        <source>%1: already exists</source>
        <translation>%1: existiert bereits</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="+9"/>
        <source>%1: doesn&apos;t exists</source>
        <translation>%1: existiert nicht</translation>
    </message>
    <message>
        <location line="+6"/>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="+9"/>
        <source>%1: out of resources</source>
        <translation>%1: Keine Ressourcen mehr verfügbar</translation>
    </message>
    <message>
        <location line="+4"/>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="+7"/>
        <source>%1: unknown error %2</source>
        <translation>%1: Unbekannter Fehler %2</translation>
    </message>
    <message>
        <location line="+21"/>
        <source>%1: key is empty</source>
        <translation>%1: Ungültige Schlüsselangabe (leer)</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>%1: unix key file doesn&apos;t exists</source>
        <translation>%1: Die Unix-Schlüsseldatei existiert nicht</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>%1: ftok failed</source>
        <translation>%1: ftok-Aufruf schlug fehl</translation>
    </message>
    <message>
        <location line="+51"/>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="+15"/>
        <source>%1: unable to make key</source>
        <translation>%1: Es kann kein Schlüssel erzeugt werden</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1: Ein systembedingtes Limit der Größe wurde erreicht</translation>
    </message>
    <message>
        <location line="+53"/>
        <source>%1: not attached</source>
        <translation>%1: nicht verbunden</translation>
    </message>
    <message>
        <location filename="../src/corelib/kernel/qsharedmemory_win.cpp" line="-27"/>
        <source>%1: invalid size</source>
        <translation>%1: Ungültige Größe</translation>
    </message>
    <message>
        <location line="+68"/>
        <source>%1: key error</source>
        <translation>%1: Fehlerhafter Schlüssel</translation>
    </message>
    <message>
        <location line="+38"/>
        <source>%1: size query failed</source>
        <translation>%1: Die Abfrage der Größe schlug fehl</translation>
    </message>
    <message>
        <location filename="../src/corelib/kernel/qsharedmemory.cpp" line="-271"/>
        <source>%1: unable to set key on lock</source>
        <translation>%1: Es kann kein Schlüssel für die Sperrung gesetzt werden</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../src/gui/kernel/qkeysequence.cpp" line="+343"/>
        <source>Space</source>
        <translation>Leertaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Tab</source>
        <translation>Tab</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Backtab</source>
        <translation>Rück-Tab</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Backspace</source>
        <translation>Rücktaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Return</source>
        <translation>Return</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Ins</source>
        <translation>Einfg</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Del</source>
        <translation>Entf</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Print</source>
        <translation>Druck</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>SysReq</source>
        <translation>SysReq</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Home</source>
        <translation>Pos1</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>End</source>
        <translation>Ende</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Up</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Down</source>
        <translation>Runter</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>PgUp</source>
        <translation>Bild aufwärts</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>PgDown</source>
        <translation>Bild abwärts</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>CapsLock</source>
        <translation>Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>NumLock</source>
        <translation>Zahlen-Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ScrollLock</source>
        <translation>Rollen-Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Menu</source>
        <translation>Menü</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Forward</source>
        <translation>Vorwärts</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Stop</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Refresh</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Volume Down</source>
        <translation>Lautstärke -</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Volume Mute</source>
        <translation>Ton aus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Volume Up</source>
        <translation>Lautstärke +</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bass Boost</source>
        <translation>Bass-Boost</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bass Up</source>
        <translation>Bass +</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Bass Down</source>
        <translation>Bass -</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Treble Up</source>
        <translation>Höhen +</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Treble Down</source>
        <translation>Höhen -</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Play</source>
        <translation>Wiedergabe</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Previous</source>
        <translation>Vorheriger</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Next</source>
        <translation>Nächster</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Media Record</source>
        <translation>Aufzeichnen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Favorites</source>
        <translation>Favoriten</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Search</source>
        <translation>Suchen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Standby</source>
        <translation>Standby</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Open URL</source>
        <translation>Öffne URL</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch Mail</source>
        <translation>Start Mail</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch Media</source>
        <translation>Start Media Player</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (0)</source>
        <translation>Start (0)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (1)</source>
        <translation>Start (1)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (2)</source>
        <translation>Start (2)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (3)</source>
        <translation>Start (3)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (4)</source>
        <translation>Start (4)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (5)</source>
        <translation>Start (5)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (6)</source>
        <translation>Start (6)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (7)</source>
        <translation>Start (7)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (8)</source>
        <translation>Start (8)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (9)</source>
        <translation>Start (9)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (A)</source>
        <translation>Start (A)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (B)</source>
        <translation>Start (B)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (C)</source>
        <translation>Start (C)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (D)</source>
        <translation>Start (D)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (E)</source>
        <translation>Start (E)</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Launch (F)</source>
        <translation>Start (F)</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Print Screen</source>
        <translation>Bildschirm drucken</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Page Up</source>
        <translation>Bild aufwärts</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Page Down</source>
        <translation>Bild abwärts</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Caps Lock</source>
        <translation>Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Num Lock</source>
        <translation>Zahlen-Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Number Lock</source>
        <translation>Zahlen-Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Scroll Lock</source>
        <translation>Rollen-Feststelltaste</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Insert</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Escape</source>
        <translation>Escape</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>System Request</source>
        <translation>System Request</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Select</source>
        <translation>Auswählen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Context1</source>
        <translation>Kontext1</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Context2</source>
        <translation>Kontext2</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Context3</source>
        <translation>Kontext3</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Context4</source>
        <translation>Kontext4</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Call</source>
        <translation>Anruf</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Hangup</source>
        <translation>Auflegen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Flip</source>
        <translation>Umdrehen</translation>
    </message>
    <message>
        <location line="+527"/>
        <location line="+122"/>
        <source>Ctrl</source>
        <translation>Strg</translation>
    </message>
    <message>
        <location line="-121"/>
        <location line="+125"/>
        <source>Shift</source>
        <translation>Umschalt</translation>
    </message>
    <message>
        <location line="-124"/>
        <location line="+122"/>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <location line="-121"/>
        <location line="+117"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <location line="-25"/>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <location line="+46"/>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
    <message>
        <location line="-720"/>
        <source>Home Page</source>
        <translation>Startseite</translation>
    </message>
</context>
<context>
    <name>QSlider</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="+151"/>
        <source>Page left</source>
        <translation>Eine Seite nach links</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Page up</source>
        <translation>Eine Seite nach oben</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Page right</source>
        <translation>Eine Seite nach rechts</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Page down</source>
        <translation>Eine Seite nach unten</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <location filename="../src/network/socket/qsocks5socketengine.cpp" line="-67"/>
        <source>Connection to proxy refused</source>
        <translation>Der Proxy-Server hat den Aufbau einer Verbindung verweigert</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Connection to proxy closed prematurely</source>
        <translation>Der Proxy-Server hat die Verbindung vorzeitig beendet</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Proxy host not found</source>
        <translation>Der Proxy-Server konnte nicht gefunden werden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Connection to proxy timed out</source>
        <translation>Bei der Verbindung mit dem Proxy-Server wurde ein Zeitlimit überschritten</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Proxy authentication failed</source>
        <translation>Die Authentifizierung beim Proxy-Server schlug fehl</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Proxy authentication failed: %1</source>
        <translation>Die Authentifizierung beim Proxy-Server schlug fehl: %1</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>SOCKS version 5 protocol error</source>
        <translation>Protokoll-Fehler (SOCKS version 5)</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>General SOCKSv5 server failure</source>
        <translation>Allgemeiner Fehler bei der Kommunikation mit dem SOCKSv5-Server</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Der SOCKSv5-Server hat die Verbindung verweigert</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>TTL expired</source>
        <translation>TTL verstrichen</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>SOCKSv5 command not supported</source>
        <translation>Dieses SOCKSv5-Kommando wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Address type not supported</source>
        <translation>Dieser Adresstyp wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Unbekannten Fehlercode vom SOCKSv5-Proxy-Server erhalten: 0x%1</translation>
    </message>
    <message>
        <location line="+685"/>
        <source>Network operation timed out</source>
        <translation>Das Zeitlimit für die Operation wurde überschritten</translation>
    </message>
</context>
<context>
    <name>QSpinBox</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/rangecontrols.cpp" line="-574"/>
        <source>More</source>
        <translation>Mehr</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Less</source>
        <translation>Weniger</translation>
    </message>
</context>
<context>
    <name>QSql</name>
    <message>
        <location filename="../src/qt3support/sql/q3sqlmanager_p.cpp" line="+860"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Delete this record?</source>
        <translation>Diesen Datensatz löschen?</translation>
    </message>
    <message>
        <location line="+1"/>
        <location line="+16"/>
        <location line="+36"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location line="-51"/>
        <location line="+16"/>
        <location line="+36"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location line="-44"/>
        <source>Insert</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Save edits?</source>
        <translation>Änderungen speichern?</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Confirm</source>
        <translation>Bestätigen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Cancel your edits?</source>
        <translation>Änderungen verwerfen?</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <location filename="../src/network/ssl/qsslsocket_openssl.cpp" line="+539"/>
        <source>Unable to write data: %1</source>
        <translation>Die Daten konnten nicht geschrieben werden: %1</translation>
    </message>
    <message>
        <location line="+119"/>
        <source>Error while reading: %1</source>
        <translation>Beim Lesen trat ein Fehler auf: %1</translation>
    </message>
    <message>
        <location line="+96"/>
        <source>Error during SSL handshake: %1</source>
        <translation>Es trat ein Fehler im Ablauf des SSL-Protokolls auf: %1</translation>
    </message>
    <message>
        <location line="-524"/>
        <source>Error creating SSL context (%1)</source>
        <translation>Es konnte keine SSL-Kontextstruktur erzeugt werden (%1)</translation>
    </message>
    <message>
        <location line="+25"/>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Ungültige oder leere Schlüsselliste (%1)</translation>
    </message>
    <message>
        <location line="+62"/>
        <source>Error creating SSL session, %1</source>
        <translation>Es konnte keine SSL-Sitzung erzeugt werden, %1</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Error creating SSL session: %1</source>
        <translation>Es konnte keine SSL-Sitzung erzeugt werden: %1</translation>
    </message>
    <message>
        <location line="-61"/>
        <source>Cannot provide a certificate with no key, %1</source>
        <translation>Ohne Schlüssel kann kein Zertifikat zur Verfügung gestellt werden, %1</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Error loading local certificate, %1</source>
        <translation>Das lokale Zertifikat konnte nicht geladen werden, %1</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>Error loading private key, %1</source>
        <translation>Der private Schlüssel konnte nicht geladen werden, %1</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Private key does not certificate public key, %1</source>
        <translation>Die Zertifizierung des öffentlichen Schlüssels durch den privaten Schlüssel schlug fehl, %1</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <location filename="../src/corelib/kernel/qsystemsemaphore_unix.cpp" line="-46"/>
        <source>%1: does not exist</source>
        <translation>%1: Nicht existent</translation>
    </message>
    <message>
        <location line="+5"/>
        <location filename="../src/corelib/kernel/qsystemsemaphore_win.cpp" line="+36"/>
        <source>%1: out of resources</source>
        <translation>%1: Keine Ressourcen mehr verfügbar</translation>
    </message>
    <message>
        <location line="-13"/>
        <location filename="../src/corelib/kernel/qsystemsemaphore_win.cpp" line="+4"/>
        <source>%1: permission denied</source>
        <translation>%1: Zugriff verweigert</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>%1: already exists</source>
        <translation>%1: existiert bereits</translation>
    </message>
    <message>
        <location line="+13"/>
        <location filename="../src/corelib/kernel/qsystemsemaphore_win.cpp" line="+3"/>
        <source>%1: unknown error %2</source>
        <translation>%1: Unbekannter Fehler %2</translation>
    </message>
</context>
<context>
    <name>QTDSDriver</name>
    <message>
        <location filename="../src/sql/drivers/tds/qsql_tds.cpp" line="+552"/>
        <source>Unable to open connection</source>
        <translation>Die Datenbankverbindung konnte nicht geöffnet werden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Unable to use database</source>
        <translation>Die Datenbank kann nicht verwendet werden</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/complexwidgets.cpp" line="-326"/>
        <source>Scroll Left</source>
        <translation>Nach links scrollen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Scroll Right</source>
        <translation>Nach rechts scrollen</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <location filename="../src/network/socket/qtcpserver.cpp" line="+252"/>
        <source>Operation on socket is not supported</source>
        <translation>Diese Socketoperation wird nicht unterstützt</translation>
    </message>
</context>
<context>
    <name>QTextControl</name>
    <message>
        <location filename="../src/gui/text/qtextcontrol.cpp" line="+1942"/>
        <source>&amp;Undo</source>
        <translation>&amp;Rückgängig</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Redo</source>
        <translation>Wieder&amp;herstellen</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Cu&amp;t</source>
        <translation>&amp;Ausschneiden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Copy &amp;Link Location</source>
        <translation>&amp;Link-Adresse kopieren</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>&amp;Paste</source>
        <translation>Einf&amp;ügen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Select All</source>
        <translation>Alles auswählen</translation>
    </message>
</context>
<context>
    <name>QToolButton</name>
    <message>
        <location filename="../src/plugins/accessible/widgets/simplewidgets.cpp" line="+254"/>
        <location line="+6"/>
        <source>Press</source>
        <translation>Drücken</translation>
    </message>
    <message>
        <location line="-4"/>
        <location line="+8"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <location filename="../src/network/socket/qudpsocket.cpp" line="+139"/>
        <source>This platform does not support IPv6</source>
        <translation>Diese Plattform unterstützt kein IPv6</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <location filename="../src/gui/util/qundogroup.cpp" line="+356"/>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Redo</source>
        <translation>Wiederherstellen</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <location filename="../src/gui/util/qundoview.cpp" line="+71"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;leer&gt;</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <location filename="../src/gui/util/qundostack.cpp" line="+804"/>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Redo</source>
        <translation>Wiederherstellen</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <location filename="../src/gui/text/qtextcontrol.cpp" line="+884"/>
        <source>LRM Left-to-right mark</source>
        <translation>LRM Left-to-right mark</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>RLM Right-to-left mark</source>
        <translation>RLM Right-to-left mark</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ZWJ Zero width joiner</source>
        <translation>ZWJ Zero width joiner</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>ZWNJ Zero width non-joiner</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>ZWSP Zero width space</source>
        <translation>ZWSP Zero width space</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>LRE Start of left-to-right embedding</source>
        <translation>LRE Start of left-to-right embedding</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>RLE Start of right-to-left embedding</source>
        <translation>RLE Start of right-to-left embedding</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>LRO Start of left-to-right override</source>
        <translation>LRO Start of left-to-right override</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>RLO Start of right-to-left override</source>
        <translation>RLO Start of right-to-left override</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>PDF Pop directional formatting</source>
        <translation>PDF Pop directional formatting</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Insert Unicode control character</source>
        <translation>Unicode-Kontrollzeichen einfügen</translation>
    </message>
</context>
<context>
    <name>QWebFrame</name>
    <message>
        <location filename="../src/3rdparty/webkit/WebKit/qt/WebCoreSupport/FrameLoaderClientQt.cpp" line="+686"/>
        <source>Request cancelled</source>
        <translation>Anfrage wurde abgebrochen</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Request blocked</source>
        <translation>Anfrage wurde abgewiesen</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Cannot show URL</source>
        <translation>Der URL kann nicht angezeigt werden</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Frame load interruped by policy change</source>
        <translation>Das Laden des Rahmens wurde durch eine Änderung der Richtlinien unterbrochen</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Cannot show mimetype</source>
        <translation>Dieser Mime-Typ kann nicht angezeigt werden</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>File does not exist</source>
        <translation>Die Datei existiert nicht</translation>
    </message>
</context>
<context>
    <name>QWebPage</name>
    <message>
        <location filename="../src/3rdparty/webkit/WebCore/platform/qt/Localizations.cpp" line="+42"/>
        <source>Submit</source>
        <comment>default label for Submit buttons in forms on web pages</comment>
        <translation>Senden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Submit</source>
        <comment>Submit (input element) alt text for &lt;input&gt; elements with no alt, title, or value</comment>
        <translation>Senden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Reset</source>
        <comment>default label for Reset buttons in forms on web pages</comment>
        <translation>Rücksetzen</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>Choose File</source>
        <comment>title for file button used in HTML forms</comment>
        <translation>Durchsuchen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>No file selected</source>
        <comment>text to display in file button used in HTML forms when no file is selected</comment>
        <translation>Es ist keine Datei ausgewählt</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Open in New Window</source>
        <comment>Open in New Window context menu item</comment>
        <translation>In neuem Fenster öffnen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Save Link...</source>
        <comment>Download Linked File context menu item</comment>
        <translation>Ziel speichern unter...</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Copy Link</source>
        <comment>Copy Link context menu item</comment>
        <translation>Link-Adresse kopieren</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Open Image</source>
        <comment>Open Image in New Window context menu item</comment>
        <translation>Grafik in neuem Fenster öffnen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Save Image</source>
        <comment>Download Image context menu item</comment>
        <translation>Grafik speichern unter</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Copy Image</source>
        <comment>Copy Link context menu item</comment>
        <translation>Grafik kopieren</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Open Frame</source>
        <comment>Open Frame in New Window context menu item</comment>
        <translation>Frame öffnen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Copy</source>
        <comment>Copy context menu item</comment>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Go Back</source>
        <comment>Back context menu item</comment>
        <translation>Zurück</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Go Forward</source>
        <comment>Forward context menu item</comment>
        <translation>Vor</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Stop</source>
        <comment>Stop context menu item</comment>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Reload</source>
        <comment>Reload context menu item</comment>
        <translation>Neu laden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Cut</source>
        <comment>Cut context menu item</comment>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Paste</source>
        <comment>Paste context menu item</comment>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>No Guesses Found</source>
        <comment>No Guesses Found context menu item</comment>
        <translation>Keine Vorschläge gefunden</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Ignore</source>
        <comment>Ignore Spelling context menu item</comment>
        <translation>Ignorieren</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Add To Dictionary</source>
        <comment>Learn Spelling context menu item</comment>
        <translation>In Wörterbuch aufnehmen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Search The Web</source>
        <comment>Search The Web context menu item</comment>
        <translation>Im Web suchen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Look Up In Dictionary</source>
        <comment>Look Up in Dictionary context menu item</comment>
        <translation>Im Wörterbuch nachschauen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Open Link</source>
        <comment>Open Link context menu item</comment>
        <translation>Adresse öffnen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Ignore</source>
        <comment>Ignore Grammar context menu item</comment>
        <translation>Ignorieren</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Spelling</source>
        <comment>Spelling and Grammar context sub-menu item</comment>
        <translation>Rechtschreibung</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Show Spelling and Grammar</source>
        <comment>menu item title</comment>
        <translation>Rechtschreibung und Grammatik anzeigen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Hide Spelling and Grammar</source>
        <comment>menu item title</comment>
        <translation>Rechtschreibung und Grammatik nicht anzeigen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Check Spelling</source>
        <comment>Check spelling context menu item</comment>
        <translation>Rechtschreibung prüfen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Check Spelling While Typing</source>
        <comment>Check spelling while typing context menu item</comment>
        <translation>Rechtschreibung während des Schreibens überprüfen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Check Grammar With Spelling</source>
        <comment>Check grammar with spelling context menu item</comment>
        <translation>Grammatik mit Rechtschreibung zusammen überprüfen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Fonts</source>
        <comment>Font context sub-menu item</comment>
        <translation>Fonts</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Bold</source>
        <comment>Bold context menu item</comment>
        <translation>Fett</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Italic</source>
        <comment>Italic context menu item</comment>
        <translation>Kursiv</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Underline</source>
        <comment>Underline context menu item</comment>
        <translation>Unterstrichen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Outline</source>
        <comment>Outline context menu item</comment>
        <translation>Umriss</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Direction</source>
        <comment>Writing direction context sub-menu item</comment>
        <translation>Schreibrichtung</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Text Direction</source>
        <comment>Text direction context sub-menu item</comment>
        <translation>Schreibrichtung</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Default</source>
        <comment>Default writing direction context menu item</comment>
        <translation>Vorgabe</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>LTR</source>
        <comment>Left to Right context menu item</comment>
        <translation>Von links nach rechts</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>RTL</source>
        <comment>Right to Left context menu item</comment>
        <translation>Von rechts nach links</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Inspect</source>
        <comment>Inspect Element context menu item</comment>
        <translation>Prüfen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>No recent searches</source>
        <comment>Label for only item in menu that appears when clicking on the search field image, when no searches have been performed</comment>
        <translation>Es existieren noch keine Suchanfragen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Recent searches</source>
        <comment>label for first item in the menu that appears when clicking on the search field image, used as embedded menu title</comment>
        <translation>Bisherige Suchanfragen</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Clear recent searches</source>
        <comment>menu item in Recent Searches menu that empties menu&apos;s contents</comment>
        <translation>Gespeicherte Suchanfragen löschen</translation>
    </message>
    <message>
        <location line="+75"/>
        <source>Unknown</source>
        <comment>Unknown filesize FTP directory listing item</comment>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <location filename="../src/3rdparty/webkit/WebKit/qt/WebCoreSupport/InspectorClientQt.cpp" line="+185"/>
        <source>Web Inspector - %2</source>
        <translation>Web Inspector - %2</translation>
    </message>
    <message>
        <location filename="../src/3rdparty/webkit/WebCore/platform/qt/Localizations.cpp" line="+5"/>
        <source>%1 (%2x%3 pixels)</source>
        <comment>Title string for images</comment>
        <translation>%1 (%2x%3 Pixel)</translation>
    </message>
    <message>
        <location filename="../src/3rdparty/webkit/WebCore/platform/network/qt/QNetworkReplyHandler.cpp" line="+382"/>
        <source>Bad HTTP request</source>
        <translation>Ungültige HTTP-Anforderung</translation>
    </message>
    <message>
        <location filename="../src/3rdparty/webkit/WebCore/platform/qt/Localizations.cpp" line="-291"/>
        <source>This is a searchable index. Enter search keywords: </source>
        <comment>text that appears at the start of nearly-obsolete web pages in the form of a &apos;searchable index&apos;</comment>
        <translation>Dieser Index verfügt über eine Suchfunktion. Geben Sie einen Suchbegriff ein:</translation>
    </message>
    <message>
        <location filename="../src/3rdparty/webkit/WebCore/platform/qt/ScrollbarQt.cpp" line="+58"/>
        <source>Scroll here</source>
        <translation>Hierher scrollen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Left edge</source>
        <translation>Linker Rand</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Top</source>
        <translation>Anfang</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Right edge</source>
        <translation>Rechter Rand</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Bottom</source>
        <translation>Ende</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Page left</source>
        <translation>Eine Seite nach links</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Page up</source>
        <translation>Eine Seite nach oben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Page right</source>
        <translation>Eine Seite nach rechts</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Page down</source>
        <translation>Eine Seite nach unten</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Scroll left</source>
        <translation>Nach links scrollen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Scroll up</source>
        <translation>Nach oben scrollen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>Scroll right</source>
        <translation>Nach rechts scrollen</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>Scroll down</source>
        <translation>Nach unten scrollen</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/3rdparty/webkit/WebCore/platform/qt/FileChooserQt.cpp" line="+45"/>
        <source>%n file(s)</source>
        <comment>number of chosen file</comment>
        <translation>
            <numerusform>Eine Datei</numerusform>
            <numerusform>%n Dateien</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/3rdparty/webkit/WebKit/qt/Api/qwebpage.cpp" line="+1342"/>
        <source>JavaScript Alert - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+15"/>
        <source>JavaScript Confirm - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+17"/>
        <source>JavaScript Prompt - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location line="+333"/>
        <source>Move the cursor to the next character</source>
        <translation type="unfinished">Positionsmarke auf folgendes Zeichen setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the previous character</source>
        <translation type="unfinished">Positionsmarke auf vorangehendes Zeichen setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the next word</source>
        <translation type="unfinished">Positionsmarke auf folgendes Wort setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the previous word</source>
        <translation type="unfinished">Positionsmarke auf vorangehendes Wort setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the next line</source>
        <translation type="unfinished">Positionsmarke auf folgende Zeile setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the previous line</source>
        <translation type="unfinished">Positionsmarke auf vorangehende Zeile setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the start of the line</source>
        <translation type="unfinished">Positionsmarke auf Zeilenanfang setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the end of the line</source>
        <translation type="unfinished">Positionsmarke auf Zeilenende setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the start of the block</source>
        <translation type="unfinished">Positionsmarke auf Anfang des Blocks setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the end of the block</source>
        <translation type="unfinished">Positionsmarke auf Ende des Blocks setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the start of the document</source>
        <translation type="unfinished">Positionsmarke auf Anfang des Dokumentes setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Move the cursor to the end of the document</source>
        <translation type="unfinished">Positionsmarke auf Ende des Dokumentes setzen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the next character</source>
        <translation type="unfinished">Bis zum folgenden Zeichen markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the previous character</source>
        <translation type="unfinished">Bis zum vorangehenden Zeichen markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the next word</source>
        <translation type="unfinished">Bis zum folgenden Wort markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the previous word</source>
        <translation type="unfinished">Bis zum vorangehenden Wort markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the next line</source>
        <translation type="unfinished">Bis zur folgenden Zeile markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the previous line</source>
        <translation type="unfinished">Bis zur vorangehenden Zeile markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the start of the line</source>
        <translation type="unfinished">Bis zum Zeilenanfang markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the end of the line</source>
        <translation type="unfinished">Bis zum Zeilenende markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the start of the block</source>
        <translation type="unfinished">Bis zum Anfang des Blocks markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the end of the block</source>
        <translation type="unfinished">Bis zum Ende des Blocks markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the start of the document</source>
        <translation type="unfinished">Bis zum Anfang des Dokuments markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Select to the end of the document</source>
        <translation type="unfinished">Bis zum Ende des Dokuments markieren</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Delete to the start of the word</source>
        <translation type="unfinished">Bis zum Anfang des Wortes löschen</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Delete to the end of the word</source>
        <translation type="unfinished">Bis zum Ende des Wortes löschen</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <location filename="../src/gui/kernel/qwhatsthis.cpp" line="+492"/>
        <source>What&apos;s This?</source>
        <translation>Direkthilfe</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <location filename="../src/gui/kernel/qwidget.cpp" line="+5290"/>
        <source>*</source>
        <translation>*</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <location filename="../src/gui/dialogs/qwizard.cpp" line="+617"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Zurück</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>&amp;Finish</source>
        <translation>Ab&amp;schließen</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <location line="-14"/>
        <source>Go Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>Continue</source>
        <translation>Weiter</translation>
    </message>
    <message>
        <location line="+5"/>
        <source>Commit</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Done</source>
        <translation>Fertig</translation>
    </message>
    <message>
        <location line="-4"/>
        <source>&amp;Next</source>
        <translation>&amp;Weiter</translation>
    </message>
    <message>
        <location line="+0"/>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Weiter &gt;</translation>
    </message>
</context>
<context>
    <name>QWorkspace</name>
    <message>
        <location filename="../src/gui/widgets/qworkspace.cpp" line="+1064"/>
        <source>&amp;Restore</source>
        <translation>Wieder&amp;herstellen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Move</source>
        <translation>Ver&amp;schieben</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>&amp;Size</source>
        <translation>&amp;Größe ändern</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Mi&amp;nimize</source>
        <translation>M&amp;inimieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Ma&amp;ximize</source>
        <translation>Ma&amp;ximieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>&amp;Close</source>
        <translation>Schl&amp;ießen</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Stay on &amp;Top</source>
        <translation>Im &amp;Vordergrund bleiben</translation>
    </message>
    <message>
        <location line="-993"/>
        <source>Minimize</source>
        <translation>Minimieren</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Restore Down</source>
        <translation>Wiederherstellen</translation>
    </message>
    <message>
        <location line="-4"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location line="+998"/>
        <location line="+1059"/>
        <source>Sh&amp;ade</source>
        <translation>&amp;Aufrollen</translation>
    </message>
    <message>
        <location line="-278"/>
        <location line="+60"/>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <location line="+214"/>
        <source>&amp;Unshade</source>
        <translation>&amp;Herabrollen</translation>
    </message>
</context>
<context>
    <name>QXml</name>
    <message>
        <location filename="../src/xml/sax/qxml.cpp" line="+28"/>
        <source>no error occurred</source>
        <translation>kein Fehler</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>error triggered by consumer</source>
        <translation>Konsument löste Fehler aus</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>unexpected end of file</source>
        <translation>unerwartetes Ende der Datei</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>more than one document type definition</source>
        <translation>mehrere Dokumenttypdefinitionen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>error occurred while parsing element</source>
        <translation>Fehler beim Parsen eines Elements</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>tag mismatch</source>
        <translation>Element-Tags sind nicht richtig geschachtelt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>error occurred while parsing content</source>
        <translation>Fehler beim Parsen des Inhalts eines Elements</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>unexpected character</source>
        <translation>unerwartetes Zeichen</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>invalid name for processing instruction</source>
        <translation>kein gültiger Name für eine Processing-Instruktion</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>version expected while reading the XML declaration</source>
        <translation>fehlende Version beim Parsen der XML-Deklaration</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>wrong value for standalone declaration</source>
        <translation>falscher Wert für die Standalone-Deklaration</translation>
    </message>
    <message>
        <location line="+3"/>
        <source>error occurred while parsing document type definition</source>
        <translation>Fehler beim Parsen der Dokumenttypdefinition</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>letter is expected</source>
        <translation>ein Buchstabe ist an dieser Stelle erforderlich</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>error occurred while parsing comment</source>
        <translation>Fehler beim Parsen eines Kommentars</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>error occurred while parsing reference</source>
        <translation>Fehler beim Parsen einer Referenz</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>internal general entity reference not allowed in DTD</source>
        <translation>in einer DTD ist keine interne allgemeine Entity-Referenz erlaubt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>external parsed general entity reference not allowed in attribute value</source>
        <translation>in einem Attribut-Wert sind keine externen Entity-Referenzen erlaubt</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>external parsed general entity reference not allowed in DTD</source>
        <translation>in der DTD sind keine externen Entity-Referenzen erlaubt </translation>
    </message>
    <message>
        <location line="+1"/>
        <source>unparsed entity reference in wrong context</source>
        <translation>nicht-analysierte Entity-Referenz im falschen Kontext verwendet</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>recursive entities</source>
        <translation>rekursive Entity</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>error in the text declaration of an external entity</source>
        <translation>Fehler in der Text-Deklaration einer externen Entity</translation>
    </message>
    <message>
        <location line="-11"/>
        <source>encoding declaration or standalone declaration expected while reading the XML declaration</source>
        <translation>fehlende Encoding-Deklaration oder Standalone-Deklaration beim Parsen der XML-Deklaration</translation>
    </message>
    <message>
        <location line="+1"/>
        <source>standalone declaration expected while reading the XML declaration</source>
        <translation>fehlende Standalone-Deklaration beim Parsen der XML Deklaration</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <location filename="../src/corelib/xml/qxmlstream.cpp" line="+562"/>
        <location filename="../src/corelib/xml/qxmlstream_p.h" line="+1739"/>
        <source>Extra content at end of document.</source>
        <translation>Überzähliger Inhalt nach Ende des Dokumentes.</translation>
    </message>
    <message>
        <location line="+222"/>
        <source>Invalid entity value.</source>
        <translation>Ungültiger Entity-Wert.</translation>
    </message>
    <message>
        <location line="+107"/>
        <source>Invalid XML character.</source>
        <translation>Ungültiges XML-Zeichen.</translation>
    </message>
    <message>
        <location line="+259"/>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>Im Inhalt ist die Zeichenfolge &apos;]]&gt;&apos; nicht erlaubt.</translation>
    </message>
    <message>
        <location line="+309"/>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>Der Namensraum-Präfix &apos;%1&apos; wurde nicht deklariert</translation>
    </message>
    <message>
        <location line="+78"/>
        <source>Attribute redefined.</source>
        <translation>Redefinition eines Attributes.</translation>
    </message>
    <message>
        <location line="+115"/>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>&apos;%1&apos; ist kein gültiges Zeichen in einer public-id-Angabe.</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>Invalid XML version string.</source>
        <translation>Ungültige XML-Versionsangabe.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Unsupported XML version.</source>
        <translation>Diese XML-Version wird nicht unterstützt.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 ist kein gültiger Name für das Encoding.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Encoding %1 is unsupported</source>
        <translation>Das Encoding %1 wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Standalone accepts only yes or no.</source>
        <translation>Der Wert für das &apos;Standalone&apos;-Attribut kann nur &apos;yes&apos; oder &apos;no&apos; sein.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Invalid attribute in XML declaration.</source>
        <translation>Die XML-Deklaration enthält ein ungültiges Attribut.</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>Premature end of document.</source>
        <translation>Vorzeitiges Ende des Dokuments.</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>Invalid document.</source>
        <translation>Ungültiges Dokument.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Expected </source>
        <translation>Es wurde </translation>
    </message>
    <message>
        <location line="+11"/>
        <source>, but got &apos;</source>
        <translation>erwartet, stattdessen erhalten &apos;</translation>
    </message>
    <message>
        <location line="+4"/>
        <source>Unexpected &apos;</source>
        <translation>Ungültig an dieser Stelle &apos; </translation>
    </message>
    <message>
        <location line="+210"/>
        <source>Expected character data.</source>
        <translation>Es wurden Zeichendaten erwartet.</translation>
    </message>
    <message>
        <location filename="../src/corelib/xml/qxmlstream_p.h" line="-995"/>
        <source>Recursive entity detected.</source>
        <translation>Es wurde eine rekursive Entity festgestellt.</translation>
    </message>
    <message>
        <location line="+516"/>
        <source>Start tag expected.</source>
        <translation>Öffnendes Element erwartet.</translation>
    </message>
    <message>
        <location line="+222"/>
        <source>XML declaration not at start of document.</source>
        <translation>Die XML-Deklaration befindet sich nicht am Anfang des Dokuments.</translation>
    </message>
    <message>
        <location line="-31"/>
        <source>NDATA in parameter entity declaration.</source>
        <translation>Eine Parameter-Entity-Deklaration darf kein NDATA enthalten.</translation>
    </message>
    <message>
        <location line="+34"/>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 ist kein gültiger Name für eine Prozessing-Instruktion.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Invalid processing instruction name.</source>
        <translation>Der Name der Prozessing-Instruktion ist ungültig.</translation>
    </message>
    <message>
        <location filename="../src/corelib/xml/qxmlstream.cpp" line="-521"/>
        <location line="+12"/>
        <location filename="../src/corelib/xml/qxmlstream_p.h" line="+164"/>
        <location line="+53"/>
        <source>Illegal namespace declaration.</source>
        <translation>Ungültige Namensraum-Deklaration.</translation>
    </message>
    <message>
        <location filename="../src/corelib/xml/qxmlstream_p.h" line="+15"/>
        <source>Invalid XML name.</source>
        <translation>Ungültiger XML-Name.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Opening and ending tag mismatch.</source>
        <translation>Die Anzahl der öffnenden Elemente stimmt nicht mit der Anzahl der schließenden Elemente überein.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Es wurde die ungeparste Entity &apos;%1&apos; referenziert.</translation>
    </message>
    <message>
        <location line="-13"/>
        <location line="+61"/>
        <location line="+40"/>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Die Entity &apos;%1&apos; ist nicht deklariert.</translation>
    </message>
    <message>
        <location line="-26"/>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Im Attributwert wurde die externe Entity &apos;%1&apos; referenziert.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>Invalid character reference.</source>
        <translation>Ungültige Zeichenreferenz.</translation>
    </message>
    <message>
        <location filename="../src/corelib/xml/qxmlstream.cpp" line="-75"/>
        <location filename="../src/corelib/xml/qxmlstream_p.h" line="-823"/>
        <source>Encountered incorrectly encoded content.</source>
        <translation>Es wurde Inhalt mit einer ungültigen Kodierung gefunden.</translation>
    </message>
    <message>
        <location line="+274"/>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>Das Standalone-Pseudoattribut muss dem Encoding unmittelbar folgen.</translation>
    </message>
    <message>
        <location filename="../src/corelib/xml/qxmlstream_p.h" line="+562"/>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 ist keine gültige Angabe für eine PUBLIC-Id.</translation>
    </message>
</context>
<context>
    <name>QtXmlPatterns</name>
    <message>
        <location filename="../src/xmlpatterns/data/qabstractduration.cpp" line="+69"/>
        <location line="+15"/>
        <source>At least one component must be present.</source>
        <translation>Es muss mindestens eine Komponente vorhanden sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qabstractfloatmathematician.cpp" line="+34"/>
        <source>No operand in an integer division, %1, can be %2.</source>
        <translation>Bei der Ganzzahldivision %1 darf kein Operand %2 sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qanyuri_p.h" line="+102"/>
        <source>%1 is not a valid value of type %2.</source>
        <translation>%1 ist kein gültiger Wert des Typs %2.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qatomiccasters_p.h" line="+193"/>
        <source>When casting to %1 from %2, the source value cannot be %3.</source>
        <translation>Bei einer &quot;cast&quot;-Operation von %1 zu %2 darf der Wert nicht %3 sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qboolean.cpp" line="+48"/>
        <source>Effective Boolean Value cannot be calculated for a sequence containing two or more atomic values.</source>
        <translation>Der effektive Boolesche Wert einer Sequenz aus zwei oder mehreren atomaren Werten kann nicht berechnet werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcomparisonplatform.cpp" line="+151"/>
        <source>Operator %1 is not available between atomic values of type %2 and %3.</source>
        <translation>Der Operator %1 kann auf atomare Werte der Typen %2 und %3 nicht angewandt werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcastingplatform.cpp" line="+119"/>
        <source>It is not possible to cast from %1 to %2.</source>
        <translation>Es kann keine &quot;cast&quot;-Operation von %1 zu %2 durchgeführt werden.</translation>
    </message>
    <message>
        <location line="+27"/>
        <source>Casting to %1 is not possible because it is an abstract type, and can therefore never be instantiated.</source>
        <translation>Es können keine &quot;cast&quot;-Operationen zu dem Typ %1 durchgeführt werden, da es ein abstrakter Typ ist und nicht instanziiert werden kann.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>It&apos;s not possible to cast the value %1 of type %2 to %3</source>
        <translation>Es kann keine &quot;cast&quot;-Operation vom Wert %1 des Typs %2 zu %3 durchgeführt werden</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Failure when casting from %1 to %2: %3</source>
        <translation>Die &quot;cast&quot;-Operation von %1 zu %2 schlug fehl: %3</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcomparisonplatform.cpp" line="-14"/>
        <source>No comparisons can be done involving the type %1.</source>
        <translation>Mit dem Typ %1 können keine Vergleichsoperationen durchgeführt werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qprocessinginstructionconstructor.cpp" line="+54"/>
        <source>The data of a processing instruction cannot contain the string %1</source>
        <translation>Die Daten einer Processing-Anweisung dürfen nicht die Zeichenkette %1 enthalten</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qqnameconstructor_p.h" line="+138"/>
        <location filename="../src/xmlpatterns/functions/qqnamefns.cpp" line="+39"/>
        <source>%1 is an invalid %2</source>
        <translation>%1 ist kein gültiges %2</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qassemblestringfns.cpp" line="+58"/>
        <source>%1 is not a valid XML 1.0 character.</source>
        <translation>%1 ist kein gültiges XML 1.0 Zeichen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qcomparingaggregator.cpp" line="+167"/>
        <source>The first argument to %1 cannot be of type %2.</source>
        <translation>Das erste Argument von %1 kann nicht vom Typ %2 sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qerrorfn.cpp" line="+31"/>
        <source>%1 was called.</source>
        <translation>%1 wurde gerufen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qpatternmatchingfns.cpp" line="+103"/>
        <source>In the replacement string, %1 must be followed by at least one digit when not escaped.</source>
        <translation>In der Ersetzung muss auf %1 eine Ziffer folgen, wenn es nicht durch ein Escape-Zeichen geschützt ist.</translation>
    </message>
    <message>
        <location line="+26"/>
        <source>In the replacement string, %1 can only be used to escape itself or %2, not %3</source>
        <translation>In der Ersetzung kann %1 nur verwendet werden, um sich selbst oder %2 schützen, nicht jedoch für %3</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qpatternplatform.cpp" line="+62"/>
        <source>%1 matches newline characters</source>
        <translation>Der Ausdruck &apos;%1&apos; schließt Zeilenvorschübe ein</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Matches are case insensitive</source>
        <translation>Groß/Kleinschreibung wird nicht beachtet</translation>
    </message>
    <message>
        <location line="+103"/>
        <source>%1 is an invalid regular expression pattern: %2</source>
        <translation>%1 ist kein gültiger regulärer Ausdruck: %2</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qsequencefns.cpp" line="+317"/>
        <source>It will not be possible to retrieve %1.</source>
        <translation>%1 kann nicht bestimmt werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qsequencegeneratingfns.cpp" line="+249"/>
        <source>The default collection is undefined</source>
        <translation>Für eine Kollektion ist keine Vorgabe definiert</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>%1 cannot be retrieved</source>
        <translation>%1 kann nicht bestimmt werden</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/janitors/qitemverifier.cpp" line="+37"/>
        <source>The item %1 did not match the required type %2.</source>
        <translation>Das Element %1 entspricht nicht dem erforderlichen Typ %2.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qquerytransformparser.cpp" line="+319"/>
        <location line="+7253"/>
        <source>%1 is an unknown schema type.</source>
        <translation>%1 ist ein unbekannter Schema-Typ.</translation>
    </message>
    <message>
        <location line="-6971"/>
        <source>Only one %1 declaration can occur in the query prolog.</source>
        <translation>Der Anfrage-Prolog darf nur eine %1-Deklaration enthalten.</translation>
    </message>
    <message>
        <location line="+188"/>
        <source>The initialization of variable %1 depends on itself</source>
        <translation>Die Initialisierung der Variable %1 hängt von ihrem eigenem Wert ab</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qparsercontext.cpp" line="+63"/>
        <source>The variable %1 is unused</source>
        <translation>Die Variable %1 wird nicht verwendet</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qquerytransformparser.cpp" line="+2904"/>
        <source>Version %1 is not supported. The supported XQuery version is 1.0.</source>
        <translation>Die Version %1 wird nicht unterstützt. Die unterstützte Version von XQuery ist 1.0.</translation>
    </message>
    <message>
        <location line="+71"/>
        <source>No function with signature %1 is available</source>
        <translation>Es existiert keine Funktion mit der Signatur %1</translation>
    </message>
    <message>
        <location line="+303"/>
        <source>It is not possible to redeclare prefix %1.</source>
        <translation>Der Präfix %1 kann nicht redeklariert werden.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>Prefix %1 is already declared in the prolog.</source>
        <translation>Der Präfix %1 wurde bereits im Prolog deklariert.</translation>
    </message>
    <message>
        <location line="+95"/>
        <source>The name of an option must have a prefix. There is no default namespace for options.</source>
        <translation>Der Name einer Option muss einen Präfix haben. Es gibt keine Namensraum-Vorgabe für Optionen.</translation>
    </message>
    <message>
        <location line="+171"/>
        <source>The Schema Import feature is not supported, and therefore %1 declarations cannot occur.</source>
        <translation>Die Deklaration %1 ist unzulässig, da Schema-Import nicht unterstützt wird.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>The target namespace of a %1 cannot be empty.</source>
        <translation>Der Ziel-Namensraum von %1 darf nicht leer sein.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>The module import feature is not supported</source>
        <translation>Modul-Import wird nicht unterstützt</translation>
    </message>
    <message>
        <location line="+52"/>
        <source>No value is available for the external variable by name %1.</source>
        <translation>Für die externe Variable des Namens %1 ist kein Wert verfügbar.</translation>
    </message>
    <message>
        <location line="+126"/>
        <source>The namespace of a user defined function in a library module must be equivalent to the module namespace. In other words, it should be %1 instead of %2</source>
        <translation>Der Namensraum einer nutzerdefinierten Funktion aus einem Bibliotheksmodul muss dem Namensraum des Moduls entsprechen (%1 anstatt %2) </translation>
    </message>
    <message>
        <location line="+34"/>
        <source>A function already exists with the signature %1.</source>
        <translation>Es existiert bereits eine Funktion mit der Signatur %1.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>No external functions are supported. All supported functions can be used directly, without first declaring them as external</source>
        <translation>Externe Funktionen werden nicht unterstützt. Alle unterstützten Funktionen können direkt verwendet werden, ohne sie als extern zu deklarieren</translation>
    </message>
    <message>
        <location line="+37"/>
        <source>An argument by name %1 has already been declared. Every argument name must be unique.</source>
        <translation>Es existiert bereits ein Argument mit dem Namen %1. Die Namen der Argumente müssen eindeutig sein.</translation>
    </message>
    <message>
        <location line="+1649"/>
        <source>The %1-axis is unsupported in XQuery</source>
        <translation>Die %1-Achse wird in XQuery nicht unterstützt</translation>
    </message>
    <message>
        <location line="-5441"/>
        <source>No variable by name %1 exists</source>
        <translation>Es existiert keine Variable mit dem Namen %1</translation>
    </message>
    <message>
        <location line="+5727"/>
        <source>No function by name %1 is available.</source>
        <translation>Es existiert keine Funktion mit dem Namen %1.</translation>
    </message>
    <message>
        <location line="+102"/>
        <source>The namespace URI cannot be the empty string when binding to a prefix, %1.</source>
        <translation>Der Namensraum-URI darf nicht leer sein, wenn er an den Präfix %1 gebunden ist.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>%1 is an invalid namespace URI.</source>
        <translation>%1 ist kein gültiger Namensraum-URI.</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>It is not possible to bind to the prefix %1</source>
        <translation>Der Präfix %1 kann nicht gebunden werden</translation>
    </message>
    <message>
        <location line="+30"/>
        <source>Two namespace declaration attributes have the same name: %1.</source>
        <translation>Es wurden zwei Namenraum-Deklarationsattribute gleichen Namens (%1) gefunden.</translation>
    </message>
    <message>
        <location line="+89"/>
        <source>The namespace URI must be a constant and cannot use enclosed expressions.</source>
        <translation>Ein Namensraum-URI muss eine Konstante sein und darf keine eingebetteten Ausdrücke verwenden.</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>An attribute by name %1 has already appeared on this element.</source>
        <translation>Das Element hat bereits ein Attribut mit dem Namen %1.</translation>
    </message>
    <message>
        <location line="+683"/>
        <location line="+71"/>
        <source>%1 is not in the in-scope attribute declarations. Note that the schema import feature is not supported.</source>
        <translation>%1 befindet sich nicht unter den Attributdeklarationen im Bereich. Schema-Import wird nicht unterstützt.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/type/qcardinality.cpp" line="+25"/>
        <source>empty</source>
        <translation>leer</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>zero or one</source>
        <translation>kein oder ein</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>exactly one</source>
        <translation>genau ein</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>one or more</source>
        <translation>ein oder mehrere</translation>
    </message>
    <message>
        <location line="+2"/>
        <source>zero or more</source>
        <translation>kein oder mehrere</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/type/qtypechecker.cpp" line="+126"/>
        <source>The focus is undefined.</source>
        <translation>Es ist kein Fokus definiert.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/utils/qoutputvalidator.cpp" line="+63"/>
        <source>An attribute by name %1 has already been created.</source>
        <translation>Es wurde bereits ein Attribut mit dem Namen %1 erzeugt.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/api/qiodevicedelegate.cpp" line="+54"/>
        <source>Network timeout.</source>
        <translation>Das Zeitlimit der Netzwerkoperation wurde überschritten.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/api/qxmlserializer.cpp" line="+290"/>
        <source>Element %1 can&apos;t be serialized because it appears outside the document element.</source>
        <translation>Das Element %1 kann nicht serialisiert werden, da es außerhalb des Dokumentenelements erscheint.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qabstractdatetime.cpp" line="+50"/>
        <source>Year %1 is invalid because it begins with %2.</source>
        <translation>%1 ist keine gültige Jahresangabe, da es mit %2 beginnt.</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>Day %1 is outside the range %2..%3.</source>
        <translation>Die Tagesangabe %1 ist außerhalb des Bereiches %2..%3.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Month %1 is outside the range %2..%3.</source>
        <translation>Die Monatsangabe %1 ist außerhalb des Bereiches %2..%3.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Overflow: Can&apos;t represent date %1.</source>
        <translation>Das Datum %1 kann nicht dargestellt werden (Überlauf).</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Day %1 is invalid for month %2.</source>
        <translation>Die Tagesangabe %1 ist für den Monat %2 ungültig.</translation>
    </message>
    <message>
        <location line="+49"/>
        <source>Time 24:%1:%2.%3 is invalid. Hour is 24, but minutes, seconds, and milliseconds are not all 0; </source>
        <translation>Die Zeitangabe 24:%1:%2.%3 ist ungültig. Bei der Stundenangabe 24 müssen Minuten, Sekunden und Millisekunden 0 sein.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Time %1:%2:%3.%4 is invalid.</source>
        <translation>Die Zeitangabe %1:%2:%3.%4 ist ungültig.</translation>
    </message>
    <message>
        <location line="+115"/>
        <source>Overflow: Date can&apos;t be represented.</source>
        <translation>Das Datum kann nicht dargestellt werden (Überlauf).</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qabstractduration.cpp" line="-7"/>
        <source>At least one time component must appear after the %1-delimiter.</source>
        <translation>Bei Vorhandensein eines %1-Begrenzers muss mindestens eine Komponente vorhanden sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qatomicmathematicians.cpp" line="+171"/>
        <location line="+32"/>
        <source>Dividing a value of type %1 by %2 (not-a-number) is not allowed.</source>
        <translation>Die Division eines Werts des Typs %1 durch %2 (kein numerischer Wert) ist nicht zulässig.</translation>
    </message>
    <message>
        <location line="-20"/>
        <source>Dividing a value of type %1 by %2 or %3 (plus or minus zero) is not allowed.</source>
        <translation>Die Division eines Werts des Typs %1 durch %2 oder %3 (positiv oder negativ Null) ist nicht zulässig.</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>Multiplication of a value of type %1 by %2 or %3 (plus or minus infinity) is not allowed.</source>
        <translation>Die Multiplikation eines Werts des Typs %1 mit %2 oder %3 (positiv oder negativ unendlich) ist nicht zulässig.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qatomicvalue.cpp" line="+49"/>
        <source>A value of type %1 cannot have an Effective Boolean Value.</source>
        <translation>Ein Wert des Typs %1 kann keinen effektiven Booleschen Wert haben.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qderivedinteger_p.h" line="+372"/>
        <source>Value %1 of type %2 exceeds maximum (%3).</source>
        <translation>Der Wert %1 des Typs %2 überschreitet das Maximum (%3).</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Value %1 of type %2 is below minimum (%3).</source>
        <translation>Der Wert %1 des Typs %2 unterschreitet das Minimum (%3).</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qhexbinary.cpp" line="+61"/>
        <source>A value of type %1 must contain an even number of digits. The value %2 does not.</source>
        <translation>Die Stellenzahl eines Wertes des Typs %1 muss geradzahlig sein. Das ist bei %2 nicht der Fall.</translation>
    </message>
    <message>
        <location line="+19"/>
        <source>%1 is not valid as a value of type %2.</source>
        <translation>%1 ist kein gültiger Wert des Typs %2.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qarithmeticexpression.cpp" line="+177"/>
        <source>Operator %1 cannot be used on type %2.</source>
        <translation>Der Operator %1 kann nicht auf den Typ %2 angewandt werden.</translation>
    </message>
    <message>
        <location line="+17"/>
        <source>Operator %1 cannot be used on atomic values of type %2 and %3.</source>
        <translation>Der Operator %1 kann nicht auf atomare Werte der Typen %2 und %3 angewandt werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qattributenamevalidator.cpp" line="+36"/>
        <source>The namespace URI in the name for a computed attribute cannot be %1.</source>
        <translation>Der Namensraum-URI im Namen eines berechneten Attributes darf nicht %1 sein</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>The name for a computed attribute cannot have the namespace URI %1 with the local name %2.</source>
        <translation>Der Name eines berechneten Attributes darf keinen Namensraum-URI %1 mit dem lokalen Namen %2 haben.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcastas.cpp" line="+58"/>
        <source>Type error in cast, expected %1, received %2.</source>
        <translation>Typfehler bei &quot;cast&quot;-Operation; es wurde %1 erwartet, aber %2 empfangen.</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>When casting to %1 or types derived from it, the source value must be of the same type, or it must be a string literal. Type %2 is not allowed.</source>
        <translation>Bei einer &quot;cast&quot;-Operation zum Typ %1 oder abgeleitetenTypen muss der Quellwert ein Zeichenketten-Literal oder ein Wert gleichen Typs sein. Der Typ %2 ist ungültig.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcommentconstructor.cpp" line="+37"/>
        <source>A comment cannot contain %1</source>
        <translation>Ein Kommentar darf nicht&apos;%1 enthalten</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>A comment cannot end with a %1.</source>
        <translation>Ein Kommentar darf nicht auf %1 enden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qdocumentcontentvalidator.cpp" line="+56"/>
        <source>An attribute node cannot be a child of a document node. Therefore, the attribute %1 is out of place.</source>
        <translation>Ein Attributknoten darf nicht als Kind eines Dokumentknotens erscheinen. Es erschien ein Attributknoten mit dem Namen %1.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qexpressionfactory.cpp" line="+139"/>
        <source>A library module cannot be evaluated directly. It must be imported from a main module.</source>
        <translation>Ein Bibliotheksmodul kann nicht direkt ausgewertet werden, er muss von einem Hauptmodul importiert werden.</translation>
    </message>
    <message>
        <location line="+40"/>
        <source>No template by name %1 exists.</source>
        <translation>Es existiert keine Vorlage mit dem Namen %1.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qgenericpredicate.cpp" line="+76"/>
        <source>A value of type %1 cannot be a predicate. A predicate must have either a numeric type or an Effective Boolean Value type.</source>
        <translation>Werte des Typs %1 dürfen keine Prädikate sein. Für Prädikate sind nur numerische oder effektiv Boolesche Typen zulässig.</translation>
    </message>
    <message>
        <location line="+32"/>
        <source>A positional predicate must evaluate to a single numeric value.</source>
        <translation>Ein positionales Prädikat muss sich als einfacher, numerischer Wert auswerten lassen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qncnameconstructor_p.h" line="+107"/>
        <source>%1 is not a valid target name in a processing instruction. It must be a %2 value, e.g. %3.</source>
        <translation>%1 ist kein gültiger Zielname einer Processing-Anweisung, es muss ein %2 Wert wie zum Beispiel %3 sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qpath.cpp" line="+79"/>
        <source>The last step in a path must contain either nodes or atomic values. It cannot be a mixture between the two.</source>
        <translation>Der letzte Schritt eines Pfades kann entweder nur Knoten oder nur atomare Werte enthalten. Sie dürfen nicht zusammen auftreten.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qqnameconstructor.cpp" line="+52"/>
        <source>No namespace binding exists for the prefix %1</source>
        <translation>Es existiert keine Namensraum-Bindung für den Präfix %1</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qqnameconstructor_p.h" line="-12"/>
        <source>No namespace binding exists for the prefix %1 in %2</source>
        <translation>Es existiert keine Namensraum-Bindung für den Präfix %1 in %2</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qaggregatefns.cpp" line="+90"/>
        <source>The first argument to %1 cannot be of type %2. It must be a numeric type, xs:yearMonthDuration or xs:dayTimeDuration.</source>
        <translation>Das erste Argument von %1 darf nicht vom Typ %2 sein; es muss numerisch, xs:yearMonthDuration oder xs:dayTimeDuration sein.</translation>
    </message>
    <message>
        <location line="+74"/>
        <source>The first argument to %1 cannot be of type %2. It must be of type %3, %4, or %5.</source>
        <translation>Das erste Argument von %1 kann nicht vom Typ %2 sein, es muss einer der Typen %3, %4 oder %5 sein.</translation>
    </message>
    <message>
        <location line="+91"/>
        <source>The second argument to %1 cannot be of type %2. It must be of type %3, %4, or %5.</source>
        <translation>Das zweite Argument von %1 kann nicht vom Typ %2 sein, es muss einer der Typen %3, %4 oder %5 sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qdatetimefn.cpp" line="+56"/>
        <source>If both values have zone offsets, they must have the same zone offset. %1 and %2 are not the same.</source>
        <translation>Wenn beide Werte mit Zeitzonen angegeben werden, müssen diese übereinstimmen. %1 und %2 sind daher unzulässig.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qpatternmatchingfns.cpp" line="-65"/>
        <source>%1 must be followed by %2 or %3, not at the end of the replacement string.</source>
        <translation>Auf %1 muss %2 oder %3 folgen; es kann nicht am Ende der Ersetzung erscheinen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qpatternplatform.cpp" line="-109"/>
        <source>%1 and %2 match the start and end of a line.</source>
        <translation>Die Ausdrücke %1 und %2 passen jeweils auf den Anfang oder das Ende einer beliebigen Zeile.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Whitespace characters are removed, except when they appear in character classes</source>
        <translation>Leerzeichen werden entfernt, sofern sie nicht in Zeichenklassen erscheinen</translation>
    </message>
    <message>
        <location line="+129"/>
        <source>%1 is an invalid flag for regular expressions. Valid flags are:</source>
        <translation>%1 ist kein gültiger Modifizierer für reguläre Ausdrücke. Gültige Modifizierer sind:</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qqnamefns.cpp" line="+17"/>
        <source>If the first argument is the empty sequence or a zero-length string (no namespace), a prefix cannot be specified. Prefix %1 was specified.</source>
        <translation>Es kann kein Präfix angegeben werden, wenn das erste Argument leer oder eine leere Zeichenkette (kein Namensraum) ist. Es wurde der Präfix %1 angegeben.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qstringvaluefns.cpp" line="+222"/>
        <source>The normalization form %1 is unsupported. The supported forms are %2, %3, %4, and %5, and none, i.e. the empty string (no normalization).</source>
        <translation>Die Normalisierungsform %1 wird nicht unterstützt. Die unterstützten Normalisierungsformen sind %2, %3, %4 and %5, und &quot;kein&quot; (eine leere Zeichenkette steht für &quot;keine Normalisierung&quot;).</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qtimezonefns.cpp" line="+57"/>
        <source>A zone offset must be in the range %1..%2 inclusive. %3 is out of range.</source>
        <translation>Eine Zeitzonen-Differenz muss im Bereich %1..%2 (einschließlich) liegen. %3 liegt außerhalb des Bereiches.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/janitors/qcardinalityverifier.cpp" line="+28"/>
        <source>Required cardinality is %1; got cardinality %2.</source>
        <translation>Die erforderliche Kardinalität ist %1 (gegenwärtig %2).</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qquerytransformparser.cpp" line="-3874"/>
        <source>The encoding %1 is invalid. It must contain Latin characters only, must not contain whitespace, and must match the regular expression %2.</source>
        <translation>Die Kodierung %1 ist ungültig; sie darf nur aus lateinischen Buchstaben bestehen und muss dem regulären Ausdruck %2 entsprechen.</translation>
    </message>
    <message>
        <location line="+260"/>
        <source>The keyword %1 cannot occur with any other mode name.</source>
        <translation>Das Schlüsselwort %1 kann nicht mit einem anderen Modusnamen zusammen verwendet werden.</translation>
    </message>
    <message>
        <location line="+29"/>
        <source>The value of attribute %1 must of type %2, which %3 isn&apos;t.</source>
        <translation>Der Wert des Attributs mit %1 muss vom Typ %2 sein. %3 ist kein gültiger Wert.</translation>
    </message>
    <message>
        <location line="+387"/>
        <source>A variable by name %1 has already been declared.</source>
        <translation>Es wurde bereits eine Variable mit dem Namen %1 deklariert.</translation>
    </message>
    <message>
        <location line="+135"/>
        <source>A stylesheet function must have a prefixed name.</source>
        <translation>Der Name einer Stylesheet-Funktion muss einen Präfix haben.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The namespace %1 is reserved; therefore user defined functions may not use it. Try the predefined prefix %2, which exists for these cases.</source>
        <translation>Der Namensraum %1 ist reserviert und kann daher von nutzerdefinierten Funktionen nicht verwendet werden (für diesen Zweck gibt es den vordefinierten Präfix %2).</translation>
    </message>
    <message>
        <location line="+285"/>
        <source>When function %1 is used for matching inside a pattern, the argument must be a variable reference or a string literal.</source>
        <translation>Bei der Verwendung der Funktion %1 zur Auswertung innerhalb eines Suchmusters muss das Argument eine Variablenreferenz oder ein String-Literal sein.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>In an XSL-T pattern, the first argument to function %1 must be a string literal, when used for matching.</source>
        <translation>Bei einem XSL-T-Suchmuster muss das erste Argument zur Funktion %1 bei der Verwendung zur Suche ein String-Literal sein.</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>In an XSL-T pattern, the first argument to function %1 must be a literal or a variable reference, when used for matching.</source>
        <translation>Bei einem XSL-T-Suchmuster muss das erste Argument zur Funktion %1 bei der Verwendung zur Suche ein Literal oder eine Variablenreferenz sein.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>In an XSL-T pattern, function %1 cannot have a third argument.</source>
        <translation>Bei einem XSL-T-Suchmuster darf die Funktion %1 kein drittes Argument haben.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>In an XSL-T pattern, only function %1 and %2, not %3, can be used for matching.</source>
        <translation>Bei einem XSL-T-Suchmuster dürfen nur die Funktionen %1 und %2, nicht jedoch  %3 zur Suche verwendet werden.</translation>
    </message>
    <message>
        <location line="+63"/>
        <source>In an XSL-T pattern, axis %1 cannot be used, only axis %2 or %3 can.</source>
        <translation>Bei einem XSL-T-Suchmuster dürfen nur die Achsen %2 oder %3 verwendet werden, nicht jedoch %1.</translation>
    </message>
    <message>
        <location line="+126"/>
        <source>%1 is an invalid template mode name.</source>
        <translation>%1 ist kein gültiger Name für einen Vorlagenmodus.</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>The name of a variable bound in a for-expression must be different from the positional variable. Hence, the two variables named %1 collide.</source>
        <translation>Der Name der gebundenen Variablen eines for-Ausdrucks muss sich von dem der Positionsvariable unterscheiden. Die zwei Variablen mit dem Namen %1 stehen im Konflikt.</translation>
    </message>
    <message>
        <location line="+758"/>
        <source>The Schema Validation Feature is not supported. Hence, %1-expressions may not be used.</source>
        <translation>%1-Ausdrücke können nicht verwendet werden, da Schemavalidierung nicht unterstützt wird. </translation>
    </message>
    <message>
        <location line="+39"/>
        <source>None of the pragma expressions are supported. Therefore, a fallback expression must be present</source>
        <translation>Es muss ein fallback-Ausdruck vorhanden sein, da keine pragma-Ausdrücke unterstützt werden</translation>
    </message>
    <message>
        <location line="+267"/>
        <source>Each name of a template parameter must be unique; %1 is duplicated.</source>
        <translation>Die Namen von Vorlagenparameter müssen eindeutig sein, %1 existiert bereits.</translation>
    </message>
    <message>
        <location line="-5750"/>
        <source>%1 is not a valid numeric literal.</source>
        <translation>%1 ist kein gültiger numerischer Literal.</translation>
    </message>
    <message>
        <location line="+3659"/>
        <source>The prefix %1 can not be bound. By default, it is already bound to the namespace %2.</source>
        <translation>Der Präfix %1 kann nicht gebunden werden. Er ist bereits durch Vorgabe an den Namensraum %2 gebunden.</translation>
    </message>
    <message>
        <location line="+2628"/>
        <source>Namespace %1 can only be bound to %2 (and it is, in either case, pre-declared).</source>
        <translation>Der Namensraum %1 kann nur an %2 gebunden werden. Dies ist bereits vordeklariert.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Prefix %1 can only be bound to %2 (and it is, in either case, pre-declared).</source>
        <translation>Der Präfix %1 kann nur an %2 gebunden werden. Dies ist bereits vordeklariert.</translation>
    </message>
    <message>
        <location line="+181"/>
        <source>A direct element constructor is not well-formed. %1 is ended with %2.</source>
        <translation>Es wurde ein fehlerhafter direkter Element-Konstruktor gefunden. %1 endet mit %2.</translation>
    </message>
    <message>
        <location line="+458"/>
        <source>The name %1 does not refer to any schema type.</source>
        <translation>Der Name %1 hat keinen Bezug zu einem Schematyp.</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>%1 is an complex type. Casting to complex types is not possible. However, casting to atomic types such as %2 works.</source>
        <translation>%1 ist ein komplexer Typ. Eine &quot;cast&quot;-Operation zu komplexen Typen ist nicht möglich. Es können allerdings &quot;cast&quot;-Operationen zu atomare Typen wie %2 durchgeführt werden.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>%1 is not an atomic type. Casting is only possible to atomic types.</source>
        <translation>%1 ist kein atomarer Typ. Es können nur &quot;cast&quot;-Operation zu atomaren Typen durchgeführt werden.</translation>
    </message>
    <message>
        <location line="+76"/>
        <source>%1 is not a valid name for a processing-instruction.</source>
        <translation>%1 ist kein gültiger Name für eine Prozessing-Instruktion.</translation>
    </message>
    <message>
        <location line="+188"/>
        <source>The name of an extension expression must be in a namespace.</source>
        <translation>Der Name eines Erweiterungsausdrucks muss sich in einem Namensraum befinden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/type/qtypechecker.cpp" line="-93"/>
        <source>Required type is %1, but %2 was found.</source>
        <translation>Der erforderliche Typ ist %1, es wurde aber %2 angegeben.</translation>
    </message>
    <message>
        <location line="+44"/>
        <source>Promoting %1 to %2 may cause loss of precision.</source>
        <translation>Die Wandlung von %1 zu %2 kann zu einem Verlust an Genauigkeit führen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/utils/qoutputvalidator.cpp" line="-7"/>
        <source>It&apos;s not possible to add attributes after any other kind of node.</source>
        <translation>Attribute dürfen nicht auf andere Knoten folgen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/utils/qxpathhelper_p.h" line="+90"/>
        <source>Only the Unicode Codepoint Collation is supported(%1). %2 is unsupported.</source>
        <translation>Es wird nur Unicode Codepoint Collation unterstützt (%1). %2 wird nicht unterstützt.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/acceltree/qacceltreebuilder.cpp" line="+175"/>
        <source>An %1-attribute with value %2 has already been declared.</source>
        <translation>Das Element hat bereits ein Attribut mit dem Namen %1 mit dem Wert %2.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>An %1-attribute must have a valid %2 as value, which %3 isn&apos;t.</source>
        <translation>Ein Attribut mit dem Namen %1 muss einen gültigen %2-Wert haben. %3 ist kein gültiger Wert.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qabstractfloatmathematician.cpp" line="+7"/>
        <source>The first operand in an integer division, %1, cannot be infinity (%2).</source>
        <translation>Der erste Operand der Ganzzahldivision %1 darf nicht unendlich (%2) sein .</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>The second operand in a division, %1, cannot be zero (%2).</source>
        <translation>Der zweite Operand der Division %1 darf nicht 0 (%2) sein.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/data/qatomicmathematicians.cpp" line="-180"/>
        <source>Integer division (%1) by zero (%2) is undefined.</source>
        <translation>Die  Ganzzahldivision (%1)  durch Null (%2) ist nicht definiert.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Division (%1) by zero (%2) is undefined.</source>
        <translation>Die  Division (%1)  durch Null (%2) ist nicht definiert.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Modulus division (%1) by zero (%2) is undefined.</source>
        <translation>Die  Modulo-Division (%1)  durch Null (%2) ist nicht definiert.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcastingplatform.cpp" line="-73"/>
        <source>No casting is possible with %1 as the target type.</source>
        <translation>Es können keine &quot;cast&quot;-Operationen zu dem Typ %1 durchgeführt werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qncnameconstructor_p.h" line="-24"/>
        <source>The target name in a processing instruction cannot be %1 in any combination of upper and lower case. Therefore, is %2 invalid.</source>
        <translation>%2 ist kein gültiger Zielname einer Processing-Anweisung, da dieser nicht %1 sein darf (ungeachtet der Groß/Kleinschreibung).</translation>
    </message>
    <message numerus="yes">
        <location filename="../src/xmlpatterns/functions/qabstractfunctionfactory.cpp" line="+47"/>
        <source>%1 takes at most %n argument(s). %2 is therefore invalid.</source>
        <translation>
            <numerusform>%1 hat nur %n Argument; die Angabe %2 ist daher ungültig.</numerusform>
            <numerusform>%1 hat nur %n Argumente; die Angabe %2 ist daher ungültig.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location line="+11"/>
        <source>%1 requires at least %n argument(s). %2 is therefore invalid.</source>
        <translation>
            <numerusform>%1 erfordert mindestens ein Argument; die Angabe %3 ist daher ungültig.</numerusform>
            <numerusform>%1 erfordert mindestens %n Argumente; die Angabe %3 ist daher ungültig.</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qcontextnodechecker.cpp" line="+24"/>
        <source>The root node of the second argument to function %1 must be a document node. %2 is not a document node.</source>
        <translation>Der übergeordnete Knoten des zweiten Arguments der Funktion %1 muss ein Dokumentknoten sein, was bei %2 nicht der Fall ist.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qquerytransformparser.cpp" line="-3102"/>
        <source>The namespace for a user defined function cannot be empty (try the predefined prefix %1 which exists for cases like this)</source>
        <translation>Der Namensraum einer nutzerdefinierten Funktion darf nicht leer sein (für diesen Zweck gibt es den vordefinierten Präfix %1)</translation>
    </message>
    <message>
        <location line="-693"/>
        <location line="+10"/>
        <source>A default namespace declaration must occur before function, variable, and option declarations.</source>
        <translation>Die Deklaration des Default-Namensraums muss vor Funktions- Variablen- oder Optionsdeklaration erfolgen.</translation>
    </message>
    <message>
        <location line="-3576"/>
        <source>A construct was encountered which only is allowed in XQuery.</source>
        <translation>Dieses Konstrukt ist zur in XQuery zulässig.</translation>
    </message>
    <message>
        <location line="+118"/>
        <source>A template by name %1 has already been declared.</source>
        <translation>Es existiert bereits eine Vorlage des Namens %1.</translation>
    </message>
    <message>
        <location line="+3468"/>
        <source>Namespace declarations must occur before function, variable, and option declarations.</source>
        <translation>Namensraums-Deklarationen müssen vor Funktions- Variablen- oder Optionsdeklarationen stehen.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>Module imports must occur before function, variable, and option declarations.</source>
        <translation>Modul-Importe müssen vor Funktions- Variablen- oder Optionsdeklarationen stehen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qtimezonefns.cpp" line="+12"/>
        <source>%1 is not a whole number of minutes.</source>
        <translation>%1 ist keine ganzzahlige Minutenangabe.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/api/qxmlserializer.cpp" line="+60"/>
        <source>Attribute %1 can&apos;t be serialized because it appears at the top level.</source>
        <translation>Das Attributelement %1 kann nicht serialisiert werden, da es auf der höchsten Ebene erscheint.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/acceltree/qacceltreeresourceloader.cpp" line="+284"/>
        <source>%1 is an unsupported encoding.</source>
        <translation>Das Encoding %1 wird nicht unterstützt.</translation>
    </message>
    <message>
        <location line="+16"/>
        <source>%1 contains octets which are disallowed in the requested encoding %2.</source>
        <translation>%1 enthält Oktette, die im Encoding %2 nicht zulässig sind.</translation>
    </message>
    <message>
        <location line="+18"/>
        <source>The codepoint %1, occurring in %2 using encoding %3, is an invalid XML character.</source>
        <translation>Der Code-Punkt %1 aus %2 mit Encoding %3 ist kein gültiges XML-Zeichen.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qapplytemplate.cpp" line="+89"/>
        <source>Ambiguous rule match.</source>
        <translation>Mehrdeutige Regel.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qcomputednamespaceconstructor.cpp" line="+39"/>
        <source>In a namespace constructor, the value for a namespace value cannot be an empty string.</source>
        <translation>Im Konstruktor eines Namensraums darf der Wert des Namensraumes keine leere Zeichenkette sein.</translation>
    </message>
    <message>
        <location line="+11"/>
        <source>The prefix must be a valid %1, which %2 is not.</source>
        <translation>Der Präfix muss ein gültiger %1 sein. Das ist bei %2 nicht der Fall.</translation>
    </message>
    <message>
        <location line="+14"/>
        <source>The prefix %1 cannot be bound.</source>
        <translation>Der Präfix %1 kann nicht gebunden werden</translation>
    </message>
    <message>
        <location line="+10"/>
        <source>Only the prefix %1 can be bound to %2 and vice versa.</source>
        <translation>An %2 kann nur der Präfix %1 gebunden werden (und umgekehrt).</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qevaluationcache.cpp" line="+87"/>
        <source>Circularity detected</source>
        <translation>Es wurde eine zirkuläre Abhängigkeit festgestellt.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/expr/qtemplate.cpp" line="+115"/>
        <source>The parameter %1 is required, but no corresponding %2 is supplied.</source>
        <translation>Es wurde kein entsprechendes %2 für den erforderlichen Parameter %1 angegeben.</translation>
    </message>
    <message>
        <location line="-71"/>
        <source>The parameter %1 is passed, but no corresponding %2 exists.</source>
        <translation>Es existiert kein entsprechendes %2 für den übergebenen Parameter %1.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/functions/qunparsedtextfn.cpp" line="+35"/>
        <source>The URI cannot have a fragment</source>
        <translation>Der URI darf kein Fragment enthalten.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qxslttokenizer.cpp" line="+489"/>
        <source>Element %1 is not allowed at this location.</source>
        <translation>Das Element %1 darf nicht an dieser Stelle stehen.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Text nodes are not allowed at this location.</source>
        <translation>An dieser Stelle dürfen keine Textknoten stehen.</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Parse error: %1</source>
        <translation>Parse-Fehler: %1</translation>
    </message>
    <message>
        <location line="+62"/>
        <source>The value of the XSL-T version attribute must be a value of type %1, which %2 isn&apos;t.</source>
        <translation>Der Wert eines XSL-T Versionsattributes muss vom Typ %1 sein, was bei %2 nicht der Fall ist.</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Running an XSL-T 1.0 stylesheet with a 2.0 processor.</source>
        <translation>Es wird ein XSL-T 1.0-Stylesheet mit einem Prozessor der Version 2.0 verarbeitet.</translation>
    </message>
    <message>
        <location line="+108"/>
        <source>Unknown XSL-T attribute %1.</source>
        <translation>Unbekanntes XSL-T Attribut: %1.</translation>
    </message>
    <message>
        <location line="+23"/>
        <source>Attribute %1 and %2 are mutually exclusive.</source>
        <translation>Die Attribute %1 und %2 schließen sich gegenseitig aus.</translation>
    </message>
    <message>
        <location line="+166"/>
        <source>In a simplified stylesheet module, attribute %1 must be present.</source>
        <translation>In einem vereinfachten Stylesheet-Modul muss das Attribut %1 vorhanden sein.</translation>
    </message>
    <message>
        <location line="+72"/>
        <source>If element %1 has no attribute %2, it cannot have attribute %3 or %4.</source>
        <translation>Das Element %1 darf keines der Attribute %3 order %4 haben, solange es nicht das Attribut %2 hat.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Element %1 must have at least one of the attributes %2 or %3.</source>
        <translation>Das Element %1 muss mindestens eines der Attribute %2 oder %3 haben.</translation>
    </message>
    <message>
        <location line="+28"/>
        <source>At least one mode must be specified in the %1-attribute on element %2.</source>
        <translation>Im %1-Attribut des Elements %2 muss mindestens ein Modus angegeben werden.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qmaintainingreader.cpp" line="+153"/>
        <source>Attribute %1 cannot appear on the element %2. Only the standard attributes can appear.</source>
        <translation>Das Element %2 kann nur die Standardattribute haben, nicht jedoch %1.</translation>
    </message>
    <message>
        <location line="+6"/>
        <source>Attribute %1 cannot appear on the element %2. Only %3 is allowed, and the standard attributes.</source>
        <translation>Das Element %2 kann nur %3 oder die Standardattribute haben, nicht jedoch %1.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>Attribute %1 cannot appear on the element %2. Allowed is %3, %4, and the standard attributes.</source>
        <translation>Das Element %2 kann nur %3, %4 oder die Standardattribute haben, nicht jedoch %1.</translation>
    </message>
    <message>
        <location line="+9"/>
        <source>Attribute %1 cannot appear on the element %2. Allowed is %3, and the standard attributes.</source>
        <translation>Das Element %2 kann nur %3 oder die Standardattribute haben, nicht jedoch %1.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>XSL-T attributes on XSL-T elements must be in the null namespace, not in the XSL-T namespace which %1 is.</source>
        <translation>Die XSL-T-Attribute eines XSL-T-Elements müssen im Null-Namensraum sein, nicht im XSL-T-Namensraum, wie %1.</translation>
    </message>
    <message>
        <location line="+12"/>
        <source>The attribute %1 must appear on element %2.</source>
        <translation>Das Element %2 muss das Attribut %1 haben.</translation>
    </message>
    <message>
        <location line="+8"/>
        <source>The element with local name %1 does not exist in XSL-T.</source>
        <translation>In XSL-T existiert kein Element mit dem lokalen Namen %1.</translation>
    </message>
    <message>
        <location filename="../src/xmlpatterns/parser/qxslttokenizer.cpp" line="+123"/>
        <source>Element %1 must come last.</source>
        <translation>Das Element %1 muss zuletzt stehen.</translation>
    </message>
    <message>
        <location line="+24"/>
        <source>At least one %1-element must occur before %2.</source>
        <translation>Vor %2 muss mindestens ein %1-Element stehen.</translation>
    </message>
    <message>
        <location line="+7"/>
        <source>Only one %1-element can appear.</source>
        <translation>Es darf nur ein einziges %1-Element stehen.</translation>
    </message>
    <message>
        <location line="+31"/>
        <source>At least one %1-element must occur inside %2.</source>
        <translation>In %2 muss mindenstens ein %1-Element stehen.</translation>
    </message>
    <message>
        <location line="+58"/>
        <source>When attribute %1 is present on %2, a sequence constructor cannot be used.</source>
        <translation>Es kann kein Sequenzkonstruktor verwendet werden, wenn %2 ein Attribut %1 hat.</translation>
    </message>
    <message>
        <location line="+13"/>
        <source>Element %1 must have either a %2-attribute or a sequence constructor.</source>
        <translation>Das Element %1 muss entweder ein %2-Attribut haben oder es muss ein Sequenzkonstruktor verwendet werden.</translation>
    </message>
    <message>
        <location line="+125"/>
        <source>When a parameter is required, a default value cannot be supplied through a %1-attribute or a sequence constructor.</source>
        <translation>Der Defaultwert eines erforderlichen Parameters kann weder durch ein %1-Attribut noch durch einen Sequenzkonstruktor angegeben werden. </translation>
    </message>
    <message>
        <location line="+270"/>
        <source>Element %1 cannot have children.</source>
        <translation>Das Element %1 kann keine Kindelemente haben.</translation>
    </message>
    <message>
        <location line="+432"/>
        <source>Element %1 cannot have a sequence constructor.</source>
        <translation>Das Element %1 kann keinen Sequenzkonstruktor haben.</translation>
    </message>
    <message>
        <location line="+86"/>
        <location line="+9"/>
        <source>The attribute %1 cannot appear on %2, when it is a child of %3.</source>
        <translation>%2 darf nicht das Attribut %1 haben, wenn es ein Kindelement von %3 ist.</translation>
    </message>
    <message>
        <location line="+15"/>
        <source>A parameter in a function cannot be declared to be a tunnel.</source>
        <translation>Der Parameter einer Funktion kann nicht als Tunnel deklariert werden.</translation>
    </message>
    <message>
        <location line="+149"/>
        <source>This processor is not Schema-aware and therefore %1 cannot be used.</source>
        <translation>%1 kann nicht verwendet werden, da dieser Prozessor keine Schemas unterstützt.</translation>
    </message>
    <message>
        <location line="+57"/>
        <source>Top level stylesheet elements must be in a non-null namespace, which %1 isn&apos;t.</source>
        <translation>Die zuoberst stehenden Elemente eines Stylesheets dürfen sich nicht im Null-Namensraum befinden, was bei %1 der Fall ist.</translation>
    </message>
    <message>
        <location line="+48"/>
        <source>The value for attribute %1 on element %2 must either be %3 or %4, not %5.</source>
        <translation>Der Wert des Attributs %1 des Elements %2 kann nur %3 oder %4 sein, nicht jedoch %5.</translation>
    </message>
    <message>
        <location line="+20"/>
        <source>Attribute %1 cannot have the value %2.</source>
        <translation>Das Attribut %1 darf nicht den Wert %2 haben.</translation>
    </message>
    <message>
        <location line="+58"/>
        <source>The attribute %1 can only appear on the first %2 element.</source>
        <translation>Nur das erste %2-Element darf das Attribut %1 haben.</translation>
    </message>
    <message>
        <location line="+99"/>
        <source>At least one %1 element must appear as child of %2.</source>
        <translation>%2 muss mindestens ein %1-Kindelement haben.</translation>
    </message>
</context>
<context>
    <name>VolumeSlider</name>
    <message>
        <location filename="../src/3rdparty/phonon/phonon/volumeslider.cpp" line="+67"/>
        <source>Muted</source>
        <translation>Stummschaltung</translation>
    </message>
    <message>
        <location line="+5"/>
        <location line="+15"/>
        <source>Volume: %1%</source>
        <translation>Lautstärke: %1%</translation>
    </message>
</context>
</TS>
