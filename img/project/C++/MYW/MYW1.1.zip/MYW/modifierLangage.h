#ifndef MODIFIERLANGAGE_H
#define MODIFIERLANGAGE_H

/*!
* \modifierLangage.h
* \brief Ce fichier permet de construire le widget modifierLangage
* \author Novak Audrey
* \date 12.03.2009
*/

#include <QToolBar>
#include <QLineEdit>
#include <QComboBox>
#include <QListWidget>
#include <QPushButton>
#include <QTextEdit>
#include <QPaintEvent>
#include <QObject>
#include <QLabel>
#include "coloration.h"


class Preferences;

/*!
* \class ModifierLangage
* \brief Classe permettant de construire le widget modifierLangage
*
*Ce widget est tr&egrave;s utile dans le cas d'une mise &agrave; jour d'un langage. L'utilisateur pourra rajouter ou supprimer facilement des mots cl&eacute;s.
* Il contient deux QComboBox, une zone de texte (un QLineEdit), un QListWidget et des QPushBoutton.
* Le premier QComboBox est une liste d&eacute;roulante permettant de choisir le langage que l'on veut modifier,
* apr&egrave;s avoir choisit le langage, une deuxi&egrave;me QComboBox s'affiche afin de s&eacute;lectionner le fichier de mots cl&eacute;s
* auquel on pourra rajouter ou supprimer des mots cl&eacute;s. Le choix du fichier lancera l'affichage des mots cl&eacute;s
* contenus dans la liste de mots cl&eacute;s correspondant dans le QListWidget.
*
*/

class ModifierLangage : public QWidget
{
     Q_OBJECT

    private :
        Coloration *coloration;             /*< parent de modifierLangage de type Coloration*/
        Preferences *parent;                /*< parent de modifierLangage de type Preferences*/

         QLineEdit *edit_texte;             /*< ligne d'&eacute;dition &agrave; partir de laquelle seront rentr&eacute;s les mots cl&eacute;s */


         // edition de la fenetre des options
         QComboBox *langage;                /*< QComboBox permettant de choisir le type de langage &agrave; modifier */
         QComboBox *fichier;                /*< QComboBox permettant de choisir le fichier texte concern&eacute; par les modifications*/
         QListWidget *affichage_liste;      /*< partie du wiget dans laquelle sera affich&eacute;e la liste des mots cl&eacute;s du fichier texte */
         QPushButton *ajouter_mot;          /*< bouton permettant d'ajouter des mots */
         QPushButton *suprimer;             /*< bouton permettant de supprimer des mots */
         QPushButton *parametre_default;    /*< bouton permettant de restaurer les listes par d&eacute;faut */


         QLabel *explication;               /*< fen&ecirc;tre d'explication s'affichant en cas d'erreur */


    public:
/*!
* \brief Constructeur
*
* Constructeur de la classe ModifierLangage
*
* \param parent : le parent de la classe ModifierLangage est de type Preferences
* \param colo : le widget modifierLangage est construit &agrave; partir de la classe Coloration
*/
        ModifierLangage(Coloration *colo=0,Preferences *parent = 0);

/*!
* \brief Fonction permettant d'ouvrir un fichier pass&eacute; en param&egrave;tre et de renvoyer son contenu sous forme de QString
*
* \param chemin : QString chemin du fichier &agrave; ouvrir
* \return QString le contenu du fichier est renvoy&eacute; sous forme de chaine de caract&egrave;res
*/
        QString ouvrirFic(const QString&);

/*!
* \brief Cette fonction permet d'&eacute;crire la chaine de caract&egrave;re pass&eacute;e en param&egrave;tre dans le fichier dont le chemin est lui aussi un param&egrave;tre de la fonction
*
* \param chemin : QString chemin du fichier dans lequel on &eacute;crira la chaine de caract&egrave;re
* \param chaine : QString chaine de caract&egrave;re &agrave; &eacute;crire dans le fichier
*/
        void ecrireFic(const QString&, QString);

/*!
* \brief Cette fonction permet de supprimer le mot cl&eacute; qui sera selectionn&eacute; par l'utilisateur. Elle l'enl&egrave;ve d'abbord de
*  la liste de mots cl&eacute;s, puis du fichier texte concern&eacute;.
*
* \param chemin : QString chemin du fichier dans lequel on supprimera le mot cl&eacute;
*/
        void suprimerMotFichier(const QString&);

    public slots:
/*!
* \brief Slot appel&eacute; par le bouton ajouter_mot, il permet de r&eacute;cuperer le texte le texte contenu dans le QLineEdit, et de l'ajouter dans le fichier
* correspondant au choix du langage ainsi qu'au fichier texte
*
*/
        QString  modifierFichierLangage();


/*!
* \brief Slot appel&eacute; lorsqu'on a fait une modification sur un fichier : suppression ou ajout de mots cl&eacute;s
* Elle permet une mise &agrave; jour de la liste de mots cl&eacute;s dans affichage_liste
*
*/
        void miseAJourListe();


/*!
* \brief Slot appel&eacute; par le bouton suprimer il lance la fonction supprimerMot() et la mise &agrave; jour de la liste
* avec le slot : miseAJourListe();

*
*/
        void supprimerMot();

/*!
* \brief Slot permettant de r&eacute;initialiser la liste de mots cl&eacute;s en fonction du langage choisit et du fichier selectionn&eacute;
* appel&eacute; par le bouton parametre_default. Ce slot va chercher dans un dossier nomm&eacute; : fichiers_initiaux les fichiers
* correspondant et remplacent ceux qui ont &eacute;t&eacute; modifi&eacute;s pas ceux l&agrave;.
*
*/
        void reinitialiser();

/*!
* \brief Slot appel&eacute; lorsque le choix du langage avec la QComboBox langage aura chang&eacute;,
* il mettra ainsi &agrave; jour et l'affichage la liste des fichiers (dans le QComobox fichier) en fonction du langage choisi
*
*\param i : int entier correspondant au numero du langage dans la QComboBox
*/
        void modifierCombobox(int);

/*!
* \brief Slot appel&eacute; lorsque le choix du fichier avec la QComboBox fichier aura chang&eacute;,
* il permettra l'affichage de la liste des mots cl&eacute;s dans affichage_liste, &agrave; partir de l'entier
* correspondant au num&eacute;ro du fichier concern&eacute;
*
*\param i : int entier correspondant au numero du fichier dans la QComboBox
*/
        void afficherListe(int);

/*!
* \brief Slot appel&eacute; par le bouton valider, il relance la r&eacute;initialisation des langage, fonction contenue dans Coloration
*
*/
        void validerModifierLangage();


/*!
* \brief Slot permettant de v&eacute;rifier que les mots entr&eacute;s dans le QLineEdit correspondent bien aux expressions r&eacute;guli&egrave;res qu'on a d&eacute;finie
* si ca correspond, la ligne se colore en vert, et le bouton ajouter_mot se d&eacute;grise, sinon, la ligne se colore en rouge, et le
* bouton ajouter_mot reste gris&eacute;
*/
        void afficherBoutonAjouter(QString);

/*!
* \brief Slot permettant d'appliquer une recoloration de tous les onglets ouverts,
* d&egrave;s que l'utilisateur aura appuyer sur tout_appliquer
* Fait appel au rehighlight de Coloration
*
*/
        void recolorer();
};

#endif // MODIFIERLANGAGE_H
