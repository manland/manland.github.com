package Server.Adapter;

public interface IListenerAdapter 
{
	public void goIn(IAdapter adapter);
	public void goOut(IAdapter adapter);
}
