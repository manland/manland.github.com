package Server.Indoor.Graphic;

public interface IEcouteurServerThread {
	void finish(ServerThread server);
}
