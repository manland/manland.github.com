package Server.Translator;

public interface IListenerTranslator 
{
	public void goIn(ITranslator adapter);
	public void goOut(ITranslator adapter);
}
