<!--D�part :
<A HREF="#mot_cl�">Texte_ou_image_�_cliquer</A>

Arriv�e :
<A NAME="mot_cl�">Texte_ou_image</A> -->

<a href="index.html"><img src="imagesDoc/retour.png" width="8%" style="position: fixed; bottom: 10px; right: 10px;" /></a>

<table width="95%" border="0" align="center">
  <tr>
    <td align="center"><img src="images/titre_aide.png" width="334" height="61" /></td>
  </tr>
</table>


<p>&nbsp;</p>
<table width="95%" border="0" align="center">
  <tr>
    <td>
    
    <p><A HREF="#1">1. G�n�ralit�s</A><br/>
  <A HREF="#2">2. Pr�requis</A><br/>
</p>
<BLOCKQUOTE>
<A HREF="#2.1">2.1. Librairies sp�ciales </A><br/>
		<A HREF="#2.2">2.2. Lancement d'Oracle </A><br/>
	</BLOCKQUOTE>
<A HREF="#3">3. Lancement de l'application</A><br/>
<A HREF="#4">4. Gestion des personnes </A><br/>
	<BLOCKQUOTE>
		<A HREF="#4.1">4.1. G�rer le personnel </A><br/>
			<BLOCKQUOTE>
				<A HREF="#4.1.1">4.1.1 Consulter le personnel </A><br/>
				<A HREF="#4.1.2">4.1.2 Ajouter du personnel </A><br/>
				<A HREF="#4.1.3">4.1.3 Modifier le personnel </A><br/>
				<A HREF="#4.1.4">4.1.4 Supprimer le personnel </A><br/>
				<A HREF="#4.1.5">4.1.5 Retourner sur la page d'accueil </A><br/>		
				
			</BLOCKQUOTE>
			
		<A HREF="#4.2">4.2. G�rer les utilisateurs </A><br/>
			<BLOCKQUOTE>
				<A HREF="#4.2.1">4.2.1 Consulter les utilisateurs </A><br/>
				<A HREF="#4.2.2">4.2.2 Ajouter un utilisateur </A><br/>
				<A HREF="#4.2.3">4.2.3 Modifier les utilisateurs </A><br/>
				<A HREF="#4.2.4">4.2.4 Supprimer un utilisateur </A><br/>
				<A HREF="#4.2.5">4.2.5 Retourner sur la page d'accueil </A><br/>		
				
			</BLOCKQUOTE>
			
	</BLOCKQUOTE>
<A HREF="#5">5. Gestion des batiments </A><br/>
	<BLOCKQUOTE>
		<A HREF="#5.5">5.5. G�rer les casiers </A><br/>
			<BLOCKQUOTE>
				<A HREF="#5.5.1">5.5.1 Consulter les r�servations des casiers</A><br/>
				<A HREF="#5.5.2">5.5.2 R�server un casier</A><br/>
				<A HREF="#5.5.3">5.5.3 R�servations annuelles</A><br/>
				
			</BLOCKQUOTE>		
			
	</BLOCKQUOTE>
	
<A HREF="#6">6. Gestion des mat�riels </A><br/>
	<BLOCKQUOTE>
		<A HREF="#6.1">6.1. Vente de mat�riel </A><br/>
			<BLOCKQUOTE>
				<A HREF="#6.1.1">6.1.1 Cr�ation du mat�riel</A><br/>
				<A HREF="#6.1.2">6.1.2 Modification du mat�riel</A><br/>
				<A HREF="#6.1.3">6.1.3 Suppression du mat�riel</A><br/>	
			</BLOCKQUOTE>	

		<A HREF="#6.2">6.2. Achat du mat�riel </A><br/>
			<BLOCKQUOTE>
				<A HREF="#6.2.1">6.2.1 Ajouter du mat�riel � acheter</A><br/>
				<A HREF="#6.2.2">6.2.2 Modifier le mat�riel � acheter</A><br/>
				<A HREF="#6.2.3">6.2.3 Supprimer le mat�riel selectionn�</A><br/>	
				<A HREF="#6.2.4">6.2.4 Consulter la facture</A><br/>	
			</BLOCKQUOTE>				
			
	</BLOCKQUOTE>
	
<A HREF="#8">8. Gestion des options et param�tres </A><br/>
	<BLOCKQUOTE>
		<A HREF="#8.1">8.1. Gestion des param�tres </A><br/>
			<BLOCKQUOTE>
				<A HREF="#8.1.1">8.1.1 Choisir le skin</A><br/>
				<A HREF="#8.1.2">8.1.2 Choisir la langue</A><br/>
				<A HREF="#8.1.3">8.1.3 Suppression du mat�riel</A><br/>	
			</BLOCKQUOTE>	
		<A HREF="#8.2">8.2. D�connexion </A><br/>
	</BLOCKQUOTE>
	


<A NAME="1"><h3>1. G�n�ralit�s</h3></A> 
Le programme Musquash est une application cr�e sous Java qui permet la gestion d'un complexe sportif. L'application a �t� programm� sous Java. La systeme de g�stion de la base de donn�es choisi est Oracle dans sa version Database Express Edition 10g.<br/>
Cette version de l'application a �t� optimis� pour la gestion des salles de musculation et des terrains de squash.<br/>
L'application fonctionne sous Windows XP ainsi que sous Ubuntu.
<br/>
<br/>

<A NAME="2"><h3>2. Pr�requis</h3></A> 
<B>Java Virtual Machine</B> : Connu �galement sous le nom de machine virtuelle Java (Java Virtual Machine, JVM, VM et Java VM ou Java Runtime Environment, JRE et Java Runtime) (...<A HREF="http://java.com/fr/download/">t�l�charger</A>). 
<br/>
<B>Oracle Database </B>: Version <A HREF="http://www.oracle.com/technology/products/database/xe/index.html"> Windows </A>, Version <A HREF="http://doc.ubuntu-fr.org/oracle"> UBUNTU </A>
 <br/>
 <B>Eclipse </B> : Environnement de d�veloppement (...<A HREF="http://www.eclipse.org/downloads/"> telecharger </A>)
<br/>

<BLOCKQUOTE>
<A NAME="2.1"><h4>2.1. Librairies sp�ciales</h4></A> 
Deux librairies sp�cifiques sont utilis�es: ojdbc14.jar et jcalendar-1.3.3.jar. <br/>
Pour les importer sous Eclipse cliquer sur: <b> Project->Properties->Java build Path->Librairies->Add External JAR's </b><br/>
Chercher les librairies sur le disque dur et les importer.<br/>
Cliquer sur OK.<br/>

<A NAME="2.2"><h4>2.2. Lancement d'Oracle</h4></A> 
Apr�s l'installation d'Oracle Express Edition 10g cr�er un utilisateur en suivant la guide <A HREF="http://download.oracle.com/docs/cd/B25329_01/doc/admin.102/b25610/toc.htm">"Getting Started"</A> �tapes 1,2,3. <br/>
Lancer le serveur Oracle 10 <B>Demarrer->Tous les programmes->Oracle Database 10g Express Edition->D�marrer la base de donn�es</B><br/>

</BLOCKQUOTE>
 
<h3><A NAME="3">3. Lancement de l'application</A></h3>
Lors du lancement du programme il faut se connecter � la base de donn�es Oracle. <br/>
<BLOCKQUOTE>
1. Entrer le nom d'utilisateur et le mot de passe de l'utilisateur cr�e sous Oracle (voir "<A HREF="#2.2">2.2. Lancement d'Oracle</A>", par d�faut nom_d'utilisateur=hr et mot_de_passe=hr)<br/><br/>
<IMG SRC="imagesDoc/connection.jpg"><br/><br/>
2. Cliquer sur "Valider"<br/><br/>
La page d'accueil apparait.

</BLOCKQUOTE>


<!--  Ajouter l'image de la page d'accueil 


-->
<br/>

<!-- ################# PERSONNES ################# -->

<h2><A NAME="4">4. Gestion des personnes </A></h2>
	<BLOCKQUOTE>
		
		
		<!-- ******************* PERSONNEL *******************-->	
		
		<A NAME="4.1"><h3>4.1. G�rer le personnel </h3></A>
		Pour g�rer le personnel cliquer sur le menu d�roulant <B>Personnes</B> et cliquer sur <B>Personnel</B> <br/>
		
			<BLOCKQUOTE>
				<A NAME="4.1.1"><h4>4.1.1 Consulter le personnel</h4> </A>
					<BLOCKQUOTE>
						1. Aller sur l'icone <B> Personnes -> Personnel </B> <br/>
						2. L'onglet <B>Personnel</B> apparait. <br/>
					</BLOCKQUOTE>
				
				<A NAME="4.1.2"><h4>4.1.2 Ajouter du personnel</h4></A>
					<BLOCKQUOTE>
						1. Aller sur l'onglet <B> Personnel </B> <br/>
						2. Cliquer sur <B> Ajouter </B> <br/>
						3. Remplire les donn�es dans la fen�tre qui apparait <br/>
							<BLOCKQUOTE>
								<IMG SRC="imagesDoc/ajouterPersonnel.jpg"><br/>
							</BLOCKQUOTE>
						4. Cliquer sur <B> Valider </B><br/>
					</BLOCKQUOTE>
				
				<A NAME="4.1.3"><h4>4.1.3 Modifier le personnel </h4></A>
					<BLOCKQUOTE>
						1. Selectionner la ligne de la personne � modifier. <br/>
						2. Cliquer sur <B> Modifier </B> <br/>
						3. Modifier les donn�es. <br/>
						4. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="4.1.4"><h4>4.1.4 Supprimer le personnel </h4></A>
					<BLOCKQUOTE>
						1. Selectionner la ligne de la personne � modifier. <br/>
						2. Cliquer sur <B> Modifier </B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="4.1.5"><h4>4.1.5 Retourner sur la page d'accueil </h4></A>
					<BLOCKQUOTE>
						1. Cliquer sur <B> Home </B> <br/>
					</BLOCKQUOTE>
					
			</BLOCKQUOTE>
			<br/>
			
			
		<!-- ******************* UTILISATEURS *******************-->	
			
		<A NAME="4.2"><h3>4.2. G�rer les utlisateurs </h3></A>
		Aller sur le menu d�roulant <B>Personnes</B> et cliquer sur <B>Utilisateurs</B> <br/>
		
			<BLOCKQUOTE>
				<A NAME="4.2.1"><h4>4.2.1 Consulter les utilisateurs</h4> </A>
					<BLOCKQUOTE>
						1. Aller sur l'icone <B> Personnes -> Utilisateurs </B> <br/>
						2. L'onglet <B>Utilisateurs</B> apparait. <br/>
					</BLOCKQUOTE>
				
				<A NAME="4.2.2"><h4>4.2.2 Ajouter un utilisateur</h4></A>
					<BLOCKQUOTE>
						1. Aller sur l'onglet <B> Utilisateur </B> <br/>
						2. Cliquer sur <B> Ajouter </B> <br/>
						3. Remplire les donn�es dans la fen�tre qui apparait <br/>
							<BLOCKQUOTE>
								<IMG SRC="imagesDoc/ajouterPersonnel.jpg"><br/>
							</BLOCKQUOTE>
						4. Cliquer sur <B> Valider </B><br/>
					</BLOCKQUOTE>
				
				<A NAME="4.2.3"><h4>4.2.3 Modifier les utilisateurs </h4></A>
					<BLOCKQUOTE>
						1. Selectionner la ligne de l'utilisateur � modifier. <br/>
						2. Cliquer sur <B> Modifier </B> <br/>
						3. Modifier les donn�es. <br/>
						4. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="4.2.4"><h4>4.2.4 Supprimer un utilisateur </h4></A>
					<BLOCKQUOTE>
						1. Selectionner la ligne de la personne � supprimer. <br/>
						2. Cliquer sur <B> Supprimer</B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="4.2.5"><h4>4.2.5 Retourner sur la page d'accueil </h4></A>
					<BLOCKQUOTE>
						1. Cliquer sur <B> Home </B> <br/>
					</BLOCKQUOTE>
					
			</BLOCKQUOTE>
			<br/>
			
	</BLOCKQUOTE>


<!-- ################# BATIMENTS ################# -->

<h2><A NAME="5">5. Gestion des batiments </A></h2>
	<BLOCKQUOTE>
		
		<!-- ******************* CASIER *******************-->	
		
		<A NAME="5.5"><h3>5.5. G�rer les casiers </h3></A>
		Pour g�rer les casiers cliquer sur menu d�roulant <B>Batiments</B> et cliquer sur <B>Casier</B>. L'onglet de g�stion des casiers va apparaitre: <br/><br/>
			
			<IMG SRC="imagesDoc/gestionCasiers.jpg"><br/><br/>
			
		- La partie gauche de la fen�tre contient le calendrier permettant de choisir la date de la r�servation. <br/>
		- La partie droite contient une vue de la liste des casiers. <br/>
			
			<BLOCKQUOTE>
				<A NAME="5.5.1"><h4>5.5.1 Consulter les r�servations des casiers</h4> </A>
					<BLOCKQUOTE>
						1. Choisir la date <br/>
						2. Choisir le casier <br/>
					</BLOCKQUOTE>
					
			
				<A NAME="5.5.2"><h4>5.5.2 R�server un casier</h4> </A>
					<BLOCKQUOTE>
						1. Choisir la date. <br/>
						2. Chosir le casier en cliquant dessus. Le cr�neau horaire de la journ�e apparait: <br/>
							<BLOCKQUOTE>
								<IMG SRC="imagesDoc/creneauCasier.jpg"><br/>
							</BLOCKQUOTE>
						3. Selectionner le cr�neau horaire libre d�sir�. (Un cr�neau horaire est libre si � droite de l'heure n'apparait pas le nom d'un utlisateur. ) <br/>
						4. Cliquer sur R�server. <br/>
						5. Controler les donn�es de la r�servation dans la fen�tre qui apparait (le type de r�servation: ann�e ou journ�e, votre nom, la dur�e).<br/>
						6. Cliquer sur Valider.
						7. Votre nom apparait � droite du cr�neau horaire r�serv�.
					</BLOCKQUOTE>
				
				<A NAME="5.5.3"><h4>5.5.3 R�servations annuelles</h4> </A>
				Pour vous permettre de choisir facilement des casiers � r�server pour toute l'ann�e vous pouvez choisir la <B>Vue Ann�e</B>
					<BLOCKQUOTE>
						1. Cliquer sur <B>Vue Ann�e</B>. La liste des casiers apparait<br/>
						2. Cliquer sur le numero de casier. Son �tat apparait � droite de la fen�tre (dans l'image ci-dessous le casier nr.5 est Vide).  <br/>
							<BLOCKQUOTE>
								<IMG SRC="imagesDoc/reservAnnuel.jpg"><br/>
							</BLOCKQUOTE>
						3. Cliquer sur <B>R�server</B>.<br/>
						4. Controler les donn�es de la r�servation. <br/>
						5. Cliquer sur <B>Valider</B>.<br/>
					</BLOCKQUOTE>
			</BLOCKQUOTE>
	</BLOCKQUOTE>
						


<!-- ################# EUROS ################# -->
<br/>
<h2><A NAME="6">6. Gestion des materiels </A></h2>
	<BLOCKQUOTE>
		
		
		Pour g�rer le mat�riel disponible aller sur <B>Euros</B> et cliquer sur <B>Vente</B>. L'onglet de g�stion des mat�riels va apparaitre: <br/><br/>
			
			<IMG SRC="imagesDoc/gestionMateriels.jpg"><br/><br/>
			
		La fenetre est divis� en 2 parties:
		- La partie gauche de la fen�tre contient la liste des mat�riels selectionn�s pour l'achat <br/>
		- La partie droite contient l'ensemble des materiels disponibles � l'achat. <br/>
		En cliquant sur chacune des parties, la fen�tre va s'�largir automatiquement vous permettant de g�rer plus facilement les modifications souhait�s.<br/>
		
		
		<!-- ******************* VENTE *******************-->	
		
		<A NAME="6.1"><h3>6.1. Vente de mat�riel </h3></A>
		
		Si vous etes un administrateur, ou un personnel vous pouvez gerer les materiels � vendre en <B> ajoutant </B>, <B> modificant </B> ou supprimant le mat�riel disponible.
		
		
		<br/>
			<BLOCKQUOTE>
				<A NAME="6.1.1"><h4>6.1.1 Cr�ation du mat�riel</h4> </A>
					<BLOCKQUOTE>
						1. Cliquer sur <B>Ajouter</B> <br/>
						2. Remplir les donn�es dans la fen�tre qui s'affiche <br/>
						<BLOCKQUOTE>
							<IMG SRC="imagesDoc/ajouterMateriel.jpg">
						</BLOCKQUOTE>
						3. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="6.1.2"><h4>6.1.2 Modification du mat�riel</h4> </A>
					<BLOCKQUOTE>
						1. Choisissez le mat�riel � modifier en y cliquant dessus <br/>
						2. Double-cliquer sur la propri�t� � modifier <br/>
						3. Effacer la valeur existante, en appuyant sur la touche <I> BACKSPACE </I> du clavier. <br/>
						4. Entrer la nouvelle valeur <br/>
						5. Appuyer sur la touche <I> ENTREE </I> du clavier <br/>
					</BLOCKQUOTE>
					
				<A NAME="6.1.3"><h4>6.1.3 Suppr�ssion du mat�riel</h4> </A>
					<BLOCKQUOTE>
						1. Choisissez le mat�riel � supprimer en y cliquant dessus <br/>
						2. Cliquer sur le bouton <B> Effacer </B> <br/>
						3. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
			Pour retourner � la page d'accueil cliquer sur <B> Home </B>. <br/>
			
			</BLOCKQUOTE>
			
			
		<!-- ******************* ACHAT *******************-->	
		<A NAME="6.2"><h3>6.2. Vente de mat�riel </h3></A>
		
			<BLOCKQUOTE>
				<A NAME="6.2.1"><h4>6.2.1 Ajouter du mat�riel � acheter</h4> </A>
					<BLOCKQUOTE>
						1. Cliquer sur <B>Ajouter</B> <br/>
						2. Selectionner le nom de l'acheteur, le mat�riel � acheter et ins�rer la quantit� d�sir�e<br/>
						3. Cliquer sur <B> Valider </B> <br/>
						Le mat�riel selectionn� va s'ajouter � la liste. <br/>
					</BLOCKQUOTE>
					
				<A NAME="6.2.2"><h4>6.2.2 Modifier le mat�riel � acheter</h4> </A>
					<BLOCKQUOTE>
						1. Choisissez le mat�riel � modifier en y cliquant dessus <br/>
						2. Cliquer sur <B> Modifier </B> <br/>
						3. Faire les modifications d�sir�es <br/>
					</BLOCKQUOTE>
					
				<A NAME="6.2.3"><h4>6.2.3 Supprimer le mat�riel selectionn�</h4> </A>
					<BLOCKQUOTE>
						1. Choisissez le mat�riel � supprimer en y cliquant dessus <br/>
						2. Cliquer sur le bouton <B> Supprimer </B> <br/>
						3. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="6.2.4"><h4>6.2.4 Consulter la facture</h4> </A>
					<BLOCKQUOTE>
						1. Cliquer sur le bouton <B> Facture </B> <br/>
					</BLOCKQUOTE>
				
				Pour retourner � la page d'accueil en tout instant cliquer sur <B> Home </B>. <br/>
			
			</BLOCKQUOTE>
			

			
			
<!-- ################# OPTIONS ################# -->
<br/>
<h2><A NAME="8">8. Gestion des options et param�tres </A></h2>
	<BLOCKQUOTE>
		
		
		L'application Musquash vous permet de gerer plusieurs parametres pour l'adapter a vos besoins. Vous pouvez adapter la skin de votre application � votre personnalit� en choisissant parmi les differentes skins propos�s, ou changer la langue pour permettre � vos clients �trangers d'utiliser facilement l'application. Par d�faut 4 langues sont disponibles (fran�ais, anglais, italien, albanais). <br/>
		Pour modifier les param�tres depuis la page d'accueil aller sur <B> Options -> Parametres</B>
		<br/><br/>
			
			<IMG SRC="imagesDoc/options.jpg"><br/><br/>
			
		
		
		<!-- ******************* PARAMETRES *******************-->	
		
		<A NAME="8.1"><h3>8.1. Gestion des param�tres </h3></A>
		
			<BLOCKQUOTE>
				<A NAME="8.1.1"><h4>8.1.1 Choisir le skin</h4> </A>
					<BLOCKQUOTE>
						1. Cliquer sur le menu d�roulant se trouvant � l'int�rieur de <B>Skin</B> <br/>
						2. Choisir le skin d�sir�. Un aper�u des principales icones va apparaitre<br/>
						3. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
					
				<A NAME="8.1.2"><h4>8.1.2 Choisir la langue</h4> </A>
					<BLOCKQUOTE>
						1. Cliquer sur le menu deroulant se trouvant � l'int�rieur de <B>Langue</B> <br/>
						<BLOCKQUOTE>
						<IMG SRC="imagesDoc/menuLangues.jpg">
						</BLOCKQUOTE>
						2. Choisir la langue d�sir�. Le nom des menus changera en fonction de la langue choisie. <br/>
						3. Cliquer sur <B> Valider </B> <br/>
					</BLOCKQUOTE>
					
				Pour enregistrer vos choix cliquer sur <B> Enregistrer </B>. <br/>
						
			</BLOCKQUOTE>	
		
		<A NAME="8.2"><h3>8.2. D�connexion </h3></A>
		<BLOCKQUOTE>
			Pour vous d�connecter aller sur <B> Options -> D�connexion </B> <br/>
		</BLOCKQUOTE>
		<br/>
    
    </td>
  </tr>
</table>

		
		
		
				

 
 
 
 
 
 
 
 
 
 