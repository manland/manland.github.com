<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Cours et Tarifs</title>
<meta http-equiv="Content-Language" content="English" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="tableau.css" media="screen" />

<style type="text/css">
<!--
img {
	text-align: left;
}
-->
</style>
</head>
<?php
//phpinfo();
include("connexion.php");
?>

<body>

<div id="wrap">

<div id="header">
<h1><a href="#">Bienvenue sur Musquash</a></h1>
<h2>Pour entretenir le corps et l'esprit</h2>
</div>

<div id="menu">
<ul>
<li><a href="index.html">Accueil</a></li>
<li><a href="#">Cours/Tarifs</a></li>
<li><a href="consultation.php">Planning</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="aide.php">Aide</a></li>
</ul>
</div>

<div id="content">

<center>
  <p>&nbsp;</p>
  <p><img src="images/titre_tarifs.png" alt="" width="334" height="61" /></p>
  <p>&nbsp;</p>
  <center>
    <p>&nbsp;</p>
      <center>
        <table width="80%" border="0" id="matable">
      	<tr>
          <th width="30%" scope="col">Forfaits / Tarifs</th>
          <th width="17.5%" scope="col">Mois</th>
          <th width="17.5%" scope="col">Trimestre</th>
          <th width="17.5%" scope="col">Semestre</th>
          <th width="17.5%" scope="col">Année</th>
        </tr>
      	<?php
			$sql = "(SELECT * FROM forfait)";
			$requet = oci_parse($conn, $sql);
			$res = oci_execute($requet); 
			
			$count=1;
			while ($row = oci_fetch_array($requet, OCI_BOTH))
			{
				echo "
					<tr>
					  <th scope=\"row\" width=\"30%\">".$row['TYPE_FORFAIT']."</th>
					  <td width=\"17.5%\">".$row['PRIX_MOIS']." €</td>
					  <td width=\"17.5%\">".$row['PRIX_TRIMESTRE']." €</td>
					  <td width=\"17.5%\">".$row['PRIX_SEMESTRE']." €</td>
					  <td width=\"17.5%\">".$row['PRIX_AN']." €</td>
					</tr>
				";
				$count++;
			}
			
			if($count==1)
			{
				echo "
					<tr>
					  <td colspan=\"5\" align=\"center\">Aucun forfait</td>
					</tr>
				";
			}
		?>
      </table>
        
        </center>
    <p>&nbsp;</p>
  </center>
      <p>N'oubliez pas! Les prix sont dégressifs en fonction du nombre de forfait choisi.</p>
      <p>Demander plus de renseignements directement en salle.</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <table width="80%" border="0">
        <tr>
          <th align="left" scope="col"><img src="images/titre_locations.png" alt="" width="334" height="49" /></th>
        </tr>
      </table>
      <center>
        <table width="80%" border="1" id="matable">
        <tr>
          <td colspan="3"><img src="images/titre_terrains.png" alt="" width="361" height="38" /></td>
        </tr>
        <tr>
          <th width="40%" scope="col">&nbsp;</th>
          <th width="30%" scope="col">Non Adhérent</th>
          <th scope="col">Adhérent</th>
          </tr>
        <tr>
          <th scope="row">A la Séances</th>
          <td>10 €</td>
          <td>5 €</td>
          </tr>
        <tr>
          <th scope="row">Avec Carte (10 séances)</th>
          <td>90 €</td>
          <td>40 €</td>
          </tr>
      </table>
      </center>
        <p>&nbsp;</p>
        <center>
        <table width="80%" border="1" id="matable">
          <tr>
            <td colspan="4"><img src="images/titre_casiers.png" alt="" width="361" height="38" /></td>
          </tr>
          <tr>
            <th width="30%" scope="col">&nbsp;</th>
            <th width="20%" scope="col">Prix</th>
            <th width="20%" scope="col">Caution</th>
            <th width="20%" scope="col">Montant Total</th>
          </tr>
          <tr>
            <th scope="row">A la Séances</th>
            <td>2 €</td>
            <td>5 €</td>
            <td>7 €</td>
          </tr>
          <tr>
            <th scope="row">A l'Année</th>
            <td>20 €</td>
            <td>50 €</td>
            <td>70 €</td>
          </tr>
        </table>
      </center>
      
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
</center>

</div>

<?php	
include("deconnexion.php");
?>

<div id="bottom"> </div>
<div id="footer">
Copyright 2009/2010 - Master 1 Informatique - UM2
</div>

</div>
</body>
</html>