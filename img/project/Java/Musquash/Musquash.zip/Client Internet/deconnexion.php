<?php
// Se d�connecter de la base
ocilogoff($conn);
?>