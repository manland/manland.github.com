<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Contact</title>
<meta http-equiv="Content-Language" content="English" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="tableau.css" media="screen" />
<style type="text/css">
<!--
th {
	text-align: left;
}
-->
</style>
</head>
<body>
<?php
	if(isset($_POST["email"]) && isset($_POST["objet"]) && isset($_POST["message"]) && isset($_POST["Envoyer"]))
	{
		$msg="";
		$email_webmaster="staff@musquash.com";
		$i=0;
		if(empty($_POST["email"])) { $msg.="Le champs <b>email</b> est vide.<br />"; $i++; }
		if(empty($_POST["objet"])) { $msg.="Le champs <b>objet</b> est vide.<br />"; $i++; }
		if(empty($_POST["message"])) { $msg.="Le champs <b>message</b> est vide.<br />"; $i++; }
		
		if(!empty($_POST["email"]) && !empty($_POST["objet"]) && !empty($_POST["message"]))
		{
			$_POST["email"]=trim(stripslashes($_POST["email"]));
			$_POST["objet"]=trim(stripslashes($_POST["objet"]));
			$_POST["message"]=trim(stripslashes($_POST["message"]));
													   
			if (!preg_match("/^[a-z0-9&\'\.\-_\+]+@[a-z0-9\-]+\.([a-z0-9\-]+\.)*+[a-z]{2}/is",$_POST["email"]))
			{ $msg.="Votre adresse e-mail n'est pas valide...<br />"; $i++; }
			else
			{
				$entete = "From: ".$email_webmaster."\n";
				$entete .= "MIME-Version: 1.0";
				
				if(@mail($_POST["email"],$_POST["objet"],$_POST["message"],$entete)) { $msg.="Le message a été envoyé."; }
				else { $msg.="<b>Le message n'a pas été envoyé.</b>"; }
			}
			
		}
	}
?>

<div id="wrap">

<div id="header">
<h1><a href="#">Bienvenue sur Musquash</a></h1>
<h2>Pour entretenir le corps et l'esprit</h2>
</div>

<div id="menu">
<ul>
<li><a href="index.html">Accueil</a></li>
<li><a href="coursettarifs.php">Cours/Tarifs</a></li>
<li><a href="consultation.php">Planning</a></li>
<li><a href="#">Contact</a></li>
<li><a href="aide.php">Aide</a></li>
</ul>
</div>

<div id="content">

<center>
  <p>&nbsp;</p>
  <p><img src="images/titre_contact.png" alt="" width="334" height="61" /></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
<table width="80%" border="0">
  <tr>
    <th scope="row"><img src="images/titre_courrier.png" alt="" width="334" height="49" /></th>
  </tr>
</table>
<center>
  <table width="64%" border="1" id="matable">
    <tr>
      <th width="17%" scope="row">Adresse</th>
      <td width="83%"> Place Eugène Bataillon </td>
    </tr>
    <tr>
      <th scope="row">Code Postal</th>
      <td>34095</td>
    </tr>
    <tr>
      <th scope="row">Ville</th>
      <td>Montpellier</td>
    </tr>
    <tr>
      <th scope="row">Téléphone</th>
      <td> 04 67 14 30 28</td>
    </tr>
  </table>
  </center>
  <p>&nbsp;</p>
  <table width="80%" border="0">
    <tr>
      <th scope="row"><a name="ancre1" id="ancre1"><img src="images/titre_email.png" alt="" width="334" height="49" /></a></th>
    </tr>
  
  <p>
    <?php
		echo "<tr><td><div style=\"color: red;\">";
  		if(isset($msg)) { echo $msg; }
		echo "</tr></td>";
	?>
  </p>
  </table>
  <center>
    <form id="form1" method="post" action="">
  <table width="80%" border="1" id="matable">
    <tr>
      <th width="22%" scope="row">Email</th>
      <td width="78%">
        <p>
          <label>
            <input type="text" name="email" id="email" size="100%"/>
          </label>
        </p></td>
    </tr>
    <tr>
      <th scope="row">Objet</th>
      <td>
        <p>
          <label>
            <input type="text" name="objet" id="objet" size="100%" />
          </label>
        </p>
      </td>
    </tr>
    <tr>
      <th scope="row">Message</th>
      <td>
        <p>
          <textarea name="message" rows="10" id="message" cols="77%"></textarea>
        </p>
      </td>
    </tr>
    <tr>
      <th colspan="2" scope="row"><label>
        <center><input type="submit" name="Envoyer" id="Envoyer" value="Envoyer" /></center>
      </label></th>
      </tr>
  </table>
  </form>
  </center>
  <p>&nbsp;</p>
</center>

</div>

<div id="bottom"> </div>
<div id="footer">Copyright 2009/2010 - Master 1 Informatique - UM2 </div>

</div>
</body>
</html>