<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Consultation</title>
<meta http-equiv="Content-Language" content="English" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<link rel="stylesheet" type="text/css" href="tableau.css" media="screen" />

<style type="text/css">
<!--
img {
	text-align: left;
}
-->
</style>
</head>
<?php
//phpinfo();
include("connexion.php");

if(isset($_POST["num_adherent"]))
{
	$mise_en_form = "";	
	
	/* On recupere les infos dans un tableau */
	$sql = "SELECT * FROM souscription WHERE num_adherent=".$_POST['num_adherent']."";
	$requet = oci_parse($conn, $sql);
	$res = oci_execute($requet);
	
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
        <tr>
          <th width=\"50%\" scope=\"col\">Type Forfait</th>
          <th width=\"25%\" scope=\"col\">Date début</th>
          <th width=\"25%\" scope=\"col\">Date Fin</th>
        </tr>";
	
	$count = 1;
	while ($row = oci_fetch_array ($requet, OCI_BOTH))
	{
		$mise_en_form .= "
			<tr>
				<td>".$row['TYPE_FORFAIT']."</td>
				<td>".$row['DATE_DEBUT']."</td>
				<td>".$row['DATE_FIN']."</td>
			</tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"3\"> Aucun Forfait </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
	
	$mise_en_form .= "<table width=\"80%\" border=\"0\"><tr><td align=\"left\" scope=\"row\"><img src=\"images/titre_squash.png\" alt=\"\" width=\"334\" height=\"49\" /></td></tr></table>";
	
	/* On recupere les infos dans un tableau */
	$sql = "(SELECT * FROM reservationTerrainSquash WHERE id_personne = (SELECT id_personne FROM adherent WHERE num_adherent=".$_POST['num_adherent']."))";
	$requet = oci_parse($conn, $sql);
	$res = oci_execute($requet);
	
	$mise_en_form .= "<table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"4\" align=\"center\"><img src=\"images/titre_vos_reservations.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"31%\" scope=\"col\">Terrain n°</th>
          <th width=\"22%\" scope=\"col\">Date</th>
          <th width=\"26%\" scope=\"col\">Horaire</th>
          <th width=\"21%\" scope=\"col\">Tarif</th>
        </tr>";
	
	$count = 1;
	while ($row = oci_fetch_array ($requet, OCI_BOTH))
	{
		$mise_en_form .= "
			<tr>
				<td>".$row['NUM_TERRAIN_SQUASH']."</td>
				<td>".$row['DATE_LOCATION']."</td>
				<td>".$row['HEURE_DEBUT']."h"; 
					if($row['MINUTE_DEBUT']!=0) 
					{ $mise_en_form .= $row['MINUTE_DEBUT']; }
					$mise_en_form .= " à ".$row['HEURE_FIN']."h ";
					if($row['MINUTE_FIN']!=0) 
					{ $mise_en_form .= $row['MINUTE_FIN']; }
					 $mise_en_form .= "</td>
				<td>".$row['PRIX_PAYE']." €</td>
			</tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"4\"> Aucune r&eacute;servation </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
	/* On recupere les infos dans un tableau */
	$sql = "(SELECT * FROM creneauCoursSqColl a, inscriptionCoursSqCollectif b
			WHERE a.id_cours = b.id_cours AND b.num_adherent=".$_POST['num_adherent'].")";
	$requet2 = oci_parse($conn, $sql);
	$res = oci_execute($requet2);
	
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"4\" align=\"center\"><img src=\"images/titre_cours_collectifs.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"15%\" scope=\"col\">Terrain n°</th>
          <th width=\"25%\" scope=\"col\">Jour</th>
          <th width=\"30%\" scope=\"col\">Horaire</th>
		  <th width=\"30%\" scope=\"col\">Trimestre</th>
        </tr>";
		
	$count = 1;
	while ($row = oci_fetch_array($requet2, OCI_BOTH))
	{
		$dateDebut = date($row['DEBUT_TRIMESTRE']);
		$dateFin = date("d/m/y", mktime(0, 0, 0, $dateDebut+3, 1,  date("Y")));
		$mise_en_form .= "
			<tr>
				<td>".$row['NUM_TERRAIN_SQUASH']."</td>
				<td>";
				if($row['JOUR']=="0") { $mise_en_form .= "Tous les Lundi"; }
				else if($row['JOUR']=="1") { $mise_en_form .= "Tous les Mardi"; }
				else if($row['JOUR']=="2") { $mise_en_form .= "Tous les Mercredi"; }
				else if($row['JOUR']=="3") { $mise_en_form .= "Tous les Jeudi"; }
				else if($row['JOUR']=="4") { $mise_en_form .= "Tous les Vendredi"; }
				else if($row['JOUR']=="5") { $mise_en_form .= "Tous les Samedi"; }
				else { $mise_en_form .= "Dimanche"; }
				$mise_en_form .= "</td>
				<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
				<td>du ".$dateDebut." au ".$dateFin."</td>
			</tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"4\"> Aucun cours </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
	/* On recupere les infos dans un tableau */
	$sql = "(SELECT * FROM creneauCoursSqIndividuel a, coursSquashIndividuel b
			WHERE a.id_cours = b.id_cours AND b.num_adherent=".$_POST['num_adherent'].")";
	$requet3 = oci_parse($conn, $sql);
	$res = oci_execute($requet3);
	
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"3\" align=\"center\"><img src=\"images/titre_cours_individuels.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"31%\" scope=\"col\">Terrain n°</th>
          <th width=\"22%\" scope=\"col\">Date</th>
          <th width=\"26%\" scope=\"col\">Horaire</th>
        </tr>";
		
		$count = 1;
	while ($row = oci_fetch_array($requet3, OCI_BOTH))
	{
		$mise_en_form .= "
			<tr>
				<td>".$row['NUM_TERRAIN_SQUASH']."</td>
				<td>".$row['DATE_COURS']."</td>
				<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
			</tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"3\"> Aucun cours </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
	/********** Location **********/
		/********** Materiels **********/
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\"><tr><td align=\"left\" scope=\"row\"><img src=\"images/titre_locations.png\" alt=\"\" width=\"334\" height=\"49\" /></td></tr></table></center>";
	
	$sql = "(SELECT num_location,date_location,heure_debut,heure_fin,id_personne,prix_paye FROM location WHERE id_personne=(SELECT id_personne FROM adherent WHERE num_adherent=".$_POST['num_adherent']."))";
	$requet13 = oci_parse($conn, $sql);
	$res = oci_execute($requet13);
	
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"5\" align=\"center\"><img src=\"images/titre_materiels.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"20%\" scope=\"col\" rowspan=\"2\">Date</th>
          <th width=\"20%\" scope=\"col\" rowspan=\"2\">Horaire</th>
          <th width=\"20%\" scope=\"col\" rowspan=\"2\">Somme Payée</th>
		  <th scope=\"col\" colspan=\"2\">Materiel</th>
        </tr>
		<tr>
          <th scope=\"col\">Type</th>
		  <th scope=\"col\">Prix</th>
        </tr>";
		
		$count = 1;

	while ($row = oci_fetch_array($requet13, OCI_BOTH))
	{
		$sql14 = "select u.num_materiel, m.num_materiel, m.type_materiel, m.prix_base from table(select ct.materiel from location ct where ct.num_location=".$row['NUM_LOCATION'].") u, materielLocation m WHERE u.num_materiel=m.num_materiel";
		
		$requet14 = oci_parse($conn, $sql14);
		$res = oci_execute($requet14);

		$mise_en_form .= "
			<tr>
				<td>".$row['DATE_LOCATION']."</td>
				<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
				<td>".$row['PRIX_PAYE']." €</td>
				<td colspan=\"2\">";
				while ($row2 = oci_fetch_array($requet14, OCI_BOTH))
				{	
					$mise_en_form .= "<table width=\"100%\" border=\"0\"><tr><td width=\"48%\">".$row2['TYPE_MATERIEL']."</td>";
					$mise_en_form .= "<td>".$row2['PRIX_BASE']." €</td></tr></table>";
				}
			$mise_en_form .= "</td></tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"5\"> Aucune location </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
		/********** Casiers **********/
			/********** Annee **********/	
	/* On recupere les infos dans un tableau */
	$sql = "(SELECT * FROM reservationCasierAnnee WHERE num_adherent=".$_POST['num_adherent'].")";
	$requet15 = oci_parse($conn, $sql);
	$res = oci_execute($requet15);
	
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"2\" align=\"center\"><img src=\"images/titre_casiers_annee.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"50%\" scope=\"col\">Casier n°</th>
          <th width=\"50%\" scope=\"col\">Année</th>
        </tr>";
	
	$count = 1;
	while ($row = oci_fetch_array ($requet15, OCI_BOTH))
	{
		$mise_en_form .= "
			<tr>
				<td>".$row['NUM_CASIER']."</td>
				<td>".$row['ANNEE']."</td>
			</tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"2\"> Aucune r&eacute;servation </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
	/********** Seance **********/	
	/* On recupere les infos dans un tableau */
	$sql = "(SELECT a.* FROM reservationCasierSeance a, adherent b WHERE a.id_personne=b.id_personne AND num_adherent=".$_POST['num_adherent'].")";
	$requet16 = oci_parse($conn, $sql);
	$res = oci_execute($requet16);
	
	$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"4\" align=\"center\"><img src=\"images/titre_casiers_seance.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"25%\" scope=\"col\">Casier n°</th>
          <th width=\"25%\" scope=\"col\">Date</th>
		  <th width=\"25%\" scope=\"col\">Horaire</th>
		  <th width=\"25%\" scope=\"col\">Prix payé</th>
        </tr>";
	
	$count = 1;
	while ($row = oci_fetch_array ($requet16, OCI_BOTH))
	{
		$mise_en_form .= "
			<tr>
				<td>".$row['NUM_CASIER']."</td>
				<td>".$row['DATE_LOCATION']."</td>
				<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
				<td>".$row['PRIX_PAYE']." €</td>
			</tr>";
		$count++;
	}
	if($count==1) { $mise_en_form .= "<tr><td colspan=\"4\"> Aucune location </td></tr>"; }
	$mise_en_form .= "</table></center><br />";
	
}

/**************************************/
/*********** PLANNING GLOBAL **********/
/**************************************/

if(isset($_POST['nomChoix']))
{
	$mise_en_form = "";
	
	if($_POST['nomChoix']=="Tout" || $_POST['nomChoix']=="Réservations Terrains Squash")
	{
		$mise_en_form .= "<table width=\"80%\" border=\"0\"><tr><td align=\"left\" scope=\"row\"><img src=\"images/titre_squash.png\" alt=\"\" width=\"334\" height=\"49\" /></td></tr></table>";
		
		/* On recupere les infos dans un tableau */
		$sql = "SELECT a.*, b.* FROM reservationTerrainSquash a, personne b WHERE a.id_personne=b.id_personne
				 AND (
						((to_char(date_location, 'YYYY')>=".date("Y")."))
						OR
						((to_char(date_location, 'YYYY')>=".date("Y").") AND (to_char(date_location, 'MM')>=".date("m")."))
						OR
						((to_char(date_location, 'YYYY')>=".date("Y").") AND (to_char(date_location, 'MM')>=".date("m").") AND (to_char(date_location, 'DD')>=".date("s").")))
				 ORDER BY date_location, heure_debut, num_terrain_squash";
				 
		$requet4 = oci_parse($conn, $sql);
		$res = oci_execute($requet4);
		
		$mise_en_form .= "<table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"5\" align=\"center\"><img src=\"images/titre_reservations_des_terrains.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
		  <th width=\"20%\" scope=\"col\">Date</th>
		  <th width=\"20%\" scope=\"col\">Horaire</th>
          <th width=\"20%\" scope=\"col\">Terrain n°</th>
		  <th width=\"20%\" scope=\"col\">Loueur</th>
          <th width=\"20%\" scope=\"col\">Tarif</th>
        </tr>";
		
		$count = 1;
		while ($row = oci_fetch_array ($requet4, OCI_BOTH))
		{
			$mise_en_form .= "
				<tr>
					<td>".$row['DATE_LOCATION']."</td>
					<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
					<td>".$row['NUM_TERRAIN_SQUASH']."</td>
					<td>".$row['NOM']." ".$row['PRENOM']."</td>
					<td>".$row['PRIX_PAYE']." €</td>		
				</tr>";
			$count++;
		}
		if($count==1) { $mise_en_form .= "<tr><td colspan=\"5\"> Aucune r&eacute;servation </td></tr>"; }
		$mise_en_form .= "</table></center><br />";
	}
	
	if($_POST['nomChoix']=="Tout" || $_POST['nomChoix']=="Cours Squash Individuels")
	{
		if($_POST['nomChoix']!="Tout") { $mise_en_form .= "<table width=\"80%\" border=\"0\"><tr><td align=\"left\" scope=\"row\"><img src=\"images/titre_squash.png\" alt=\"\" width=\"334\" height=\"49\" /></td></tr></table>"; }
		
		/* On recupere les infos dans un tableau */	 
		$sql = "SELECT *
				FROM creneauCoursSqIndividuel
				WHERE (
						((to_char(date_cours, 'YYYY')>=".date("Y")."))
						OR
						((to_char(date_cours, 'YYYY')>=".date("Y").") AND (to_char(date_cours, 'MM')>=".date("m")."))
						OR
						((to_char(date_cours, 'YYYY')>=".date("Y").") AND (to_char(date_cours, 'MM')>=".date("m").") AND (to_char(date_cours, 'DD')>=".date("s").")))
				ORDER BY date_cours, heure_debut, num_terrain_squash";
				 
		$requet5 = oci_parse($conn, $sql);
		$res = oci_execute($requet5);
		
		$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"3\" align=\"center\"><img src=\"images/titre_creneaux_de_cours_individuels.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
          <th width=\"33%\" scope=\"col\">Date</th>
          <th width=\"34%\" scope=\"col\">Horaire</th>
		  <th width=\"33%\" scope=\"col\">Terrain n°</th>
        </tr>";
		
		$count = 1;
		while ($row = oci_fetch_array($requet5, OCI_BOTH))
		{
			$mise_en_form .= "
				<tr>
					<td>".$row['DATE_COURS']."</td>
					<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
					<td>".$row['NUM_TERRAIN_SQUASH']."</td>
				</tr>";
			$count++;
		}
		if($count==1) { $mise_en_form .= "<tr><td colspan=\"3\"> Aucun cours </td></tr>"; }
		$mise_en_form .= "</table></center><br />";
	}
	
	if($_POST['nomChoix']=="Tout" || $_POST['nomChoix']=="Cours Squash Collectifs")
	{
		// date debut trimestre courant
		$dateCourant = date("d-m-Y");
		
		list($jour, $mois, $annee) = explode("-",$dateCourant);
		if($mois==1 || $mois==2 || $mois==3) { $moisDebutTrimestreCourant=1; }
		else if($mois==4 || $mois==5 || $mois==6) { $moisDebutTrimestreCourant=4; }
		else if($mois==7 || $mois==8 || $mois==9) { $moisDebutTrimestreCourant=7; }
		else { $moisDebutTrimestreCourant=10; }
		
		$dateDebutTrimestreCourant = mktime(0, 0, 0, $moisDebutTrimestreCourant, 1, $annee);
		
		if($_POST['nomChoix']!="Tout") { $mise_en_form .= "<table width=\"80%\" border=\"0\"><tr><td align=\"left\" scope=\"row\"><img src=\"images/titre_squash.png\" alt=\"\" width=\"334\" height=\"49\" /></td></tr></table>"; }
		
		/* On recupere les infos dans un tableau */				 
		$sql = "SELECT a.*
				FROM creneauCoursSqColl a
				WHERE
				(
						((to_char(debut_trimestre, 'YYYY')>=".date("Y",$dateDebutTrimestreCourant)."))
						OR
						((to_char(debut_trimestre, 'YYYY')>=".date("Y",$dateDebutTrimestreCourant).") AND (to_char(debut_trimestre, 'MM')>=".date("m",$dateDebutTrimestreCourant)."))
						OR
						((to_char(debut_trimestre, 'YYYY')>=".date("Y",$dateDebutTrimestreCourant).") AND (to_char(debut_trimestre, 'MM')>=".date("m",$dateDebutTrimestreCourant).") AND (to_char(debut_trimestre, 'DD')>=".date("d",$dateDebutTrimestreCourant)."))
				)
				ORDER BY a.debut_trimestre, a.jour, a.heure_debut, a.num_terrain_squash ASC";
		
		$requet6 = oci_parse($conn, $sql);
		$res = oci_execute($requet6);
		
		$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"5\" align=\"center\"><img src=\"images/titre_creneaux_de_cours_collectifs.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
		  <th width=\"25%\" scope=\"col\">Trimestre</th>
		  <th width=\"20%\" scope=\"col\">Date</th>
		  <th width=\"20%\" scope=\"col\">Horaire</th>
          <th width=\"15%\" scope=\"col\">Terrain n°</th>
		  <th width=\"20%\" scope=\"col\">Nb Place Dispo</th>
        </tr>";
		
		$count = 1;
		while ($row = oci_fetch_array($requet6, OCI_BOTH))
		{
			$dateDebut = date($row['DEBUT_TRIMESTRE']);
			$dateFin = date("d/m/y", mktime(0, 0, 0, $dateDebut+3, 1,  date("Y")));
		
			/** AUTRE REQUETE **/
			$sql2 = "(SELECT a.id_cours, count(b.id_cours) as nb_pers_effective, b.nb_personne as nb_pers_max
					  FROM inscriptionCoursSqCollectif a, coursSquashCollectif b
					  WHERE a.id_cours=b.id_cours AND a.id_cours=".$row['ID_COURS']."group by a.id_cours,b.nb_personne)";
			
			$requet10 = oci_parse($conn, $sql2);
			$res = oci_execute($requet10);	
			$row2 = oci_fetch_array($requet10, OCI_BOTH);
			
			/** FIN AUTRE REQUETE **/
			
			$placesRestantes=$row2['NB_PERS_MAX']-$row2['NB_PERS_EFFECTIVE'];
			$mise_en_form .= "
				<tr>
					<td>Du ".$dateDebut." au ".$dateFin."</td>
					<td>";
					if($row['JOUR']=="0") { $mise_en_form .= "Tous les Lundi"; }
					else if($row['JOUR']=="1") { $mise_en_form .= "Tous les Mardi"; }
					else if($row['JOUR']=="2") { $mise_en_form .= "Tous les Mercredi"; }
					else if($row['JOUR']=="3") { $mise_en_form .= "Tous les Jeudi"; }
					else if($row['JOUR']=="4") { $mise_en_form .= "Tous les Vendredi"; }
					else if($row['JOUR']=="5") { $mise_en_form .= "Tous les Samedi"; }
					else { $mise_en_form .= "Dimanche"; }
					$mise_en_form .= "</td>
					<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
					<td>".$row['NUM_TERRAIN_SQUASH']."</td>
					<td>".$placesRestantes." pl.</td>
				</tr>";
			$count++;
		}
		if($count==1) { $mise_en_form .= "<tr><td colspan=\"5\"> Aucun cours </td></tr>"; }
		$mise_en_form .= "</table></center><br /><br />";
	}
	
	
	/*************************/
	/********** GYM **********/
	/*************************/
	
	if($_POST['nomChoix']=="Tout" || $_POST['nomChoix']=="Gymnastique")
	{
		$mise_en_form .= "<center><table width=\"80%\" border=\"0\"><tr><td align=\"left\" scope=\"row\"><img src=\"images/titre_gymnastique.png\" alt=\"\" width=\"334\" height=\"49\" /></td></tr></table></center>";
		
		/* On recupere les infos dans un tableau */
		$sql = "SELECT a.*, b.*, c.*, d.*, e.*
		FROM creneauCoursGym a, salleGym b, coursGym c, personnelSportif d, personne e
		WHERE (a.id_salle=b.id_salle)
		AND (a.type_cours=c.type_cours) 
		AND (d.id_prof=c.id_prof) 
		AND (d.id_personne=e.id_personne) 
		AND (
				((to_char(date_cours, 'YYYY')>=".date("Y")."))
				OR
				((to_char(date_cours, 'YYYY')>=".date("Y").") AND (to_char(date_cours, 'MM')>=".date("m")."))
				OR
				((to_char(date_cours, 'YYYY')>=".date("Y").") AND (to_char(date_cours, 'MM')>=".date("m").") AND (to_char(date_cours, 'DD')>=".date("s")."))
			)
		ORDER BY a.type_cours, a.date_cours, a.heure_debut, a.id_salle";
		
		$requet7 = oci_parse($conn, $sql);
		$res = oci_execute($requet7);
		
		$mise_en_form .= "<center><table width=\"80%\" border=\"0\" cellspacing=\"1\"  id=\"matable\">
		<tr>
			<td colspan=\"6\" align=\"center\"><img src=\"images/titre_tous_les_creneaux.png\" alt=\"\" width=\"361\" height=\"38\" /></td>
		</tr>
        <tr>
		  <th width=\"15%\" scope=\"col\">Date</th>
          <th width=\"20%\" scope=\"col\">Type</th>
		  <th width=\"15%\" scope=\"col\">Horaire</th>
          <th width=\"15%\" scope=\"col\">Salle</th>
          <th width=\"15%\" scope=\"col\">Capacité Max</th>
		  <th width=\"20%\" scope=\"col\">Professeur</th>
        </tr>";
		
		$count = 1;
		while ($row = oci_fetch_array($requet7, OCI_BOTH))
		{
			$mise_en_form .= "
				<tr>
					<td>".$row['DATE_COURS']."</td>
					<td>".$row['TYPE_COURS']."</td>
					<td>".$row['HEURE_DEBUT']." h à ".$row['HEURE_FIN']." h</td>
					<td>".$row['ID_SALLE']."</td>
					<td>".$row['CAPACITE']." pers.</td>
					<td>".$row['NOM']." ".$row['PRENOM']."</td>
				</tr>";
				
			$count++;
		}
		if($count==1) { $mise_en_form .= "<tr><td colspan=\"6\"> Aucun cours </td></tr>"; }
		$mise_en_form .= "</table></center>";
	}

}
	
include("deconnexion.php");
?>

<body>

<div id="wrap">

<div id="header">
<h1><a href="#">Bienvenue sur Musquash</a></h1>
<h2>Pour entretenir le corps et l'esprit</h2>
</div>

<div id="menu">
<ul>
<li><a href="index.html">Accueil</a></li>
<li><a href="coursettarifs.php">Cours/Tarifs</a></li>
<li><a href="consultation.php">Planning</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="#">Aide</a></li>
</ul>
</div>

<div id="content">

<center>
  <p>&nbsp;</p>
  <p><img src="images/titre_planning.png" alt="" width="334" height="61" /></p>
  <p>&nbsp;</p>
      <center>
      <table width="59%" border="0" id="matable">
          <tr>
            <td width="30" align="center"><img src="images/puce.png" alt="" width="14" height="13" /></td>
            <td>Vous êtes adh&eacute;rent ! Visualiser vos cours.</td>
            <!-- Ici on visualalise la reponse du formulaire -->
            <td width="482">
                <form id="formAdherent" method="post" action="">
                  <label>
                  	N°Adhérent :
                    <input type="text" name="num_adherent" id="num_adherent" value="<?php if(isset($_POST['num_adherent'])){ echo $_POST['num_adherent']; }?>"/>
                    <!-- <a href="#" onclick="javascript:document.forms['formAdherent'].submit();">
                        <img src="images/ok.png" alt="" width="41" height="26"/>
                        </a>  -->
                </label>
                  <input type="submit" value="OK" />
              </form></td>
            <!-- Fin visualisation -->
          </tr>
          <tr>
            <td align="center"><img src="images/puce.png" alt="" width="14" height="13" /></td>
            <td width="308" align="left" valign="middle">Visualiser le planning g&eacute;n&eacute;ral par...</td>
            <td><form id="formChoix" method="post" action="">
              <select name="nomChoix" size="1">
                <option selected="selected">Tout </option>
                <option <?php if(isset($_POST['nomChoix']) && $_POST['nomChoix']=="Cours Squash Individuels"){ echo "selected=\"selected\""; }?>>Cours Squash Individuels</option>
                <option <?php if(isset($_POST['nomChoix']) && $_POST['nomChoix']=="Cours Squash Collectifs"){ echo "selected=\"selected\""; }?>>Cours Squash Collectifs </option>
                <option <?php if(isset($_POST['nomChoix']) && $_POST['nomChoix']=="Réservations Terrains Squash"){ echo "selected=\"selected\""; }?>>Réservations Terrains Squash</option>
                <option <?php if(isset($_POST['nomChoix']) && $_POST['nomChoix']=="Gymnastique"){ echo "selected=\"selected\""; }?>>Gymnastique </option>
              </select>
              <!-- <a href="#" onclick="document.forms['formChoix'].submit();">
                  <img src="images/ok.png" alt="" width="41" height="26"/>
                  </a> -->
              <input type="submit" value="OK" />
            </form></td>
          </tr>
      </table>
      </center>
      <p>&nbsp;</p>
      <p>
        <?php
            	if(isset($mise_en_form))
				{
					echo $mise_en_form;
				}
				else
				{
					echo "<br /><blink><div align=\"center\">Nouveau cours de Squash Collectif ouvert : venez nombreux !</div></blink><br />";
				}
            ?>
      </p>
      
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
</center>

</div>

<div id="bottom"> </div>
<div id="footer">
Copyright 2009/2010 - Master 1 Informatique - UM2
</div>

</div>
</body>
</html>