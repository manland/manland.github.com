<?php
// connexion.php se connecte � la base.
$conn = ocilogon("john","0000","XE");
if (!$conn) {
	$e = oci_error();
	print htmlentities($e['message']);
	exit;
}
?>