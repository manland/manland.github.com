-- START /home/audrey/Master/SIBD/projet/table.sql

alter session set NLS_DATE_FORMAT='DD-MM-YYYY';

/*==============================================================*/
/* Table : Personne                                             */
/*==============================================================*/
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (1,'novak','audrey','08-04-1987','8 rue fournel MEZE');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (2,'novak','diane','08-04-1987','8 rue fournel MEZE');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (3,'maneschi','romain','12-02-1986','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (4,'maillet','laurent','27-11-1987','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (5,'fhal','john','13-12-1986','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (6,'sauvan','william','08-10-1987','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (7,'konig','melanie','11-11-1988','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (8,'bregu','erion','12-02-1986','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (9,'smith','john','12-02-1986','8 ave pr grasset MONTPELLIER');
insert into personne(id_personne,nom,prenom,dateDeNaissance,adresse) values (10,'pitt','brad','12-02-1986','8 ave pr grasset MONTPELLIER');


/*==============================================================*/
/* Table : Adhérent                                             */
/*==============================================================*/
insert into adherent(num_adherent,id_personne) values (1,1);
insert into adherent(num_adherent,id_personne) values (2,2);
insert into adherent(num_adherent,id_personne) values (3,3);
insert into adherent(num_adherent,id_personne) values (4,4);
insert into adherent(num_adherent,id_personne) values (5,5);
insert into adherent(num_adherent,id_personne) values (6,6);


/*==============================================================*/
/* Table : PersonnelAdministratif                                             */
/*==============================================================*/
insert into personnelAdministratif(num_employe,id_personne,affectation) values (1,1,'secretaire');
insert into personnelAdministratif(num_employe,id_personne,affectation) values (2,2,'directeur');

/*==============================================================*/
/* Table : PersonnelSportif                                    */
/*==============================================================*/
insert into personnelSportif(id_prof,id_personne,type_sport) values (1,1,'gym');
insert into personnelSportif(id_prof,id_personne,type_sport) values (2,2,'squash');
insert into personnelSportif(id_prof,id_personne,type_sport) values (3,3,'squash');
insert into personnelSportif(id_prof,id_personne,type_sport) values (4,4,'squash');
insert into personnelSportif(id_prof,id_personne,type_sport) values (5,5,'squash');
insert into personnelSportif(id_prof,id_personne,type_sport) values (6,6,'gym');
/*==============================================================*/
/* Table : MaterielLocation                                */
/*==============================================================*/
insert into materielLocation(num_materiel,type_materiel,date_achat,etat,prix_base) values (1,'raquette','01-01-2008','etat',5);
insert into materielLocation(num_materiel,type_materiel,date_achat,etat,prix_base) values (2,'raquette','01-01-2008','etat',5);
insert into materielLocation(num_materiel,type_materiel,date_achat,etat,prix_base) values (3,'balle','01-01-2008','etat',5);
insert into materielLocation(num_materiel,type_materiel,date_achat,etat,prix_base) values (4,'balle','01-01-2008','etat',5);
insert into materielLocation(num_materiel,type_materiel,date_achat,etat,prix_base) values (5,'chaussures','01-01-2008','etat',5);

/*==============================================================*/
/* Table : Location                                */
/*==============================================================*/
insert into location values (1,'01-12-2010',14,15,
			    tab_materiel_loue(
						type_materiel_loue(1),
						type_materiel_loue(2)
					      ),
			    1,5);
insert into location values (8,'01-12-2010',15,16,
			    tab_materiel_loue(
						type_materiel_loue(1)
					      ),
			    1,5);
insert into location values (7,'02-12-2010',14,15,
			    tab_materiel_loue(
						type_materiel_loue(2)
					      ),
			    2,5);

/*==============================================================*/
/* Table : MaterielVente                                 */
/*==============================================================*/
insert into materielVente(type_materiel,description,quantite,prix_base) values ('raquette','pour jouer au tennis',10,30);
insert into materielVente(type_materiel,description,quantite,prix_base) values ('balles','pour jouer au tennis',8,30);
insert into materielVente(type_materiel,description,quantite,prix_base) values ('filet','pour jouer au tennis',8,30);

/*==============================================================*/
/* Table : Vente                                */
/*==============================================================*/
insert into vente values (3,
      tab_materiel_achete(
			type_materiel_achete('filet',2,30),
			type_materiel_achete('raquette',10,30)
		       ),
      '10-04-2000',2,50);
insert into vente values (4,
			  tab_materiel_achete(
					    type_materiel_achete('filet',8,30),
					    type_materiel_achete('raquette',2,30)
					  ),
			  '10-04-2000',1,50);

/*==============================================================*/
/* Table : casier                                */
/*==============================================================*/
insert into casier(num_casier) values (1);
insert into casier(num_casier) values (2);
insert into casier(num_casier) values (70);
insert into casier(num_casier) values (71);
insert into casier(num_casier) values (100);

/*==============================================================*/
/* Table : reservationCasierAnnee                                */
/*==============================================================*/
insert into reservationCasierAnnee(num_casier,num_adherent,annee) values (1,1,2010);
insert into reservationCasierAnnee(num_casier,num_adherent,annee) values (2,2,2010);
-- insert into reservationCasierAnnee(num_casier,num_adherent,annee) values (70,2,2009);

/*==============================================================*/
/* Table : reservationCasierSeance                               */
/*==============================================================*/
insert into reservationCasierSeance(num_casier,date_location,heure_debut,heure_fin,id_personne,prix_paye) values (71,'3-03-2009',14,15,1,30);
insert into reservationCasierSeance(num_casier,date_location,heure_debut,heure_fin,id_personne,prix_paye) values (100,'3-03-2009',14,15,2,30);

/*==============================================================*/
/* Table : forfait                               */
/*==============================================================*/
insert into forfait values ('salle muscu',35,95,175,300);
insert into forfait values ('cours gymnastique',45,120,210,400);
insert into forfait values ('terrain squash',10,25,45,80);
insert into forfait values ('cours particulier squash',75,215,410,800);
insert into forfait values ('cours groupe squash',65,190,360,700);


/*==============================================================*/
/* Table : souscription                               */
/*==============================================================*/
insert into souscription(type_forfait,num_adherent,date_debut,date_fin) values ('salle muscu',1,'30-12-2009','29-01-2010');
insert into souscription(type_forfait,num_adherent,date_debut,date_fin) values ('cours groupe squash',1,'5-01-2010','04-02-2010');
insert into souscription(type_forfait,num_adherent,date_debut,date_fin) values ('cours particulier squash',1,'5-01-2010','04-02-2010');
insert into souscription(type_forfait,num_adherent,date_debut,date_fin) values ('cours particulier squash',3,'5-01-2010','04-02-2010');
insert into souscription(type_forfait,num_adherent,date_debut,date_fin) values ('cours groupe squash',3,'5-01-2010','04-02-2010');

/*==============================================================*/
/* Table : terrainSquash                               */
/*==============================================================*/
insert into terrainSquash(num_terrain_squash) values (1);
insert into terrainSquash(num_terrain_squash) values (2);
insert into terrainSquash(num_terrain_squash) values (3);
insert into terrainSquash(num_terrain_squash) values (4);
insert into terrainSquash(num_terrain_squash) values (5);
insert into terrainSquash(num_terrain_squash) values (6);

/*==============================================================*/
/* Table : reservationTerrainSquash                               */
/*==============================================================*/
-- insert into reservationTerrainSquash(num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin,id_personne,prix_paye) values(1,'3-04-2009',13,14,30,10,1,30);
insert into reservationTerrainSquash(num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin,id_personne,prix_paye) values(2,'12-01-2010',11,11,00,40,1,30);
insert into reservationTerrainSquash(num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin,id_personne,prix_paye) values(5,'12-01-2010',14,15,20,00,3,30);
insert into reservationTerrainSquash(num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin,id_personne,prix_paye) values(6,'3-04-2010',14,15,20,00,9,30);
-- insert into reservationTerrainSquash(num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin,id_personne,prix_paye) values(5,'3-04-2009',14,15,20,00,4,30);
-- 
-- insert into reservationTerrainSquash(num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin,id_personne,prix_paye) values(3,'3-04-2009',14,15,20,00,9,30);


/*==============================================================*/
/* Table : coursSquash                               */
/*==============================================================*/
insert into coursSquash(id_cours,id_prof,type_de_cours) values (1,5,'individuel');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (2,3,'individuel');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (3,3,'collectif');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (4,3,'collectif');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (5,2,'individuel');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (6,2,'individuel'); 
insert into coursSquash(id_cours,id_prof,type_de_cours) values (7,2,'collectif');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (8,2,'individuel');
insert into coursSquash(id_cours,id_prof,type_de_cours) values (9,4,'collectif'); 
insert into coursSquash(id_cours,id_prof,type_de_cours) values (10,4,'collectif'); 



/*==============================================================*/
/* Table : coursSquashIndividuel                               */
/*==============================================================*/
insert into coursSquashIndividuel(id_cours,num_adherent) values (1,1);
insert into coursSquashIndividuel(id_cours,num_adherent) values (2,3);
insert into coursSquashIndividuel(id_cours,num_adherent) values (6,1);
insert into coursSquashIndividuel(id_cours,num_adherent) values (5,1);
-- insert into coursSquashIndividuel(id_cours,num_adherent) values (8,1);

/*==============================================================*/
/* Table : creneauCoursSqIndividuel                           */
 /*==============================================================*/
  insert into creneauCoursSqIndividuel(id_cours,num_terrain_squash,date_cours,heure_debut,heure_fin) values (1,1,'05-01-2010',9,10);
  insert into creneauCoursSqIndividuel(id_cours,num_terrain_squash,date_cours,heure_debut,heure_fin) values (5,1,'12-01-2010',13,14);
  insert into creneauCoursSqIndividuel(id_cours,num_terrain_squash,date_cours,heure_debut,heure_fin) values (2,2,'12-01-2010',9,10);

/*==============================================================*/
/* Table : creneauCoursSqColl		                */
/*==============================================================*/
insert into creneauCoursSqColl(id_cours,num_terrain_squash,jour,heure_debut,heure_fin,debut_trimestre) values (3,3,2,18,20,'01-10-2010');
insert into creneauCoursSqColl(id_cours,num_terrain_squash,jour,heure_debut,heure_fin,debut_trimestre) values (9,5,5,10,12,'01-01-2010');
insert into creneauCoursSqColl(id_cours,num_terrain_squash,jour,heure_debut,heure_fin,debut_trimestre) values (7,1,2,9,11,'01-01-2010');
insert into creneauCoursSqColl(id_cours,num_terrain_squash,jour,heure_debut,heure_fin,debut_trimestre) values (4,1,3,9,11,'01-01-2010');
insert into creneauCoursSqColl(id_cours,num_terrain_squash,jour,heure_debut,heure_fin,debut_trimestre) values (10,3,3,10,12,'01-01-2010');


/*==============================================================*/
/* Table : coursSquashCollectif                               */
/*==============================================================*/
insert into coursSquashCollectif(id_cours,nb_personne) values (3,2);
insert into coursSquashCollectif(id_cours,nb_personne) values (4,5);
insert into coursSquashCollectif(id_cours,nb_personne) values (10,5);
insert into coursSquashCollectif(id_cours,nb_personne) values (7,2);
insert into coursSquashCollectif(id_cours,nb_personne) values (9,2);
--insert into coursSquashCollectif(id_cours,nb_personne) values (5,5);


/*==============================================================*/
/* Table : inscriptionCoursSquashCollectif                               */
/*========================================================*/
insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (3,1);
insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (3,3);
insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (10,1);
insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (7,1);
-- insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (5,1);
-- -- insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (3,1);
--   insert into inscriptionCoursSqCollectif(id_cours,num_adherent) values (7,1);
-- 
-- 
/*==============================================================*/
/* Table : salleGym                              */
/*========================================================*/
insert into salleGym(id_salle,capacite) values (1,30);
insert into salleGym(id_salle,capacite) values (2,30);
insert into salleGym(id_salle,capacite) values (3,30);
insert into salleGym(id_salle,capacite) values (4,30);
insert into salleGym(id_salle,capacite) values (5,30);
insert into salleGym(id_salle,capacite) values (6,30);
insert into salleGym(id_salle,capacite) values (7,30);
insert into salleGym(id_salle,capacite) values (8,30);
insert into salleGym(id_salle,capacite) values (9,30);
insert into salleGym(id_salle,capacite) values (10,30);

/*==============================================================*/
/* Table : coursGym                            			*/
/*========================================================*/
insert into coursGym(type_cours,id_prof) values ('step',1);
insert into coursGym(type_cours,id_prof) values ('cardio',6);


/*==============================================================*/
/* Table : creneauCoursGym                              */
/*========================================================*/
insert into creneauCoursGym(id_salle,type_cours,date_cours,heure_debut,heure_fin,debut_trimestre) values(1,'step','4-07-2010',14,15,'01-07-2010');
insert into creneauCoursGym(id_salle,type_cours,date_cours,heure_debut,heure_fin,debut_trimestre) values(2,'cardio','4-01-2010',14,15,'01-01-2010');
insert into creneauCoursGym(id_salle,type_cours,date_cours,heure_debut,heure_fin,debut_trimestre) values(3,'cardio','4-01-2010',14,15,'01-01-2010');
-- insert into creneauCoursGym(id_salle,type_cours,date_cours,heure_debut,heure_fin,debut_trimestre) values(1,'step','4-07-2009',14,15,'01-01-2010');