-- START /home/audrey/Master/SIBD/projet/table-new-version.sql

/*==============================================================*/
/* Table : Personne                                             */
/*==============================================================*/
drop table personne cascade constraint;
create table personne
(
	id_personne int,
	nom varchar2(30),
	prenom varchar2(30),
	dateDeNaissance date,
	adresse varchar2(200),
	constraint pk_personne primary key (id_personne),
	unique(nom,prenom)
);


/*==============================================================*/
/* Table : Adherent                                             */
/*==============================================================*/
drop table adherent cascade constraint;
create table adherent
(
	num_adherent int,
	id_personne int not null,
	constraint pk_adherent primary key (num_adherent),
	constraint fk_adherent foreign key(id_personne) references personne(id_personne),
	unique (id_personne)	
);


/*==============================================================*/
/* Table : personnelAdministratif                                   */
/*==============================================================*/
drop table personnelAdministratif cascade constraint;
create table personnelAdministratif
(
	num_employe int,
	id_personne int not null,
	affectation varchar2(30),
	constraint pk_personnel_administratif primary key (num_employe),
	constraint fk_personnel_administratif foreign key(id_personne) references personne(id_personne),
	unique (id_personne)
);


/*==============================================================*/
/* Table : personnelSportif                         */
/*==============================================================*/
drop table personnelSportif cascade constraint;
create table personnelSportif
(
	id_prof int,
	id_personne int not null,
	type_sport varchar2(30),
	constraint pk_personnel_sportif primary key (id_prof),
	constraint fk_personnel_sportif foreign key(id_personne) references personne(id_personne),
	unique (id_personne)
);



/*==============================================================*/
/* Table : materiel en location    correspond au stock disponible                             */
/*==============================================================*/
drop table materielLocation cascade constraints;
create table materielLocation
(
	num_materiel int,
	type_materiel varchar2(50) not null,
	date_achat date,
	etat varchar2(10),
	description varchar2(200),
	prix_base int,
	constraint pk_materielLocation primary key (num_materiel)
);

/*==============================================================*/
/* type : materiel loue correspond a ce que vient de louer la personne  */
/*==============================================================*/
drop table location cascade constraints;
drop type tab_materiel_loue force;
drop type type_materiel_loue force;

create type type_materiel_loue as object
(
	num_materiel int
);
/


create type tab_materiel_loue as table of type_materiel_loue
/


/*==============================================================*/
/* Table : location                                             */
/*==============================================================*/
create table location
(
    num_location int,
    date_location date,
    heure_debut int, 
    heure_fin int, check(heure_fin=heure_debut+1),
    materiel tab_materiel_loue,
    id_personne int,
    prix_paye int,
    constraint pk_location primary key (num_location),
    constraint fk_location_id_personne foreign key(id_personne) references personne(id_personne)
) 
nested table materiel store as tab_materiel_loc;

-- trigger permettant de verifier avant l'ajout dans la location que l'objet de la liste est bien dans les objets louables
create or replace trigger tg_location
before insert or update on location
for each row
declare 
tab_mat_loue tab_materiel_loue;
cpt int;
taille int;
date_loc date;
hd int;
hf int;
begin
  tab_mat_loue := :new.materiel;
  for cpt in tab_mat_loue.first..tab_mat_loue.last loop
    select count(num_materiel) into taille from materielLocation where num_materiel=tab_mat_loue(cpt).num_materiel;
    if(taille=0) then
      raise_application_error(-20301,'erreur materiel pas dans la liste du materiel a louer');
    end if;
  end loop;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- trigger permettant de controler le meme matériel ne peut pas etre loue oui
-- a la meme heure de la meme journée
create or replace trigger tg_location_2
before insert or update on location
for each row
declare 
tab_mat_loue tab_materiel_loue;
cpt int;
i int;
taille int;
date_loc date;
hd int;
hf int;
begin
  date_loc:=:new.date_location;
  hd := :new.heure_debut;
  hf := :new.heure_fin;
  tab_mat_loue := :new.materiel;
 for i in tab_mat_loue.first..tab_mat_loue.last loop
  select count(*) into cpt from location;
  if(cpt!=0) then
    select count(u.num_materiel) into taille from table(select ct.materiel from location ct where ct.date_location=date_loc and ct.heure_debut=hd and ct.heure_fin=hf) u where num_materiel=tab_mat_loue(i).num_materiel;
    if(taille!=0) then
      raise_application_error(-20301,'erreur au moins un materiel est deja loue');
    end if;
  end if;
  end loop;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


/*==============================================================*/
/* Table : materiel en vente   correspond au stock                                  */
/*==============================================================*/
drop table materielVente cascade constraints;
create table materielVente
(
	type_materiel varchar2(50),
	description varchar2(200),
	quantite int,
	prix_base int,
	constraint pk_materielVente primary key (type_materiel)
);



/*==============================================================*/
/* type : materiel acheté correspond a ce que vient d'acheté la personne                               */
/*==============================================================*/
drop table vente cascade constraints;
drop type tab_materiel_achete force;
drop type type_materiel_achete force;

create type type_materiel_achete as object
(
	type_materiel varchar2(50),
	quantite int,
	prix_base int
);
/

create type tab_materiel_achete as Table of type_materiel_achete
/

create table vente
(
    num_vente int,
    materiel tab_materiel_achete,
    date_vente date,
    id_personne int,
    prix_paye int,
    constraint pk_vente primary key (num_vente),
    constraint fk_vente_id_personne foreign key(id_personne) references personne(id_personne)
) 
nested table materiel store as tab_materiel;

-- trigger permettant de verifier avant l'ajout dans la vente que l'objet de la liste est bien dans les objets vendables
create or replace trigger tg_vente
before insert or update on vente
for each row
declare 
tab_mat_achete tab_materiel_achete;
cpt int;
taille int;
taille_qte int;
qte int;
begin
  tab_mat_achete := :new.materiel;
  for cpt in tab_mat_achete.first..tab_mat_achete.last loop
    select count(type_materiel) into taille from materielVente where type_materiel=tab_mat_achete(cpt).type_materiel;
    if(taille=0) then
      raise_application_error(-20301,'erreur_type_materiel_achete pas dans stock');
    else
       select count(quantite) into taille_qte from materielVente where quantite>=tab_mat_achete(cpt).quantite;
       if(taille_qte=0) then
	 raise_application_error(-20301,'erreur_type_materiel_achete_quantite');
       end if;
    end if;
  end loop;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- vue 
-- create view Vmatos2 of type_materiel_achete with object OID(type_materiel,quantite) as select type_materiel,quantite,prix_base from materielVente;



/*==============================================================*/
/* Table : casier                                               */
/*==============================================================*/
drop table casier cascade constraints;
create table casier
(
	num_casier int, check(num_casier between 1 and 100),
	constraint pk_casier primary key (num_casier)
);



/*==============================================================*/
/* Table : reservation casier a l'annee                         */
/*==============================================================*/
drop table reservationCasierAnnee cascade constraints;
create table reservationCasierAnnee
(
	num_casier int, check(num_casier between 1 and 70),
	num_adherent int,
	annee int,
	constraint pk_reservation_casier_annee primary key (num_casier, annee),
	constraint fk_resa_casier_an_adherent foreign key(num_adherent) references adherent(num_adherent),
	constraint fk_resa_casier_an_casier foreign key(num_casier) references casier(num_casier),
	unique(num_adherent,annee)
);



/*==============================================================*/
/* Table : reservation casier a la seance                       */
/*==============================================================*/
drop table reservationCasierSeance cascade constraints;
create table reservationCasierSeance
(
	num_casier int, check(num_casier between 71 and 100),
	date_location date,
	heure_debut int, check(heure_debut between 9 and 21),
	heure_fin int, check(heure_fin between 10 and 22), 
	id_personne int,
	prix_paye int,
	check(heure_fin=heure_debut+1),
	constraint pk_reservation_casier_seance primary key (num_casier, date_location, heure_debut),
	constraint fk_resa_casier_seance_personne foreign key(id_personne) references personne(id_personne),
	constraint fk_resa_casier_seance_casier foreign key(num_casier) references casier(num_casier)
);

/*==============================================================*/
/* Table : forfait                                              */
/*==============================================================*/
drop table forfait cascade constraints;
create table forfait
(
	type_forfait varchar2(30), 
	prix_mois int,
	prix_trimestre int,
	prix_semestre int,
	prix_an int,
	check(type_forfait in ('salle muscu','cours gymnastique','terrain squash','cours particulier squash','cours groupe squash')),
	constraint pk_forfait primary key (type_forfait)
);


/*==============================================================*/
/* Table : Historiquesouscription                                              */
/*==============================================================*/
drop table historiqueSouscription cascade constraints;
create table historiqueSouscription
(
	type_forfait varchar2(30), 
	num_adherent int,
	date_debut date,
	date_fin date,
	check(type_forfait in ('salle muscu','cours gymnastique','terrain squash','cours particulier squash','cours groupe squash')),
	constraint pk_histo_souscription primary key (type_forfait,date_debut,date_fin,num_adherent),
	constraint fk_histo_sous_num_adherent foreign key(num_adherent) references adherent(num_adherent),
	constraint fk_histo_sous_type_forfait foreign key(type_forfait) references forfait(type_forfait)
);



/*==============================================================*/
/* Table : souscription                                              */
/*==============================================================*/
drop table souscription cascade constraints;
create table souscription
(
	type_forfait varchar2(30), 
	num_adherent int,
	date_debut date,
	date_fin date,
	check(type_forfait in ('salle muscu','cours gymnastique','terrain squash','cours particulier squash','cours groupe squash')),
	constraint pk_souscription primary key (type_forfait,date_debut,date_fin,num_adherent),
	constraint fk_souscription_num_adherent foreign key(num_adherent) references adherent(num_adherent),
	constraint fk_souscription_type_forfait foreign key(type_forfait) references forfait(type_forfait)
);

-- trigger permettant de donner une validité a un forfait, on considère :
-- un forfait d'un mois dure 30 jours
-- un forfait d'un trimestre dure 90 jours
-- un forfait d'un semestre dure 180 jours
-- un forfait d'un an dure 365 jours
create or replace trigger tg_souscription
before insert or update on souscription
for each row
declare 
res int;
begin
res := :new.date_fin-:new.date_debut;
if(res!=30 and res!=90 and res!=180 and res!=365) then
  raise_application_error(-20501,'date_souscription_incorrect');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- trigger permettant d'effacer la ligne du forfait perimé
create or replace trigger tg_souscription_perime
before insert or update on souscription
for each row
declare 
res int;
date_auj date;
nb_forf int;
num_ad int;
typ varchar2(30);
dat_deb date;
dat_fin date;
begin
res := :new.date_fin-:new.date_debut;
date_auj := sysdate;
num_ad := :new.num_adherent;
typ := :new.type_forfait;
select count(*) into nb_forf from souscription where num_adherent=num_ad and type_forfait=typ;
if(nb_forf>0) then
   select  date_debut, date_fin into dat_deb,dat_fin from souscription where num_adherent=num_ad and type_forfait=typ;
  if(dat_fin<date_auj) then
    insert into historiqueSouscription values (typ,num_ad,dat_deb,dat_fin);
    delete from souscription where num_adherent=num_ad and date_fin<date_auj and type_forfait=typ;
  else
    raise_application_error(-20501,'cet adherent possede deja ce type de forfait');
  end if;
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

/*==============================================================*/
/* Table : terrainSquash                                              */
/*==============================================================*/
drop table terrainSquash cascade constraints;
create table terrainSquash
(
	num_terrain_squash int, check(num_terrain_squash between 1 and 6),
	constraint pk_terrainSquash primary key (num_terrain_squash)
);



/*==============================================================*/
/* Table : reservationTerrainSquash                             */
/*==============================================================*/
drop table reservationTerrainSquash cascade constraints;
create table reservationTerrainSquash
(
	num_terrain_squash int,
	date_location date,
	heure_debut int,
	heure_fin int,
	minute_debut int,
	minute_fin int,
	id_personne int,
	prix_paye int,
	constraint pk_reservation_terrain_squash primary key (num_terrain_squash,date_location,heure_debut,heure_fin,minute_debut,minute_fin),
	constraint fk_resa_terrain_sq_personne foreign key(id_personne) references personne(id_personne),
	constraint fk_resa_terrain_sq_terrain foreign key(num_terrain_squash) references terrainSquash(num_terrain_squash)
);

-- ajout d'un trigger qui verifie que la reservation d'un terrain de squash dure bien 40min
create or replace trigger tg_reservation_terrain_squash
before insert or update on reservationTerrainSquash
for each row
declare
hd int;
hf int;
md int;
mf int;
res int;
begin
hd := :new.heure_debut;
hf := :new.heure_fin;
md := :new.minute_debut;
mf := :new.minute_fin;
if(hf-hd=1) then
  if(mf=0) then
    res:= 60-md;
    if(res!=40) then
      raise_application_error(-20501,'erreur');
    end if;
  elsif(md>mf) then
    res:=(60+mf)-md;
    if(res!=40) then
      raise_application_error(-20501,'erreur');
    end if;
  else
    raise_application_error(-20501,'erreur');
  end if;
elsif(hd=hf) then
  if(md<mf) then
    res:=mf-md;
    if(res!=40) then
      raise_application_error(-20501,'erreur');
    end if;
  else
    raise_application_error(-20501,'erreur');
  end if;
else
  raise_application_error(-20501,'erreur');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- trigger verifiant que les terrains ne soient pas loué par plus de 4 adhérents en meme temps;
create or replace trigger tg_res_terrain_limite_ad
before insert or update on reservationTerrainSquash
for each row
declare
nb_terr_res_par_ad int;
nb_adherent int;
date_loc date;
hd int;
hf int;
num_person int;
nb_cours_col int;
nb_cours_ind int;
res_nb_cours int;
min_fin int;
min_deb int;
jour_inter int;
jour_res varchar2(3);
begin
date_loc := :new.date_location;
hd := :new.heure_debut;
hf := :new.heure_fin;
min_fin := :new.minute_fin;
min_deb := :new.minute_debut;
num_person :=:new.id_personne;
jour_res := to_char(:new.date_location,'dy');
select count(num_terrain_squash) into nb_terr_res_par_ad from personne p, reservationTerrainSquash r, adherent a where r.id_personne=a.id_personne and r.id_personne=p.id_personne and p.id_personne=a.id_personne and date_location=date_loc and ((((hd=heure_debut and min_deb<=minute_debut) or hd<heure_debut) and (hf>heure_debut or (hf=heure_debut and min_fin>minute_debut))) or (((heure_debut=hd and minute_debut<min_deb) or heure_debut<hd) and (heure_fin>hd or (heure_fin=hd and minute_fin>min_deb))) ); 
if(nb_terr_res_par_ad>=4) then
  select count(num_adherent) into nb_adherent from adherent where id_personne=num_person;
  if(nb_adherent!=0) then
    raise_application_error(-20501,'erreur il n y a plus de terrain dispo pour les adherents');
  end if;
end if;
  if(jour_res='mon') then
    jour_inter:=0;
  elsif (jour_res='tue') then
    jour_inter:=1;
  elsif (jour_res='wed') then
    jour_inter:=2;
  elsif (jour_res='thu') then
    jour_inter:=3;
  elsif (jour_res='fri') then
    jour_inter:=4;
  elsif (jour_res='sat') then
    jour_inter:=5;
  elsif (jour_res='sun') then
    jour_inter:=6;
  end if;
select count(*) into nb_cours_col from creneauCoursSqColl cren, adherent a, inscriptionCoursSqCollectif i where a.id_personne=num_person and i.num_adherent=a.num_adherent and i.id_cours=cren.id_cours and jour=jour_inter and ((cren.heure_debut=hd or cren.heure_debut=hd-1) or ((hf=cren.heure_debut and min_fin!=0) or hf=cren.heure_debut+1));
if(nb_cours_col>0) then
  raise_application_error(-20501,'erreur cet adherent a un cours collectif pour cet horaire');
end if;
select count(*) into nb_cours_ind from creneauCoursSqIndividuel cren, adherent a, coursSquashIndividuel c where a.id_personne=num_person and c.num_adherent=a.num_adherent and c.id_cours=cren.id_cours and date_cours=date_loc and (cren.heure_debut=hd  or ((hf=cren.heure_debut and min_fin!=0)));
if(nb_cours_ind>0) then
  raise_application_error(-20501,'erreur cet adherent a un cours individuel pour cet horaire');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- trigger permettant de voir qu'une personne ne reserve pas plusieurs terrain en meme temps
create or replace trigger tg_res_terr_limite_reserv
before insert or update on reservationTerrainSquash
for each row
declare
nb_terr_res_par_ad int;
nb_adherent int;
date_loc date;
hd int;
hf int;
min_deb int;
min_fin int;
num_person int;
n int;
nb_id_pers int;
num_terr int;
cpt int;
begin
date_loc := :new.date_location;
hd := :new.heure_debut;
hf := :new.heure_fin;
min_deb := :new.minute_debut;
min_fin := :new.minute_fin;
num_person :=:new.id_personne;
num_terr := :new.num_terrain_squash;
select count(*) into n from reservationTerrainSquash;
if(n!=0) then
  select count(*) into nb_id_pers from reservationTerrainSquash where id_personne=num_person and date_location=date_loc and ((((hd=heure_debut and min_deb<=minute_debut) or hd<heure_debut) and (hf>heure_debut or (hf=heure_debut and min_fin>minute_debut))) or (((heure_debut=hd and minute_debut<min_deb) or heure_debut<hd) and (heure_fin>hd or (heure_fin=hd and minute_fin>min_deb))) ); 
  if(nb_id_pers!=0) then
      raise_application_error(-20501,'erreur cette personne reserve deja un terrain au meme horaire (ou chevauchement des horraires)');
  end if;
  select count(*) into cpt from reservationTerrainSquash where num_terrain_squash=num_terr and date_location=date_loc and ((((hd=heure_debut and min_deb<=minute_debut) or hd<heure_debut) and (hf>heure_debut or (hf=heure_debut and min_fin>minute_debut))) or (((heure_debut=hd and minute_debut<min_deb) or heure_debut<hd) and (heure_fin>hd or (heure_fin=hd and minute_fin>min_deb))) ); 
  if(cpt!=0) then
    raise_application_error(-20501,'erreur ce terrain est deja reserve pour cet horraire (ou chevauchement des horraires)');
  end if;
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- trigger permettant de verifier que le terrain n'est pas deja reservé pour un cours individuel ou un cours collectif
create or replace trigger tg_res_terr_reserv_cren
before insert or update on reservationTerrainSquash
for each row
declare
num_terr int;
date_res date;
hd int;
hf int;
min_deb int;
min_fin int;
nb_cours_ind int;
nb_cours_col int;
jour_res int;
begin
num_terr := :new.num_terrain_squash;
date_res := :new.date_location;
hd := :new.heure_debut;
hf := :new.heure_fin;
min_deb := :new.minute_debut;
min_fin := :new.minute_fin;
jour_res := to_char(:new.date_location,'D')-2;
select count(*) into nb_cours_ind from creneauCoursSqIndividuel where num_terrain_squash=num_terr and date_cours=date_res and (heure_debut=hd or (hf=heure_debut and min_fin!=0));
if(nb_cours_ind>0) then
  raise_application_error(-20501,'erreur, terrain deja reservé pour un cours individuel');
end if;
select count(*) into nb_cours_col from creneauCoursSqColl where num_terrain_squash=num_terr and jour=jour_res and ((heure_debut=hd or heure_debut=hd-1) or ((hf=heure_debut and min_fin!=0) or hf=heure_debut+1));
if(nb_cours_col>0) then
  raise_application_error(-20501,'erreur, terrain deja reservé pour un cours collectif');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run



/*==============================================================*/
/* Table : coursSquash                                              */
/*==============================================================*/
drop table coursSquash cascade constraints;
create table coursSquash
(
	id_cours int,
	id_prof int,
	type_de_cours varchar2(10),check(type_de_cours in ('individuel','collectif')),
	constraint pk_cours_squash primary key (id_cours),
	constraint fk_cours_squash_prof foreign key(id_prof) references personnelSportif(id_prof)
);

-- trigger servant a determiner si le id_prof correspond bien a un prof de squash
create or replace trigger tg_cours_squash_prof
before insert or update on coursSquash
for each row
declare
id_p int;
typ_p varchar2(30);
begin
id_p:= :new.id_prof;
select type_sport into typ_p from personnelSportif where id_prof=id_p;
if(typ_p!='squash') then
  raise_application_error(-20501,'erreur type_prof!=squash');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;




/*==============================================================*/
/* Table : coursSquashIndividuel                                              */
/*==============================================================*/
drop table coursSquashIndividuel cascade constraints;
create table coursSquashIndividuel
(
	id_cours int,
	num_adherent int,
	constraint pk_cours_squash_individuel primary key (id_cours),
	constraint fk_cours_squash_indiv_idcours foreign key(id_cours) references coursSquash(id_cours),
	constraint fk_cours_squash_indiv_adherent foreign key(num_adherent) references adherent(num_adherent)
);

-- trigger servant a determiner si le id_cours correspond bien a un cours individuel sinon le cours ne peut etre ajouté
create or replace trigger tg_cours_squash_individuel
before insert or update on coursSquashIndividuel
for each row
declare
id_c int;
typ varchar2(30);
begin
id_c:= :new.id_cours;
select type_de_cours into typ from coursSquash where id_cours=id_c;
if(typ='collectif') then
  raise_application_error(-20501,'erreur type doit etre individuel');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;

-- trigger verifiant qu'un type a bien le bon forfait pour s'inscrire au cours individuel
create or replace trigger tg_cours_sq_indiv_forfait
before insert or update on coursSquashIndividuel
for each row
declare
id_c int;
nb_pers int;
cpt int;
num_ad int;
date_c date;
date_deb_forfait date;
date_fin_forfait date;
nb_forfait int;
res int;
nb_ad int;
begin
id_c := :new.id_cours;
num_ad := :new.num_adherent;
select count(*) into nb_forfait from souscription where type_forfait='cours particulier squash' and num_adherent=num_ad;
if (nb_forfait=0) then
  raise_application_error(-20301,'erreur pas de forfait pour cet adherent');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run

/*==============================================================*/
/* Table : creneauCoursSqIndividuel                                   */
/*==============================================================*/
drop table creneauCoursSqIndividuel cascade constraints;
create table creneauCoursSqIndividuel
(
	id_cours int,
	num_terrain_squash int,
	date_cours date,
	heure_debut int,check(heure_debut between 9 and 20), check(heure_fin=heure_debut+1),
	heure_fin int, check(heure_fin between 10 and 22),
	constraint pk_creneau_cours_sq_ind primary key (id_cours),
	constraint fk_creneau_cours_sq_cours foreign key(id_cours) references coursSquash(id_cours),
	constraint fk_creneau_cours_sq_terrain foreign key(num_terrain_squash) references terrainSquash(num_terrain_squash),
	unique(num_terrain_squash,date_cours,heure_debut)
);


-- permet de verifier qu'un cours enregistre est bien un cours individuel
create or replace trigger tg_creneau_cours_sq_indiv
before insert or update on creneauCoursSqIndividuel
for each row
declare
id_c int;
typ varchar2(10);
taille int;
begin 
id_c := :new.id_cours;
select count(*) into taille from creneauCoursSqIndividuel;
if(taille!=0) then
  select type_de_cours into typ from coursSquash where id_cours=id_c;
  if(typ!='individuel') then
    raise_application_error(-20501, 'erreur type_cours=collectif');
  end if;
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;



-- trigger permettant d'interdire d'inserer un creneau si le terrain est deja pris pour cet horraire
-- verifie aussi qu'un prof ne peut pas donner deux cours en meme temps
-- et qu'un adherent ne peu pas etre sur deux cours en meme temps
create or replace trigger tg_cren_cours_sq_ind_date
after insert on creneauCoursSqIndividuel
declare
jour_ind varchar2(9);
id_c_cren int;
id_c_ind int;
hd_ind int;
hf_ind int;
hd_coll int;
hf_coll int;
num_terr int;
jour_coll int;
date_c date;
cpt int;
prof int;
res_prof_ind int;
res_prof_col int;
res_total int;
res_adh_coll int;
res_adh_ind int;
res_total_adh int;
num_ad int;
idd creneauCoursSqIndividuel.id_cours%TYPE;
i int;
jour_inter int;
trimestre date;
mois_fin_trimestre varchar2(2);
annee int;
fin_trimestre varchar2(10);
concat_mois varchar2(5);
concat_annee varchar2(5);
date_fin_trimestre date;
jour_trim varchar2(2);
nb_terr_res int;
nb_reservation int;
CURSOR curseur is select ci.date_cours,to_char(date_cours,'dy'),ci.id_cours, ci.heure_debut, ci.heure_fin, ci.num_terrain_squash from creneauCoursSqIndividuel ci;
begin
i :=0;
open curseur;
loop
  FETCH curseur into date_c,jour_ind,id_c_cren,hd_ind,hf_ind,num_terr;
  select num_adherent into num_ad from coursSquashIndividuel where id_cours=id_c_cren;
  select id_prof into prof from coursSquash where id_cours=id_c_cren;
  select count(*) into res_prof_ind from creneauCoursSqIndividuel cren, coursSquash cs where id_prof=prof and cren.id_cours=cs.id_cours and date_cours=date_c and (heure_debut=hd_ind or heure_debut=hf_ind-1); 
  select count(*) into res_adh_ind from creneauCoursSqIndividuel cren, coursSquashIndividuel cs where num_adherent=num_ad and cren.id_cours=cs.id_cours and date_cours=date_c and (heure_debut=hd_ind or heure_debut=hf_ind-1); 
  if(jour_ind='mon') then
    jour_inter:=0;
  elsif (jour_ind='tue') then
    jour_inter:=1;
  elsif (jour_ind='wed') then
    jour_inter:=2;
  elsif (jour_ind='thu') then
    jour_inter:=3;
  elsif (jour_ind='fri') then
    jour_inter:=4;
  elsif (jour_ind='sat') then
    jour_inter:=5;
  elsif (jour_ind='sun') then
    jour_inter:=6;
  end if;
  select count(*) into nb_reservation from reservationTerrainSquash resa, adherent a, coursSquashIndividuel ind where ind.id_cours=id_c_cren and resa.id_personne=a.id_personne and a.num_adherent=ind.num_adherent and date_location=date_c and (resa.heure_debut=hd_ind or (resa.heure_fin=hd_ind and resa.minute_fin!=0));
  select count(*) into res_prof_col from creneauCoursSqColl cren, coursSquash cs where id_prof=prof and cren.id_cours=cs.id_cours and jour=jour_inter and (heure_debut=hd_ind or heure_debut=hd_ind-1);
  select count(*) into cpt from creneauCoursSqColl where num_terrain_squash=num_terr and jour=jour_inter and (heure_debut=hd_ind or heure_debut=hd_ind-1); 
  select count(*) into res_adh_coll from creneauCoursSqColl cren, coursSquashIndividuel cs, inscriptionCoursSqCollectif col where col.num_adherent=num_ad and cren.id_cours=col.id_cours and jour=jour_inter and  (cren.heure_debut=hd_ind or cren.heure_debut=hd_ind-1); 
  select count(*) into nb_terr_res from reservationTerrainSquash where num_terrain_squash=num_terr and date_location=date_c and (heure_debut=hd_ind or (heure_fin=hd_ind and minute_fin!=0));
  if(nb_reservation>0) then
     raise_application_error(-20501,'erreur cet adherent reserve deja un terrain pour cet horraire');
  end if;
  if(cpt>0) then
    delete from creneauCoursSqIndividuel where id_cours=id_c_cren and to_char(date_cours,'dy')=jour_ind and heure_debut=hd_ind and heure_fin=hf_ind;
    raise_application_error(-20501,'erreur ce terrain est deja pris pour cet horraire');
  end if;
  res_total := res_prof_col+res_prof_ind;
  if(res_total>1) then
    delete from creneauCoursSqIndividuel where id_cours=id_c_cren and date_cours=date_c and heure_debut=hd_ind and heure_fin=hf_ind;
    raise_application_error(-20501,'erreur ce prof est deja occupe pour cet horraire');
  end if;
  res_total_adh:=res_adh_coll+res_adh_ind;
  if(res_total_adh>1) then
    delete from creneauCoursSqIndividuel where id_cours=id_c_cren and date_cours=date_c and heure_debut=hd_ind and heure_fin=hf_ind;
    raise_application_error(-20501,'erreur cet adherent a deja un cours pour cet horraire');
  end if;
  if(nb_terr_res>0) then
    delete from creneauCoursSqIndividuel where id_cours=id_c_cren and date_cours=date_c and heure_debut=hd_ind and heure_fin=hf_ind;
    raise_application_error(-20501,'erreur ce terrain est deja reservé pour cet horraire');
  end if;
  
EXIT WHEN (curseur%NOTFOUND);
      i := i + 1;
end loop;
CLOSE curseur;
end;
.
run;


-- trigger verifiant que le forfait de l'adherent correspond bien aux horraire du cours :
create or replace trigger tg_creneau_cours_ind_forfait
before insert or update on creneauCoursSqIndividuel
for each row
declare
id_c int;
cpt int;
num_ad int;
date_c date;
date_deb_forfait date;
date_fin_forfait date;
nb_forfait int;
begin
id_c := :new.id_cours;
date_c:=:new.date_cours;
select num_adherent into num_ad from coursSquashIndividuel where id_cours=id_c;
select date_debut,date_fin into date_deb_forfait,date_fin_forfait from souscription where type_forfait='cours particulier squash' and num_adherent=num_ad;
if(not (date_deb_forfait=date_c or (date_deb_forfait<date_c and date_fin_forfait>date_c) or date_fin_forfait=date_c)) then 
  raise_application_error(-20301,'erreur dates de forfait non valides');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;



/*==============================================================*/
/* Table : coursSquashCollectif                                              */
/*==============================================================*/
drop table coursSquashCollectif cascade constraints;
create table coursSquashCollectif
(
	id_cours int,
	nb_personne int,
	check(nb_personne between 2 and 6),
	constraint pk_cours_squash_coll primary key (id_cours),
	constraint inscriptionCoursSquashCollec foreign key(id_cours) references coursSquash(id_cours)
);


-- trigger servant a determiner si le id_cours correspond bien a un cours collectif sinon le cours ne peut etre ajouté
create or replace trigger tg_cours_squash_collectif
before insert or update on coursSquashCollectif
for each row
declare
id_c int;
typ varchar2(30);
begin
id_c := :new.id_cours;
select type_de_cours into typ from coursSquash where id_cours=id_c;
if(typ='individuel') then
raise_application_error(-20501,'erreur type_cours=individuel au lieu de collectif');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


/*==============================================================*/
/* Table : inscriptionCoursSquashCollectif                                          */
/*==============================================================*/
drop table inscriptionCoursSqCollectif cascade constraints;
create table inscriptionCoursSqCollectif
(
	id_cours int,
	num_adherent int,
	constraint pk_insc_cours_squash_coll primary key (id_cours,num_adherent),
	constraint fk_insc_cours_sq_coll_creneau foreign key(id_cours) references coursSquash(id_cours),
	constraint fk_insc_cours_sq_coll_adherent foreign key(num_adherent) references adherent(num_adherent)
);


-- trigger calculant la taille d'un groupe si il reste encore des places alors l'utilisateur peut s'inscrire sinon il y a une erreur
-- erreur egalement si l'utilisateur entre un num de cours individuel
create or replace trigger tg_inscription_cours_sq_coll
before insert or update on inscriptionCoursSqCollectif
for each row
declare
id_c int;
nb_pers int;
cpt int;
typ varchar2(30);
begin
id_c := :new.id_cours;
select type_de_cours into typ from coursSquash where id_cours=id_c;
if(typ!='collectif') then
  raise_application_error(-20501,'erreur vous essayez de vous inscrire a un cours individuel');
end if;
select nb_personne into nb_pers from coursSquashCollectif where id_cours=id_c;
select count(num_adherent) into cpt from inscriptionCoursSqCollectif where  id_cours=id_c;
if(cpt>=nb_pers) then
  raise_application_error(-20501,'erreur ce cours est plein');
end if; 
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


-- trigger verifiant que l'adherant a le bon forfait pour participer aux cours collectif :
create or replace trigger tg_insc_cours_sq_coll_forfait
before insert or update on inscriptionCoursSqCollectif
for each row
declare
id_c int;
nb_pers int;
cpt int;
num_ad int;
jour_cours int;
deb_trimestre date;
fin_trimestre date;
date_deb_forfait date;
date_fin_forfait date;
nb_forfait int;
res int;
nb_ad int;
begin
id_c := :new.id_cours;
num_ad := :new.num_adherent;
select jour, debut_trimestre into jour_cours,deb_trimestre from creneauCoursSqColl where id_cours=id_c;
fin_trimestre := deb_trimestre+90;
select count(*) into nb_forfait from souscription where type_forfait='cours groupe squash' and num_adherent=num_ad;
if(nb_forfait>0) then
  select date_debut,date_fin into date_deb_forfait,date_fin_forfait from souscription where type_forfait='cours groupe squash' and num_adherent=num_ad;
  if(not((date_deb_forfait<deb_trimestre and date_fin_forfait<fin_trimestre) or (date_deb_forfait=deb_trimestre and (date_fin_forfait=fin_trimestre or date_fin_forfait<fin_trimestre)) or (date_deb_forfait>deb_trimestre and (date_fin_forfait=fin_trimestre or date_fin_forfait>fin_trimestre or date_fin_forfait<fin_trimestre)))) then 
    raise_application_error(-20301,'erreur dates de forfait non valides');
  end if;
elsif (nb_forfait=0) then
  raise_application_error(-20301,'erreur pas de forfait pour cet adherent');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


-- trigger permettant de verifier qu'un utilisateur ne peut pas s'inscrire a un cours collectif le meme jours a la meme heure si il est deja inscrit dans un cours individuel le meme jour a la meme heure et inversement. il permet aussi de gerer qu'un utilisateur ne peut pas s'inscrire dans deux creneaux qui se chevauchent.
create or replace trigger tg_insc_cours_sq_coll_adh
before insert or update on inscriptionCoursSqCollectif
for each row
declare
id_c int;
jour_c int;
hd int;
hf int;
res_col int;
res_ind int;
res_total int;
jour_inter varchar2(3);
num_ad int;
trimestre date;
mois_fin_trimestre varchar2(2);
annee int;
fin_trimestre varchar2(10);
concat_mois varchar2(5);
concat_annee varchar2(5);
date_fin_trimestre date;
jour_trim varchar2(2);
nb_terr_res int;
nb_reservation int;
personne int;
begin
id_c:=:new.id_cours;
num_ad := :new.num_adherent;
select jour,heure_debut,heure_fin,debut_trimestre,to_number(to_char(debut_trimestre,'YYYY')) into jour_c,hd,hf,trimestre,annee from creneauCoursSqColl where  id_cours=id_c;
select count(*) into res_col from creneauCoursSqColl c, inscriptionCoursSqCollectif i where  num_adherent=num_ad and c.id_cours=i.id_cours and jour=jour_c and (heure_debut=hd or (heure_debut>hd and heure_debut<hf) or (hd>heure_debut and hd<heure_fin)) and debut_trimestre=trimestre;
if(jour_c=0) then
  jour_inter:='mon';
elsif (jour_c=1) then
    jour_inter:='tue';
elsif (jour_c=2) then
    jour_inter:='wed';
elsif (jour_c=3) then
    jour_inter:='thu';
elsif (jour_c=4) then
    jour_inter:='fri';
elsif (jour_c=5) then
    jour_inter:='sat';
elsif (jour_c=6) then
    jour_inter:='sun';
end if;
if(to_char(trimestre,'MM')=01) then
    mois_fin_trimestre:='04';
elsif(to_char(trimestre,'MM')=04) then 
    mois_fin_trimestre:='07';
elsif(to_char(trimestre,'MM')=07) then 
    mois_fin_trimestre:='10';
elsif(to_char(trimestre,'MM')=10) then 
    mois_fin_trimestre:='01';
    annee:=annee+1;
end if;
jour_trim:='01';
concat_mois := concat(jour_trim,mois_fin_trimestre);
fin_trimestre :=  concat(concat_mois,annee);
date_fin_trimestre:= to_date(fin_trimestre);
select count(*) into res_ind from creneauCoursSqIndividuel c, creneauCoursSqColl col, coursSquashIndividuel ind where  ind.num_adherent=num_ad and ind.id_cours=c.id_cours and col.id_cours=id_c and to_char(c.date_cours,'dy')=jour_inter and (c.heure_debut=hd or (c.heure_debut>hd and c.heure_debut<hf) or (hd>c.heure_debut and hd<c.heure_fin)) and debut_trimestre=trimestre and (c.date_cours>trimestre and c.date_cours<date_fin_trimestre);
select id_personne into personne from adherent where num_adherent=num_ad;
select count(*) into nb_reservation from reservationTerrainSquash res, creneauCoursSqColl cren where id_personne=personne and to_char(date_location,'dy')=jour_inter and ((cren.heure_debut=res.heure_debut or cren.heure_debut=res.heure_debut-1) or ((res.heure_fin=cren.heure_debut and minute_fin!=0) or res.heure_fin=cren.heure_debut+1)); 
if(nb_reservation>0)then
  raise_application_error(-20501,'erreur cet adherent reserve deja un terrain pour cet horraire');
end if;
res_total:= res_col+res_ind;
if(res_total>0) then
  raise_application_error(-20301,'erreur adherent deja inscrit dans un autre cours pour ce creneau');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


/*==============================================================*/
/* Table : creneauCoursSqhColl                                   */
/*==============================================================*/
drop table creneauCoursSqColl cascade constraints;
create table creneauCoursSqColl
(
	id_cours int,
	num_terrain_squash int,
	jour int, check(jour between 0 and 6),		-- 0 lundi et 6 dimanche
	heure_debut int,check(heure_debut between 9 and 20), check(heure_fin=heure_debut+2),
	heure_fin int, check(heure_fin between 10 and 22),
	debut_trimestre date, 
	constraint pk_creneau_cours_sq_coll primary key (id_cours),
	constraint fk_creneau_cours_sq_cours_co foreign key(id_cours) references coursSquash(id_cours),
	constraint fk_creneau_cours_sq_terr foreign key(num_terrain_squash) references terrainSquash(num_terrain_squash)
);


-- trigger verifiant que l'id_cours correspond bien a un cours collectif
-- trigger verifiant que si le cours est de type collectif alors il ne peut pas y avoir 3 cours collectif en meme temps, meme date, meme heure
-- et que si collectif alors pas plus d'un cours par semaine
create or replace trigger tg_creneau_cours_sq_coll
before insert or update on creneauCoursSqColl
for each row
declare
id_c int;
typ varchar2(10);
hd int;
hf int;
semaine int;
taille int;
nb_creneau int;
dat_trim date;
jour_c int;
mois_trimestre int;
jour_trimestre int;
begin 
id_c := :new.id_cours;
hd := :new.heure_debut;
hf := :new.heure_fin;
jour_c := :new.jour;
mois_trimestre:= to_char(:new.debut_trimestre,'MM');
jour_trimestre := to_char(:new.debut_trimestre,'DD');
if(not((mois_trimestre=01 or mois_trimestre=04 or mois_trimestre=07 or mois_trimestre=10) and jour_trimestre=01)) then
 raise_application_error(-20501,'erreur, les creneaux horraires ne peuvent etre changer que par trimestre');
end if;
select count(*) into taille from creneauCoursSqColl;
if(taille!=0) then
  select type_de_cours into typ from coursSquash where id_cours=id_c;
  if(typ!='collectif') then
    raise_application_error(-20501, 'erreur type_cours=individuel au lieu de collectif');
  end if;
  select count(id_cours) into nb_creneau from creneauCoursSqColl where jour=jour_c and (heure_debut=hd or (hd>heure_debut and hd<heure_fin) or (hf>heure_debut and hf<heure_fin));
  if(nb_creneau>=3) then
    raise_application_error(-20501,'erreur trop de cours groupe pour ce creneau');
  end if;
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


-- trigger permettant d'interdire l'insertion de tuple dans la table si les creneaux horaires se chevauchent pour un meme terrain ;
-- interdit aussi l'ajout de tuples dans la table si le prof est deja occupé sur un autre cours
create or replace trigger tg_cren_cours_sq_co_date_terr
before insert or update on creneauCoursSqColl
for each row
declare
id_c int;
jour_c int;
jour_coll varchar2(3);
hd int;
hf int;
num_terr int;
res_col int;
res_ind int;
res_total_terr int;
taille int;
prof int;
res_prof_ind int;
res_prof_col int;
res_total_prof int;
res_adh_ind int;
res_adh_coll int;
jour_inter varchar2(3);
trimestre date;
mois_fin_trimestre varchar2(2);
annee int;
fin_trimestre varchar2(10);
concat_mois varchar2(5);
concat_annee varchar2(5);
date_fin_trimestre date;
jour_trim varchar2(2);
nb_terr_res int;
begin
id_c:=:new.id_cours;
hd := :new.heure_debut;
hf := :new.heure_fin;
jour_c := :new.jour;
num_terr := :new.num_terrain_squash;
trimestre := :new.debut_trimestre;
annee := to_number(to_char(trimestre,'YYYY'));
select id_prof into prof from coursSquash where id_cours=id_c;
select count(*) into res_col from creneauCoursSqColl where jour=jour_c and num_terrain_squash=num_terr and (heure_debut=hd or (heure_debut>hd and heure_debut<hf) or (hd>heure_debut and hd<heure_fin)) and debut_trimestre=trimestre;
select count(*) into res_prof_col from creneauCoursSqColl col, coursSquash cs where id_prof=prof and (heure_debut=hd or (heure_debut>hd and heure_debut<hf) or (hd>heure_debut and hd<heure_fin)) and jour=jour_c and col.id_cours=cs.id_cours and debut_trimestre=trimestre;
if(jour_c=0) then
  jour_inter:='mon';
elsif (jour_c=1) then
    jour_inter:='tue';
elsif (jour_c=2) then
    jour_inter:='wed';
elsif (jour_c=3) then
    jour_inter:='thu';
elsif (jour_c=4) then
    jour_inter:='fri';
elsif (jour_c=5) then
    jour_inter:='sat';
elsif (jour_c=6) then
    jour_inter:='sun';
end if;
if(to_char(trimestre,'MM')=01) then
    mois_fin_trimestre:='04';
elsif(to_char(trimestre,'MM')=04) then 
    mois_fin_trimestre:='07';
elsif(to_char(trimestre,'MM')=07) then 
    mois_fin_trimestre:='10';
elsif(to_char(trimestre,'MM')=10) then 
    mois_fin_trimestre:='01';
    annee:=annee+1;
end if;
jour_trim:='01';
concat_mois := concat(jour_trim,mois_fin_trimestre);
fin_trimestre :=  concat(concat_mois,annee);
date_fin_trimestre:= to_date(fin_trimestre);
select count(*) into res_ind from creneauCoursSqIndividuel where to_char(date_cours,'dy')=jour_inter and num_terrain_squash=num_terr and (heure_debut=hd or (heure_debut>hd and heure_debut<hf) or (hd>heure_debut and hd<heure_fin)) and (date_cours>trimestre and date_cours<date_fin_trimestre);
select count(*) into res_prof_ind from creneauCoursSqIndividuel ind, coursSquash cs where id_prof=prof and (heure_debut=hd or (heure_debut>hd and heure_debut<hf) or (hd>heure_debut and hd<heure_fin)) and to_char(date_cours,'dy')=jour_inter and ind.id_cours=cs.id_cours and (date_cours>trimestre and date_cours<date_fin_trimestre);
res_total_terr:=res_col+res_ind;
if(res_total_terr>0) then
  raise_application_error(-20301,'erreur creneau sq terrain deja reserver pour un cours collectif');
end if;
select count(*) into nb_terr_res from reservationTerrainSquash where num_terrain_squash=num_terr and to_char(date_location,'dy')=jour_inter and (heure_debut=hd or heure_debut=hd+1 or (heure_fin=hd and minute_fin!=0) or heure_fin=hd+1);
if(nb_terr_res>0) then
  raise_application_error(-20301,'erreur creneau sq date terrain deja pris');
end if;
res_total_prof:=res_prof_col+res_prof_ind;
if(res_total_prof>0) then
  raise_application_error(-20301,'erreur creneau sq prof deja occupe');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;



/*==============================================================*/
/* Table :        salleGym                          */
/*==============================================================*/
drop table salleGym cascade constraints;
create table salleGym
(
	id_salle int, check(id_salle between 1 and 10),
	capacite int,
	constraint pk_salle_gym primary key (id_salle)
);



/*==============================================================*/
/* Table : coursGym                               */
/*==============================================================*/
drop table coursGym cascade constraints;
create table coursGym
(
	type_cours varchar2(30),
	id_prof int,
	constraint pk_cours_gym primary key (type_cours),
	constraint fk_cours_gym_prof foreign key(id_prof) references personnelSportif(id_prof)
);

-- trigger verifiant que le prof de gym n'est pas un prof de squah
create or replace trigger tg_cours_gym_prof
before insert or update on coursGym
for each row
declare
id_p int;
typ_p varchar2(30);
begin
id_p:= :new.id_prof;
select type_sport into typ_p from personnelSportif where id_prof=id_p;
if(typ_p='squash') then
  raise_application_error(-20501,'erreur type_prof=squash');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


/*==============================================================*/
/* Table : creneauCoursGym                               */
/*==============================================================*/
drop table creneauCoursGym cascade constraints;
create table creneauCoursGym
(
	id_salle int,
	type_cours varchar2(30),
	date_cours date,
	heure_debut int, check(heure_debut between 9 and 21),
	heure_fin int, check(heure_fin between 10 and 22),
	debut_trimestre date,
	check(heure_fin=heure_debut+1),  -- un cours de gym dure une heure
	constraint pk_creneau_cours_gym primary key (id_salle,date_cours,heure_debut),
	constraint fk_creneau_cours_gym_salle foreign key(id_salle) references salleGym(id_salle),
	constraint fk_creneau_cours_gym_cours foreign key(type_cours) references coursGym(type_cours)
);

-- trigger permettant de verifier que la date de changement des horraires de gym est bien un trimestre :
create or replace trigger tg_creneau_gym_trimestre
before insert or update on creneauCoursGym
for each row
declare
jour_trim varchar2(2);
hd int;
hf int;
date_c date;
mois_trimestre int;
jour_trimestre int;
trimestre date;
mois_fin_trimestre varchar2(2);
annee int;
fin_trimestre varchar2(10);
concat_mois varchar2(5);
concat_annee varchar2(5);
date_fin_trimestre date;
cpt int;
begin 
hd := :new.heure_debut;
hf := :new.heure_fin;
date_c := :new.date_cours;
trimestre := :new.debut_trimestre;
annee := to_number(to_char(trimestre,'YYYY'));
mois_trimestre:= to_char(:new.debut_trimestre,'MM');
jour_trimestre := to_char(:new.debut_trimestre,'DD');
if(not((mois_trimestre=01 or mois_trimestre=04 or mois_trimestre=07 or mois_trimestre=10) and jour_trimestre=01)) then
 raise_application_error(-20501,'erreur, les creneaux horraires ne peuvent etre changer que par trimestre');
end if;
if(to_char(trimestre,'MM')=01) then
    mois_fin_trimestre:='04';
elsif(to_char(trimestre,'MM')=04) then 
    mois_fin_trimestre:='07';
elsif(to_char(trimestre,'MM')=07) then 
    mois_fin_trimestre:='10';
elsif(to_char(trimestre,'MM')=10) then 
    mois_fin_trimestre:='01';
    annee:=annee+1;
end if;
jour_trim:='01';
concat_mois := concat(jour_trim,mois_fin_trimestre);
fin_trimestre :=  concat(concat_mois,annee);
date_fin_trimestre:= to_date(fin_trimestre);
if(date_c<trimestre or date_c>date_fin_trimestre) then 
   raise_application_error(-20501,'erreur, la date du cours n est pas comprise dans le trimestre');
end if;
exception
when no_data_found then
raise_application_error(-20301,'aucune donnee trouvee');
end;
.
run;


-- chargement des tuples :
START /home/audrey/Master/SIBD/projet/tuples-08-01-2010.sql
commit;