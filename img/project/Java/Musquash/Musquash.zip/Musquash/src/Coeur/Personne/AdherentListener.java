package Coeur.Personne;

public interface AdherentListener extends PersonneListener {
	
}