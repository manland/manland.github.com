package Coeur.Cours;

import java.util.EventListener;

public interface CreneauxCoursSquashsIndividuelsListener extends EventListener {
	void ajouterCreneauCoursSquashIndividuel(CreneauCoursSquashIndividuel creneau_cours_squash_individuel);
	void supprimerCreneauCoursSquashIndividuel(CreneauCoursSquashIndividuel creneau_cours_squash_individuel);

}
