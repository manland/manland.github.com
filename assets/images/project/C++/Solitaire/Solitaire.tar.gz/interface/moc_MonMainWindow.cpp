/****************************************************************************
** Meta object code from reading C++ file 'MonMainWindow.h'
**
** Created: Mon Dec 8 17:18:06 2008
**      by: The Qt Meta Object Compiler version 59 (Qt 4.4.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "MonMainWindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MonMainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 59
#error "This file was generated using the moc from 4.4.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MonMainWindow[] = {

 // content:
       1,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   10, // methods
       0,    0, // properties
       0,    0, // enums/sets

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x0a,
      37,   14,   14,   14, 0x0a,
      54,   14,   14,   14, 0x0a,
      66,   14,   14,   14, 0x08,
      78,   14,   14,   14, 0x08,
      90,   14,   14,   14, 0x08,
     102,   14,   14,   14, 0x08,
     116,   14,   14,   14, 0x08,
     131,   14,   14,   14, 0x08,
     147,   14,   14,   14, 0x08,
     161,   14,   14,   14, 0x08,
     192,   14,   14,   14, 0x08,
     220,   14,   14,   14, 0x08,
     248,   14,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MonMainWindow[] = {
    "MonMainWindow\0\0mettreAJourStatuBar()\0"
    "melangerPioche()\0voirCarte()\0tempsReel()\0"
    "newPartie()\0aproposde()\0aproposdeQt()\0"
    "agrandirIcon()\0rapeticirIcon()\0"
    "recommencer()\0afficherCacherToolBarFichier()\0"
    "afficherCacherToolBarJeux()\0"
    "afficherCacherToolBarAide()\0"
    "afficherCacherStatusBar()\0"
};

const QMetaObject MonMainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MonMainWindow,
      qt_meta_data_MonMainWindow, 0 }
};

const QMetaObject *MonMainWindow::metaObject() const
{
    return &staticMetaObject;
}

void *MonMainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MonMainWindow))
        return static_cast<void*>(const_cast< MonMainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MonMainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: mettreAJourStatuBar(); break;
        case 1: melangerPioche(); break;
        case 2: voirCarte(); break;
        case 3: tempsReel(); break;
        case 4: newPartie(); break;
        case 5: aproposde(); break;
        case 6: aproposdeQt(); break;
        case 7: agrandirIcon(); break;
        case 8: rapeticirIcon(); break;
        case 9: recommencer(); break;
        case 10: afficherCacherToolBarFichier(); break;
        case 11: afficherCacherToolBarJeux(); break;
        case 12: afficherCacherToolBarAide(); break;
        case 13: afficherCacherStatusBar(); break;
        }
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
