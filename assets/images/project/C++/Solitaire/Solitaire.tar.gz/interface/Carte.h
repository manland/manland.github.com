/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant de gérer une Carte : sa valeure, sa famille, et son apparence
  *******************************************************/

#ifndef Carte_h
#define Carte_h

#include <QLabel>
#include <QPainter>

#include <iostream>
using namespace std;

class Carte : public QLabel
{
	Q_OBJECT

    public:
	//constructeur
	Carte(QWidget *parent=0);
        Carte(int, QString, QWidget *parent=0);

	//accesseur de visibilité
	int getX();
	int getY();
	int getHauteure();
        int getLargeure();
        int getValeure();
        QString getFamille();
        QString getCouleure();
        bool getVisibilite();

	//accesseur de modification
	void setX(int);
	void setY(int);
	void setHauteure(int);
        void setLargeure(int);
        void setValeure(int);
        void setFamille(QString);
        void setVisibilite(bool);

        //autre
        void setAccessible();//surbrillance au passage

    public slots:
    
    protected :
        void moveEvent(QMoveEvent *);

    private:
        //attributs
	int x;
	int y;
	int largeure;
        int hauteure;
        QString famille;
        int valeure;
        QString couleure;
        bool visibilite;

        //méthodes
        void pixmapVide();
        void pixmapVidePioche();
        void pixmapVisible();
        void pixmapNonVisible();
};

#endif
