/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe réimplentant MaFrame pour ajouter le fait de tricher en voyant une carte de dos
  *******************************************************/

#include "MaFrameBas.h"

MaFrameBas::MaFrameBas(QWidget *parent) : MaFrame(parent) {
    setMinimumSize(100, 200);
    voirCarte = false;
    t = new QTimer();
    setAttribute(Qt::WA_DeleteOnClose);
}

void MaFrameBas::setVoirCarte(bool b) {
    voirCarte = b;
}

void MaFrameBas::mousePressEvent(QMouseEvent * event) {
    if (event->button() == buttonDeplacement)
        startPos = event->pos();
    else if(event->button() == buttonClick) {
        Carte * ca = static_cast<Carte*>(childAt(event->pos()));
        if(!ca)
            return;
        if(!voirCarte)
            selectionerCarte(event);
        else if(voirCarte){
            c = static_cast<Carte*>(childAt(event->pos()));
            voirCarte = false;
            t->setInterval(3000);
            c->setVisibilite(true);
            t->start();
            connect(t, SIGNAL(timeout()), this, SLOT(cacherCarte()));
            connect(t, SIGNAL(timeout()), t, SLOT(stop()));
        }
    }
}

void MaFrameBas::cacherCarte() {
    c->setVisibilite(false);
}
