/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe gérant les menus, toolbars, statuBar et contenant le jeux
  *******************************************************/

#ifndef MonMainWindow_h
#define MonMainWindow_h

#include <QMainWindow>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QWidget>
#include <QMessageBox>
#include <QTime>
#include <QTimer>

class QAction;
class QDialog;

#include "Jeux.h"
#include "MaFramePioche.h"

#include <iostream>
using namespace std;

class MonMainWindow : public QMainWindow
{
    Q_OBJECT

    public:
	//constructeur
        MonMainWindow(QWidget *parent=0);
        void chargerParametres();
        void gagner();
        QPixmap pixmap();


    public slots:
        void mettreAJourStatuBar();
        void melangerPioche();
        void voirCarte();
        void annuler();
        void preference();

    protected:
        void paintEvent(QPaintEvent *);
        void closeEvent(QCloseEvent *);

    private slots:
        void tempsReel();
        void newPartie();
//        void sauvegarder();
        void aproposde();
        void aproposdeQt();
//        void sauvegardeRecente();
        void agrandirIcon();
        void rapeticirIcon();
        void recommencer();
        void afficherCacherToolBarFichier();
        void afficherCacherToolBarJeux();
        void afficherCacherToolBarAide();
        void afficherCacherStatusBar();

    private:
        int pointPerdu;
        int nbParties;
        Jeux * j;

        void creerActions();
        void creerMenu();
        void creerMenuTool();
        void creerStatusBar();
//        void sauverParametres();
//        void chargerParametres();
        bool okPourContinuer(QString, QString, int);
//        bool chargerPartie(const QString &fileName);
//        bool sauvegarderPartie(const QString &fileName);

        QLabel * temps;
        QLabel * cartesFinies;
        QLabel * cartesPioche;
        QTimer * qtempsReel;
        QTime time;

        QAction * actionNouvellePartie;
        QAction * actionQuitter;
        QAction * actionAgrandirIcon;
        QAction * actionRapeticirIcon;
        QAction * actionRecommencer;
        QAction * actionAfficherCacherToolBarS;
        QAction * actionAfficherCacherToolBarFichier;
        QAction * actionAfficherCacherToolBarJeux;
        QAction * actionAfficherCacherToolBarAide;
        QAction * actionAfficherCacherStatusBar;

        QAction * actionVoirCarte;
        QAction * actionMelangerPioche;
        QAction * actionAnnuler;
        QAction * actionPreference;

        QAction * actionAProposDe;
        QAction * actionAProposDeQt;

        QMenuBar * menu;
        QMenu * menuFichier;
        QMenu * menuJeux;
        QMenu * menuAffichage;
        QMenu * menuAffichageToolBar;
        QMenu * menuAide;
        QToolBar * toolBarFichier;
        QToolBar * toolBarAide;
        QToolBar * toolBarJeux;
};

#endif
