/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe réimplentant MaFrame pour ajouter le fait de tricher en voyant une carte de dos
  *******************************************************/

#ifndef MaFrameBas_H
#define MaFrameBas_H

#include "MaFrame.h"
#include <QTimer>

class MaFrameBas : public MaFrame {

    Q_OBJECT

    public:
        MaFrameBas(QWidget *parent=0);
        void setVoirCarte(bool);

    protected:
        void mousePressEvent(QMouseEvent *);

    private slots:
        void cacherCarte();

    private:
        bool voirCarte;
        Carte * c;
        QTimer * t;
};
#endif
