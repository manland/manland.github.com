/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe gérant les options graphiquement et en écriture
  *******************************************************/

#ifndef Options_h
#define Options_h

#include <QWidget>
#include <QRadioButton>
#include <QPixmap>

#include "BuildCarte.h"
#include "Carte.h"
#include "Jeux.h"

class Options : public QWidget
{
    Q_OBJECT

    public:
        Options(Jeux *, QWidget *parent=0);

    public slots:
        void setCarteDos();
        void setCarteVide();

    private slots:
        void carteDos();
        void carteVide();
        void frame();

        void changerDecalageXFrameBas(int);
        void changerDecalageYFrameBas(int);
        void changerDecalageFramePioche(int);
        void changerDecalageFrameFinX(int);
        void changerDecalageFrameFinY(int);

        void click(bool);
        void drag(bool);

        void annuler();
        void defo();

        void enregistrer();

    private:
        Jeux * jeux;

        QPixmap * ancienCarteDos;
        QPixmap * ancienCarteVide;
        QPixmap * ancienMonMainWindow;

        int decalageFrameBasX;
        int decalageFrameBasY;
        int decalageFramePioche;
        int decalageFrameFinX;
        int decalageFrameFinY;
        int deplacement;

        int ancienDecalageFrameBasX;
        int ancienDecalageFrameBasY;
        int ancienDecalageFramePioche;
        int ancienDecalageFrameFinX;
        int ancienDecalageFrameFinY;
        int ancienDeplacement;

        QWidget* buildCarteWidget();
        QWidget* buildAffichageWidget();
        QWidget* buildJeuxWidget();
        QRadioButton * qrbDrag;
        QRadioButton * qrbClick;
};
#endif
