/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant mère de toutes les frames contenant les fonctions les plus utiles
  *******************************************************/

#include "MaFrame.h"

#include "Jeux.h"

MaFrame::MaFrame(QWidget *parent) : QFrame(parent) {
    setFrameStyle(QFrame::Sunken | QFrame::StyledPanel);
    setAcceptDrops(true);
    nbCartes = 0;
    estAccessible = false;
    decalageX = 4;
    decalageY = 15;
    pixmapCarteDos = new QString("CarteDosDefault.png");
    pixmapCarteVide = new QString("0");
    buttonDeplacement = Qt::LeftButton;
    buttonClick = Qt::RightButton;
}

void MaFrame::addCarte(int valeure, QString famille, bool jouee) {
    cartes[nbCartes] = new Carte(valeure, famille, this);

    if(!jouee)
        if(nbCartes-1>=0) {
            if(cartes[nbCartes-1]->getVisibilite())
                cartes[nbCartes-1]->setVisibilite(false);
        }

    if(valeure != 0 && famille != "vide")
        nbCartes = nbCartes + 1;

    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width()+200, this->height()+200)));
}

void MaFrame::addCarte(Carte * c, bool jouee) {
    cartes[nbCartes] = c;
    cartes[nbCartes]->setParent(this);

    if(!jouee)
        if(nbCartes-1 >= 0) {
            if(cartes[nbCartes-1]->getVisibilite())
                cartes[nbCartes-1]->setVisibilite(false);
        }

    if(c->getValeure() != 0 && c->getFamille() != "vide")
        nbCartes = nbCartes + 1;

    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));

    Jeux * mmw = static_cast<Jeux*>(this->parentWidget());
    mmw->mettreAJourStatistiques();
}

void MaFrame::delCarte(int nb) {
    for(int i=1; i<=nb; i++) {
        cartes[nbCartes-i]->hide();
        cartes[nbCartes-i]->close();
    }
    nbCartes = nbCartes - nb;
    if (nbCartes == 0)
        addCarte(0, "vide", false);
    else if (!cartes[nbCartes-1]->getVisibilite())
        cartes[nbCartes-1]->setVisibilite(true);

    Jeux * mmw = static_cast<Jeux*>(this->parentWidget());
    mmw->mettreAJourStatistiques();
}

int MaFrame::getNbCartes() {
    return nbCartes;
}
int MaFrame::getIdCarte(int valeure) {
    int res = -1;
    for (int i=0; i<nbCartes; i++) {
        if(cartes[i]->getValeure() == valeure) {
            res = i;
        }
    }
    return res;
}
Carte* MaFrame::getCarteId(int i) {
    return cartes[i];
}

int MaFrame::getDecalageCarteX() {
    return decalageX;
}
int MaFrame::getDecalageCarteY() {
    return decalageY;
}
void MaFrame::setDecalageCarteX(int i) {
    decalageX = i;
    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));
}
void MaFrame::setDecalageCarteY(int i) {
    decalageY = i;
    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));
}
QString MaFrame::getCarteDos() {
    return *pixmapCarteDos;
}
QString MaFrame::getCarteVide() {
    return *pixmapCarteVide;
}
void MaFrame::setCartePixmap(QString carte, bool type) {
    if(type) {
        pixmapCarteDos = new QString(carte);
        for(int i=0; i<nbCartes; i++)
            if(!cartes[i]->getVisibilite())
                cartes[i]->setVisibilite(false);
    }
    else {
        pixmapCarteVide = new QString(carte);
        if(nbCartes==0) {
            Carte * carte = static_cast<Carte*>(this->children().at(0));
            carte->setVisibilite(true);
        }
    }
}
int MaFrame::getButtonDeplacement() {
    return buttonDeplacement;
}
int MaFrame::getButtonClick() {
    return buttonClick;
}
void MaFrame::setButtonDeplacement(int i) {
    buttonDeplacement = i;
}
void MaFrame::setButtonClick(int i) {
    buttonClick = i;
}

void MaFrame::dragEnterEvent(QDragEnterEvent *event) {
    if (event->mimeData()->hasFormat("application/Carte-Pixmap")) {
        if (event->source() == this) {
            event->accept();
        }
        else {
            QByteArray itemData = event->mimeData()->data("application/Carte-Pixmap");
            QDataStream dataStream(&itemData, QIODevice::ReadOnly);

            int count;
            int valeure;
            QString famille;
            dataStream >> count >> valeure >> famille;

            Carte * c = new Carte();
            c->setValeure(valeure);
            c->setFamille(famille);
            c->setParent(this);

            if (conditionsAjoutCarte(c)) {
                if(nbCartes == 0)
                    cartes[0]->setAccessible();
                else
                    cartes[nbCartes-1]->setAccessible();
                estAccessible = true;
            }
            c->close();
            event->acceptProposedAction();
        }
    }
    else
        event->ignore();
}

void MaFrame::dragLeaveEvent (QDragLeaveEvent * event) {
    if(estAccessible) {
        if(nbCartes==0) {
            cartes[nbCartes]->hide();
            cartes[nbCartes]->close();
            addCarte(0, "vide", false);
        }
        else
            cartes[nbCartes-1]->setVisibilite(true);
    }
}

void MaFrame::dragMoveEvent(QDragMoveEvent *event) {
    if (event->mimeData()->hasFormat("application/Carte-Pixmap")) {
        if (event->source() == this) {
            event->setDropAction(Qt::MoveAction);
            event->accept();
        }
    else
        event->acceptProposedAction();
    }
    else
        event->ignore();
}

void MaFrame::dropEvent(QDropEvent *event) {
    if (event->mimeData()->hasFormat("application/Carte-Pixmap")) {
        QByteArray itemData = event->mimeData()->data("application/Carte-Pixmap");
        QDataStream dataStream(&itemData, QIODevice::ReadOnly);

        int count;
        int valeure;
        QString famille;
        dataStream >> count >> valeure >> famille;

        Carte * c = new Carte();
        c->setValeure(valeure);
        c->setFamille(famille);
        c->setParent(this);

        if (conditionsAjoutCarte(c)) {
            MaFrame *frameprovenance = static_cast<MaFrame*>(event->source());
            if(nbCartes == 0) {
                cartes[0]->hide();
                cartes[0]->close();
            }
            if(nbCartes>0)
                cartes[nbCartes-1]->setVisibilite(true);
            event->setDropAction(Qt::MoveAction);
            event->accept();

            Carte * sschildren[count];
            for(int i=0; i<count; i++) {
                sschildren[i] = new Carte();
            }
            this->addCarte(valeure, famille, true);
            sschildren[0]->setValeure(valeure);
            sschildren[0]->setFamille(famille);
            for(int i=1; i<count; i++) {
                int valeure;
                QString famille;
                dataStream >> valeure >> famille;
                this->addCarte(valeure, famille, true);
                sschildren[i]->setValeure(valeure);
                sschildren[i]->setFamille(famille);
            }

            Jeux *j = static_cast<Jeux*>(this->parentWidget());

            sschildren[0]->setX(frameprovenance->getCarteId(frameprovenance->getNbCartes()-1)->getX());
            sschildren[0]->setY(frameprovenance->getCarteId(frameprovenance->getNbCartes()-1)->getY());


            if(frameprovenance->getNbCartes()-count-1>0) {
                    if(!frameprovenance->getCarteId(frameprovenance->getNbCartes()-count-1)->getVisibilite()) {
                        j->addAnnuler(frameprovenance, sschildren, count, this, 1);
                    }
                    else {
                        j->addAnnuler(frameprovenance, sschildren, count, this, 0);
                    }
                }
            else if(frameprovenance->getNbCartes()-count>0) {
                j->addAnnuler(frameprovenance, sschildren, count, this, 1);
            }
            else
                j->addAnnuler(frameprovenance, sschildren, count, this, 2);

            cartes[nbCartes-1]->setAttribute(Qt::WA_DeleteOnClose);
            cartes[nbCartes-1]->show();

            frameprovenance->delCarte(count);
        }
        c->close();
    }
    else
        event->ignore();
}

void MaFrame::mousePressEvent(QMouseEvent * event) {
    if (event->button() == buttonDeplacement)
        startPos = event->pos();
    else if(event->button() == buttonClick) {
        Carte * ca = static_cast<Carte*>(childAt(event->pos()));
        if(!ca)
            return;
        else
            selectionerCarte(event);
    }
}

void MaFrame::selectionerCarte(QMouseEvent * event) {
    Jeux *jeux = static_cast<Jeux*>(this->parentWidget());
    Carte *carte = static_cast<Carte*>(this->childAt(event->pos()));
    if(jeux && carte && carte->getVisibilite()) {
        if(!jeux->getIfCarteSelectionee()) {//Si aucune carte n'est sélectionnée
            int index = this->children().indexOf(carte);

            int dif = this->children().count() - index;
            Carte * sschildren[dif];
            for (int i=0; i<dif; i++) {
                Carte * sschild = static_cast<Carte*>(this->children().at(index));
                sschildren[i] = sschild;
                sschildren[i]->setAccessible();
                index++;
            }
            jeux->selectionerCarte(sschildren, dif, this);
        }
        else {//Sinon on compare la carte sélectionnée avec la frame
            if(conditionsAjoutCarte(jeux->getCarteSelectionee()[0])) {//si c'est bon on l'ajoute
                jeux->setIfCarteSelectionee(false);
                if(nbCartes == 0) {
                    cartes[0]->hide();
                    cartes[0]->close();
                }
                Carte * sschildren[jeux->getCarteSelectioneeCount()];
                for(int i=0; i<jeux->getCarteSelectioneeCount(); i++) {
                    sschildren[i] = new Carte();
                }

                for(int i=0; i<jeux->getCarteSelectioneeCount(); i++) {
                    this->addCarte(jeux->getCarteSelectionee()[i]->getValeure(), jeux->getCarteSelectionee()[i]->getFamille(), true);
                    jeux->getCarteSelectionee()[i]->hide();
                    jeux->getCarteSelectionee()[i]->close();
                    sschildren[i]->setValeure(jeux->getCarteSelectionee()[i]->getValeure());
                    sschildren[i]->setFamille(jeux->getCarteSelectionee()[i]->getFamille());
                }
                Jeux *j = static_cast<Jeux*>(this->parentWidget());
                if(jeux->getFrameCarteSelectionee()->getNbCartes()-jeux->getCarteSelectioneeCount()>0)
                    j->addAnnuler(jeux->getFrameCarteSelectionee(), sschildren, jeux->getCarteSelectioneeCount(), this, 1);
                else
                    j->addAnnuler(jeux->getFrameCarteSelectionee(), sschildren, jeux->getCarteSelectioneeCount(), this, 2);
                jeux->getFrameCarteSelectionee()->delCarte(jeux->getCarteSelectioneeCount());
            }

            else {//sinon on remet tout a vide
                jeux->setIfCarteSelectionee(false);
                for(int i=0; i<jeux->getFrameCarteSelectionee()->getNbCartes(); i++) {
                    if(jeux->getFrameCarteSelectionee()->getCarteId(i)->getVisibilite())
                        jeux->getFrameCarteSelectionee()->getCarteId(i)->setVisibilite(true);
                }
            }
        }
    }
    else {//si on click ailleur on remet tout à vide
        if(jeux->getIfCarteSelectionee()) {
            jeux->setIfCarteSelectionee(false);
            for(int i=0; i<jeux->getFrameCarteSelectionee()->getNbCartes(); i++) {
                if(jeux->getFrameCarteSelectionee()->getCarteId(i)->getVisibilite())
                        jeux->getFrameCarteSelectionee()->getCarteId(i)->setVisibilite(true);
            }
        }
    }
}

void MaFrame::mouseDoubleClickEvent(QMouseEvent * event) {
    if (event->buttons() == Qt::LeftButton) {
        Carte *child = static_cast<Carte*>(childAt(event->pos()));
        if (!child || this->getNbCartes()==0 || !child->getVisibilite())
            return;
        if(nbCartes>0)
            if(child->getValeure() != cartes[nbCartes-1]->getValeure() || child->getFamille() != cartes[nbCartes-1]->getFamille())
                return;

        bool ajoute = false;
        int i=1;
        while(i<=4 && !ajoute) {
            MaFrame * frame = static_cast<MaFrame*>(this->parentWidget()->children().at(i));
            if(frame->conditionsAjoutCarte(child)) {
                ajoute = true;
                if(frame->getNbCartes() == 0) {
                    frame->getCarteId(0)->hide();
                    frame->getCarteId(0)->close();
                }
                Carte * sschildren[1];
                sschildren[0] = new Carte();
                sschildren[0]->setValeure(child->getValeure());
                sschildren[0]->setFamille(child->getFamille());
                sschildren[0]->setX(child->getX());
                sschildren[0]->setY(child->getY());

                Jeux *j = static_cast<Jeux*>(this->parentWidget());

                if(nbCartes-2>0) {
                    if(!cartes[nbCartes-2]->getVisibilite()) {
                        j->addAnnuler(this, sschildren, 1, frame, 1);
                    }
                }
                else if(nbCartes<=0)
                    j->addAnnuler(this, sschildren, 1, frame, 2);

                frame->addCarte(child->getValeure(), child->getFamille(), true);
                child->hide();
                child->close();
                delCarte(1);
            }
            i++;
        }
    }
}

void MaFrame::mouseMoveEvent(QMouseEvent * event) {
    if (event->buttons() == buttonDeplacement) {
        int distance = (event->pos() - startPos).manhattanLength();
        if(distance >= 10)
            startDrag(event);
    }
}

void MaFrame::startDrag(QMouseEvent * event) {
    Carte *child = static_cast<Carte*>(childAt(event->pos()));
    if (!child || this->getNbCartes()==0 || !child->getVisibilite())
        return;

    int index = this->children().indexOf(child);

    int dif = this->children().count() - index;
    Carte * sschildren[dif];
    for (int i=0; i<dif; i++) {
        Carte * sschild = static_cast<Carte*>(this->children().at(index));
        sschildren[i] = sschild;
        index++;
    }
    monDragStart(sschildren, event);
}

void MaFrame::monDragStart(Carte ** child, QMouseEvent * event) {
    int count = this->children().count() - this->children().indexOf(child[0]);
    QPixmap pixmapNonModif = *child[0]->pixmap();
    QPixmap pixmap(child[0]->pixmap()->width()+((count-1)*7), child[0]->pixmap()->height()+((count-1)*20));
    pixmap.fill(QColor(0,0,0,0));
    QPainter painter(&pixmap);
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.drawPixmap(0, 0, *child[0]->pixmap());

    for (int i=1; i<count; i++) {
        painter.drawPixmap(i*7, i*20, *child[i]->pixmap());
    }
    painter.end();

    for (int i=0; i<count; i++) {
        child[i]->hide();
    }

    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);

    dataStream << count;
    for (int i=0; i<count; i++) {
        dataStream << child[i]->getValeure() << child[i]->getFamille();
    }

    QMimeData * mimeData = new QMimeData;
    mimeData->setData("application/Carte-Pixmap", itemData);

    QDrag *drag = new QDrag(this);
    drag->setMimeData(mimeData);
    drag->setPixmap(pixmap);
    drag->setHotSpot(event->pos() - child[0]->pos());

    if (drag->exec(Qt::CopyAction | Qt::MoveAction, Qt::CopyAction) == Qt::MoveAction) {
        for (int i=0; i<count; i++) {
            child[i]->close();
        }
    }
    else {
        child[0]->show();
        for (int i=0; i<count; i++) {
            child[i]->show();
        }
    }
}

void MaFrame::resizeEvent(QResizeEvent * event) {
    if(nbCartes==0 && this->children().count()>0) {
        cartes[0]->setX(((this->rect().width()-cartes[0]->rect().width())/2));
        cartes[0]->setY((1)*decalageY);
    }

    else {
        for(int i=0; i<nbCartes; i++) {
            cartes[i]->setX(((this->rect().width()-cartes[i]->rect().width())/2)+(i*decalageX));
            cartes[i]->setY((i+1)*decalageY);
        }
    }
}

bool MaFrame::conditionsAjoutCarte(Carte * c) {
    bool vide = true;
    if(nbCartes>0)
        vide = false;

    bool ajoute = false;
    if (vide) {
        if(c->getValeure() == 13) {
            ajoute = true;
        }
    }
    else {
        if (cartes[nbCartes-1]->getValeure() == (c->getValeure()+1)) {
            if (cartes[nbCartes-1]->getCouleure() == "rouge") {
                if (c->getFamille()=="trefle" || c->getFamille()=="pique")
                    ajoute = true;
            }
            else if (c->getFamille()=="coeur" || c->getFamille()=="carreau")
                ajoute = true;
        }
    }
    return ajoute;
}

bool MaFrame::conditionsAjoutCarte(int valeure, QString famille) {
    bool vide = true;
    if(nbCartes>0)
        vide = false;

    bool ajoute = false;
    if (vide) {
        if(valeure == 13) {
            ajoute = true;
        }
    }
    else {
        if (cartes[nbCartes-1]->getValeure() == (valeure+1)) {
            if (cartes[nbCartes-1]->getCouleure() == "rouge") {
                if (famille=="trefle" || famille=="pique")
                    ajoute = true;
            }
            else if (famille=="coeur" || famille=="carreau")
                ajoute = true;
        }
    }
    return ajoute;
}

