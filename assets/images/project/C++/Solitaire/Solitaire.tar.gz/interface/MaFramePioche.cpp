/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe réimplentant MaFrame avec les différences d'une frame pioche : conditionAjoute(), pressEvent...
  *******************************************************/

#include "MaFramePioche.h"

#include "Jeux.h"

MaFramePioche::MaFramePioche(QWidget *parent) : MaFrame(parent) {
    setAcceptDrops(false);
    alendroit = QRect((this->width()/3) + 50, (this->height()/2)-20, this->width()-((this->width()*50)/100), this->height()/2);
    alenvers = QRect(0, 0, this->width()/3, this->height()/2);
    nbCartesVisibles = 0;//initialiser dans addCarteVisible()
    nbCarteRetournee = 2;
    nbCarteRetourneeTemps = 0;
    espaceCarteRetournee = 20;
    setAttribute(Qt::WA_DeleteOnClose);
}

void MaFramePioche::addCarte(int valeure, QString famille, bool jouee) {
    cartes[nbCartes] = new Carte(valeure, famille, this);

    cartes[nbCartes]->setX(xCarteNonJouable);
    cartes[nbCartes]->setY(yCarteNonJouable);

    cartes[nbCartes]->setVisibilite(false);

    if(valeure != 0 && famille != "vide") {
        nbCartes = nbCartes + 1;
    }
}

void MaFramePioche::addCarteVisible(int valeure, QString famille) {
    cartesVisibles[nbCartesVisibles] = new Carte(valeure, famille, this);
    cartesVisibles[nbCartesVisibles]->setX(xCarteJouable);
    cartesVisibles[nbCartesVisibles]->setY(yCarteJouable);
    cartesVisibles[nbCartesVisibles]->setVisibilite(true);
    nbCartesVisibles = nbCartesVisibles + 1;
}

int MaFramePioche::getDecalageCarteX() {
    return espaceCarteRetournee;
}
void MaFramePioche::setDecalageCarteX(int i) {
    espaceCarteRetournee = i;
    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));
}

void MaFramePioche::delCarte(int nb) {
    cartesVisibles[nbCartesVisibles-1]->hide();
    cartesVisibles[nbCartesVisibles-1]->close();
    nbCartesVisibles = nbCartesVisibles - 1;

    if(nbCarteRetournee>1) {
        int i=nbCartesVisibles;
        bool trouvee = false;
        while(!trouvee && i>=0) {
            if(cartesVisibles[i]->isVisible())
                trouvee=true;
            else
                i--;
        }

        if(nbCartesVisibles<=0)
            trouvee = true;

        if(!trouvee) {
            int i=0;
            int mac = nbCartesVisibles-1;
            while (i<nbCarteRetournee) {
                    cartesVisibles[mac]->show();
                if (cartesVisibles[mac]->pos().x() == xCarteJouable) {
                    i = nbCarteRetournee;
                }
                mac--;
                i++;
            }
        }
    }

    Jeux * mmw = static_cast<Jeux*>(this->parentWidget());
    mmw->mettreAJourStatistiques();
}

int MaFramePioche::getNbCartes() {
    return nbCartesVisibles;
}

int MaFramePioche::getNbCartesTotal() {
    return nbCartes + nbCartesVisibles;
}

Carte* MaFramePioche::getCarteId(int i) {
    return cartesVisibles[i];
}

int MaFramePioche::getNbCarteRetournee() {
    return nbCarteRetournee;
}

void MaFramePioche::melangePioche() {
    srand(time(NULL));
    random_shuffle(&cartes[0], &cartes[nbCartes]);
}

void MaFramePioche::mousePressEvent(QMouseEvent *event) {
    if (event->button() == buttonDeplacement)
        startPos = event->pos();
    bool retournePioche = false;
    if (event->button() == Qt::LeftButton) {
        Carte *child = static_cast<Carte*>(childAt(event->pos()));
        if(!child)//enlève la possibilité de clické ailleur
            return;
        else if(child->getValeure() == 0 && child->getFamille().compare("vide") && nbCartesVisibles>0) {//remet toutes les cartes à l'envers
            vide->close();
            for(int i=nbCartesVisibles-1; i>=0; i--) {
                addCarte(cartesVisibles[i]->getValeure(), cartesVisibles[i]->getFamille(), false);
                cartesVisibles[i]->hide();
                cartesVisibles[i]->close();
            }
            nbCartesVisibles = 0;
            retournePioche = true;
        }
        else if(!child->getVisibilite()) {//si on click sur une carte de la pioche on la retourne à coté
            if(nbCartes-nbCarteRetournee <= 0) {//si c'est la dernière on ajoute une carte vide
                vide = new Carte(0, "videPioche", this);
                vide->setX(xCarteNonJouable);
                vide->setY(yCarteNonJouable);
            }

            nbCarteRetourneeTemps = nbCarteRetournee;
            if(nbCartes < nbCarteRetournee)
                nbCarteRetourneeTemps = nbCartes;

            if(nbCarteRetournee>1)
                for(int i=0; i<nbCartesVisibles; i++)
                    cartesVisibles[i]->hide();
            int i = 0;
            while(i<nbCarteRetournee && i<nbCarteRetourneeTemps) {
                addCarteVisible(cartes[nbCartes-1]->getValeure(), cartes[nbCartes-1]->getFamille());
                if(nbCarteRetournee>1) {
                    cartesVisibles[nbCartesVisibles-1]->move(cartesVisibles[nbCartesVisibles-1]->getX()+i*espaceCarteRetournee, cartesVisibles[nbCartesVisibles-1]->getY());
                    cartesVisibles[nbCartesVisibles-1]->setX(cartesVisibles[nbCartesVisibles-1]->getX()+i*espaceCarteRetournee);
                            cartesVisibles[nbCartesVisibles-1]->setY(cartesVisibles[nbCartesVisibles-1]->getY());
                }
                cartes[nbCartes-1]->hide();
                cartes[nbCartes-1]->close();
                nbCartes = nbCartes - 1;
                i++;
            }
        }
    }
    if(event->button() == buttonClick && !retournePioche) {
        Carte * ca = static_cast<Carte*>(childAt(event->pos()));
        if(!ca || ca->getValeure() != cartesVisibles[nbCartesVisibles-1]->getValeure() || ca->getFamille() != cartesVisibles[nbCartesVisibles-1]->getFamille())
            return;
        else
            selectionerCarte(event);
    }
}

void MaFramePioche::selectionerCarte(QMouseEvent * event) {
    Jeux *jeux = static_cast<Jeux*>(this->parentWidget());
    Carte *carte = static_cast<Carte*>(this->childAt(event->pos()));
    if(jeux && carte && carte->getVisibilite()) {
        if(!jeux->getIfCarteSelectionee()) {//Si aucune carte n'est sélectionnée
            Carte * sschildren[1];
            carte->setAccessible();
            sschildren[0] = carte;
            jeux->selectionerCarte(sschildren, 1, this);
        }
        else {//Sinon on compare la carte sélectionnée avec la frame
            if(conditionsAjoutCarte(jeux->getCarteSelectionee()[0])) {//si c'est bon on l'ajoute
                jeux->setIfCarteSelectionee(false);
                if(nbCartes == 0) {
                    cartes[0]->hide();
                    cartes[0]->close();
                }
                for(int i=0; i<jeux->getCarteSelectioneeCount(); i++) {
                    this->addCarte(jeux->getCarteSelectionee()[i]->getValeure(), jeux->getCarteSelectionee()[i]->getFamille(), true);
                    jeux->getCarteSelectionee()[i]->hide();
                    jeux->getCarteSelectionee()[i]->close();
                }
                jeux->getFrameCarteSelectionee()->delCarte(jeux->getCarteSelectioneeCount());
            }
            else {//sinon on remet tout a vide
                jeux->setIfCarteSelectionee(false);
                for(int i=0; i<jeux->getFrameCarteSelectionee()->getNbCartes(); i++) {
                    if(jeux->getFrameCarteSelectionee()->getCarteId(i)->getVisibilite())
                        jeux->getFrameCarteSelectionee()->getCarteId(i)->setVisibilite(true);
                }
            }
        }
    }
    else {//si on click ailleur on remet tout à vide
        if(jeux->getIfCarteSelectionee()) {
            jeux->setIfCarteSelectionee(false);
            for(int i=0; i<jeux->getFrameCarteSelectionee()->getNbCartes(); i++) {
                if(jeux->getFrameCarteSelectionee()->getCarteId(i)->getVisibilite())
                        jeux->getFrameCarteSelectionee()->getCarteId(i)->setVisibilite(true);
            }
        }
    }
}

void MaFramePioche::mouseDoubleClickEvent(QMouseEvent * event) {
    if (event->buttons() == Qt::LeftButton) {
        Carte *child = static_cast<Carte*>(childAt(event->pos()));
        if (!child || nbCartesVisibles==0 || !child->getVisibilite())
            return;

        bool ajoute = false;
        int i=1;
        while(i<=4 && !ajoute) {
            MaFrame * frame = static_cast<MaFrame*>(this->parentWidget()->children().at(i));
            if(frame->conditionsAjoutCarte(child)) {
                ajoute = true;
                if(frame->getNbCartes() == 0) {
                    frame->getCarteId(0)->hide();
                    frame->getCarteId(0)->close();
                }
                Carte * sschildren[1];
                sschildren[0] = new Carte();
                sschildren[0]->setValeure(child->getValeure());
                sschildren[0]->setFamille(child->getFamille());
                sschildren[0]->setX(child->getX());
                sschildren[0]->setY(child->getY());

                Jeux *j = static_cast<Jeux*>(this->parentWidget());

                if(frame->getNbCartes()-1>0)
                    j->addAnnuler(this, sschildren, 1, frame, 1);
                else
                    j->addAnnuler(this, sschildren, 1, frame, 2);

                frame->addCarte(child->getValeure(), child->getFamille(), true);
                child->hide();
                child->close();
                delCarte(1);
            }
            i++;
        }
    }
}

void MaFramePioche::mouseMoveEvent(QMouseEvent *event) {
    if (event->buttons() & buttonDeplacement) {
        int distance = (event->pos() - startPos).manhattanLength();
        if(distance >= 10)
            startDrag(event);
    }
}

void MaFramePioche::startDrag(QMouseEvent *event) {
    Carte *child = static_cast<Carte*>(childAt(event->pos()));
    if (!child ||
        !child->getVisibilite() ||
        child->getValeure()==0 ||
        child->getValeure()!=cartesVisibles[nbCartesVisibles-1]->getValeure() ||
        child->getFamille()!=cartesVisibles[nbCartesVisibles-1]->getFamille())
        return;
    Carte * sschildren[1];
    sschildren[0] = child;
    monDragStart(sschildren, event);
}

void MaFramePioche::monDragStart(Carte ** child, QMouseEvent *event) {
    int count = 1;
    QPixmap pixmapNonModif = *child[0]->pixmap();
    QPixmap pixmap(child[0]->pixmap()->width()+((count-1)*7), child[0]->pixmap()->height()+((count-1)*20));
    pixmap.fill(QColor(0,0,0,0));
    QPainter painter(&pixmap);
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.drawPixmap(0, 0, *child[0]->pixmap());

    for (int i=1; i<count; i++) {
        painter.drawPixmap(i*7, i*20, *child[i]->pixmap());
    }
    painter.end();

    for (int i=0; i<count; i++) {
        child[i]->hide();
    }

    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);

    dataStream << count;
    for (int i=0; i<count; i++) {
        dataStream << child[i]->getValeure() << child[i]->getFamille();
    }

    QMimeData * mimeData = new QMimeData;
    mimeData->setData("application/Carte-Pixmap", itemData);

    QDrag *drag = new QDrag(this);
    drag->setMimeData(mimeData);
    drag->setPixmap(pixmap);
    drag->setHotSpot(event->pos() - child[0]->pos());

    if (drag->exec(Qt::CopyAction | Qt::MoveAction, Qt::CopyAction) == Qt::MoveAction) {
        for (int i=0; i<count; i++) {
            child[i]->close();
        }
    }
    else {
        child[0]->show();
        for (int i=0; i<count; i++) {
            child[i]->show();
        }
    }
}

void MaFramePioche::resizeEvent(QResizeEvent * event) {
    alendroit = QRect((this->width()/3) + 50, (this->height()/2)-50, this->width()-((this->width()*60)/100), this->height()/2);
    alenvers = QRect(0, 0, this->width()/3, this->height()/2);
    int ancienXCarteJouable = xCarteJouable;

    if(nbCartes>0) {
        xCarteJouable = (alendroit.x() + ((alendroit.width() - cartes[0]->width())/2));
        yCarteJouable = (alendroit.y() + ((alendroit.height() - cartes[0]->height())/2));
        xCarteNonJouable = (alenvers.x() + ((alenvers.width() - cartes[0]->width())/2));
        yCarteNonJouable = (alenvers.y() + ((alenvers.height() - cartes[0]->height())/2));
    }
    else if(nbCartesVisibles>0) {
        xCarteJouable = (alendroit.x() + ((alendroit.width() - cartesVisibles[0]->width())/2));
        yCarteJouable = (alendroit.y() + ((alendroit.height() - cartesVisibles[0]->height())/2));
        xCarteNonJouable = (alenvers.x() + ((alenvers.width() - cartesVisibles[0]->width())/2));
        yCarteNonJouable = (alenvers.y() + ((alenvers.height() - cartesVisibles[0]->height())/2));
    }
    if(nbCarteRetournee>1)
        xCarteJouable = xCarteJouable-(((nbCarteRetournee-1)*espaceCarteRetournee)/2);

    if(nbCartes==0 && nbCartesVisibles==0) {//s'il n'y a plus de carte à jouer
            cartes[0]->setX(xCarteNonJouable);
            cartes[0]->setY(yCarteNonJouable);
    }
    else {
        if(nbCartes>=0)
            for(int i=0; i<nbCartes; i++) {
                cartes[i]->setX(xCarteNonJouable);
                cartes[i]->setY(yCarteNonJouable);
            }
        if(nbCartesVisibles>0)
            for(int i=0; i<nbCartesVisibles; i++) {
                if(nbCarteRetournee>1) {
                    if(cartesVisibles[i]->pos().x() == ancienXCarteJouable)
                        cartesVisibles[i]->setX(xCarteJouable);
                    else if(cartesVisibles[i]->pos().x() == ancienXCarteJouable+espaceCarteRetournee)
                        cartesVisibles[i]->setX(xCarteJouable + espaceCarteRetournee);
                    else if(cartesVisibles[i]->pos().x() == ancienXCarteJouable+espaceCarteRetournee*2)
                        cartesVisibles[i]->setX(xCarteJouable + espaceCarteRetournee*2);
                    else if(cartesVisibles[i]->pos().x() == ancienXCarteJouable+espaceCarteRetournee*3)
                        cartesVisibles[i]->setX(xCarteJouable + espaceCarteRetournee*3);
                    else if(cartesVisibles[i]->pos().x() == ancienXCarteJouable+espaceCarteRetournee*4)
                        cartesVisibles[i]->setX(xCarteJouable + espaceCarteRetournee*4);
                    else
                        cartesVisibles[i]->setX(xCarteJouable + espaceCarteRetournee*5);
                }
                else
                    cartesVisibles[i]->setX(xCarteJouable);
                cartesVisibles[i]->setY(yCarteJouable);
            }
    }
}

void MaFramePioche::paintEvent(QPaintEvent *event) {
    QPainter painter(this);

    painter.setPen(QColor(0, 0, 0, 255));
    painter.setBrush(QBrush(QColor(0, 0, 0, 120)));

    painter.drawRect(alenvers);
    painter.drawRect(alendroit);
}
