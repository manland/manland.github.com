/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Lance l'application
  *******************************************************/

#include <QApplication>

#include "MonMainWindow.h"
#include "Options.h"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    new MonMainWindow();

    return app.exec();
}

