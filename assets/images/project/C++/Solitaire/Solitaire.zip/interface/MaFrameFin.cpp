/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe réimplentant MaFrame avec les différences d'une frame fin : conditionAjoute(), pressEvent...
  *******************************************************/

#include "MaFrameFin.h"

#include "Jeux.h"

MaFrameFin::MaFrameFin(QWidget *parent) : MaFrame(parent) {
    setAttribute(Qt::WA_DeleteOnClose);
    fini = false;
    decalageX = 4;
    decalageY = 15;
    setMinimumSize(100, 13*decalageY);
}

void MaFrameFin::addCarte(int valeure, QString famille, bool jouee) {
    cartes[nbCartes] = new Carte(valeure, famille, this);

    if(!jouee)
        if(nbCartes-1>=0) {
            if(cartes[nbCartes-1]->getVisibilite())
                cartes[nbCartes-1]->setVisibilite(false);
        }

    if(valeure != 0 && famille != "vide")
        nbCartes = nbCartes + 1;

    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));

    if(nbCartes==13 && !fini) {
        Jeux * j = static_cast<Jeux*>(this->parentWidget());
        j->plein();
        fini = true;
    }
}

int MaFrameFin::getDecalageCarteX() {
    return decalageX;
}
int MaFrameFin::getDecalageCarteY() {
    return decalageY;
}
void MaFrameFin::setDecalageCarteX(int i) {
    decalageX = i;
    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));
}
void MaFrameFin::setDecalageCarteY(int i) {
    decalageY = i;
    resizeEvent(new QResizeEvent(QSize(this->width(), this->height()), QSize(this->width(), this->height())));
}

void MaFrameFin::dragEnterEvent(QDragEnterEvent *event) {
    if (event->mimeData()->hasFormat("application/Carte-Pixmap")) {
        if (event->source() == this) {
            event->accept();
        }
        else {
            QByteArray itemData = event->mimeData()->data("application/Carte-Pixmap");
            QDataStream dataStream(&itemData, QIODevice::ReadOnly);

            int count;
            int valeure;
            QString famille;
            dataStream >> count >> valeure >> famille;

            bool vide = true;
            if(nbCartes>0)
                vide = false;

            bool ajoute = false;
            if (event->source() != this && vide) {
                if(valeure == 1) {
                    ajoute = true;
                }
            }

            else if (event->source() != this && !vide && count==1) {
                if ((cartes[nbCartes-1]->getValeure() == (valeure-1) && cartes[nbCartes-1]->getFamille() == famille))
                    ajoute = true;
            }

            if(ajoute) {
                if(nbCartes==0)
                    cartes[0]->setAccessible();
                else
                    cartes[nbCartes-1]->setAccessible();
                estAccessible = true;
            }
            event->acceptProposedAction();
        }
    }
    else
        event->ignore();
}

void MaFrameFin::dragLeaveEvent (QDragLeaveEvent * event) {
    if(estAccessible) {
        if(nbCartes==0) {
            cartes[nbCartes]->hide();
            cartes[nbCartes]->close();
            addCarte(0, "vide", false);
        }
        else
            cartes[nbCartes-1]->setVisibilite(true);
    }
}

void MaFrameFin::mousePressEvent(QMouseEvent * event) {
    if (event->button() == buttonDeplacement)
        startPos = event->pos();
    else if(event->button() == buttonClick) {
        Jeux *jeux = static_cast<Jeux*>(this->parentWidget());
        Carte * ca = static_cast<Carte*>(childAt(event->pos()));
        if(!ca)
            return;
        else {
            if(nbCartes>0 && !jeux->getIfCarteSelectionee()) {
                if(ca->getValeure() == cartes[nbCartes-1]->getValeure()) {
                    selectionerCarte(event);
                }
            }
            else if(jeux->getIfCarteSelectionee()) {
                selectionerCarte(event);
            }
        }
    }
}

void MaFrameFin::startDrag(QMouseEvent *event) {
    Carte *child = static_cast<Carte*>(childAt(event->pos()));
    if (!child || this->getNbCartes()==0 || !child->getVisibilite())
        return;

    if(child->getValeure() == cartes[nbCartes-1]->getValeure() && child->getFamille() == cartes[nbCartes-1]->getFamille()) {
        Carte * sschildren[1];
        sschildren[0] = child;
        monDragStart(sschildren, event);
    }
}

void MaFrameFin::monDragStart(Carte ** child, QMouseEvent *event) {
    int count = this->children().count() - this->children().indexOf(child[0]);
    QPixmap pixmapNonModif = *child[0]->pixmap();
    QPixmap pixmap(child[0]->pixmap()->width()+((count-1)*7), child[0]->pixmap()->height()+((count-1)*20));
    pixmap.fill(QColor(0,0,0,0));
    QPainter painter(&pixmap);
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.drawPixmap(0, 0, *child[0]->pixmap());

    for (int i=1; i<count; i++) {
        painter.drawPixmap(i*7, i*20, *child[i]->pixmap());
    }
    painter.end();

    for (int i=0; i<count; i++) {
        child[i]->hide();
    }

    QByteArray itemData;
    QDataStream dataStream(&itemData, QIODevice::WriteOnly);

    dataStream << count;
    for (int i=0; i<count; i++) {
        dataStream << child[i]->getValeure() << child[i]->getFamille();
    }

    QMimeData * mimeData = new QMimeData;
    mimeData->setData("application/Carte-Pixmap", itemData);

    QDrag *drag = new QDrag(this);
    drag->setMimeData(mimeData);
    drag->setPixmap(pixmap);
    drag->setHotSpot(event->pos() - child[0]->pos());

    if (drag->exec(Qt::CopyAction | Qt::MoveAction, Qt::CopyAction) == Qt::MoveAction) {
        for (int i=0; i<count; i++) {
            child[i]->close();
        }
    }
    else {
        child[0]->show();
        for (int i=0; i<count; i++) {
            child[i]->show();
        }
    }
}

void MaFrameFin::dropEvent(QDropEvent *event) {
    if (event->mimeData()->hasFormat("application/Carte-Pixmap")) {
        QByteArray itemData = event->mimeData()->data("application/Carte-Pixmap");
        QDataStream dataStream(&itemData, QIODevice::ReadOnly);

        int count;
        int valeure;
        QString famille;
        dataStream >> count >> valeure >> famille;

        Carte * c = new Carte();
        c->setValeure(valeure);
        c->setFamille(famille);
        c->setParent(this);

        if (conditionsAjoutCarte(c)) {
            if(nbCartes == 0) {
                cartes[0]->hide();
                cartes[0]->close();
            }
            if(nbCartes>0)
                cartes[nbCartes-1]->setVisibilite(true);
            event->setDropAction(Qt::MoveAction);
            event->accept();

            Carte * sschildren[count];
            for(int i=0; i<count; i++) {
                sschildren[i] = new Carte();
            }
            this->addCarte(valeure, famille, true);
            sschildren[0]->setValeure(valeure);
            sschildren[0]->setFamille(famille);
            for(int i=1; i<count; i++) {
                int valeure;
                QString famille;
                dataStream >> valeure >> famille;
                this->addCarte(valeure, famille, true);
                sschildren[i]->setValeure(valeure);
                sschildren[i]->setFamille(famille);
            }
            MaFrame *frameprovenance = static_cast<MaFrame*>(event->source());
            Jeux *j = static_cast<Jeux*>(this->parentWidget());

            if(frameprovenance->getNbCartes()-count>0)
                j->addAnnuler(frameprovenance, sschildren, count, this, 1);
            else
                j->addAnnuler(frameprovenance, sschildren, count, this, 2);

            cartes[nbCartes-1]->setAttribute(Qt::WA_DeleteOnClose);
            cartes[nbCartes-1]->show();

            frameprovenance->delCarte(count);
        }
        c->close();
    }
    else
        event->ignore();
}

bool MaFrameFin::conditionsAjoutCarte(Carte * c) {
    bool vide = true;
    if(nbCartes>0)
        vide = false;

    bool ajoute = false;
    if (vide) {
        if(c->getValeure() == 1) {
            ajoute = true;
        }
    }
    else {
        if ((cartes[nbCartes-1]->getValeure() == (c->getValeure()-1) && cartes[nbCartes-1]->getFamille() == c->getFamille()))
            ajoute = true;
    }
    return ajoute;
}

bool MaFrameFin::conditionsAjoutCarte(int valeure, QString famille) {
    bool vide = true;
    if(nbCartes>0)
        vide = false;

    bool ajoute = false;
    if (vide) {
        if(valeure == 1) {
            ajoute = true;
        }
    }
    else {
        if ((cartes[nbCartes-1]->getValeure() == (valeure-1) && cartes[nbCartes-1]->getFamille() == famille))
            ajoute = true;
    }
    return ajoute;
}

void MaFrameFin::resizeEvent(QResizeEvent * event) {
    if(nbCartes==0 && this->children().count()>0) {
        cartes[0]->setX(((this->rect().width()-cartes[0]->rect().width())/2));
        cartes[0]->setY((1)*decalageY);
    }

    else {
        for(int i=0; i<nbCartes; i++) {
            cartes[i]->setX(((this->rect().width()-cartes[i]->rect().width())/2)+(i*decalageX));
            cartes[i]->setY((i+1)*decalageY);
        }
    }
}
