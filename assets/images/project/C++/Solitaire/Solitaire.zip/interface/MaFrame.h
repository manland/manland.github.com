/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant mère de toutes les frames contenant les fonctions les plus utiles
  *******************************************************/

#ifndef MaFrame_H
#define MaFrame_H

#include <QDragEnterEvent>
#include <QDropEvent>
#include <QFrame>
#include <QStack>

#include "Carte.h"
class Jeux;

class MaFrame : public QFrame {

    public:
        MaFrame(QWidget *parent=0);
        virtual void addCarte(int, QString, bool jouee=false);
        virtual void addCarte(Carte*, bool jouee=false);
        virtual void delCarte(int);
        virtual int getNbCartes();
        virtual int getIdCarte(int);
        virtual Carte* getCarteId(int);
        virtual int getDecalageCarteX();
        virtual int getDecalageCarteY();
        virtual void setDecalageCarteX(int);
        virtual void setDecalageCarteY(int);
        virtual QString getCarteDos();
        virtual QString getCarteVide();
        virtual void setCartePixmap(QString, bool);
        int getButtonDeplacement();
        int getButtonClick();
        void setButtonDeplacement(int);
        void setButtonClick(int);

        virtual bool conditionsAjoutCarte(Carte *);
        virtual bool conditionsAjoutCarte(int, QString);

    protected:

        virtual void dragEnterEvent(QDragEnterEvent *);
        virtual void dragLeaveEvent (QDragLeaveEvent *);
        virtual void dragMoveEvent(QDragMoveEvent *);
        virtual void dropEvent(QDropEvent *);

        virtual void mousePressEvent(QMouseEvent *);
        virtual void selectionerCarte(QMouseEvent *);
        virtual void mouseDoubleClickEvent(QMouseEvent *);
        virtual void mouseMoveEvent(QMouseEvent *);
        virtual void startDrag(QMouseEvent *);
        virtual void monDragStart(Carte **, QMouseEvent *);
        QPoint startPos;

        virtual void resizeEvent(QResizeEvent *);

        Carte * cartes[50];
        int nbCartes;
        bool estAccessible;//permet de savoir si la carte était jouable pour le dragLeaveEvent

        int buttonDeplacement;
        int buttonClick;

    private:
        Jeux *jeux;//parent
        QString * pixmapCarteDos;
        QString * pixmapCarteVide;


        int decalageX;
        int decalageY;

};
#endif
