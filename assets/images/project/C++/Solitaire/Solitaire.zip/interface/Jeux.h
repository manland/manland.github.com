/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant de gérer tout ce qui est le jeux, l'apparence comme l'interne
        - contient
                - la pioche
                - les frames
                - les frames fin
        - fait le lien entre MonMainWindow et les frames
  *******************************************************/

#ifndef Jeux_h
#define Jeux_h

#include <QBoxLayout>
#include <QPushButton>
#include <QDialog>
#include <QPicture>
#include <QStack>
#include <QObjectList>

#include <time.h>
#include <algorithm>

#include "MaFramePioche.h"
#include "MaFrameBas.h"
#include "MaFrameFin.h"

class MonMainWindow;

#include <iostream>
using namespace std;

class Jeux : public QWidget
{
    public:
        //constructeur
        Jeux(QWidget *parent=0);
        Jeux(Carte**, QWidget *parent=0);
        MonMainWindow * getParent();
        void initialisation();
        void melange();
        void affect();
        void plein();
        Carte* getCarteById(int);
        QPixmap getCarteDos();
        QPixmap getCarteVide();
        int getButtonDeplacement();
        int getButtonClick();
        void setButtonDeplacement(int);
        void setButtonClick(int);
        void setCartePixmap(QString, bool);
        MaFrame* getFrameById(int);

        void mettreAJourStatistiques();

        bool getIfCarteSelectionee();
        void setIfCarteSelectionee(bool);
        Carte** getCarteSelectionee();
        int getCarteSelectioneeCount();
        void selectionerCarte(Carte **, int, MaFrame *);
        MaFrame* getFrameCarteSelectionee();

        void addAnnuler(MaFrame *, Carte**, int, MaFrame*, int);
        bool annulerIsEmpty();
        void annuler();

    protected:


    private:
        MonMainWindow * parent;

        MaFrame * frameCarteSelectionne;
        Carte ** carteSelectionne;
        int carteSelectionneCount;
        bool boolCarteSelectionee;
        int nbCarte;
        int nbFrameFinPleine;
        Carte * jeux[52];

        MaFramePioche * pioche;
        MaFrameFin * fin1;
        MaFrameFin * fin2;
        MaFrameFin * fin3;
        MaFrameFin * fin4;
        MaFrameBas * jeux1;
        MaFrameBas * jeux2;
        MaFrameBas * jeux3;
        MaFrameBas * jeux4;
        MaFrameBas * jeux5;
        MaFrameBas * jeux6;
        MaFrameBas * jeux7;

        QStack<MaFrame*> annulerSource;
        QStack<int> annulerCarteValeure;
        QStack<QString> annulerCarteFamille;
        QStack<QPoint> annulerCartePos;
        QStack<int> annulerCarteCount;
        QStack<MaFrame*> annulerDestination;
        QStack<int> annulerEffetDeBord;
};

#endif
