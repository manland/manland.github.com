/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe réimplentant MaFrame avec les différences d'une frame pioche : conditionAjoute(), pressEvent...
  *******************************************************/

#ifndef MaFramePioche_h
#define MaFramePioche_h

#include "MaFrame.h"

#include <iostream>
using namespace std;

class MaFramePioche : public MaFrame
{
	Q_OBJECT

    public:
	//constructeur
	MaFramePioche(QWidget *parent=0);
        void addCarte(int, QString, bool);
        void addCarteVisible(int , QString);
        int getDecalageCarteX();
        void setDecalageCarteX(int);
        void delCarte(int nb);
        int getNbCartes();
        int getNbCartesTotal();
        int getNbCarteRetournee();
        Carte* getCarteId(int);

    public slots:
        void melangePioche();

    protected:
        void mousePressEvent(QMouseEvent *event);
        void selectionerCarte(QMouseEvent *);
        void mouseDoubleClickEvent(QMouseEvent *);
        void mouseMoveEvent(QMouseEvent *);
        void startDrag(QMouseEvent *);
        void monDragStart(Carte **, QMouseEvent *);

        void resizeEvent(QResizeEvent *);
        void paintEvent(QPaintEvent *);

    private:
        int nbCartesVisibles;
        Carte * cartesVisibles[50];
        int nbCarteRetournee;
        int nbCarteRetourneeTemps;
        int espaceCarteRetournee;

        Carte * vide;

        QRect alenvers;
        QRect alendroit;
        int xCarteJouable;
        int yCarteJouable;
        int xCarteNonJouable;
        int yCarteNonJouable;
};

#endif
