/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe gérant les options graphiquement et en écriture
  *******************************************************/

#include "Options.h"

#include "MonMainWindow.h"

Options::Options(Jeux *j, QWidget *parent) : QWidget(parent) {
    this->setWindowTitle(trUtf8("Options"));

    jeux = j;

    ancienCarteDos = new QPixmap(jeux->getCarteDos());
    QFile * file = new QFile("ancienCarteDos.png");
    ancienCarteDos->save(file, "PNG");
    file->close();
    ancienCarteVide = new QPixmap(jeux->getCarteVide());
    file = new QFile("ancienCarteVide.png");
    ancienCarteDos->save(file, "PNG");
    file->close();
    MonMainWindow * mmw = static_cast<MonMainWindow*>(this->parentWidget());
    ancienMonMainWindow = new QPixmap(mmw->pixmap());

    decalageFrameBasX = jeux->getFrameById(5)->getDecalageCarteX();
    ancienDecalageFrameBasX = jeux->getFrameById(5)->getDecalageCarteX();
    decalageFrameBasY = jeux->getFrameById(5)->getDecalageCarteY();
    ancienDecalageFrameBasY = jeux->getFrameById(5)->getDecalageCarteY();
    decalageFramePioche = jeux->getFrameById(0)->getDecalageCarteX();
    ancienDecalageFramePioche = jeux->getFrameById(0)->getDecalageCarteX();
    decalageFrameFinX = jeux->getFrameById(1)->getDecalageCarteX();
    ancienDecalageFrameFinX = jeux->getFrameById(1)->getDecalageCarteX();
    decalageFrameFinY = jeux->getFrameById(1)->getDecalageCarteY();
    ancienDecalageFrameFinY = jeux->getFrameById(1)->getDecalageCarteY();
    deplacement = jeux->getButtonDeplacement();
    ancienDeplacement = jeux->getButtonDeplacement();

    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);
    layout->addWidget(buildCarteWidget());
    layout->addWidget(buildAffichageWidget());
    layout->addWidget(buildJeuxWidget());

    QBoxLayout * Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    QPushButton * annuler = new QPushButton(QIcon("icons/healive/rouge.png"), trUtf8("Annuler"), this);
    connect(annuler, SIGNAL(clicked()), this, SLOT(annuler()));
    Hlayout->addWidget(annuler);
    QPushButton * defo = new QPushButton(QIcon("icons/healive/jaune.png"), trUtf8("Défault"), this);
    connect(defo, SIGNAL(clicked()), this, SLOT(defo()));
    Hlayout->addWidget(defo);
    QPushButton * accepter = new QPushButton(QIcon("icons/healive/vert.png"), trUtf8("Accepter"), this);
    connect(accepter, SIGNAL(clicked()), this, SLOT(enregistrer()));
    Hlayout->addWidget(accepter);

    layout->addLayout(Hlayout);

    this->setLayout(layout);
    this->setMaximumWidth(200);
    this->setGeometry(j->width()-this->width(), j->y(), this->width(), j->height());

    show();
}

QWidget* Options::buildCarteWidget() {
    QGroupBox * carteWidget = new QGroupBox(trUtf8("Cartes"), this);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    QPushButton * creerCarteDos = new QPushButton(trUtf8("Dos"));
    connect(creerCarteDos, SIGNAL(clicked()), this, SLOT(carteDos()));
    layout->addWidget(creerCarteDos);
    QPushButton * creerCarteVide = new QPushButton(trUtf8("Vide"));
    connect(creerCarteVide, SIGNAL(clicked()), this, SLOT(carteVide()));
    layout->addWidget(creerCarteVide);
    QPushButton * creerFrame = new QPushButton(trUtf8("Frame"));
    connect(creerFrame, SIGNAL(clicked()), this, SLOT(frame()));
    layout->addWidget(creerFrame);

    carteWidget->setLayout(layout);
    return carteWidget;
}

void Options::carteDos() {
    BuildCarte * bg = new BuildCarte("CarteDos.png");
    connect(bg, SIGNAL(destroyed()), this, SLOT(setCarteDos()));
}

void Options::carteVide() {
    BuildCarte * bg = new BuildCarte("CarteVide.png");
    connect(bg, SIGNAL(destroyed()), this, SLOT(setCarteVide()));
}

void Options::frame() {
    BuildCarte * bg = new BuildCarte("");
}

QWidget* Options::buildAffichageWidget() {
    QGroupBox * widget = new QGroupBox(trUtf8("Affichage"), this);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    QSlider * qsDecalageFrameBasX = new QSlider(Qt::Horizontal);
    qsDecalageFrameBasX->setValue(decalageFrameBasX);
    qsDecalageFrameBasX->setMinimum(-40);
    qsDecalageFrameBasX->setMaximum(40);
    connect(qsDecalageFrameBasX,SIGNAL(valueChanged(int)),this,SLOT(changerDecalageXFrameBas(int)));
    layout->addWidget(new QLabel(trUtf8("Décalage x de la frame du bas")));
    layout->addWidget(qsDecalageFrameBasX);

    QSlider * qsDecalageFrameBasY = new QSlider(Qt::Horizontal);
    qsDecalageFrameBasY->setValue(decalageFrameBasX);
    qsDecalageFrameBasY->setMinimum(-40);
    qsDecalageFrameBasY->setMaximum(40);
    connect(qsDecalageFrameBasY,SIGNAL(valueChanged(int)),this,SLOT(changerDecalageYFrameBas(int)));
    layout->addWidget(new QLabel(trUtf8("Décalage y de la frame du bas")));
    layout->addWidget(qsDecalageFrameBasY);

    QSlider * qsDecalageFramePioche = new QSlider(Qt::Horizontal);
    qsDecalageFramePioche->setValue(decalageFramePioche);
    qsDecalageFramePioche->setMinimum(-40);
    qsDecalageFramePioche->setMaximum(40);
    connect(qsDecalageFramePioche,SIGNAL(valueChanged(int)),this,SLOT(changerDecalageFramePioche(int)));
    layout->addWidget(new QLabel(trUtf8("Décalage de la frame pioche")));
    layout->addWidget(qsDecalageFramePioche);

    QSlider * qsDecalageFrameFinX = new QSlider(Qt::Horizontal);
    qsDecalageFrameFinX->setValue(decalageFrameFinX);
    qsDecalageFrameFinX->setMinimum(-40);
    qsDecalageFrameFinX->setMaximum(40);
    connect(qsDecalageFrameFinX,SIGNAL(valueChanged(int)),this,SLOT(changerDecalageFrameFinX(int)));
    layout->addWidget(new QLabel(trUtf8("Décalage x de la frame fin")));
    layout->addWidget(qsDecalageFrameFinX);

    QSlider * qsDecalageFrameFinY = new QSlider(Qt::Horizontal);
    qsDecalageFrameFinY->setValue(decalageFrameFinY);
    qsDecalageFrameFinY->setMinimum(-40);
    qsDecalageFrameFinY->setMaximum(40);
    connect(qsDecalageFrameFinY,SIGNAL(valueChanged(int)),this,SLOT(changerDecalageFrameFinY(int)));
    layout->addWidget(new QLabel(trUtf8("Décalage y de la frame fin")));
    layout->addWidget(qsDecalageFrameFinY);

    widget->setLayout(layout);
    return widget;
}

void Options::changerDecalageXFrameBas(int i) {
    decalageFrameBasX = i;
    for(int h=5; h<12; h++)
        jeux->getFrameById(h)->setDecalageCarteX(i);
}

void Options::changerDecalageYFrameBas(int i) {
    decalageFrameBasY = i;
    for(int h=5; h<12; h++)
        jeux->getFrameById(h)->setDecalageCarteY(i);
}

void Options::changerDecalageFramePioche(int i) {
    decalageFramePioche = i;
    jeux->getFrameById(0)->setDecalageCarteX(i);
}

void Options::changerDecalageFrameFinX(int i) {
    decalageFrameFinX = i;
    for(int h=1; h<5; h++)
        jeux->getFrameById(h)->setDecalageCarteX(i);
}

void Options::changerDecalageFrameFinY(int i) {
    decalageFrameFinY = i;
    for(int h=1; h<5; h++)
        jeux->getFrameById(h)->setDecalageCarteY(i);
}

QWidget* Options::buildJeuxWidget() {
    QGroupBox * carteWidget = new QGroupBox(trUtf8("Jeux"), this);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    qrbClick = new QRadioButton(trUtf8("Déplacer par Click"), this);
    connect(qrbClick, SIGNAL(clicked(bool)), this, SLOT(click(bool)));
    layout->addWidget(qrbClick);
    qrbDrag = new QRadioButton(trUtf8("Déplacer par DragAndDrop"), this);
    connect(qrbDrag, SIGNAL(clicked(bool)), this, SLOT(drag(bool)));
    layout->addWidget(qrbDrag);

    if(deplacement == Qt::RightButton)
        qrbClick->setChecked(true);
    else
        qrbDrag->setChecked(true);

    carteWidget->setLayout(layout);
    return carteWidget;
}

void Options::click(bool b) {
    qrbClick->setChecked(b);
    qrbDrag->setChecked(!b);
    deplacement = Qt::LeftButton;
    jeux->setButtonDeplacement(Qt::RightButton);
    jeux->setButtonClick(deplacement);
}

void Options::drag(bool b) {
    qrbClick->setChecked(!b);
    qrbDrag->setChecked(b);
    deplacement = Qt::RightButton;
    jeux->setButtonDeplacement(Qt::LeftButton);
    jeux->setButtonClick(deplacement);
}

void Options::annuler() {
//    QPixmap * ancienMonMainWindow;
    QFile * file = new QFile("./CarteDos.png");
    ancienCarteDos->save(file, "PNG");
    file->close();
    jeux->setCartePixmap("CarteDos.png", true);
    file = new QFile("./CarteVide.png");
    ancienCarteVide->save(file, "PNG");
    file->close();
    jeux->setCartePixmap("CarteVide.png", false);

    changerDecalageXFrameBas(ancienDecalageFrameBasX);
    changerDecalageYFrameBas(ancienDecalageFrameBasY);
    changerDecalageFramePioche(ancienDecalageFramePioche);
    changerDecalageFrameFinX(ancienDecalageFrameFinX);
    changerDecalageFrameFinY(ancienDecalageFrameFinY);

    jeux->setButtonDeplacement(ancienDeplacement);
    if(ancienDeplacement == Qt::LeftButton)
        jeux->setButtonClick(Qt::RightButton);
    else
        jeux->setButtonClick(Qt::LeftButton);

    this->close();
}

void Options::defo() {
//    QPixmap * ancienMonMainWindow;
    jeux->setCartePixmap("CarteDosDefault.png", true);
    jeux->setCartePixmap("0", false);

    changerDecalageXFrameBas(ancienDecalageFrameBasX);
    changerDecalageYFrameBas(ancienDecalageFrameBasY);
    changerDecalageFramePioche(ancienDecalageFramePioche);
    changerDecalageFrameFinX(ancienDecalageFrameFinX);
    changerDecalageFrameFinY(ancienDecalageFrameFinY);

    jeux->setButtonDeplacement(Qt::LeftButton);
    jeux->setButtonClick(Qt::RightButton);

    enregistrer();
    this->close();
}

void Options::setCarteDos() {
    jeux->setCartePixmap("CarteDos.png", true);
}

void Options::setCarteVide() {
    jeux->setCartePixmap("CarteVide.png", false);
}

void Options::enregistrer() {
    QFile file("config.conf");
    file.open(QIODevice::WriteOnly);
    QByteArray qba;
    qba.append("CarteDos.png\n");
    qba.append("CarteVide.png\n");
    qba.append("01.png\n");
    qba.append(QString().setNum(decalageFrameBasX)+"\n");
    qba.append(QString().setNum(decalageFrameBasY)+"\n");
    qba.append(QString().setNum(decalageFramePioche)+"\n");
    qba.append(QString().setNum(decalageFrameFinX)+"\n");
    qba.append(QString().setNum(decalageFrameFinY)+"\n");
    qba.append(QString().setNum(deplacement)+"\n");
    file.write(qba);
    file.close();
    this->close();
}
