/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe réimplentant MaFrame avec les différences d'une frame fin : conditionAjoute(), pressEvent...
  *******************************************************/

#ifndef MaFrameFin_H
#define MaFrameFin_H

#include "MaFrame.h"

class MaFrameFin : public MaFrame {

    public:
        MaFrameFin(QWidget *parent=0);
        void addCarte(int, QString, bool jouee=false);
        int getDecalageCarteX();
        int getDecalageCarteY();
        void setDecalageCarteX(int);
        void setDecalageCarteY(int);

    protected:
        void dragEnterEvent(QDragEnterEvent *);
        void dragLeaveEvent (QDragLeaveEvent *);
        void mousePressEvent(QMouseEvent *event);
        void startDrag(QMouseEvent *);
        void monDragStart(Carte **, QMouseEvent *);
        void dropEvent(QDropEvent *);
        void resizeEvent(QResizeEvent *);

        bool conditionsAjoutCarte(Carte *);
        bool conditionsAjoutCarte(int, QString);

    private:
        bool fini;
        int decalageX;
        int decalageY;


};
#endif
