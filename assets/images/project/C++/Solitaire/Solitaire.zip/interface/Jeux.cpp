/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant de gérer tout ce qui est le jeux, l'apparence comme l'interne
        - contient
                - la pioche
                - les frames
                - les frames fin
        - fait le lien entre MonMainWindow et les frames
  *******************************************************/

#include "Jeux.h"

#include "MonMainWindow.h"
#include "Carte.h"

Jeux::Jeux(QWidget *parent) : QWidget(parent) {
    this->setMinimumSize(800, 450);

    nbCarte = 52;
    nbFrameFinPleine = 0;

    /*##################
    FrameS
    #################*/
    pioche = new MaFramePioche(this);

    fin1 = new MaFrameFin(this);
    fin2 = new MaFrameFin(this);
    fin3 = new MaFrameFin(this);
    fin4 = new MaFrameFin(this);

    jeux1 = new MaFrameBas(this);
    jeux2 = new MaFrameBas(this);
    jeux3 = new MaFrameBas(this);
    jeux4 = new MaFrameBas(this);
    jeux5 = new MaFrameBas(this);
    jeux6 = new MaFrameBas(this);
    jeux7 = new MaFrameBas(this);

    /*##################
    LayoutS
    #################*/
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    QBoxLayout * HlayoutHaut = new QBoxLayout(QBoxLayout::LeftToRight);
    QBoxLayout * HlayoutHautFin = new QBoxLayout(QBoxLayout::LeftToRight);
    QBoxLayout * HlayoutBas = new QBoxLayout(QBoxLayout::LeftToRight);

    layout->addLayout(HlayoutHaut);
    layout->addLayout(HlayoutBas);

    HlayoutHaut->addWidget(pioche);
    HlayoutHaut->addLayout(HlayoutHautFin);

    HlayoutHautFin->addWidget(fin1);
    HlayoutHautFin->addWidget(fin2);
    HlayoutHautFin->addWidget(fin3);
    HlayoutHautFin->addWidget(fin4);

    HlayoutBas->addWidget(jeux1);
    HlayoutBas->addWidget(jeux2);
    HlayoutBas->addWidget(jeux3);
    HlayoutBas->addWidget(jeux4);
    HlayoutBas->addWidget(jeux5);
    HlayoutBas->addWidget(jeux6);
    HlayoutBas->addWidget(jeux7);

    this->setLayout(layout);

    /*##################
    Jeux
    #################*/
    initialisation();//remplie le tableau jeux[nbCartes]
    melange();//mélange le tableau jeux[nbCartes]
    affect();//reparti les cartes dans les frames

    this->update();
    this->show();
    this->setAttribute(Qt::WA_DeleteOnClose);
}

Jeux::Jeux(Carte * c[52], QWidget *parent) : QWidget(parent) {
    this->setMinimumSize(800, 450);

    for(int i=0; i<52; i++)
        jeux[i] = c[i];
    nbCarte = 52;
    nbFrameFinPleine = 0;

    /*##################
    FrameS
    #################*/
    pioche = new MaFramePioche(this);

    fin1 = new MaFrameFin(this);
    fin2 = new MaFrameFin(this);
    fin3 = new MaFrameFin(this);
    fin4 = new MaFrameFin(this);

    jeux1 = new MaFrameBas(this);
    jeux2 = new MaFrameBas(this);
    jeux3 = new MaFrameBas(this);
    jeux4 = new MaFrameBas(this);
    jeux5 = new MaFrameBas(this);
    jeux6 = new MaFrameBas(this);
    jeux7 = new MaFrameBas(this);

    /*##################
    LayoutS
    #################*/
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    QBoxLayout * HlayoutHaut = new QBoxLayout(QBoxLayout::LeftToRight);
    QBoxLayout * HlayoutHautFin = new QBoxLayout(QBoxLayout::LeftToRight);
    QBoxLayout * HlayoutBas = new QBoxLayout(QBoxLayout::LeftToRight);

    layout->addLayout(HlayoutHaut);
    layout->addLayout(HlayoutBas);

    HlayoutHaut->addWidget(pioche);
    HlayoutHaut->addLayout(HlayoutHautFin);

    HlayoutHautFin->addWidget(fin1);
    HlayoutHautFin->addWidget(fin2);
    HlayoutHautFin->addWidget(fin3);
    HlayoutHautFin->addWidget(fin4);

    HlayoutBas->addWidget(jeux1);
    HlayoutBas->addWidget(jeux2);
    HlayoutBas->addWidget(jeux3);
    HlayoutBas->addWidget(jeux4);
    HlayoutBas->addWidget(jeux5);
    HlayoutBas->addWidget(jeux6);
    HlayoutBas->addWidget(jeux7);

    this->setLayout(layout);

    /*##################
    Jeux
    #################*/
    affect();//reparti les cartes dans les frames

    this->update();
    this->show();
    this->setAttribute(Qt::WA_DeleteOnClose);
}

MonMainWindow* Jeux::getParent() {
    parent = static_cast<MonMainWindow*>(this->parentWidget());
    return parent;
}

Carte* Jeux::getCarteById(int i) {
    return jeux[i];
}

void Jeux::initialisation() {
    int h = 0;
    QString c[4] = {"coeur", "carreau", "pique", "trefle"};
    int point = 1;
    for(int i=0;i<nbCarte;i++) {
        jeux[i] = new Carte();//pour ne pas qu'elles paraissent
        jeux[i]->setFamille(c[h]);
        jeux[i]->setValeure(point);
        point++;
        if(((i+1)%13) == 0 && i!=0 && h<=3) {
            h = h + 1;//incrémente fammille
            point = 1;//réinitialise les points des cartes
        }
    }
}

void Jeux::melange() {
    srand(time(NULL));
    random_shuffle(&jeux[0], &jeux[nbCarte]);
}

void Jeux::affect() {
    fin1->addCarte(0, "vide", false);
    fin2->addCarte(0, "vide", false);
    fin3->addCarte(0, "vide", false);
    fin4->addCarte(0, "vide", false);
    for (int i=0; i<nbCarte; i++) {
        if(i<7)
            jeux7->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else if(i>=7 && i<13)
            jeux6->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else if(i>=13 && i<18)
            jeux5->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else if(i>=18 && i<22)
            jeux4->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else if(i>=22 && i<25)
            jeux3->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else if(i>=25 && i<27)
            jeux2->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else if(i>=27 && i<28)
            jeux1->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        else {
            pioche->addCarte(jeux[i]->getValeure(), jeux[i]->getFamille(), false);
        }
    }
}

QPixmap Jeux::getCarteDos() {
    return pioche->getCarteDos();
}
QPixmap Jeux::getCarteVide() {
    return pioche->getCarteVide();
}
int Jeux::getButtonDeplacement() {
    return pioche->getButtonDeplacement();
}
int Jeux::getButtonClick() {
    return pioche->getButtonClick();
}
void Jeux::setButtonDeplacement(int i) {
    pioche->setButtonDeplacement(i);
    fin1->setButtonDeplacement(i);
    fin2->setButtonDeplacement(i);
    fin3->setButtonDeplacement(i);
    fin4->setButtonDeplacement(i);
    jeux1->setButtonDeplacement(i);
    jeux2->setButtonDeplacement(i);
    jeux3->setButtonDeplacement(i);
    jeux4->setButtonDeplacement(i);
    jeux5->setButtonDeplacement(i);
    jeux6->setButtonDeplacement(i);
    jeux7->setButtonDeplacement(i);
}
void Jeux::setButtonClick(int i) {
    pioche->setButtonClick(i);
    fin1->setButtonClick(i);
    fin2->setButtonClick(i);
    fin3->setButtonClick(i);
    fin4->setButtonClick(i);
    jeux1->setButtonClick(i);
    jeux2->setButtonClick(i);
    jeux3->setButtonClick(i);
    jeux4->setButtonClick(i);
    jeux5->setButtonClick(i);
    jeux6->setButtonClick(i);
    jeux7->setButtonClick(i);
}
void Jeux::setCartePixmap(QString carte, bool type) {
    pioche->setCartePixmap(carte, type);
    fin1->setCartePixmap(carte, type);
    fin2->setCartePixmap(carte, type);
    fin3->setCartePixmap(carte, type);
    fin4->setCartePixmap(carte, type);
    jeux1->setCartePixmap(carte, type);
    jeux2->setCartePixmap(carte, type);
    jeux3->setCartePixmap(carte, type);
    jeux4->setCartePixmap(carte, type);
    jeux5->setCartePixmap(carte, type);
    jeux6->setCartePixmap(carte, type);
    jeux7->setCartePixmap(carte, type);
}

MaFrame* Jeux::getFrameById(int i) {
    if(i == 0)
        return pioche;
    else if(i == 1)
        return fin1;
    else if(i == 2)
        return fin2;
    else if(i == 3)
        return fin3;
    else if(i == 4)
        return fin4;
    else if(i == 5)
        return jeux1;
    else if(i == 6)
        return jeux2;
    else if(i == 7)
        return jeux3;
    else if(i == 8)
        return jeux4;
    else if(i == 9)
        return jeux5;
    else if(i == 10)
        return jeux6;
    else
        return jeux7;
}

void Jeux::plein() {
    nbFrameFinPleine++;
    if(nbFrameFinPleine == 4) {
        getParent()->gagner();
    }
}

void Jeux::mettreAJourStatistiques() {
    MonMainWindow * mmw = static_cast<MonMainWindow*>(this->parentWidget());
    mmw->mettreAJourStatuBar();
}

void Jeux::selectionerCarte(Carte ** c, int count, MaFrame * f) {
    carteSelectionne = new Carte*[count];
    for(int i=0; i<count; i++) {
        carteSelectionne[i] = new Carte();
        carteSelectionne[i]->setValeure(c[i]->getValeure());
        carteSelectionne[i]->setFamille(c[i]->getFamille());
    }
    frameCarteSelectionne = f;
    boolCarteSelectionee = true;
    carteSelectionneCount = count;
}

Carte** Jeux::getCarteSelectionee() {
    return carteSelectionne;
}

int Jeux::getCarteSelectioneeCount() {
    return carteSelectionneCount;
}

MaFrame* Jeux::getFrameCarteSelectionee() {
        return frameCarteSelectionne;
}

bool Jeux::getIfCarteSelectionee() {
    return boolCarteSelectionee;
}

void Jeux::setIfCarteSelectionee(bool s) {
    boolCarteSelectionee = s;
}

void Jeux::addAnnuler(MaFrame * source, Carte ** c, int count, MaFrame * destination, int effetDeBord) {
    annulerSource.push(source);
    for(int i=count-1; i>=0; i--) {
        annulerCarteValeure.push(c[i]->getValeure());
        annulerCarteFamille.push(c[i]->getFamille());
        annulerCartePos.push(QPoint(c[i]->getX(), c[i]->getY()));
    }
    annulerCarteCount.push(count);
    annulerDestination.push(destination);
    annulerEffetDeBord.push(effetDeBord);
}

bool Jeux::annulerIsEmpty() {
    return annulerCarteCount.isEmpty();
}

void Jeux::annuler() {
    MaFrame * source = static_cast<MaFrame*>(annulerSource.pop());

    int count = annulerCarteCount.pop();
    MaFrame * destination = static_cast<MaFrame*>(annulerDestination.pop());
    int effetDeBord = annulerEffetDeBord.pop();

    MaFramePioche * sourcep = dynamic_cast<MaFramePioche*>(source);

    if(effetDeBord == 1 && !sourcep)//return la dernière carte qui n'était pas visible
        source->getCarteId(source->getNbCartes()-1)->setVisibilite(false);
    else if(effetDeBord == 2 && !sourcep) {//enlève la carte vide qui n'y était pas
        Carte * carte = static_cast<Carte*>(source->children().at(0));
        carte->hide();
        carte->close();
    }

    for(int i=0; i<count; i++) {
        int valeure = annulerCarteValeure.pop();
        QString famille = annulerCarteFamille.pop();
        QPoint pos = annulerCartePos.pop();
        if(sourcep) {
            cout<<"sourcep"<<endl;
            if(sourcep->getNbCarteRetournee()>1)
//                for(int i=0; i<sourcep->getNbCartes()-1; i++) {
//                    sourcep->getCarteId(sourcep->getNbCartes()-i)->hide();
//            }
            sourcep->addCarteVisible(valeure, famille);
            sourcep->getCarteId(sourcep->getNbCartes()-1)->move(pos);
        }
        else
            source->addCarte(valeure, famille, true);
    }
    destination->delCarte(count);
}

