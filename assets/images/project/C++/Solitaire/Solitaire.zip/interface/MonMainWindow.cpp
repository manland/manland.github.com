/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe gérant les menus, toolbars, statuBar et contenant le jeux
  *******************************************************/

#include "MonMainWindow.h"

#include <QAction>
#include <QLabel>
#include <QMenu>

#include "Options.h"

MonMainWindow::MonMainWindow(QWidget *parent) : QMainWindow(parent) {
    /*######################
    Initialisation de la fenêtre
    ######################*/
    this->setWindowIconText ("icons/icone.png");
    this->setWindowTitle("Client");
    this->setAccessibleName("Client");
    this->setMinimumSize(800, 600);

    nbParties = 1;
    pointPerdu = 0;

    j = new Jeux(this);
    setCentralWidget(j);

    chargerParametres();

    creerActions();
    creerMenu();
    creerMenuTool();
    creerStatusBar();

//    chargerParametres();

    this->update();
    this->show();
    this->setAttribute(Qt::WA_DeleteOnClose);
}

void MonMainWindow::chargerParametres() {
    QFile file("config.conf");
    file.open(QFile::ReadOnly);
    qint64 tailleLigne = 0;
    for(int i=0; i<9 && tailleLigne != -1; i++) {
        char buf[1024];
        tailleLigne = file.readLine(buf, sizeof(buf));
        if(tailleLigne != -1) {
                if(i==0) {
                    j->setCartePixmap("./CarteDos.png", true);
                }
                else if(i==1)
                    j->setCartePixmap("./CarteVide.png", false);
                else if(i==2)
                    int g;
                else if(i==3)
                    for(int h=5; h<12; h++)
                        j->getFrameById(h)->setDecalageCarteX(QString(buf).toInt());
                else if(i==4)
                    for(int h=5; h<12; h++)
                        j->getFrameById(h)->setDecalageCarteY(QString(buf).toInt());
                else if(i==5)
                    j->getFrameById(0)->setDecalageCarteX(QString(buf).toInt());
                else if(i==6)
                    for(int h=1; h<5; h++)
                        j->getFrameById(h)->setDecalageCarteX(QString(buf).toInt());
                else if(i==7)
                    for(int h=1; h<5; h++)
                        j->getFrameById(h)->setDecalageCarteY(QString(buf).toInt());
                else if(i==8) {
                    if(QString(buf).toInt() == 1) {
                        j->setButtonDeplacement(Qt::LeftButton);
                        j->setButtonClick(Qt::RightButton);
                    }
                    else {
                        j->setButtonDeplacement(Qt::RightButton);
                        j->setButtonClick(Qt::LeftButton);
                    }
                }
            }
        else {
            if(okPourContinuer(trUtf8("Paramètres par défault ?"), trUtf8("C'est la première fois que vous ouvrez ce jeux, voulez-vous le paramètrer (accepter) ? Ou utiliser les paramètres par défault (annuler) ?"), 0)) {
                new Options(j);
            }
            else {
                QFile file("config.conf");
                file.open(QIODevice::WriteOnly);
                QByteArray qba;
                qba.append("CarteDosDefault.png\n");
                qba.append("0\n");
                qba.append("01.png\n");
                qba.append(j->getFrameById(5)->getDecalageCarteX()+"\n");
                qba.append(j->getFrameById(5)->getDecalageCarteY()+"\n");
                qba.append(j->getFrameById(0)->getDecalageCarteX()+"\n");
                qba.append(j->getFrameById(1)->getDecalageCarteX()+"\n");
                qba.append(j->getFrameById(1)->getDecalageCarteY()+"\n");
                qba.append(j->getFrameById(0)->getButtonDeplacement()+"\n");
                file.write(qba);
                file.close();
            }
        }
    }
}

void MonMainWindow::gagner() {
    QString titre(trUtf8("Gagné !!"));
    QString message(trUtf8("Bravo vous avez gagné !!\nVoulez-vous recommencer ?"));
    if(okPourContinuer(titre, message, 0)) {
        j = new Jeux(this);
        setCentralWidget(j);
        qtempsReel->stop();
        time.setHMS(0, 0, 0);
        tempsReel();
        mettreAJourStatuBar();
    }

}

void MonMainWindow::creerActions() {
    actionNouvellePartie = new QAction(trUtf8("&Nouvelle Partie"), this);
    actionNouvellePartie->setIcon(QIcon("icons/healive/new.png"));
    actionNouvellePartie->setShortcut(trUtf8("Ctrl+N"));
    actionNouvellePartie->setStatusTip(trUtf8("Nouvelle partie"));
    connect(actionNouvellePartie, SIGNAL(triggered()), this, SLOT(newPartie()));

    actionRecommencer = new QAction(trUtf8("&Recommencer"), this);
    actionRecommencer->setIcon(QIcon("icons/healive/recommencer.png"));
    actionRecommencer->setShortcut(trUtf8("Ctrl+R"));
    actionRecommencer->setStatusTip(trUtf8("Reprendre depuis le début"));
    connect(actionRecommencer, SIGNAL(triggered()), this, SLOT(recommencer()));

    actionQuitter = new QAction(trUtf8("&Quitter"), this);
    actionQuitter->setIcon(QIcon("icons/healive/exit.png"));
    actionQuitter->setShortcut(trUtf8("Ctrl+Q"));
    actionQuitter->setStatusTip(trUtf8("Quitter"));
    connect(actionQuitter, SIGNAL(triggered()), this, SLOT(close()));

    actionAfficherCacherToolBarS = new QAction(trUtf8("Afficher/Cacher les boites d'outils"), this);
    actionAfficherCacherToolBarS->setIcon(QIcon("icons/healive/rouge.png"));
    actionAfficherCacherToolBarS->setStatusTip(trUtf8("Afficher/Cacher ToolBarS"));
    connect(actionAfficherCacherToolBarS, SIGNAL(triggered()), this, SLOT(afficherCacherToolBarFichier()));
    connect(actionAfficherCacherToolBarS, SIGNAL(triggered()), this, SLOT(afficherCacherToolBarJeux()));
    connect(actionAfficherCacherToolBarS, SIGNAL(triggered()), this, SLOT(afficherCacherToolBarAide()));

    actionAfficherCacherToolBarFichier = new QAction(trUtf8("Cacher la boite d'outil Fichier"), this);
    actionAfficherCacherToolBarFichier->setIcon(QIcon("icons/healive/bleu.png"));
    actionAfficherCacherToolBarFichier->setStatusTip(trUtf8("Afficher/Cacher ToolBar Fichier"));
    connect(actionAfficherCacherToolBarFichier, SIGNAL(triggered()), this, SLOT(afficherCacherToolBarFichier()));

    actionAfficherCacherToolBarJeux = new QAction(trUtf8("Cacher la boite d'outil Jeux"), this);
    actionAfficherCacherToolBarJeux->setIcon(QIcon("icons/healive/bleu.png"));
    actionAfficherCacherToolBarJeux->setStatusTip(trUtf8("Afficher/Cacher ToolBar Jeux"));
    connect(actionAfficherCacherToolBarJeux, SIGNAL(triggered()), this, SLOT(afficherCacherToolBarJeux()));

    actionAfficherCacherToolBarAide = new QAction(trUtf8("Cacher la boite d'outil Aide"), this);
    actionAfficherCacherToolBarAide->setIcon(QIcon("icons/healive/vert.png"));
    actionAfficherCacherToolBarAide->setStatusTip(trUtf8("Afficher/Cacher ToolBar Aide"));
    connect(actionAfficherCacherToolBarAide, SIGNAL(triggered()), this, SLOT(afficherCacherToolBarAide()));

    actionAgrandirIcon = new QAction(trUtf8("Augmenter la taille des icones"), this);
    actionAgrandirIcon->setIcon(QIcon("icons/healive/plus.png"));
    actionAgrandirIcon->setStatusTip(trUtf8("Taille icones +"));
    connect(actionAgrandirIcon, SIGNAL(triggered()), this, SLOT(agrandirIcon()));

    actionRapeticirIcon = new QAction(trUtf8("Diminuer la taille des icones"), this);
    actionRapeticirIcon->setIcon(QIcon("icons/healive/moins.png"));
    actionRapeticirIcon->setStatusTip(trUtf8("Taille icones -"));
    connect(actionRapeticirIcon, SIGNAL(triggered()), this, SLOT(rapeticirIcon()));

    actionAfficherCacherStatusBar = new QAction(trUtf8("Cacher la barre de status"), this);
    actionAfficherCacherStatusBar->setIcon(QIcon("icons/healive/statu.png"));
    actionAfficherCacherStatusBar->setStatusTip(trUtf8("Cacher la barre de status"));
    connect(actionAfficherCacherStatusBar, SIGNAL(triggered()), this, SLOT(afficherCacherStatusBar()));

    actionVoirCarte = new QAction(trUtf8("Voir une carte"), this);
    actionVoirCarte->setIcon(QIcon("icons/healive/triche2.png"));
    actionVoirCarte->setStatusTip(trUtf8("Permet de voir une carte même si elle est de dos."));
    connect(actionVoirCarte, SIGNAL(triggered()), this, SLOT(voirCarte()));

    actionMelangerPioche = new QAction(trUtf8("Mélanger la pioche"), this);
    actionMelangerPioche->setIcon(QIcon("icons/healive/triche1.png"));
    actionMelangerPioche->setStatusTip(trUtf8("Permet de mélanger la pioche si vous n'avez plus de solutions possibles"));
    connect(actionMelangerPioche, SIGNAL(triggered()), this, SLOT(melangerPioche()));

    actionAnnuler = new QAction(trUtf8("Annuler"), this);
    actionAnnuler->setIcon(QIcon("icons/healive/rouge.png"));
    actionAnnuler->setStatusTip(trUtf8("Permet d'annuler le dernier déplacement"));
    connect(actionAnnuler, SIGNAL(triggered()), this, SLOT(annuler()));

    actionPreference = new QAction(trUtf8("Préférences..."), this);
    actionPreference->setIcon(QIcon("icons/healive/preferences.png"));
    actionPreference->setStatusTip(trUtf8("Permet de configurer le Solitaire"));
    connect(actionPreference, SIGNAL(triggered()), this, SLOT(preference()));

    actionAProposDe = new QAction(trUtf8("&A Propos Du Solitaire..."), this);
    actionAProposDe->setIcon(QIcon("icons/healive/about.png"));
    actionAProposDe->setShortcut(trUtf8("Ctrl+N"));
    actionAProposDe->setStatusTip(trUtf8("A Propos Du Solitaire"));
    connect(actionAProposDe, SIGNAL(triggered()), this, SLOT(aproposde()));

    actionAProposDeQt = new QAction(trUtf8("&A Propos De Qt..."), this);
    actionAProposDeQt->setIcon(QIcon("icons/healive/qtlogo.png"));
    actionAProposDeQt->setStatusTip(trUtf8("A Propos De Qt"));
    connect(actionAProposDeQt, SIGNAL(triggered()), this, SLOT(aproposdeQt()));

}

void MonMainWindow::creerMenu() {
    menu = menuBar();

    menuFichier = menu->addMenu(trUtf8("&Fichier"));
    menuFichier->addAction(actionNouvellePartie);
    menuFichier->addAction(actionRecommencer);
    menuFichier->addSeparator();
    menuFichier->addAction(actionQuitter);

    menuJeux = menu->addMenu(trUtf8("&Jeux"));
    menuJeux->addAction(actionAnnuler);
    menuJeux->addSeparator();
    menuJeux->addAction(actionVoirCarte);
    menuJeux->addAction(actionMelangerPioche);
    menuJeux->addSeparator();
    menuJeux->addAction(actionPreference);

    menuAffichage = menu->addMenu(trUtf8("&Affichage"));
    menuAffichageToolBar = menuAffichage->addMenu(trUtf8("Barres d'Outils"));
    menuAffichageToolBar->setIcon(QIcon("icons/healive/jaune.png"));
    menuAffichageToolBar->addAction(actionAfficherCacherToolBarS);
    menuAffichageToolBar->addAction(actionAfficherCacherToolBarFichier);
    menuAffichageToolBar->addAction(actionAfficherCacherToolBarJeux);
    menuAffichageToolBar->addAction(actionAfficherCacherToolBarAide);
    menuAffichageToolBar->addSeparator();
    menuAffichageToolBar->addAction(actionAgrandirIcon);
    menuAffichageToolBar->addAction(actionRapeticirIcon);
    menuAffichage->addAction(actionAfficherCacherStatusBar);

    menu->addSeparator();//pour la cohésion avec la plateforme déplace l'aide à droite ou pas

    menuAide = menu->addMenu(trUtf8("&Aide"));
    menuAide->addAction(actionAProposDe);
    menuAide->addAction(actionAProposDeQt);
}

void MonMainWindow::creerMenuTool() {
    toolBarFichier = addToolBar(trUtf8("&File"));
    toolBarFichier->setIconSize(QSize(50, 50));
    toolBarFichier->addAction(actionNouvellePartie);
    toolBarFichier->addAction(actionRecommencer);
    toolBarFichier->addAction(actionPreference);
    toolBarFichier->addAction(actionQuitter);

    toolBarJeux = addToolBar(trUtf8("&Jeux"));
    toolBarJeux->setIconSize(QSize(50, 50));
    toolBarJeux->addAction(actionVoirCarte);
    toolBarJeux->addAction(actionMelangerPioche);
    toolBarJeux->addAction(actionAnnuler);

    toolBarAide = addToolBar(trUtf8("&Aide"));
    toolBarAide->setIconSize(QSize(50, 50));
    toolBarAide->addAction(actionAProposDe);
}

void MonMainWindow::newPartie() {
    if(okPourContinuer(trUtf8("Nouvelle Partie"), trUtf8("Etes-vous sûr de vouloir commencer une nouvelle partie ?"), 0)) {
        j = new Jeux(this);
        setCentralWidget(j);

        chargerParametres();

        qtempsReel->stop();
        time.setHMS(0, 0, 0);
        tempsReel();
        pointPerdu = 0;

        mettreAJourStatuBar();
    }
}

void MonMainWindow::agrandirIcon() {
    toolBarFichier->setIconSize(QSize(toolBarFichier->iconSize().width()+10, toolBarFichier->iconSize().height()+10));
    toolBarJeux->setIconSize(QSize(toolBarJeux->iconSize().width()+10, toolBarJeux->iconSize().height()+10));
    toolBarAide->setIconSize(QSize(toolBarAide->iconSize().width()+10, toolBarAide->iconSize().height()+10));
}

void MonMainWindow::rapeticirIcon() {
    toolBarFichier->setIconSize(QSize(toolBarFichier->iconSize().width()-10, toolBarFichier->iconSize().height()-10));
    toolBarJeux->setIconSize(QSize(toolBarJeux->iconSize().width()-10, toolBarJeux->iconSize().height()-10));
    toolBarAide->setIconSize(QSize(toolBarAide->iconSize().width()-10, toolBarAide->iconSize().height()-10));
}

void MonMainWindow::recommencer() {
    if(okPourContinuer(trUtf8("Recommencer"), trUtf8("Etes-vous sûr de vouloir recommencer la partie ?"), 0)) {
        Carte * c[52];
        for(int i=0; i<52; i++)
            c[i] = j->getCarteById(i);
        j = new Jeux(c, this);
        setCentralWidget(j);
        mettreAJourStatuBar();
    }
}

void MonMainWindow::afficherCacherToolBarFichier() {
    if(toolBarFichier->isVisible()) {
        toolBarFichier->hide();
        actionAfficherCacherToolBarFichier->setText(trUtf8("Afficher la boite d'outil Fichier"));
    }
    else {
        toolBarFichier->show();
        actionAfficherCacherToolBarFichier->setText(trUtf8("Cacher la boite d'outil Fichier"));
    }
}

void MonMainWindow::afficherCacherToolBarJeux() {
    if(toolBarJeux->isVisible()) {
        toolBarJeux->hide();
        actionAfficherCacherToolBarJeux->setText(trUtf8("Afficher la boite d'outil Jeux"));
    }
    else {
        toolBarJeux->show();
        actionAfficherCacherToolBarJeux->setText(trUtf8("Cacher la boite d'outil Jeux"));
    }
}

void MonMainWindow::afficherCacherToolBarAide() {
    if(toolBarAide->isVisible()) {
        toolBarAide->hide();
        actionAfficherCacherToolBarAide->setText(trUtf8("Afficher la boite d'outil Aide"));
    }
    else {
        toolBarAide->show();
        actionAfficherCacherToolBarAide->setText(trUtf8("Cacher la boite d'outil Aide"));
    }
}

void MonMainWindow::creerStatusBar() {
    QLabel * cartesPioche1 = new QLabel(trUtf8(" Cartes dans la pioche : "));
    cartesPioche1->setMinimumSize(cartesPioche1->sizeHint());
    statusBar()->addWidget(cartesPioche1);

    cartesPioche = new QLabel(trUtf8(" 99 "));
    cartesPioche->setMinimumSize(cartesPioche->sizeHint());
    statusBar()->addWidget(cartesPioche);

    QLabel * cartesFinies1 = new QLabel(trUtf8(" Points : "));
    cartesFinies1->setMinimumSize(cartesFinies1->sizeHint());
    statusBar()->addWidget(cartesFinies1);

    cartesFinies = new QLabel(trUtf8(" 99 "));
    cartesFinies->setMinimumSize(cartesFinies->sizeHint());
    statusBar()->addWidget(cartesFinies, 1);

    mettreAJourStatuBar();

    qtempsReel = new QTimer();
    qtempsReel->start(1000);
    connect(qtempsReel, SIGNAL(timeout()), this, SLOT(tempsReel()));

    time = QTime(0, 0, 0);

    QLabel * temps1 = new QLabel(trUtf8(" Durée : "));
    temps1->setAlignment(Qt::AlignHCenter);
    temps1->setMinimumSize(temps1->sizeHint());
    statusBar()->addPermanentWidget(temps1);

    temps = new QLabel(trUtf8(" 00:00:00 "));
    temps->setAlignment(Qt::AlignHCenter);
    temps->setMinimumSize(temps->sizeHint());
    statusBar()->addPermanentWidget(temps);
}

void MonMainWindow::mettreAJourStatuBar() {
    MaFramePioche * mfp = static_cast<MaFramePioche*>(j->getFrameById(0));
    int nbCartesPioche = mfp->getNbCartesTotal();
    int nbCartesFin = 0;
    for(int i=1; i<=4; i++) {
        nbCartesFin = nbCartesFin + j->getFrameById(i)->getNbCartes();
    }
    if(pointPerdu > 0)
        nbCartesFin = nbCartesFin - pointPerdu;
    QString s;
    s.setNum(nbCartesFin);
    if(pointPerdu>0 && nbCartesFin>0) {
        s.append(" (-");
        s.append(QString().setNum(pointPerdu));
        s.append(")");
    }
    cartesFinies->setText(s);
    cartesPioche->setText(QString().setNum(nbCartesPioche));
}

void MonMainWindow::tempsReel() {
    int h = time.hour();
    int m = time.minute();
    int s = time.second();
    s = s + 1;
    if(s == 60) {
        m = m + 1;
        s = 0;
    }
    if(m == 60) {
        h = h + 1;
        m = 0;
    }
    time.setHMS (h, m, s);
    temps->setText(time.toString());
    qtempsReel->start(1000);
}

void MonMainWindow::afficherCacherStatusBar() {
    if(statusBar()->isVisible()) {
        statusBar()->hide();
        actionAfficherCacherStatusBar->setText(trUtf8("Afficher la barre d'états"));
    }
    else {
        statusBar()->show();
        actionAfficherCacherStatusBar->setText(trUtf8("Cacher la barre d'états"));
    }
}

void MonMainWindow::melangerPioche() {
    if(okPourContinuer(trUtf8("Melanger"), trUtf8("Le fait de mélanger la pioche vous enlève 2 points.\nDe plus cela ne mélange que les cartes qui ne sont pas encore retournées."), 1)) {
        MaFramePioche * p = dynamic_cast<MaFramePioche*>(j->getFrameById(0));
        p->melangePioche();
        pointPerdu = pointPerdu + 2;
        mettreAJourStatuBar();
    }
}

void MonMainWindow::voirCarte() {
    if(okPourContinuer(trUtf8("Voir Carte"), trUtf8("Le fait de regarder une carte par pile vous enlève 4 points.\nDe plus cela ne fonctionne que sur les cartes qui sont de dos et qui sont sorties de la pioche."), 1)) {
        for(int i=5; i<12; i++) {
            MaFrameBas * p = static_cast<MaFrameBas*>(j->getFrameById(i));
            p->setVoirCarte(true);
        }
        pointPerdu = pointPerdu + 4;
        mettreAJourStatuBar();
    }
}

void MonMainWindow::annuler() {
    if(!j->annulerIsEmpty())
        if(okPourContinuer(trUtf8("Annuler"), trUtf8("Le fait d'annuler un déplacement vous enlève 1 points."), 1)) {
            j->annuler();
            pointPerdu = pointPerdu + 1;
            mettreAJourStatuBar();
        }
}

void MonMainWindow::preference() {
    new Options(j);
}

void MonMainWindow::aproposde() {
    QDialog * gagner = new QDialog(this, Qt::Dialog);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);
    QBoxLayout * HlayoutHaut = new QBoxLayout(QBoxLayout::LeftToRight);
    Carte * c = new Carte(0, "vide", gagner);
    c->setVisibilite(false);
    HlayoutHaut->addWidget(c);
    QLabel * l = new QLabel(trUtf8("Ce logiciel à été créé dans le but d'un Tp noté en 3e année de licence Informatique afin d'apprendre à se servir l'API QT de Trolltech."));
    l->setWordWrap(true);
    HlayoutHaut->addWidget(l);
    QPushButton * ferme = new QPushButton(trUtf8("Fermer"));
    ferme->setIcon(QIcon("icons/healive/exit.png"));
    connect(ferme, SIGNAL(clicked()), gagner, SLOT(close()));
    layout->addLayout(HlayoutHaut);
    layout->addWidget(ferme);
    gagner->setLayout(layout);
    gagner->show();
}

void MonMainWindow::aproposdeQt() {
    QMessageBox().aboutQt(this, trUtf8("A propos de Qt"));
}

bool MonMainWindow::okPourContinuer(QString titre, QString message, int icon) {
    QMessageBox msg(this);
    msg.setWindowTitle(titre);
    msg.setText(message);
    if(icon == 0)
        msg.setIcon(QMessageBox::Question);
    else if(icon == 1)
        msg.setIcon(QMessageBox::Information);
    else if(icon == 2)
        msg.setIcon(QMessageBox::Warning);
    else if(icon == 3)
        msg.setIcon(QMessageBox::Critical);
    else
        msg.setIcon(QMessageBox::NoIcon);

    QPushButton * annuler = new QPushButton(QIcon("icons/healive/rouge.png"), "Annuler");
    QPushButton * accepter = new QPushButton(QIcon("icons/healive/vert.png"), "Accepter");

    msg.addButton(accepter, QMessageBox::AcceptRole);
    msg.addButton(annuler, QMessageBox::RejectRole);

    int r = msg.exec();
    if(r==QMessageBox::AcceptRole)
        return true;
    else
        return false;
}

void MonMainWindow::paintEvent(QPaintEvent *event) {
    QPainter painter(this);

//    QLinearGradient gradient(0, 0, this->width(), this->height());
//    gradient.setColorAt(0.0, Qt::white);
//    gradient.setColorAt(0.8, Qt::blue);
//    gradient.setColorAt(1.0, Qt::white);
//
//    painter.setPen(QColor(0, 153, 0, 255));
////    painter.setBrush(gradient);
//    painter.setBrush(QColor(255, 0, 0));
//    painter.drawRect(0, 0, this->width(), this->height());

    painter.drawPixmap(0, 0, QPixmap("01.png"));
}

QPixmap MonMainWindow::pixmap() {
    return QPixmap("01.png");
}

void MonMainWindow::closeEvent(QCloseEvent * event) {
    if(okPourContinuer(trUtf8("Quitter"), trUtf8("Etes-vous sûr de vouloir quitter la partie ?"), 3))
        event->accept();
    else
        event->ignore();
}
