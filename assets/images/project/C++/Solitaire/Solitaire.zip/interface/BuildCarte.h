/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant de créer sa propre carte qu'elle soit de dos ou vide
  *******************************************************/

#ifndef BuildCarte_h
#define BuildCarte_h

#include <QWidget>
#include <QBoxLayout>
#include <QIcon>
#include <QSlider>
#include <QCheckBox>
#include <QGroupBox>
#include <QPushButton>
#include <QVector>
#include <QPair>
#include <QRadialGradient>
#include <QLinearGradient>
#include <QColorDialog>
#include <QToolBox>
#include <QFile>
#include <QBuffer>
#include <QLineEdit>

#include "Carte.h"

#include <iostream>
using namespace std;

class BuildCarte : public QWidget
{
    Q_OBJECT


    public:
        BuildCarte(QString, QWidget *parent=0);
        QPixmap getPixmap();

    protected:

    private slots:
        void save();

        void rouge(int);
        void bleu(int);
        void vert(int);

        void changerCouleure1();
        void changerCouleure2();
        void changerCouleure3();

        void chooseGradient(int);

        void degradeRondWidgetCentreX(int);
        void degradeRondWidgetCentreY(int);
        void degradeRondWidgetRadiusQ(int);
        void degradeRondWidgetFocalX(int);
        void degradeRondWidgetFocalY(int);


        void degradeTraitWidgetDepartX(int);
        void degradeTraitWidgetDepartY(int);
        void degradeTraitWidgetArriveeX(int);
        void degradeTraitWidgetArriveeY(int);

        void changerCouleureBordure();
        void changerBordureX(int);
        void changerBordureY(int);

        void changerText();
        void changerCouleureText();
        void changerTextX(int);
        void changerTextY(int);

    private:
        QLabel * image;
        QPixmap * pixmapSansBordure;
        QPixmap * pixmapAvecBordure;
        QPixmap * pixmapAvecText;
        QPainter * painter;
        QPainter * painter2;
        QPainter * painter3;

        QCheckBox * qcheckboxDegradeRond;
        QCheckBox * qcheckboxDegradeTrait;
        QCheckBox * qcheckboxDegradeAucun;

        QColor * couleure[30];
        QColor * couleureEnCours;

        QGradient * degrade;
        QVector<QColor*> couleuresDegrade;
        QPushButton * p1;
        QPushButton * p2;
        QPushButton * p3;
        QPushButton * p11;
        QPushButton * p22;
        QPushButton * p33;

        void degradeRond();
        QRadialGradient * qdegradeRond;
        QWidget * degradeRondWidget;
        QPointF degradeRondWidgetCentre;
        qreal degradeRondWidgetRadius;
        QPointF degradeRondWidgetFocal;

        void degradeTrait();
        QLinearGradient * qdegradeTrait;
        QPointF * degradeTraitWidgetDepart;
        QPointF * degradeTraitWidgetFin;

        void degradeAucun();

        QColor * couleureBordure;
        QPushButton * bouttonBordure;
        int bordureX;
        int bordureY;

        QPushButton * bouttonText;
        QLineEdit * qlineeditText;
        QColor * couleureText;
        int textX;
        int textY;
        QString text;

        QWidget* makeOptions();
        QWidget* Couleure();
        QWidget* Gradient();
        QWidget* buildDegradeRondWidget();
        QWidget* buildDegradeTraitWidget();
        QWidget* Bordure();
        QWidget* Image();
        QWidget* Text();
        void mettreAJourPixmap();
        int largeure;
        int hauteure;

        QFile * file;
        QString * type;
};
#endif
