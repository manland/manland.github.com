/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant de créer sa propre carte qu'elle soit de dos ou vide
  *******************************************************/

#include "BuildCarte.h"

#include "Jeux.h"

BuildCarte::BuildCarte(QString t, QWidget *parent) : QWidget(parent) {
    setMinimumSize(800, 600);
    setAttribute(Qt::WA_DeleteOnClose);
    largeure = 800;
    hauteure = 600;

    pixmapSansBordure = new QPixmap(71, 96);
    pixmapAvecBordure = new QPixmap(71, 96);
    pixmapAvecText = new QPixmap(71, 96);

    image = new QLabel(this);
    image->setPixmap(*pixmapSansBordure);
    painter = new QPainter(pixmapSansBordure);

    p1 = new QPushButton(this);
    p2 = new QPushButton(this);
    p3 = new QPushButton(this);

    degradeRondWidgetCentre = QPointF(pixmapSansBordure->width()/2, pixmapSansBordure->height()/2);
    degradeRondWidgetRadius = 80;
    degradeRondWidgetFocal = QPointF(0, 0);
    couleuresDegrade.append(new QColor(Qt::green));
    couleuresDegrade.append(new QColor(Qt::blue));
    couleuresDegrade.append(new QColor(Qt::red));

    degradeTraitWidgetDepart = new QPointF(0, 0);
    degradeTraitWidgetFin = new QPointF(pixmapSansBordure->width(), pixmapSansBordure->height());

    for(int i=0; i<30; i++)
        couleure[i] = new QColor(0, 0, 0);

    painter2 = new QPainter(pixmapAvecBordure);
    bordureX = 0;
    bordureY = 0;

    painter3 = new QPainter(pixmapAvecText);
    textX = pixmapAvecText->width()/2;
    textY = pixmapAvecText->height()/2;
    text = "";

    QBoxLayout * layout = new QBoxLayout(QBoxLayout::LeftToRight);
    layout->addWidget(image, 1, Qt::AlignHCenter);
    layout->addWidget(makeOptions());
    setLayout(layout);

    chooseGradient(1);
    chooseGradient(2);
    chooseGradient(0);

    if(t == "CarteDos.png") {
        file = new QFile("./CarteDos.png");
    }
    else if(t == "CarteVide.png") {
        file = new QFile("./CarteVide.png");
    }
    else
        file = new QFile("./test.png");
    type = new QString(t);

    update();
    show();

}

QWidget* BuildCarte::makeOptions() {
    QWidget * options = new QWidget(this);
    options->setMinimumSize(largeure/2, hauteure-50);
    options->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * layoutDroite = new QBoxLayout(QBoxLayout::TopToBottom);
    couleure[0] = new QColor(255, 30, 30);
    couleureEnCours = couleure[0];

    QToolBox * tout = new QToolBox(this);
    tout->setMinimumSize(largeure/2, hauteure-300);
    tout->setMaximumSize(largeure/2+100, hauteure);
    tout->setAttribute(Qt::WA_DeleteOnClose);

    QGroupBox * fond = new QGroupBox(this);
    fond->setMinimumSize(largeure/2, 120);
    fond->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * fondlayout = new QBoxLayout(QBoxLayout::TopToBottom);
    fondlayout->addWidget(Gradient());
    fond->setLayout(fondlayout);
    tout->addItem(fond, QString(trUtf8("Fond")));

    QGroupBox * qgbTxt = new QGroupBox(this);
    QBoxLayout * tempLayout = new QBoxLayout(QBoxLayout::TopToBottom);
    tempLayout->addWidget(Text());
    qgbTxt->setLayout(tempLayout);
    tout->addItem(qgbTxt, QString(trUtf8("Texte")));

    QGroupBox * qgbBordur = new QGroupBox(this);
    tempLayout = new QBoxLayout(QBoxLayout::TopToBottom);
    tempLayout->addWidget(Bordure());
    qgbBordur->setLayout(tempLayout);
    tout->addItem(qgbBordur, QString(trUtf8("Bordure")));

//    layoutDroite->addWidget(Image());

    layoutDroite->addWidget(tout);

    QPushButton * enregistrer = new QPushButton(trUtf8("Enregistrer"), this);
    connect(enregistrer, SIGNAL(clicked()), this, SLOT(save()));
    layoutDroite->addWidget(enregistrer);

    options->setLayout(layoutDroite);
    return options;
}

QWidget* BuildCarte::Couleure() {
    QWidget * couleure = new QWidget(this);
    couleure->setMaximumSize((largeure/2)-50, 150);
    couleure->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);
    QBoxLayout * Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);

    Hlayout->addWidget(new QLabel(trUtf8("Rouge : ")));
    QSlider * r = new QSlider(Qt::Horizontal);
    r->setValue(couleureEnCours->red());
    r->setMinimum(0);
    r->setMaximum(255);
    connect(r,SIGNAL(valueChanged(int)),this,SLOT(rouge(int)));
    Hlayout->addWidget(r);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Vert : ")));
    QSlider * g = new QSlider(Qt::Horizontal);
    g->setValue(couleureEnCours->green());
    g->setMinimum(0);
    g->setMaximum(255);
    connect(g,SIGNAL(valueChanged(int)),this,SLOT(vert(int)));
    Hlayout->addWidget(g);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Bleu : ")));
    QSlider * b = new QSlider(Qt::Horizontal);
    b->setValue(couleureEnCours->blue());
    b->setMinimum(0);
    b->setMaximum(255);
    connect(b,SIGNAL(valueChanged(int)),this,SLOT(bleu(int)));
    Hlayout->addWidget(b);
    layout->addLayout(Hlayout);

    couleure->setLayout(layout);

    return couleure;
}

void BuildCarte::rouge(int i) {
    couleureEnCours->setRed(i);
    painter->fillRect(pixmapSansBordure->rect(),QBrush(*couleureEnCours));

    mettreAJourPixmap();
}
void BuildCarte::vert(int i) {
    couleureEnCours->setGreen(i);
    painter->fillRect(pixmapSansBordure->rect(),QBrush(*couleureEnCours));

    mettreAJourPixmap();
}
void BuildCarte::bleu(int i) {
    couleureEnCours->setBlue(i);
    painter->fillRect(pixmapSansBordure->rect(),QBrush(*couleureEnCours));

    mettreAJourPixmap();
}

QWidget* BuildCarte::Gradient() {
    QToolBox * gradient = new QToolBox(this);
    gradient->setMinimumSize(largeure/2, 100);
    gradient->setAttribute(Qt::WA_DeleteOnClose);

    gradient->addItem(buildDegradeRondWidget(), QString(trUtf8("Dégradé Rond")));

    gradient->addItem(buildDegradeTraitWidget(), QString(trUtf8("Dégradé")));

    QGroupBox * buildDegradeAucunWidget = new QGroupBox(this);
    QBoxLayout * tempLayout = new QBoxLayout(QBoxLayout::TopToBottom);
    tempLayout->addWidget(Couleure());
    buildDegradeAucunWidget->setLayout(tempLayout);
    gradient->addItem(buildDegradeAucunWidget, QString(trUtf8("Aucun Dégradé")));

    connect(gradient, SIGNAL(currentChanged(int)), this, SLOT(chooseGradient(int)));

    return gradient;
}

void BuildCarte::chooseGradient(int i) {
    if(i ==0)
        degradeRond();
    else if(i == 1)
        degradeTrait();
    else
        degradeAucun();
}

//------------------ DEBUT DEGRADE ROND ------------------
void BuildCarte::degradeRond() {
    qdegradeRond = new QRadialGradient(degradeRondWidgetCentre, degradeRondWidgetRadius, degradeRondWidgetFocal);
    degrade = qdegradeRond;

    qdegradeRond->setColorAt(0.0, *couleuresDegrade.at(0));
    qdegradeRond->setColorAt(0.5, *couleuresDegrade.at(1));
    qdegradeRond->setColorAt(1.0, *couleuresDegrade.at(2));

    painter->setBrush(*qdegradeRond);
    painter->drawRect(pixmapSansBordure->rect());

    mettreAJourPixmap();
}

QWidget* BuildCarte::buildDegradeRondWidget() {
    QGroupBox * degradeRondWidget = new QGroupBox(this);
    degradeRondWidget->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    layout->addWidget(new QLabel(trUtf8("Couleures")));

    QBoxLayout * Hlayout1 = new QBoxLayout(QBoxLayout::LeftToRight);//1
    Hlayout1->addWidget(new QLabel(QString().setNum(0.0)));
    connect(p1, SIGNAL(pressed()), this, SLOT(changerCouleure1()));
    Hlayout1->addWidget(p1);
    QPixmap pix1(30, 30);
    pix1.fill(*couleuresDegrade.at(0));
    p1->setIcon(QIcon(pix1));
    layout->addLayout(Hlayout1);
    QBoxLayout * Hlayout2 = new QBoxLayout(QBoxLayout::LeftToRight);//2
    Hlayout2->addWidget(new QLabel(QString().setNum(0.5)));
    connect(p2, SIGNAL(pressed()), this, SLOT(changerCouleure2()));
    Hlayout2->addWidget(p2);
    QPixmap pix2(30, 30);
    pix2.fill(*couleuresDegrade.at(1));
    p2->setIcon(QIcon(pix2));
    layout->addLayout(Hlayout2);
    QBoxLayout * Hlayout3 = new QBoxLayout(QBoxLayout::LeftToRight);//3
    Hlayout3->addWidget(new QLabel(QString().setNum(1.0)));
    connect(p3, SIGNAL(pressed()), this, SLOT(changerCouleure3()));
    Hlayout3->addWidget(p3);
    QPixmap pix3(30, 30);
    pix3.fill(*couleuresDegrade.at(2));
    p3->setIcon(QIcon(pix3));
    layout->addLayout(Hlayout3);

    QSlider * degradeRondWidgetCentreX = new QSlider(Qt::Horizontal);
    degradeRondWidgetCentreX->setValue(degradeRondWidgetCentre.x());
    degradeRondWidgetCentreX->setMinimum(-255);
    degradeRondWidgetCentreX->setMaximum(255);
    connect(degradeRondWidgetCentreX,SIGNAL(valueChanged(int)),this,SLOT(degradeRondWidgetCentreX(int)));
    layout->addWidget(new QLabel(trUtf8("Coordonnée X du centre du dégradé")));
    layout->addWidget(degradeRondWidgetCentreX);

    QSlider * degradeRondWidgetCentreY = new QSlider(Qt::Horizontal);
    degradeRondWidgetCentreY->setValue(degradeRondWidgetCentre.y());
    degradeRondWidgetCentreY->setMinimum(-255);
    degradeRondWidgetCentreY->setMaximum(255);
    connect(degradeRondWidgetCentreY,SIGNAL(valueChanged(int)),this,SLOT(degradeRondWidgetCentreY(int)));
    layout->addWidget(new QLabel(trUtf8("Coordonnée Y du centre du dégradé")));
    layout->addWidget(degradeRondWidgetCentreY);

    QSlider * degradeRondWidgetRadiusQ = new QSlider(Qt::Horizontal);
    degradeRondWidgetRadiusQ->setValue(degradeRondWidgetRadius);
    degradeRondWidgetRadiusQ->setMinimum(-255);
    degradeRondWidgetRadiusQ->setMaximum(255);
    connect(degradeRondWidgetRadiusQ,SIGNAL(valueChanged(int)),this,SLOT(degradeRondWidgetRadiusQ(int)));
    layout->addWidget(new QLabel(trUtf8("Radius")));
    layout->addWidget(degradeRondWidgetRadiusQ);

    QSlider * degradeRondWidgetFocalX = new QSlider(Qt::Horizontal);
    degradeRondWidgetFocalX->setValue(degradeRondWidgetFocal.x());
    degradeRondWidgetFocalX->setMinimum(-255);
    degradeRondWidgetFocalX->setMaximum(255);
    connect(degradeRondWidgetFocalX,SIGNAL(valueChanged(int)),this,SLOT(degradeRondWidgetFocalX(int)));
    layout->addWidget(new QLabel(trUtf8("Coordonnée X du focus du dégradé")));
    layout->addWidget(degradeRondWidgetFocalX);

    QSlider * degradeRondWidgetFocalY = new QSlider(Qt::Horizontal);
    degradeRondWidgetFocalY->setValue(degradeRondWidgetFocal.y());
    degradeRondWidgetFocalY->setMinimum(-255);
    degradeRondWidgetFocalY->setMaximum(255);
    connect(degradeRondWidgetFocalY,SIGNAL(valueChanged(int)),this,SLOT(degradeRondWidgetFocalY(int)));
    layout->addWidget(new QLabel(trUtf8("Coordonnée Y du focus du dégradé")));
    layout->addWidget(degradeRondWidgetFocalY);

    degradeRondWidget->setLayout(layout);
    return degradeRondWidget;
}

void BuildCarte::changerCouleure1() {
    QPixmap pix(30, 30);
    QColor * c = new QColor(QColorDialog::getRgba());
    couleuresDegrade.replace(0, c);
    pix.fill(*couleuresDegrade.at(0));
    p1->setIcon(QIcon(pix));
    p11->setIcon(QIcon(pix));

    qdegradeRond->setColorAt(0.0, *c);
    qdegradeTrait->setColorAt(0.0, *c);

    if(degrade->type() == QGradient::RadialGradient)
        painter->setBrush(*qdegradeRond);
    else if(degrade->type() == QGradient::LinearGradient)
        painter->setBrush(*qdegradeTrait);

    painter->drawRect(pixmapSansBordure->rect());

    mettreAJourPixmap();
}
void BuildCarte::changerCouleure2() {
    QPixmap pix(30, 30);
    QColor * c = new QColor(QColorDialog::getRgba());
    couleuresDegrade.replace(1, c);
    pix.fill(*couleuresDegrade.at(1));
    p2->setIcon(QIcon(pix));
    p22->setIcon(QIcon(pix));

    qdegradeRond->setColorAt(0.5, *c);
    qdegradeTrait->setColorAt(0.5, *c);

    if(degrade->type() == QGradient::RadialGradient)
        painter->setBrush(*qdegradeRond);
    else if(degrade->type() == QGradient::LinearGradient)
        painter->setBrush(*qdegradeTrait);

    painter->drawRect(pixmapSansBordure->rect());

    mettreAJourPixmap();
}
void BuildCarte::changerCouleure3() {
    QPixmap pix(30, 30);
    QColor * c = new QColor(QColorDialog::getRgba());
    couleuresDegrade.replace(2, c);
    pix.fill(*couleuresDegrade.at(2));
    p3->setIcon(QIcon(pix));
    p33->setIcon(QIcon(pix));

    qdegradeRond->setColorAt(1.0, *c);
    qdegradeTrait->setColorAt(1.0, *c);

    if(degrade->type() == QGradient::RadialGradient)
        painter->setBrush(*qdegradeRond);
    else if(degrade->type() == QGradient::LinearGradient)
        painter->setBrush(*qdegradeTrait);

    painter->drawRect(pixmapSansBordure->rect());

    mettreAJourPixmap();
}

void BuildCarte::degradeRondWidgetCentreX(int i) {
    if(degrade->type() == QGradient::RadialGradient) {
        qdegradeRond->setCenter(i, qdegradeRond->center().y());
        painter->setBrush(*qdegradeRond);
        painter->drawRect(pixmapSansBordure->rect());

        degradeRondWidgetCentre = QPointF(i, qdegradeRond->center().y());

        mettreAJourPixmap();
    }
}

void BuildCarte::degradeRondWidgetCentreY(int i) {
    if(degrade->type() == QGradient::RadialGradient) {
        qdegradeRond->setCenter(qdegradeRond->center().x(), i);
        painter->setBrush(*qdegradeRond);
        painter->drawRect(pixmapSansBordure->rect());

        degradeRondWidgetCentre = QPointF(qdegradeRond->center().x(), i);

        mettreAJourPixmap();
    }
}

void BuildCarte::degradeRondWidgetRadiusQ(int i) {
    if(degrade->type() == QGradient::RadialGradient) {
        qdegradeRond->setRadius(i);
        painter->setBrush(*qdegradeRond);
        painter->drawRect(pixmapSansBordure->rect());

        degradeRondWidgetRadius = i;

        mettreAJourPixmap();
    }
}

void BuildCarte::degradeRondWidgetFocalX(int i) {
    if(degrade->type() == QGradient::RadialGradient) {
        qdegradeRond->setFocalPoint(i, qdegradeRond->focalPoint().y());
        painter->setBrush(*qdegradeRond);
        painter->drawRect(pixmapSansBordure->rect());

        degradeRondWidgetFocal = QPointF(i, qdegradeRond->focalPoint().y());

        mettreAJourPixmap();
    }
}

void BuildCarte::degradeRondWidgetFocalY(int i) {
    if(degrade->type() == QGradient::RadialGradient) {
        qdegradeRond->setFocalPoint(qdegradeRond->focalPoint().x(), i);
        painter->setBrush(*qdegradeRond);
        painter->drawRect(pixmapSansBordure->rect());

        degradeRondWidgetFocal = QPointF(qdegradeRond->focalPoint().x(), i);

        mettreAJourPixmap();
    }
}
//------------------ FIN DEGRADE ROND ------------------

//------------------ DEBUT DEGRADE TRAIT ------------------
void BuildCarte::degradeTrait() {
    qdegradeTrait = new QLinearGradient(*degradeTraitWidgetDepart, *degradeTraitWidgetFin);
    degrade = qdegradeTrait;

    qdegradeTrait->setColorAt(0.0, *couleuresDegrade.at(0));
    qdegradeTrait->setColorAt(0.5, *couleuresDegrade.at(1));
    qdegradeTrait->setColorAt(1.0, *couleuresDegrade.at(2));

    painter->setBrush(*qdegradeTrait);
    painter->drawRect(pixmapSansBordure->rect());

    painter2->setBrush(*couleureBordure);
    painter2->drawRect(pixmapAvecBordure->rect());
    painter2->drawPixmap(bordureX, bordureY, pixmapSansBordure->width()-(2*bordureX), pixmapSansBordure->height()-(2*bordureY), *pixmapSansBordure);
    mettreAJourPixmap();
}

QWidget* BuildCarte::buildDegradeTraitWidget() {
    QGroupBox * degradeTraitWidget = new QGroupBox(this);
    degradeTraitWidget->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);

    QBoxLayout * Hlayout1 = new QBoxLayout(QBoxLayout::LeftToRight);//1
    Hlayout1->addWidget(new QLabel(QString().setNum(0.0)));
    p11 = new QPushButton(p1);
    connect(p11, SIGNAL(pressed()), this, SLOT(changerCouleure1()));
    Hlayout1->addWidget(p11);
    QPixmap pix1(30, 30);
    pix1.fill(*couleuresDegrade.at(0));
    p11->setIcon(QIcon(pix1));
    layout->addLayout(Hlayout1);
    QBoxLayout * Hlayout2 = new QBoxLayout(QBoxLayout::LeftToRight);//2
    Hlayout2->addWidget(new QLabel(QString().setNum(0.5)));
    p22 = new QPushButton(p2);
    connect(p22, SIGNAL(pressed()), this, SLOT(changerCouleure1()));
    Hlayout2->addWidget(p22);
    QPixmap pix2(30, 30);
    pix2.fill(*couleuresDegrade.at(1));
    p22->setIcon(QIcon(pix2));
    layout->addLayout(Hlayout2);
    QBoxLayout * Hlayout3 = new QBoxLayout(QBoxLayout::LeftToRight);//3
    Hlayout3->addWidget(new QLabel(QString().setNum(1.0)));
    p33 = new QPushButton(p3);
    connect(p33, SIGNAL(pressed()), this, SLOT(changerCouleure1()));
    Hlayout3->addWidget(p33);
    QPixmap pix3(30, 30);
    pix3.fill(*couleuresDegrade.at(2));
    p33->setIcon(QIcon(pix3));
    layout->addLayout(Hlayout3);

    layout->addWidget(new QLabel(trUtf8("Coordonnée X du point de départ")));
    QSlider * qsliderXDepart = new QSlider(Qt::Horizontal);
    qsliderXDepart->setValue(degradeTraitWidgetDepart->x());
    qsliderXDepart->setMinimum(0);
    qsliderXDepart->setMaximum(pixmapSansBordure->width());
    connect(qsliderXDepart,SIGNAL(valueChanged(int)),this,SLOT(degradeTraitWidgetDepartX(int)));
    layout->addWidget(qsliderXDepart);

    layout->addWidget(new QLabel(trUtf8("Coordonnée Y du point de départ")));
    QSlider * qsliderYDepart = new QSlider(Qt::Horizontal);
    qsliderYDepart->setValue(degradeTraitWidgetDepart->y());
    qsliderYDepart->setMinimum(0);
    qsliderYDepart->setMaximum(pixmapSansBordure->height());
    connect(qsliderYDepart,SIGNAL(valueChanged(int)),this,SLOT(degradeTraitWidgetDepartY(int)));
    layout->addWidget(qsliderYDepart);

    layout->addWidget(new QLabel(trUtf8("Coordonnée X du point d'arrivée")));
    QSlider * qsliderXArrivee = new QSlider(Qt::Horizontal);
    qsliderXArrivee->setValue(degradeTraitWidgetFin->x());
    qsliderXArrivee->setMinimum(0);
    qsliderXArrivee->setMaximum(pixmapSansBordure->width());
    connect(qsliderXArrivee,SIGNAL(valueChanged(int)),this,SLOT(degradeTraitWidgetArriveeX(int)));
    layout->addWidget(qsliderXArrivee);

    layout->addWidget(new QLabel(trUtf8("Coordonnée Y du point d'arrivée")));
    QSlider * qsliderYArrivee = new QSlider(Qt::Horizontal);
    qsliderYArrivee->setValue(degradeTraitWidgetFin->y());
    qsliderYArrivee->setMinimum(0);
    qsliderYArrivee->setMaximum(pixmapSansBordure->height());
    connect(qsliderYArrivee,SIGNAL(valueChanged(int)),this,SLOT(degradeTraitWidgetArriveeY(int)));
    layout->addWidget(qsliderYArrivee);

    degradeTraitWidget->setLayout(layout);
    return degradeTraitWidget;
}

void BuildCarte::degradeTraitWidgetDepartX(int i) {
    if(degrade->type() == QGradient::LinearGradient) {
        qdegradeTrait->setStart(i, degradeTraitWidgetDepart->y());
        painter->setBrush(*qdegradeTrait);
        painter->drawRect(pixmapSansBordure->rect());
        mettreAJourPixmap();
    }
}

void BuildCarte::degradeTraitWidgetDepartY(int i) {
    if(degrade->type() == QGradient::LinearGradient) {
        qdegradeTrait->setStart(degradeTraitWidgetDepart->x(), i);
        painter->setBrush(*qdegradeTrait);
        painter->drawRect(pixmapSansBordure->rect());
        mettreAJourPixmap();
    }
}

void BuildCarte::degradeTraitWidgetArriveeX(int i) {
    if(degrade->type() == QGradient::LinearGradient) {
        qdegradeTrait->setFinalStop(i, degradeTraitWidgetFin->y());
        painter->setBrush(*qdegradeTrait);
        painter->drawRect(pixmapSansBordure->rect());
        mettreAJourPixmap();
    }
}

void BuildCarte::degradeTraitWidgetArriveeY(int i) {
    if(degrade->type() == QGradient::LinearGradient) {
        qdegradeTrait->setFinalStop(degradeTraitWidgetFin->x(), i);
        painter->setBrush(*qdegradeTrait);
        painter->drawRect(pixmapSansBordure->rect());
        mettreAJourPixmap();
    }
}
//------------------ FIN DEGRADE TRAIT ------------------

void BuildCarte::degradeAucun() {
    couleureEnCours = couleure[0];
    painter->setBrush(QBrush(*couleureEnCours));
    painter->drawRect(pixmapSansBordure->rect());
    mettreAJourPixmap();
}

QWidget* BuildCarte::Bordure() {
    QWidget * bordureWidget = new QWidget(this);
    bordureWidget->setMinimumSize(largeure/2, 120);
    bordureWidget->setMaximumSize(largeure/2, 120);
    bordureWidget->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);
    QBoxLayout * Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);

    bouttonBordure = new QPushButton(p1);
    connect(bouttonBordure, SIGNAL(pressed()), this, SLOT(changerCouleureBordure()));
    couleureBordure = new QColor(*couleuresDegrade.at(0));
    QPixmap pix1(30, 30);
    pix1.fill(*couleureBordure);
    bouttonBordure->setIcon(QIcon(pix1));
    Hlayout->addWidget(new QLabel(trUtf8("Couleure : ")));
    Hlayout->addWidget(bouttonBordure);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Largeure : ")));
    QSlider * qsliderXDepart = new QSlider(Qt::Horizontal);
    qsliderXDepart->setValue(bordureX);
    qsliderXDepart->setMinimum(0);
    qsliderXDepart->setMaximum(pixmapSansBordure->width()/2);
    connect(qsliderXDepart,SIGNAL(valueChanged(int)),this,SLOT(changerBordureX(int)));
    Hlayout->addWidget(qsliderXDepart);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Hauteure : ")));
    QSlider * qsliderYDepart = new QSlider(Qt::Horizontal);
    qsliderYDepart->setValue(bordureY);
    qsliderYDepart->setMinimum(0);
    qsliderYDepart->setMaximum(pixmapSansBordure->height()/2);
    connect(qsliderYDepart,SIGNAL(valueChanged(int)),this,SLOT(changerBordureY(int)));
    Hlayout->addWidget(qsliderYDepart);
    layout->addLayout(Hlayout);

    bordureWidget->setLayout(layout);
    return bordureWidget;
}

void BuildCarte::changerCouleureBordure() {
    QPixmap pix(30, 30);
    QColor * c = new QColor(QColorDialog::getRgba());
    couleureBordure = c;
    pix.fill(*c);
    bouttonBordure->setIcon(QIcon(pix));
    mettreAJourPixmap();
}

void BuildCarte::changerBordureX(int i) {
    bordureX = i;
    mettreAJourPixmap();
}

void BuildCarte::changerBordureY(int i) {
    bordureY = i;
    mettreAJourPixmap();
}

QWidget* BuildCarte::Image() {

//    url;
    //déplacé dan aucun dégradé fer soi couleure soi image avec QCheckBox ou QRadio
}

QWidget* BuildCarte::Text() {
    QWidget * textWidget = new QWidget(this);
    textWidget->setMinimumSize(largeure/2, 160);
    textWidget->setMaximumSize(largeure/2, 160);
    textWidget->setAttribute(Qt::WA_DeleteOnClose);
    QBoxLayout * layout = new QBoxLayout(QBoxLayout::TopToBottom);
    QBoxLayout * Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);

    Hlayout->addWidget(new QLabel(trUtf8("Texte : ")));
    qlineeditText = new QLineEdit(this);
    Hlayout->addWidget(qlineeditText);
    QPushButton * validerText = new QPushButton(trUtf8("Valider"));
    connect(validerText, SIGNAL(pressed()), this, SLOT(changerText()));
    Hlayout->addWidget(validerText);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Couleure : ")));
    bouttonText = new QPushButton(p1);
    connect(bouttonText, SIGNAL(pressed()), this, SLOT(changerCouleureText()));
    couleureText = new QColor(*couleuresDegrade.at(0));
    QPixmap pix1(30, 30);
    pix1.fill(*couleureText);
    bouttonText->setIcon(QIcon(pix1));
    Hlayout->addWidget(bouttonText);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Coordonnée X du texte")));
    QSlider * qsliderXDepartText = new QSlider(Qt::Horizontal);
    qsliderXDepartText->setValue(textX);
    qsliderXDepartText->setMinimum(0);
    qsliderXDepartText->setMaximum(pixmapSansBordure->width());
    connect(qsliderXDepartText,SIGNAL(valueChanged(int)),this,SLOT(changerTextX(int)));
    Hlayout->addWidget(qsliderXDepartText);
    layout->addLayout(Hlayout);

    Hlayout = new QBoxLayout(QBoxLayout::LeftToRight);
    Hlayout->addWidget(new QLabel(trUtf8("Coordonnée Y du texte")));
    QSlider * qsliderYDepartText = new QSlider(Qt::Horizontal);
    qsliderYDepartText->setValue(textY);
    qsliderYDepartText->setMinimum(0);
    qsliderYDepartText->setMaximum(pixmapSansBordure->height());
    connect(qsliderYDepartText,SIGNAL(valueChanged(int)),this,SLOT(changerTextY(int)));
    Hlayout->addWidget(qsliderYDepartText);
    layout->addLayout(Hlayout);

    textWidget->setLayout(layout);
    return textWidget;
}

void BuildCarte::changerText() {
    text = qlineeditText->text();
    mettreAJourPixmap();
}

void BuildCarte::changerCouleureText() {
    QPixmap pix(30, 30);
    QColor * c = new QColor(QColorDialog::getRgba());
    couleureText = c;
    pix.fill(*c);
    bouttonText->setIcon(QIcon(pix));

    mettreAJourPixmap();
}

void BuildCarte::changerTextX(int i) {
    textX = i;
    mettreAJourPixmap();
}

void BuildCarte::changerTextY(int i) {
    textY = i;
    mettreAJourPixmap();
}

void BuildCarte::mettreAJourPixmap() {
    painter3->setBrush(*couleureBordure);
    painter3->setPen(*couleureBordure);
    painter3->drawRect(pixmapAvecBordure->rect());
    painter3->drawPixmap(bordureX, bordureY, pixmapSansBordure->width()-(2*bordureX), pixmapSansBordure->height()-(2*bordureY), *pixmapSansBordure);
    painter3->setPen(*couleureText);
    painter3->drawText(QPoint(textX, textY), text);
    painter3->setPen(*couleureBordure);
    image->setPixmap(*pixmapAvecText);
}

void BuildCarte::save() {
    image->pixmap()->save(file, "PNG");
    file->close();
    this->close();
}

QPixmap BuildCarte::getPixmap() {
    return *pixmapAvecText;
}
