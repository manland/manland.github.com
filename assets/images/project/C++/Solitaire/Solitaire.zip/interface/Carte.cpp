/********************************************************
  Créé par Romain Maneschi
  n° Etudiant : 20053659

  Classe permettant de gérer une Carte : sa valeure, sa famille, et son apparence
  *******************************************************/

#include "Carte.h"

#include "MaFrame.h"
#include "Jeux.h"

Carte::Carte(QWidget *parent) : QLabel(parent) {
    x = 0;
    y = 0;
    largeure = 71;
    hauteure = 96;
    valeure = 0;
    famille = "vide";
    visibilite = true;
	
    setAttribute(Qt::WA_DeleteOnClose);
}

Carte::Carte(int valeure2, QString famille2, QWidget *parent) : QLabel(parent) {
    x = 0;
    y = 0;
    largeure = 71;
    hauteure = 96;
    valeure = valeure2;
    famille = famille2;
    visibilite = true;

    if(valeure == 0 && famille == "vide") {
        pixmapVide();
    }
    else if(valeure == 0 && famille == "videPioche") {
        pixmapVidePioche();
    }
    else {
        if(famille == "pique" || famille=="trefle")
            couleure = "noir";
        else
            couleure = "rouge";
        pixmapVisible();
    }
    setGeometry(x, y, largeure, hauteure);
    show();
    setAttribute(Qt::WA_DeleteOnClose);
}

int Carte::getX() {return x;}
int Carte::getY() {return y;}
int Carte::getHauteure() {return hauteure;}
int Carte::getLargeure() {return largeure;}
int Carte::getValeure() {return valeure;}
QString Carte::getFamille() {return famille;}
QString Carte::getCouleure() {return couleure;}
bool Carte::getVisibilite() {return visibilite;}

void Carte::setX(int x2) {x = x2;move(x, y);}
void Carte::setY(int y2) {y = y2;move(x, y);}
void Carte::setHauteure(int h) {
    hauteure = h;
    setPixmap(pixmap()->scaled(largeure, hauteure, Qt::IgnoreAspectRatio));
}
void Carte::setLargeure(int l) {
    largeure = l;
    setPixmap(pixmap()->scaled(largeure, hauteure, Qt::IgnoreAspectRatio));
}
void Carte::setValeure(int v) {valeure = v;}
void Carte::setFamille(QString f) {famille = f;}
void Carte::setVisibilite(bool visibilite2) {
    visibilite = visibilite2;

    if(!visibilite) {
        pixmapNonVisible();
    }
    else if(valeure == 0 && famille == "vide")
        pixmapVide();
    else {
        pixmapVisible();
    }
}

void Carte::pixmapVide() {
    MaFrame * f = static_cast<MaFrame*>(this->parentWidget());
    if(f->getCarteVide() == "0")
        moveEvent(new QMoveEvent(QPoint(), QPoint()));
    else {
        QPixmap tempPixmap = QPixmap(f->getCarteVide());
        setPixmap(tempPixmap);
    }
}

void Carte::setAccessible() {
    QPixmap tempPixmap = *this->pixmap();

    QRadialGradient gradient(tempPixmap.rect().width()/2, tempPixmap.rect().height()/2, 90);
    gradient.setColorAt(0.0, QColor(255, 255, 255, 150));
    gradient.setColorAt(1.0, QColor(0, 0, 200, 150));

    QPainter painter(&tempPixmap);
    painter.setBrush(gradient);
    painter.setPen(QColor(0, 0, 153, 220));
    painter.drawRect(tempPixmap.rect());

    setPixmap(tempPixmap);
}

void Carte::pixmapVidePioche() {
    MaFrame * f = static_cast<MaFrame*>(this->parentWidget());
    if(f->getCarteVide() == "0") {
        moveEvent(new QMoveEvent(QPoint(), QPoint()));
    }
    else {
        QPixmap tempPixmap = QPixmap(f->getCarteVide());
        setPixmap(tempPixmap);
    }
}

void Carte::pixmapVisible() {
    QString temp = "icons/cartes-gif/";
    temp.append(QString().setNum(valeure));
    temp.append(famille);
    temp.append(".gif");
    setPixmap(QPixmap(temp));
}

void Carte::pixmapNonVisible() {
    MaFrame * f = static_cast<MaFrame*>(this->parentWidget());
    QPixmap tempPixmap = QPixmap(f->getCarteDos());
//    QPixmap tempPixmap = QPixmap("icons/cartes-gif/vide.gif");

//    QPainter painter(&tempPixmap);
//
//    painter.setBrush(QColor(255, 255, 255));
//    painter.setPen(QColor(255, 255, 255));
//    painter.drawRect(tempPixmap.rect());
//
//    QRadialGradient gradient(tempPixmap.rect().width()/2, tempPixmap.rect().height()/2, 100);
//    gradient.setColorAt(0.0, Qt::yellow);
//    gradient.setColorAt(0.8, Qt::red);
//
//    painter.setBrush(gradient);
//    painter.setPen(QColor(255, 0, 0));
//    painter.drawRect(5.0, 5.0, tempPixmap.rect().width()-10.0, tempPixmap.rect().height()-10.0);
//    painter.drawText(tempPixmap.rect(), Qt::AlignCenter, trUtf8("m@n\nSolitaire"));
    setPixmap(tempPixmap);
}

void Carte::moveEvent(QMoveEvent * event) {
    MaFrame * f = static_cast<MaFrame*>(this->parentWidget());
    if(this->valeure == 0 && (this->famille == "vide" || this->famille == "videPioche") && f->getCarteVide() == "0") {
        QPixmap tempPixmap(largeure, hauteure);

        QPainter painter(&tempPixmap);
//    painter.setPen(QColor(0, 0, 255, 0));
        painter.setBrush(QBrush(QPixmap("01.png")));

        MaFrame * maframe = static_cast<MaFrame*>(this->parentWidget());
        Jeux * jeux = static_cast<Jeux*>(maframe->parentWidget());

        QRadialGradient gradient(tempPixmap.rect().width()/2, tempPixmap.rect().height()/2, 90);

        gradient.setColorAt(0.0, QColor(200, 200, 200));
        gradient.setColorAt(1.0, Qt::black);

        painter.setBrush(gradient);

        painter.drawRect(tempPixmap.rect());

        painter.setBrush(QColor(0, 153, 0, 255));
        painter.drawRect(5.0, 5.0, tempPixmap.rect().width()-10.0, tempPixmap.rect().height()-10.0);

        painter.drawPixmap(5.0, 5.0, QPixmap("01.png"), jeux->mapToParent(maframe->mapToParent(this->pos())).x(), jeux->mapToParent(maframe->mapToParent(this->pos())).y(), largeure-10.0, hauteure-10.0);
        painter.setPen(QColor(0, 0, 0));
        painter.setPen(QColor(0, 0, 0, 255));
        painter.setBrush(QBrush(QColor(0, 0, 0, 120)));
        painter.drawRect(tempPixmap.rect());
        painter.drawText(tempPixmap.rect(), Qt::AlignCenter, trUtf8("Vide"));

        setPixmap(tempPixmap);
    }
}
