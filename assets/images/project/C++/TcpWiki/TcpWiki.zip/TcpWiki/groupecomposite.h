#ifndef GROUPECOMPOSITE_H
#define GROUPECOMPOSITE_H

#include <vector>
#include <string>
#include <iostream>
using namespace std;

class Groupe;

class GroupeComposite
{
protected:
    string nom;
    Groupe * parent;
public:
    GroupeComposite(string = "", Groupe* = NULL);
    virtual ~GroupeComposite();
    virtual string absoluteAdresse();
    virtual string getNom();
    virtual Groupe* getParent();
    virtual void setParent(Groupe*);
};

#endif // GROUPECOMPOSITE_H
