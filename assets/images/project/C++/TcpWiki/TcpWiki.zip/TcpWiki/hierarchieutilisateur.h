#ifndef HIERARCHIEUTILISATEUR_H
#define HIERARCHIEUTILISATEUR_H

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <utility>
#include <stdlib.h>
#include <string.h>
using namespace std;

#include "groupecomposite.h"
#include "groupe.h"
#include "utilisateur.h"
#include "sha1.h"

class HierarchieUtilisateur
{
private:
    Groupe * groupe_utilisateurs;//1er groupe contenant tous les autres
    Utilisateur * admin;
    Groupe * bannis;//groupe obligatoir des bannis
    vector< pair<string, Groupe*> > * proprioS;//permet de charger les proprio des groupe lors de la restauration du dur !!
public:
    HierarchieUtilisateur();
    virtual ~HierarchieUtilisateur();
    virtual string cryptageSha1(string);
    virtual Utilisateur* estUtilisateur(string, string);
    virtual Utilisateur* estUtilisateur(string);
    virtual Groupe* ajouterGroupe(string, Groupe*, Utilisateur*);
    virtual Utilisateur* ajouterUtilisateur(string, Groupe*, string, string, int);
    virtual void enregistrerUtilisateursEnDur();
    virtual void enregistrerUtilisateurEnDur(Utilisateur*);
    virtual void enregistrerInfosServeurEnDur();
    virtual void enregistrerHistoriqueUtilisateurs();
    virtual void enregistrerHistoriqueUtilisateur(Utilisateur*);
    virtual void restaurerInfoServeurDuDur();
    virtual void restaurerUtilisateursDuDur();
    virtual void enregistrerGroupesEnDur();
    virtual void enregistrerGroupeEnDur(Groupe*);
    virtual void restaurerGroupesDuDur();
    virtual Groupe* getGroupeRoot();
    virtual string getUtilisateurs();
    virtual Utilisateur* getAdmin();
    virtual vector< pair<string, Groupe*> > * getProprioS();
    virtual Groupe* lierProprietaireGroupe(Utilisateur*);
    virtual Groupe* getGroupeBannis();
    virtual void configurerServeur();
};

#endif // HIERARCHIEUTILISATEUR_H
