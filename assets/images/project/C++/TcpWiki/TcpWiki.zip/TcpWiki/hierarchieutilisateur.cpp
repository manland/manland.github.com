#include "hierarchieutilisateur.h"

HierarchieUtilisateur::HierarchieUtilisateur()
{
    groupe_utilisateurs = new Groupe("utilisateurs", NULL, NULL);
    bannis = new Groupe("Bannis", NULL, NULL);
    restaurerInfoServeurDuDur();
    if(admin == NULL) {
        configurerServeur();
    }
    bannis->setProprietaire(admin);
    groupe_utilisateurs->setProprietaire(admin);
    proprioS = new vector< pair<string, Groupe*> >;
    restaurerGroupesDuDur();
    restaurerUtilisateursDuDur();
//    lierProprietaireGroupe(admin);
}

HierarchieUtilisateur::~HierarchieUtilisateur() {
    delete groupe_utilisateurs;
    delete admin;
    delete bannis;
    proprioS->clear();
    delete proprioS;
}

string HierarchieUtilisateur::cryptageSha1(string mot) {
    SHA1 sha;
    string resultatSha1;
    unsigned messageDigest[5];
    sha.Reset();
    sha<<mot.c_str();
    if (!sha.Result(messageDigest))
        cout<<"Probleme avec le sha1 apres la réception du mot de passe pour l'authentification"<<endl;
    else {
        char buffer[50]="0";
        for (int i =0; i<5; i++) {
            sprintf(buffer,"%x",messageDigest[i]);
            resultatSha1 = resultatSha1 + buffer;
        }
    }
    return resultatSha1;
}

Utilisateur* HierarchieUtilisateur::estUtilisateur(string nom, string mdp) {
    Utilisateur * u = NULL;
    vector<Utilisateur*> * utis_ban = bannis->tousMesUtilisateursRecursif();
    vector<Utilisateur*> * utilisateurS = groupe_utilisateurs->tousMesUtilisateursRecursif();
    utilisateurS->push_back(admin);
    for(int i=0; i<utis_ban->size(); i++) {
        utilisateurS->push_back(utis_ban->at(i));
    }
    for(int i=0; i<utilisateurS->size(); i++) {
        if(utilisateurS->at(i)->getNom() == nom && utilisateurS->at(i)->getMotDePasse() == mdp) {
            u = utilisateurS->at(i);
        }
    }
    return u;
}

Utilisateur* HierarchieUtilisateur::estUtilisateur(string nom) {
    Utilisateur * u = NULL;
    vector<Utilisateur*> * utis_ban = bannis->tousMesUtilisateursRecursif();
    vector<Utilisateur*> * utilisateurS = groupe_utilisateurs->tousMesUtilisateursRecursif();
    utilisateurS->push_back(admin);
    for(int i=0; i<utis_ban->size(); i++) {
        utilisateurS->push_back(utis_ban->at(i));
    }
    for(int i=0; i<utilisateurS->size(); i++) {
        if(utilisateurS->at(i)->getNom() == nom) {
            u = utilisateurS->at(i);
        }
    }
    return u;
}

Groupe* HierarchieUtilisateur::ajouterGroupe(string nom, Groupe * parent, Utilisateur * proprio) {
    if(parent == NULL) {
        parent = groupe_utilisateurs;
    }
    Groupe * g = new Groupe(nom, parent, proprio);
    return g;
}

Utilisateur* HierarchieUtilisateur::ajouterUtilisateur(string nom, Groupe * parent, string pwd, string i, int p) {
    if(parent == NULL) {
        parent = groupe_utilisateurs;
    }
    Utilisateur * u = new Utilisateur(nom, parent, pwd, i, p);
    return u;
}

void HierarchieUtilisateur::enregistrerUtilisateursEnDur() {
    vector<Utilisateur*> * utis_ban = bannis->tousMesUtilisateursRecursif();
    vector<Utilisateur*> * v = groupe_utilisateurs->tousMesUtilisateursRecursif();
    for(int i=0; i<utis_ban->size(); i++) {
        v->push_back(utis_ban->at(i));
    }
    ofstream fichier("utilisateurs", ios::out | ios::trunc);//ouverture en écriture avec effacement du fichier ouvert
    if(fichier && v)
    {
        for(int i=0; i<v->size(); i++) {
            if(v->at(i)->getNom() != admin->getNom()) {//on en registre pas l'admin car il a son propre fichier
                fichier<<v->at(i)->getGroupe()->getNom()<<"#";
                fichier<<v->at(i)->getNom()<<"#"<<v->at(i)->getMotDePasse()<<"#";
                fichier<<v->at(i)->getIp()<<"#"<<v->at(i)->getPort();
                fichier<<endl;
            }
        }
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en écriture !"<<endl;
}

void HierarchieUtilisateur::enregistrerUtilisateurEnDur(Utilisateur * u) {
    ofstream fichier("utilisateurs", ios::app);//ouverture en écriture avec effacement du fichier ouvert
    if(fichier)
    {
        fichier<<u->getGroupe()->getNom()<<"#";
        fichier<<u->getNom()<<"#"<<u->getMotDePasse()<<"#";
        fichier<<u->getIp()<<"#"<<u->getPort();
        fichier<<endl;
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en écriture !"<<endl;
}

void HierarchieUtilisateur::enregistrerInfosServeurEnDur() {
    ofstream fichier("infos_serveur", ios::app);//ouverture en écriture avec effacement du fichier ouvert
    if(fichier)
    {
        //admin
        fichier<<admin->getGroupe()->getNom()<<"#";
        fichier<<admin->getNom()<<"#"<<admin->getMotDePasse()<<"#";
        fichier<<admin->getIp()<<"#"<<admin->getPort();
        fichier<<endl;
        //nom_groupe_utilisateur
        fichier<<groupe_utilisateurs->getNom()<<endl;
        //nom_groupe_bannis
        fichier<<bannis->getNom()<<endl;
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en écriture !"<<endl;
}

void HierarchieUtilisateur::enregistrerHistoriqueUtilisateurs() {
    vector<Utilisateur*> * v = groupe_utilisateurs->tousMesUtilisateursRecursif();
    for(int i=0; i<v->size(); i++) {
        string nom = "Utilisateur/" + v->at(i)->getNom();
        ofstream fichier(nom.c_str(), ios::app);//ouverture en écriture
        if(fichier) {
            if(v->at(i)->getHistorique()->size() > 0) {
                fichier<<"----------------------JOUR.MOIS.ANNEE---------------------"<<endl;
                for(int j=0; j<v->at(i)->getHistorique()->size(); j++) {
                    fichier<<v->at(i)->getHistorique()->at(j)<<endl;
                }
            }
            fichier.close();
        }
        else
            cout<<"Impossible d'ouvrir le fichier "<<nom<<" en écriture !"<<endl;
    }
}

void HierarchieUtilisateur::enregistrerHistoriqueUtilisateur(Utilisateur * u) {
    string nom = "Utilisateur/" + u->getNom();
    ofstream fichier(nom.c_str(), ios::app);//ouverture en écriture
    if(fichier) {
        if(u->getHistorique()->size()) {
            fichier<<"----------------------JOUR.MOIS.ANNEE---------------------"<<endl;
            for(int j=0; j<u->getHistorique()->size(); j++) {
                fichier<<u->getHistorique()->at(j)<<endl;
            }
        }
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier "<<nom<<" en écriture !"<<endl;
}

void HierarchieUtilisateur::restaurerInfoServeurDuDur() {
    Utilisateur * u = NULL;
    ifstream fichier("infos_serveur", ios::in);//ouverture du fichier en lecture
    if(fichier)
    {
        string ligne = "";
        getline(fichier, ligne);
        //ADMIN
        string parent = "";
        string pseudo = "";
        string pass = "";
        string ip = "";
        string port = "";
        int i = 0;
        while(ligne[i] != '#') {//on lit jusqu'au #
            parent = parent + ligne[i];
            i++;
        }
        i++;//permet d'enlever le '#'
        while(ligne[i] != '#') {//on lit jusqu'au #
            pseudo = pseudo + ligne[i];
            i++;
        }
        i++;//permet d'enlever le '#'
        while(ligne[i] != '#') {//on lit jusqu'au #
            pass = pass + ligne[i];
            i++;
        }
        i++;//permet d'enlever le '#'
        while(ligne[i] != '#') {//on lit jusqu'au #
            ip = ip + ligne[i];
            i++;
        }
        i++;//permet d'enlever le '#'
        while(i<ligne.size()) {//puis jusqu'à la fin
            port = port + ligne[i];
            i++;
        }
        int port2 = atoi(port.c_str());
        if(parent == groupe_utilisateurs->getNom()) {
            u = ajouterUtilisateur(pseudo, groupe_utilisateurs, pass, ip, port2);
        }
        else if(parent == bannis->getNom()) {
            u = ajouterUtilisateur(pseudo, bannis, pass, ip, port2);
        }
        else {
            vector<Groupe*> * g = groupe_utilisateurs->tousMesGroupesRecursif();
            for(int i=0; i<g->size(); i++) {
                if(g->at(i)->getNom() == parent) {
                    u = ajouterUtilisateur(pseudo, g->at(i), pass, ip, port2);
                }
            }
        }
        admin = u;

        getline(fichier, ligne);
        //NOM GROUPE UTILISATEUR
        string nom_groupe_utilisateurs = ligne;
        groupe_utilisateurs->setNom(nom_groupe_utilisateurs);

        getline(fichier, ligne);
        //NOM GROUPE BANNIS
        string nom_groupe_bannis = ligne;
        bannis->setNom(ligne);
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en lecture !"<<endl;
}

void HierarchieUtilisateur::restaurerUtilisateursDuDur() {
    ifstream fichier("utilisateurs", ios::in);//ouverture du fichier en lecture
    if(fichier)
    {
        string ligne = "";
        while(getline(fichier, ligne))//tant qu'il y a des lignes à lire
        {
            string parent = "";
            string pseudo = "";
            string pass = "";
            string ip = "";
            string port = "";
            int i = 0;
            while(ligne[i] != '#') {//on lit jusqu'au #
                parent = parent + ligne[i];
                i++;
            }
            i++;//permet d'enlever le '#'
            while(ligne[i] != '#') {//on lit jusqu'au #
                pseudo = pseudo + ligne[i];
                i++;
            }
            i++;//permet d'enlever le '#'
            while(ligne[i] != '#') {//on lit jusqu'au #
                pass = pass + ligne[i];
                i++;
            }
            i++;//permet d'enlever le '#'
            while(ligne[i] != '#') {//on lit jusqu'au #
                ip = ip + ligne[i];
                i++;
            }
            i++;//permet d'enlever le '#'
            while(i<ligne.size()) {//puis jusqu'à la fin
                port = port + ligne[i];
                i++;
            }
            int port2 = atoi(port.c_str());
            Utilisateur * u = NULL;
            if(parent == groupe_utilisateurs->getNom()) {
                u = ajouterUtilisateur(pseudo, groupe_utilisateurs, pass, ip, port2);
            }
            else if(parent == bannis->getNom()) {
                u = ajouterUtilisateur(pseudo, bannis, pass, ip, port2);
            }
            else {
                vector<Groupe*> * g = groupe_utilisateurs->tousMesGroupesRecursif();
                for(int i=0; i<g->size(); i++) {
                    if(g->at(i)->getNom() == parent) {
                        u = ajouterUtilisateur(pseudo, g->at(i), pass, ip, port2);
                    }
                }
            }
            if(u)
                lierProprietaireGroupe(u);
        }
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en lecture !"<<endl;
}

void HierarchieUtilisateur::enregistrerGroupesEnDur() {
    vector<Groupe*> * v = groupe_utilisateurs->tousMesGroupesRecursif();
    ofstream fichier("groupes", ios::out | ios::trunc);//ouverture en écriture avec effacement du fichier ouvert
    if(fichier && v)
    {
        for(int i=0; i<v->size(); i++) {
            fichier<<v->at(i)->getNom()<<"#";
            fichier<<v->at(i)->getParent()->getNom()<<"#";
            fichier<<v->at(i)->getProprietaire()->getNom();
            fichier<<endl;
        }
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des groupes en écriture !"<<endl;
}

void HierarchieUtilisateur::enregistrerGroupeEnDur(Groupe * g) {
    ofstream fichier("groupes", ios::app);//ouverture en écriture avec effacement du fichier ouvert
    if(fichier)
    {
        fichier<<g->getNom()<<"#";
        fichier<<g->getParent()->getNom()<<"#";
        fichier<<g->getProprietaire()->getNom();
        fichier<<endl;
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en écriture !"<<endl;
}

void HierarchieUtilisateur::restaurerGroupesDuDur() {
    ifstream fichier("groupes", ios::in);
    if(fichier)
    {
        string ligne = "";
        while(getline(fichier, ligne))
        {
            string groupe = "";
            string parent = "";
            string proprio = "";
            int i = 0;
            while(ligne[i] != '#') {//on lit jusqu'au #
                groupe = groupe + ligne[i];
                i++;
            }
            i++;//permet d'enlever le '#'
            while(ligne[i] != '#') {//on lit jusqu'au #
                parent = parent + ligne[i];
                i++;
            }
            i++;//permet d'enlever le '#'
            while(i<ligne.size()) {//puis jusqu'à la fin
                proprio = proprio + ligne[i];
                i++;
            }

            Groupe * temp = NULL;
            if(parent == groupe_utilisateurs->getNom()) {
                temp = ajouterGroupe(groupe, groupe_utilisateurs, NULL);
            }
            else {
                vector<Groupe*> * g = groupe_utilisateurs->tousMesGroupesRecursif();
                for(int i=0; i<g->size(); i++) {
                    if(g->at(i)->getNom() == parent) {
                        temp = ajouterGroupe(groupe, g->at(i), NULL);
                    }
                }
            }
            proprioS->push_back(make_pair(proprio, temp));
        }
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des groupes en lecture !"<<endl;
}

Groupe* HierarchieUtilisateur::getGroupeRoot() {
    return groupe_utilisateurs;
}

string HierarchieUtilisateur::getUtilisateurs() {
    string res = "";
    vector<Utilisateur*> * u = groupe_utilisateurs->tousMesUtilisateurs();
    for(int i =0; i<u->size(); i++) {
        res = res + "[ " + u->at(i)->getNom() + " ] ";
    }
    return res;
}

Utilisateur* HierarchieUtilisateur::getAdmin() {
    return admin;
}

vector< pair<string, Groupe*> >* HierarchieUtilisateur::getProprioS() {
    return proprioS;
}

Groupe* HierarchieUtilisateur::lierProprietaireGroupe(Utilisateur * u) {
    Groupe * g = NULL;
    for(int i=0; i<proprioS->size() && !g; i++) {
        if (u->getNom() == proprioS->at(i).first) {
            proprioS->at(i).second->setProprietaire(u);
            g = proprioS->at(i).second;
        }
    }
    return g;
}

Groupe* HierarchieUtilisateur::getGroupeBannis() {
    return bannis;
}

void HierarchieUtilisateur::configurerServeur() {
    cout<<"Veuillez configurer la partie utilisateur du serveur..."<<endl;
    cout<<"Veuillez entrer le pseudo de l'admin : ";
    string pseudo = "";
    cin>>pseudo;
    cout<<"Veuillez entrer le mot de passe de l'admin : ";
    string pass_en_clair = "";
    cin>>pass_en_clair;
    string pass = cryptageSha1(pass_en_clair);
    admin = new Utilisateur(pseudo, groupe_utilisateurs, pass, "", 0);
    cout<<"Entrez le nom du groupe qui contiendra tous les utilisateurs et tous les sous-groupes d'utilisateurs : ";
    string nom_groupe_utilisateurs = "";
    cin>>nom_groupe_utilisateurs;
    groupe_utilisateurs->setNom(nom_groupe_utilisateurs);
    cout<<"Entrez le nom du groupe qui contiendra les utilisateurs bannis : ";
    string nom_groupe_bannis = "";
    cin>>nom_groupe_bannis;
    bannis->setNom(nom_groupe_bannis);
    enregistrerInfosServeurEnDur();
}
