#ifndef HIERARCHIEDOC_H
#define HIERARCHIEDOC_H

#include "hierarchieutilisateur.h"
#include "categoriecomposite.h"
#include "categorie.h"
#include "article.h"

class HierarchieDoc
{
private:
    Categorie * categorie_root;
    vector<struc_catcomp_proprio> * liaison_doc_proprio;
    vector<string> * articles_en_attente_bannis;
public:
    HierarchieDoc();
    virtual ~HierarchieDoc();
    virtual Categorie* ajouterCategorie(string, Categorie*, Utilisateur*);
    virtual Article* ajouterArticle(string, Categorie*, string, Utilisateur*);
    virtual void enregistrerEnDur();
    virtual void enregistrerArticleEnDur(Article*);
    virtual Categorie* getCategorieRoot();
    virtual string ls(Categorie*);
    virtual string lsDroit(Categorie*);
    virtual void lierDocProprios(HierarchieUtilisateur*);
    virtual bool ajouterArticleEnAttenteBannis(Article*);
    virtual bool retirerArticleEnAttenteBannis(Article*);
    virtual string lsArticleEnAttenteBannis();
    virtual void enregistrerArticleEnAttenteBannis();
    virtual void restaurerArticleEnAttenteBannis();
    virtual CategorieComposite* find(const string);
};

#endif // HIERARCHIEDOC_H
