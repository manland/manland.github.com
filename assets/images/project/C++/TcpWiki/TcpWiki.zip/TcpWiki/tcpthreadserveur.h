#ifndef TCPTHREADSERVEUR_H
#define TCPTHREADSERVEUR_H

#include <pthread.h>

#include "tcpserveur.h"

class TCPThreadServeur;

struct ServeurNumClient {
    TCPThreadServeur * serveur;
    int id_client;
};

class TCPThreadServeur : public TCPserveur
{
private:
    int nb_max_thread;
    int num_thread;
    pthread_t thread;
protected:
//    pthread_mutex_t verrou;
public:
    TCPThreadServeur(int);
    virtual ~TCPThreadServeur();
    virtual void onConnect(const int);
    static void* startThreadEnvoyer(void*);
    static void* startThreadRecevoir(void*);
};
#endif // TCPTHREADSERVEUR_H
