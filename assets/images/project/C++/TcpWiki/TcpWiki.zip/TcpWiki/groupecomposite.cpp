#include "groupecomposite.h"
#include "groupe.h"

GroupeComposite::GroupeComposite(string n, Groupe * p) {
    nom = n;
    parent = p;
    if(parent != NULL) {
        parent->addElement(this);
    }
}

GroupeComposite::~GroupeComposite() {
    delete parent;
}

string GroupeComposite::absoluteAdresse() {
    string resultat = nom;
    Groupe * p = getParent();
    while(p!=NULL) {
        resultat = p->getNom() + "/" + resultat;
        p = p->getParent();
    }
    return resultat;
}

string GroupeComposite::getNom() {
    return nom;
}

void GroupeComposite::setParent(Groupe * g) {
    parent = g;
}

Groupe* GroupeComposite::getParent() {
    return parent;
}
