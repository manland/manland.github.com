#include "tcpserveur.h"

TCPserveur::TCPserveur(int p) {
    port = p;
    for(int i=0; i<MAX_UTILISATEURS; i++) {
        descripteur_connexion[i] = NULL;
    }
}

TCPserveur::~TCPserveur() {
    close(id_socket);
    delete [] descripteur_connexion;
    delete [] utilisateur_ip;
    delete [] utilisateur_port;
}

int TCPserveur::Exec() {
    int res = 0;
    res = InitialisationSocket();
    if(res != 1) {
        AttenteConnexion();
    }
    return res;
}

int TCPserveur::InitialisationSocket() {
    if ((id_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0 ){
        perror("socket error");
        return 1;
    }

    bzero(&servaddr, sizeof(servaddr));//met la structure à zéro

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(port);

    if (bind(id_socket, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0){
        perror("bind error");
        close(id_socket);
        return 1;
    }

    if (listen(id_socket, 100) < 0){
        perror("listen error");
        close(id_socket);
        return 1;
    }
    return 0;
}

void TCPserveur::AttenteConnexion() {
    while (1) {
        int temp = sizeof(information_sur_la_source); // Passe par une variable afin d'utiliser un pointeur
        int place = trouverUnePlace();
        descripteur_connexion[place] = accept(id_socket, (struct sockaddr *)&information_sur_la_source, (socklen_t*)&temp);
        if (descripteur_connexion[place] < 0){
            perror("accept error");
//            return;
        }
        utilisateur_port[place] = information_sur_la_source.sin_port;
        utilisateur_ip[place] = inet_ntoa(information_sur_la_source.sin_addr);
        onConnect(place);
        cout<<"Connexion établie. Port du client : "<<information_sur_la_source.sin_port<<" ip : "<<inet_ntoa(information_sur_la_source.sin_addr)<<endl;
    }
}

void TCPserveur::Envoyer(const int client) {
    char msgbuff[2000] = "0";
    cout<<"> "<<flush;
    cin.getline(msgbuff, sizeof(msgbuff));
    int res = send(descripteur_connexion[client], msgbuff, (size_t)sizeof(msgbuff), 0);
    if(res == -1) {
        perror("send error");
    }
    return Envoyer(client);
}

void TCPserveur::Envoyer(const int client, const char * msgbuff) {
    cout<<"TCPServeur Envoyer() : "<<msgbuff<<endl;
    int res = send(descripteur_connexion[client], msgbuff, (size_t)strlen(msgbuff), 0);
    if(res == -1) {
        perror("send error");
        return;
    }
}

void TCPserveur::Recevoir(const int client) {
    char msgbuff[1024] = "0";
    int res = recv(descripteur_connexion[client], msgbuff, (size_t)sizeof(msgbuff), 0);
    if(res == -1) {
        perror("recv error");
    }
}

int TCPserveur::trouverUnePlace() const {
    for(int i=0; i<MAX_UTILISATEURS; i++) {
        if(!descripteur_connexion[i])
            return i;
    }
}
