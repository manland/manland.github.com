#ifndef GROUPE_H
#define GROUPE_H

#include "groupecomposite.h"
#include "utilisateur.h"

class Groupe : public GroupeComposite
{
private:
    vector<GroupeComposite*> * contenues;
    vector<Utilisateur*> * en_attente;
    Utilisateur * proprietaire;
public:
    Groupe(string = "", Groupe* = NULL, Utilisateur* = NULL);
    virtual ~Groupe();
    virtual int nbElement();
    virtual Groupe* addElement(GroupeComposite*);
    virtual bool removeElement(GroupeComposite*);
    virtual bool appartient(GroupeComposite*);
    virtual bool appartientParNom(string);
    virtual Utilisateur* appartientUtilisateurParNom(string);
    virtual Utilisateur* appartientUtilisateurParNomRecursif(string);
    virtual vector<Utilisateur*>* tousMesUtilisateurs();
    virtual vector<Utilisateur*>* tousMesUtilisateursRecursif();
    virtual vector<Groupe*>* tousMesGroupes();
    virtual vector<Groupe*>* tousMesGroupesRecursif();
    virtual Utilisateur* getProprietaire();
    virtual void setProprietaire(Utilisateur*);
    virtual string lsGroupe();
    virtual string lsUtilisateur();
    virtual string ls();
    virtual void setNom(string);
    virtual void ajouterMembreEnAttente(Utilisateur*);
    virtual vector<Utilisateur*>* tousMesUtilisateursEnAttente();
    virtual void accepterUtilisateur(int);
};

#endif // GROUPE_H
