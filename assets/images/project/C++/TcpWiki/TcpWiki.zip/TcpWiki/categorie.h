#ifndef CATEGORIE_H
#define CATEGORIE_H

#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
using namespace std;

#include "article.h"
#include "categoriecomposite.h"

class Categorie : public virtual CategorieComposite {
private:
    vector<CategorieComposite*> * contenues;
public:
    Categorie(string = "", Categorie* = NULL, Utilisateur* = NULL);
    virtual ~Categorie();
    virtual string ls();
    virtual int nbElement();
    virtual vector<CategorieComposite*>* find(string);
    virtual vector<CategorieComposite*>* findR(string);
    virtual Categorie* addElement(CategorieComposite*);
    virtual bool removeElement(CategorieComposite*);
    virtual int size();
    virtual void enregistrerEnDurRecursif();
    virtual void restaurerDuDurRecursif(vector<struc_catcomp_proprio>*);
    virtual string lsDroit();
};

#endif // CATEGORIE_H
