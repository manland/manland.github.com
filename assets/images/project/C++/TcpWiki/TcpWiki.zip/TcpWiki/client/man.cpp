#include "man.h"

MAN::MAN() {
}

void MAN::man() {
    cout<<"[MAN - Liste des commandes]"<<endl;
    cout<<"     ls : liste le contenue d'une catégorie. Tappez \"man ls\" pour plus d'informations."<<endl;
    cout<<"     who : liste les utilisateurs connectés au serveur. Tappez \"man who\" pour plus d'informations."<<endl;
    cout<<"     cd nom_de_catégorie : permet de se déplacer dans la nouvelle catégorie si vous avez le droit de lecture sur celle-ci. Tappez \"man cd\" pour plus d'informations."<<endl;
    cout<<"     mkCat nom_de_catégorie : créer nom_de_catégorie dans la catégorie où vous vous trouvez si vous avez le droit d'écriture sur celle-ci. Tappez \"man mkCat\" pour plus d'informations."<<endl;
    cout<<"     mdCat nom_de_catégorie nouveau_nom_de_catégorie : permet de modifier le nom de la catégorie nom_de_catégorie par le nouveau_nom_de_catégorie si vous avez le droit d'écriture sur la catégorie parente. Tappez \"man mdCat\" pour plus d'informations."<<endl;
    cout<<"     mdCatD nom_de_catégorie ... : modifie les droits de la catégorie nom_de_catégorie si vous en êtes le propriétaire. Tappez \"man mdCatD\" pour plus d'informations."<<endl;
    cout<<"     quit : peremet de quitter ce logiciel. Tappez \"man quit\" pour plus d'informations."<<endl;
}

void MAN::ls() {
    cout<<""<<endl;
}
