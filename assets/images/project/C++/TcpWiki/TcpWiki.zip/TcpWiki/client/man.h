#ifndef MAN_H
#define MAN_H

#include <iostream>
using namespace std;

class MAN
{
public:
    MAN();
    static void man();
    static void ls();
};

#endif // MAN_H
