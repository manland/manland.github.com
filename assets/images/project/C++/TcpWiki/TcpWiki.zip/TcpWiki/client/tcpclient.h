#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <iostream>

#include <pthread.h>

using namespace std;

class TCPclient
{
private:
    struct sockaddr_in servaddr;
protected:
    int id_socket;
    int port;
public:
    TCPclient(int);
    virtual ~TCPclient();
    virtual int Exec(const string);
    virtual int ConnexionSocket(const string);
    virtual void Envoyer(const char*);
    virtual char* Recevoir();
};

#endif // TCPCLIENT_H
