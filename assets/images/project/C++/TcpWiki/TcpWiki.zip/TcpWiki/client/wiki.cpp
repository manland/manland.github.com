#include "wiki.h"

Wiki::Wiki(int p) : TCPclient(p) {
    url_courant = "";
    pthread_mutex_init(&verrou_boite_reception, NULL);
    news = true;
    descripteur_udp = ouvreSocketUDP();
}

Wiki::~Wiki() {
    close(id_socket);
    close(descripteur_udp);
}

string Wiki::cryptageSha1(string mot) {
    SHA1 sha;
    string resultatSha1;
    unsigned messageDigest[5];
    sha.Reset();
    sha<<mot.c_str();
    if (!sha.Result(messageDigest))
        cout<<"Probleme avec le sha1 apres la réception du mot de passe pour l'authentification"<<endl;
    else {
        char buffer[50]="0";
        for (int i =0; i<5; i++) {
            sprintf(buffer,"%x",messageDigest[i]);
            resultatSha1 = resultatSha1 + buffer;
        }
    }
    return resultatSha1;
}

int Wiki::Exec(const string adresse_serveur) {
    int i =  TCPclient::Exec(adresse_serveur);
    pthread_create(&thread, 0, Wiki::startThreadRecevoirUDP, (void*)this);
    pthread_create(&thread, 0, Wiki::startThreadRecevoir, (void*)this);
    return i;
}

bool Wiki::identification() {
    cout<<"--------Identification--------"<<endl;
    cout<<"Entrez votre login : ";
    string login = "";
    cin>>login;
    if(login == "Inscription" || login == "inscription") {
        return inscription();
    }
    cout<<"Entrez votre mot de passe : ";
    string pass_en_clair = "";
    cin>>pass_en_clair;
    string pass = cryptageSha1(pass_en_clair);
    char envoi[1024] = "0";
    envoi[0] = '0';
    envoi[1] = '0';
    envoi[2] = '#';
    int h = 3;
    for(int i=0; i<login.size(); i++) {
        envoi[h] = login[i];
        if(envoi[h] == '#' || envoi[h] == '/') {
            cout<<"Caractère interdit : "<<envoi[h]<<endl;
            return false;
        }
        h++;
    }
    envoi[h] = '#';
    h++;
    for(int i=0; i<pass.size(); i++) {
        envoi[h] = pass[i];
        if(envoi[h] == '#' || envoi[h] == '/') {
            envoi[h] = '@';//SHA1 peut retourner ces caractères mais nous ne le voulons vraiment pas
        }
        h++;
    }
    Envoyer(envoi);
    char * msg = Recevoir();
    if(msg[0] == 't') {
        for(int i=1; i<strlen(msg); i++) {
            url_courant = url_courant + msg[i];
        }
        cout<<"Vous êtes loggé, entrez une commande."<<endl;
        return true;
    }
    else {
        cout<<"Erreur de pseudo ou de mot de passe."<<endl;
        return false;
    }
}

bool Wiki::inscription() {
    cout<<"--------Inscription--------"<<endl;
    cout<<"Entrez le login souhaitez : ";
    string login = "";
    cin>>login;
    cout<<"Entrez votre mot de passe : ";
    string pass_en_clair = "";
    cin>>pass_en_clair;
    string pass = cryptageSha1(pass_en_clair);
    cout<<"Entrez une 2eme fois votre mot de passe : ";
    string pass_en_clair2 = "";
    cin>>pass_en_clair2;
    string pass2 = cryptageSha1(pass_en_clair2);
    bool trouve = false;
    int i = 0;
    int j = 0;
    while(!trouve && i<pass.size() && j<pass2.size()) {
        if(pass[i] != pass2[j])
            trouve = true;
        else {
            i++;
            j++;
        }
    }
    if(trouve) {
        cout<<"Vos 2 mots de passe ne correspondent pas veuillez rééssayer. (Ctrl+C pour sortir du programme :D^^)"<<endl;
        return inscription();
    }
    char envoi[1024] = "0";
    envoi[0] = '0';
    envoi[1] = '1';
    envoi[2] = '#';
    int h = 3;
    for(int i=0; i<login.size(); i++) {
        envoi[h] = login[i];
        if(envoi[h] == '#' || envoi[h] == '/') {
            cout<<"Caractère interdit : "<<envoi[h]<<endl;
            return false;
        }
        h++;
    }
    envoi[h] = '#';
    h++;
    for(int i=0; i<pass.size(); i++) {
        if(envoi[h] == '#' || envoi[h] == '/') {
            envoi[h] = '@';//SHA1 peut retourner ces caractères mais nous ne le voulons vraiment pas
        }
        else {
            envoi[h] = pass[i];
        }
        h++;
    }
    Envoyer(envoi);
    char * msg = Recevoir();
    if(msg[0] == 't') {
        for(int i=1; i<strlen(msg); i++) {
            url_courant = url_courant + msg[i];
        }
        return true;
    }
    else {
        cout<<"Ce pseudo existe déjà."<<endl;
        return false;
    }
}

char* Wiki::Recevoir() {
    char * res = "0";
    pthread_mutex_lock(&verrou_boite_reception);
    if(msg_reception != "") {
        res = const_cast<char*>(msg_reception.c_str());
    }
    else {
        pthread_mutex_unlock(&verrou_boite_reception);
        sleep(0.1);//rend le control a receptionExecptionnelle
        return Recevoir();
    }
    pthread_mutex_unlock(&verrou_boite_reception);
    return res;
}

int Wiki::commandes() {
    char res_char[1024] = "0";
    cout<<"cmd [ "<<url_courant<<" ] > "<<flush;
    cin.getline(res_char, sizeof(res_char));
    string res = res_char;
    if(res == "who" || res == "WHO") {
        Envoyer("03#who");
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "ls") {
        if(url_courant == "") {
            Envoyer("04#ls#00");
        }
        else {
            string s = "04#ls#" + url_courant;
            char * temp = "0";
            temp = const_cast<char*>(s.c_str());
            Envoyer(temp);
        }
        char * msg = Recevoir();
        string s = "";
        if(msg[0] == 'f' && msg[1] == '#') {
            for(int i=2; i<strlen(msg); i++) {
                s = s + msg[i];
            }
        }
        else
            s = msg;
        cout<<s<<endl;
        return commandes();
    }
    else if(res[0] == 'c' && res[1] == 'd') {
        if(res[3] == '.' && res[4] == '.') {
            int count = 0;
            bool fin = false;
            string nouveau_url = url_courant;
            for(int i=nouveau_url.size()-1; i>=0 && !fin; i--) {
                if(nouveau_url[i] == '/') {
                    nouveau_url[i] = NULL;
                    fin = true;
                    count++;
                }
                else {
                    nouveau_url[i] = NULL;
                }
            }
            if(count>0) {
                url_courant = "";
                for(int i=0; i<nouveau_url.size() && nouveau_url[i]!=NULL; i++) {
                        url_courant = url_courant + nouveau_url[i];
                }
            }
        }
        else {
            string nouveau_url;
            bool est_contenue = true;
            if(url_courant.size() != res.size()-3)
                est_contenue = false;
            for(int i=3; i<url_courant.size()+3 && est_contenue; i++) {
                if(url_courant[i-3] != res[i]) {
                    est_contenue = false;
                }
            }
            if(est_contenue) {
                nouveau_url = "";
            }
            else {
                nouveau_url = url_courant + "/";
            }
            for(int i=3; i<res.size(); i++) {
                nouveau_url = nouveau_url + res[i];
            }
            string s = "04#ls#" + nouveau_url;
            char * temp = "0";
            temp = const_cast<char*>(s.c_str());
            Envoyer(temp);
            char * msg = Recevoir();
            if(msg[0] == 'f' && msg[1] == '#') {
                string s = "";
                for(int i=2; i<strlen(msg); i++) {
                    s = s + msg[i];
                }
                cout<<s<<endl;
            }
            else
                url_courant = nouveau_url;
        }
        return commandes();
    }
    else if(res[0]=='m' && res[1]=='k' && res[2]=='C' && res[3]=='a' && res[4]=='t') {
        string s = "05#mkCat#" + url_courant + "#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == '/' || res[i] == '#') {
                cout<<"Caractère interdit : "<<res[i]<<endl;
                return commandes();
            }
            s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        if(msg[0] == '#' && msg[1] == 'f')
            cout<<"Vous ne pouvez pas créer de catégorie dans ce répertoire !"<<endl;
        else
            cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='m' && res[1]=='d' && res[2]=='C' && res[3]=='a' && res[4]=='t') {
        string s;
        int deb = 0;
        if(res[5] != 'D') {
            s = "07#mdCat#" + url_courant + "#";
            deb = 6;
        }
        else {
            s = "06#mdCatD#" + url_courant + "#";
            deb = 7;
        }
        int taille_donnee = res.size();
        for(int i=deb; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        if(msg[0] == '#' && msg[1] == 'f')
            cout<<"Vous ne pouvez pas modifier cette catégorie !"<<endl;
        else
            cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='f' && res[1]=='i' && res[2]=='n' && res[3]=='d') {
        string s;
        int deb = 0;
        if(res[4] != 'R') {
            s = "08#find#" + url_courant + "#";
            deb = 5;
        }
        else {
            s = "09#findR#" + url_courant + "#";
            deb = 6;
        }
        int taille_donnee = s.size();
        for(int i=deb; i<res.size(); i++) {
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='r' && res[1]=='m' && res[2]=='C' && res[3]=='a' && res[4]=='t') {
        string s = "10#rmCat#" + url_courant + "#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='m' && res[1]=='k' && res[2]=='A' && res[3]=='r' && res[4]=='t') {
        string s = "11#mkArt#" + url_courant + "#";
        string nom = "";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == '/' || res[i] == '#') {
                cout<<"Caractère interdit : "<<res[i]<<endl;
                return commandes();
            }
            s = s + res[i];
            nom = nom + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        if(msg[0] == '#' && msg[1] == 't') {
            modifierArticle(nom, "");
        }
        else {
            cout<<msg<<endl;
        }
        return commandes();
    }
    else if(res[0]=='m' && res[1]=='d' && res[2]=='A' && res[3]=='r' && res[4]=='t') {//12#mdArt#chemin#nom#nouveau_nom#attendre
        string s = "12#mdArt#" + url_courant + "#";
        string nom = "";
        string nouveau_nom = "";
        bool est_nouveau_nom = false;
        int debut = 0;

        if(res[5] == 'D') {
            s = "14#mdArtD#" + url_courant + "#";
            debut = 7;
        }
        else if(res[6] == '-')
            debut = 9;
        else
            debut = 6;
        int taille_donnee = s.size();
        for(int i=debut; i<res.size(); i++) {
            if(res[i] == ' ') {
                s = s + "#";
                est_nouveau_nom = true;
            }
            else
                s = s + res[i];
            if(!est_nouveau_nom)
                nom = nom + res[i];
            else if(debut == 6)
                nouveau_nom = nouveau_nom + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        if(res[5] != 'D') {
            if(nouveau_nom == "") {
                s = s + "#" + nom;
            }
            if(debut == 9) {
                s = s + "#-a";
                cout<<"Attente du déblocage du fichier : "<<nom<<"..."<<endl;
            }
            char * temp = "0";
            temp = const_cast<char*>(s.c_str());
            Envoyer(temp);
            char * msg;
            msg = Recevoir();
            if(msg[0] == '#' && msg[1] == 't') {
                if(nouveau_nom == "") {
                    cout<<"Réception des données de l'article..."<<endl;
                    sleep(1);
                    char * taille = Recevoir();
                    int t = atoi(taille);
                    Envoyer("ok");
                    sleep(1);
                    string contenu_texte = "";
                    while(contenu_texte.size() < t) {
                        contenu_texte = contenu_texte + Recevoir();
                        sleep(1);
                    }
                    modifierArticle(nom, contenu_texte);
                }
            }
            else
                cout<<msg<<endl;
        }
        else {
            char * temp = "0";
            temp = const_cast<char*>(s.c_str());
            Envoyer(temp);
            char * msg;
            msg = Recevoir();
            cout<<msg<<endl;
        }
        return commandes();
    }
    else if(res[0]=='r' && res[1]=='m' && res[2]=='A' && res[3]=='r' && res[4]=='t') {
        string s = "13#rmArt#" + url_courant + "#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='m' && res[1]=='k' && res[2]=='G' && res[3]=='r' && res[4]=='p') {
        string s = "15#mkGrp#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='r' && res[1]=='m' && res[2]=='G' && res[3]=='r' && res[4]=='p') {
        string s = "16#rmGrp#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "lsGrp" || res == "lsG" || res == "ls -g") {
        string s = "17#lsGrp";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='m' && res[1]=='d' && res[2]=='G' && res[3]=='r' && res[4]=='p') {
        string s = "18#mdGrp#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='r' && res[1]=='j' && res[2]=='G' && res[3]=='r' && res[4]=='p') {
        string s = "19#mdGrp#";
        int taille_donnee = s.size();
        for(int i=6; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "lsG -m" || res == "ls -mg") {
        string s = "20#lsG#-m";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='a' && res[1]=='c' && res[2]=='c' && res[3]=='e' && res[4]=='p' && res[5]=='t' && res[6]=='e' && res[7]=='r') {
        string s = "21#accepter#";
        int taille_donnee = s.size();
        for(int i=9; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='s' && res[1]=='e' && res[2]=='n' && res[3]=='d') {
        string s = "22#send#";
        bool premier = true;
        int taille_donnee = s.size();
        for(int i=5; i<res.size(); i++) {
            if(res[i] == ' ' && premier) {
                s = s + "#";
                premier = false;
            }
            else
                s = s + res[i];
        }
        if(s.size()<taille_donnee+3) {
            cout<<"3 caractères minimum sont requis."<<endl;
            return commandes();
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "lsD" || res == "lsDroit" || res == "ls -d") {
        string s = "23#lsD#" + url_courant + "#";
        for(int i=7; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "newsOn" || res == "NewsOn" || res == "newson" || res == "non") {
        news = true;
        return commandes();
    }
    else if(res == "newsOff" || res == "NewsOff" || res == "newsoff" || res == "noff") {
        news = false;
        return commandes();
    }
    else if(res[0] == 'c' && res[1] == 'a' && res[2] == 't') {
        string s = "24#cat#" + url_courant + "#";
        for(int i=4; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * taille = "0";
        taille = Recevoir();
        int t = atoi(taille);
        Envoyer("ok");
        sleep(1);
        string texte = "";
        while(texte.size() < t) {
            texte = texte + Recevoir();
            sleep(1);
        }
        cout<<texte<<endl;
        return commandes();
    }
    else if(res == "quitGrp") {
        string s = "25#quitGrp";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0]=='u' && res[1]=='Q' && res[2]=='u' && res[3]=='i' && res[4]=='t' && res[5]=='G' && res[6]=='r' && res[7]=='p') {
        string s = "26#uQuitGrp#";
        for(int i=9; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "crash") {
        string s = "27#crash";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        return commandes();
    }
    else if(res == "reboot") {
        string s = "28#reboot";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        return commandes();
    }
    else if(res[0] == 'b' && res[1] == 'a' && res[2] == 'n' && res[3] == 'U' && res[4] == 't' && res[5] == 'i') {
        string s = "29#banUti#";
        for(int i=7; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "enregistrer") {
        string s = "30#enregistrer";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0] == 'b' && res[1] == 'a' && res[2] == 'n' && res[3] == 'A' && res[4] == 'r' && res[5] == 't') {
        string s = "31#banArt#" + url_courant + "#";
        for(int i=7; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "lsB" || res == "ls -b") {
        string s = "32#ls-b";
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0] == 'd' && res[1] == 'e' && res[2] == 'b' && res[3] == 'a' && res[4] == 'n' && res[5] == 'A' && res[6] == 'r' && res[7] == 't') {
        string s = "33#debanArt#" + url_courant + "#";
        for(int i=9; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res[0] == 'd' && res[1] == 'e' && res[2] == 'b' && res[3] == 'a' && res[4] == 'n' && res[5] == 'U' && res[6] == 't' && res[7] == 'i') {
        string s = "34#debanUti#";
        for(int i=9; i<res.size(); i++) {
            if(res[i] == ' ')
                s = s + "#";
            else
                s = s + res[i];
        }
        char * temp = "0";
        temp = const_cast<char*>(s.c_str());
        Envoyer(temp);
        char * msg;
        msg = Recevoir();
        cout<<msg<<endl;
        return commandes();
    }
    else if(res == "man") {
        MAN::man();
        return commandes();
    }
    else if(res == "ghost") {
        afficherGhost();
        return commandes();
    }
    else if(res == "bart") {
        afficherBart();
        return commandes();
    }
    else if(res == "pingouin") {
        afficherPingouin();
        return commandes();
    }
    else if(res == "mort") {
        afficherTeteMort();
        return commandes();
    }
    else if(res == "quit" || res == "q" || res == "quitter") {
        cout<<"Merci d'avoir utilisé notre Wiki. A bientôt..."<<endl;
        Envoyer("86");
        close(descripteur_udp);
        close(id_socket);
        return 0;
    }
    else {
        cout<<"Commande inconnue. Tappez \"man\" pour une explication des commandes."<<endl;
        return commandes();
    }
    return 0;
}

void Wiki::modifierArticle(string nom, string texte) {
    char * nom_temp = const_cast<char*>(nom.c_str());
    pid_t pid = fork();
    if (pid > 0) {//pére
        cout<<"Entrez \"ok\" pour envoyer votre version au serveur. Assurez-vous d'avoir bien enregistré dans votre éditeur de texte."<<endl;
        string nop;
        cin>>nop;
        string reponse = "";
        ifstream fichier(nom_temp, ios::in);//ouverture du fichier en lecture
        if(fichier)
        {
            string ligne = "";
            while(getline(fichier, ligne))//tant qu'il y a des lignes à lire
            {
                if(ligne == "" && ligne != "\n")
                    reponse = reponse + "\n";
                else
                    reponse = reponse + ligne + "\n";
            }
            if(unlink(nom_temp) < 0) {//supprime le fichier
                perror("unlink");
            }
        }
        else {
            cout<<"Impossible d'ouvrir le fichier des utilisateurs en lecture !"<<endl;
        }
        if(reponse.size() > 0) {
            ostringstream out;
            out<<reponse.size();
            Envoyer(out.str().c_str());
            sleep(1);
            Envoyer(reponse.c_str());
            char * msg_retour = Recevoir();
            cout<<msg_retour<<endl;
        }
        else {
            cout<<"Le fichier ne contient aucune donnée (vérifiez que vous ayez bien enregistré)."<<endl;
        }
    }
    else if (pid == 0) {//fils
        ofstream fichier(nom_temp, ios::out | ios::trunc);//ouverture en écriture avec effacement du fichier ouvert
        if(fichier)
        {
            fichier<<texte<<endl;
            fichier.close();
        }
        else
            cout<<"Impossible d'ouvrir le fichier des groupes en écriture !"<<endl;
        char * argv[2];
        argv[0] = "./";
        argv[1] = nom_temp;
        execvp("gedit", argv);
    }
    else {//erreur
        cout<<"erreur de fork"<<endl;
    }
}

void* Wiki::startThreadRecevoir(void * obj) {
    Wiki * serveur = reinterpret_cast<Wiki*>(obj);
    if(serveur) {
        serveur->ReceptionExceptionnelle();
    }
}

void Wiki::ReceptionExceptionnelle() {
    pthread_mutex_lock(&verrou_boite_reception);
    char msgbuff[1024] = "0";
    int res = recv(id_socket, &msgbuff, (size_t)sizeof(msgbuff), 0);
    if(res == -1) {
        perror("recv error");
    }
    if(msgbuff[0] == '0') {
        close(descripteur_udp);
        close(id_socket);
        cout<<"Nous sommes désolé mais le serveur doit redémarer."<<endl;
        cout<<"Si vous êtes en train de modifier/créer un article veuillez à enregistrer votre travail car ce logiciel va fermer votre logiciel de traitement de texte."<<endl;
        cout<<"Veullez attendre 80sc..."<<endl;
        sleep(10);
        cout<<"70sc..."<<endl;
        sleep(10);
        cout<<"60sc..."<<endl;
        sleep(10);
        cout<<"50sc..."<<endl;
        sleep(10);
        cout<<"40sc..."<<endl;
        sleep(10);
        cout<<"30sc..."<<endl;
        sleep(10);
        cout<<"20sc..."<<endl;
        sleep(10);
        cout<<"10sc..."<<endl;
        sleep(1);
        cout<<"9sc..."<<endl;
        sleep(1);
        cout<<"8sc..."<<endl;
        sleep(1);
        cout<<"7sc..."<<endl;
        sleep(1);
        cout<<"6sc..."<<endl;
        sleep(1);
        cout<<"5sc..."<<endl;
        sleep(1);
        cout<<"4sc..."<<endl;
        sleep(1);
        cout<<"3sc..."<<endl;
        sleep(1);
        cout<<"2sc..."<<endl;
        sleep(1);
        cout<<"1sc..."<<endl;
        sleep(1);
        cout<<"0sc..."<<endl;
        cout<<"Je redémarre."<<endl;
        execvp("./main", NULL);
    }
    else if(msgbuff[0] == '9' && msgbuff[1] == '9' && msgbuff[2] == '#') {
        string res = "";
        for(int i=3; i<strlen(msgbuff); i++) {
            res = res + msgbuff[i];
        }
        cout<<"Message du serveur -----> "<<res<<endl;
        cout<<"cmd [ "<<url_courant<<" ] > "<<flush;
    }
    else if(msgbuff[0] == '9' && msgbuff[1] == '8' && msgbuff[2] == '#') {
        string res = "";
        for(int i=3; i<strlen(msgbuff); i++) {
            res = res + msgbuff[i];
        }
        cout<<"Message -----> "<<res<<endl;
        cout<<"cmd [ "<<url_courant<<" ] > "<<flush;
    }
    else {
        msg_reception = "";
        for(int i=0; i<strlen(msgbuff); i++) {
            msg_reception = msg_reception + msgbuff[i];
        }
    }
    pthread_mutex_unlock(&verrou_boite_reception);
    sleep(1);
    return ReceptionExceptionnelle();
}

void Wiki::afficherGhost() {
    cout<<"                              __---__"<<endl;
    cout<<"                            _-       _--______"<<endl;
    cout<<"                       __--( /     \\ )XXXXXXXXXXXXX_"<<endl;
    cout<<"                     --XXX(   O   O  )XXXXXXXXXXXXXXX-"<<endl;
    cout<<"                    /XXX(       U     )        XXXXXXX\\"<<endl;
    cout<<"                  /XXXXX(              )--_  XXXXXXXXXXX\\"<<endl;
    cout<<"                 /XXXXX/ (      O     )   XXXXXX   \\XXXXX\\"<<endl;
    cout<<"                 XXXXX/   /            XXXXXX   \\__ \\XXXXX----"<<endl;
    cout<<"                 XXXXXX__/          XXXXXX         \\__----  -"<<endl;
    cout<<"         ---___  XXX__/          XXXXXX      \\__         ---"<<endl;
    cout<<"           --  --__/   ___/\\  XXXXXX            /  ___---="<<endl;
    cout<<"             -_    ___/    XXXXXX              '--- XXXXXX"<<endl;
    cout<<"               --\\/XXX\\ XXXXXX                      /XXXXX"<<endl;
    cout<<"                 \\XXXXXXXXX                        /XXXXX/"<<endl;
    cout<<"                  \\XXXXXX                        _/XXXXX/"<<endl;
    cout<<"                    \\XXXXX--__/              __-- XXXX/"<<endl;
    cout<<"                     --XXXXXXX---------------  XXXXX--"<<endl;
    cout<<"                        \\XXXXXXXXXXXXXXXXXXXXXXXX-"<<endl;
    cout<<"                          --XXXXXXXXXXXXXXXXXX-"<<endl;
}

void Wiki::afficherPingouin() {
    cout<<"                  .88888888:. "<<endl;
    cout<<"                88888888.88888. "<<endl;
    cout<<"              .8888888888888888. "<<endl;
    cout<<"              888888888888888888 "<<endl;
    cout<<"              88' _`88'_  `88888 "<<endl;
    cout<<"              88 88 88 88  88888 "<<endl;
    cout<<"              88_88_::_88_:88888 "<<endl;
    cout<<"              88:::,::,:::::8888 "<<endl;
    cout<<"              88`:::::::::'`8888 "<<endl;
    cout<<"             .88  `::::'    8:88. "<<endl;
    cout<<"            8888            `8:888. "<<endl;
    cout<<"          .8888'             `888888. "<<endl;
    cout<<"         .8888:..  .::.  ...:'8888888:. "<<endl;
    cout<<"        .8888.'     :'     `'::`88:88888 "<<endl;
    cout<<"       .8888        '         `.888:8888. "<<endl;
    cout<<"      888:8         .           888:88888 "<<endl;
    cout<<"    .888:88        .:           888:88888:"<<endl;
    cout<<"    8888888.       ::           88:888888 "<<endl;
    cout<<"    `.::.888.      ::          .88888888 "<<endl;
    cout<<"   .::::::.888.    ::         :::`8888'.:."<<endl;
    cout<<"  ::::::::::.888   '         .::::::::::::"<<endl;
    cout<<"  ::::::::::::.8    '      .:8::::::::::::. "<<endl;
    cout<<" .::::::::::::::.        .:888::::::::::::: "<<endl;
    cout<<" :::::::::::::::88:.__..:88888:::::::::::' "<<endl;
    cout<<"  `'.:::::::::::88888888888.88:::::::::' "<<endl;
    cout<<"        `':::_:' -- '' -'-' `':_::::'` "<<endl;
}

void Wiki::afficherBart() {
    cout<<"       \\  /\\  /\\  /\\  /\\  /\\  /\\  /"<<endl;
    cout<<"        \\/  \\/  \\/  \\/  \\/  \\/  \\/ "<<endl;
    cout<<"        |                        |       H   H  EEEEE  Y   Y"<<endl;
    cout<<"        |                        |       H   H  E      Y   Y"<<endl;
    cout<<"        |                        |       HHHHH  EEE     Y Y"<<endl;
    cout<<"        |                        |       H   H  E        Y"<<endl;
    cout<<"        | __----__      __----__ |       H   H  EEEEE    Y"<<endl;
    cout<<"        |/        \\    /        \\|"<<endl;
    cout<<"        |          |  |          |       M   M   AAA   N   N   !!"<<endl;
    cout<<"      --|\\     *  /    \\     *  /|--     MM MM  A   A  NN  N   !!"<<endl;
    cout<<"     /  | --____--      --____-- |  \\    M M M  AAAAA  N N N   !!"<<endl;
    cout<<"    | (-|         /    \\         |-) |   M   M  A   A  N  NN   "<<endl;
    cout<<"     \\  |.        \\____/        .|  /    M   M  A   A  N   N   ()"<<endl;
    cout<<"      --/                        \\--   "<<endl;
    cout<<"       /                          \\     "<<endl;
    cout<<"       `--______________________--' "<<endl;
    cout<<"          \\_                  _/"<<endl;
    cout<<"            `---__      __---' "<<endl;
    cout<<"                  `----'"<<endl;
}

void Wiki::afficherTeteMort() {
    cout<<"                       .ed\"\"\"\" \"\"\"$$$$be.                     "<<endl;
    cout<<"                     -\"           ^\"\"**$$$e.                  "<<endl;
    cout<<"                   .\"                   '$$$c                 "<<endl;
    cout<<"                  /                      \"4$$b                "<<endl;
    cout<<"                 d  3                     $$$$                "<<endl;
    cout<<"                 $  *                   .$$$$$$               "<<endl;
    cout<<"                .$  ^c           $$$$$e$$$$$$$$.              "<<endl;
    cout<<"                d$L  4.         4$$$$$$$$$$$$$$b              "<<endl;
    cout<<"                $$$$b ^ceeeee.  4$$ECL.F*$$$$$$$              "<<endl;
    cout<<"    e$\"\"=.      $$$$P d$$$$F $ $$$$$$$$$- $$$$$$              "<<endl;
    cout<<"   z$$b. ^c     3$$$F \"$$$$b   $\"$$$$$$$  $$$$*\"      .=\"\"$c  "<<endl;
    cout<<"  4$$$$L   \\     $$P\"  \"$$b   .$ $$$$$...e$$        .=  e$$$. "<<endl;
    cout<<"  ^*$$$$$c  %..   *c    ..    $$ 3$$$$$$$$$$eF     zP  d$$$$$ "<<endl;
    cout<<"    \"**$$$ec   \"\\   %ce\"\"    $$$  $$$$$$$$$$*    .r\" =$$$$P\"\" "<<endl;
    cout<<"          \"*$b.  \"c  *$e.    *** d$$$$$\"L$$    .d\"  e$$***\"   "<<endl;
    cout<<"            ^*$$c ^$c $$$      4J$$$$$% $$$ .e*\".eeP\"         "<<endl;
    cout<<"               \"$$$$$$\"'$=e....$*$$**$cz$$\" \"..d$*\"           "<<endl;
    cout<<"                 \"*$$$  *=%4.$ L L$ P3$$$F $$$P\"              "<<endl;
    cout<<"                    \"$   \"%*ebJLzb$e$$$$$b $P\"                "<<endl;
    cout<<"                      %..      4$$$$$$$$$$ \"                  "<<endl;
    cout<<"                       $$$e   z$$$$$$$$$$%                    "<<endl;
    cout<<"                        \"*$c  \"$$$$$$$P\"                      "<<endl;
    cout<<"                         .\"\"\"*$$$$$$$$bc                      "<<endl;
    cout<<"                      .-\"    .$***$$$\"\"\"*e.                   "<<endl;
    cout<<"                   .-\"    .e$\"     \"*$c  ^*b.                 "<<endl;
    cout<<"            .=*\"\"\"\"    .e$*\"          \"*bc  \"*$e..            "<<endl;
    cout<<"          .$\"        .z*\"               ^*$e.   \"*****e.      "<<endl;
    cout<<"          $$ee$c   .d\"                     \"*$.        3.     "<<endl;
    cout<<"          ^*$E\")$..$\"                         *   .ee==d%     "<<endl;
    cout<<"             $.d$$$*                           *  J$$$e*      "<<endl;
    cout<<"              \"\"\"\"\"                             \"$$$\"   "<<endl;
}

int Wiki::ouvreSocketUDP() {
    struct sockaddr_in locale_addr;
    locale_addr.sin_family = AF_INET;
    locale_addr.sin_port = htons(port);
    locale_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    descripteur_udp = socket(AF_INET, SOCK_DGRAM, 0); /* Créé socket UDP*/
    if(descripteur_udp == -1) {
        perror("Erreur lors de la création de la socket UDP");
        return -1;
    }

    int res = bind(descripteur_udp, (struct sockaddr*) &locale_addr, sizeof(locale_addr));
    if(res == -1) {
        perror("Erreur lors du bind de la socket UDP");
        close(descripteur_udp);
        return -1;
    }
    return descripteur_udp;
}

void* Wiki::startThreadRecevoirUDP(void * obj) {
    Wiki * serveur = reinterpret_cast<Wiki*>(obj);
    if(serveur) {
        serveur->receptionUdp();
    }
}

void Wiki::receptionUdp() {
    struct sockaddr_in locale_addr;
    locale_addr.sin_family = AF_INET;
    locale_addr.sin_port = htons(port);
    locale_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    socklen_t longuer = sizeof(locale_addr);
    char msgbuff[1024] = "0";
    int res = recvfrom(descripteur_udp, &msgbuff, sizeof(msgbuff),0, (sockaddr *)&locale_addr, &longuer);
    if(res == -1) {
        cout<<"recvfrom error"<<endl;
        return;
    }
    if(news) {
        cout<<"Message du serveur --> "<<msgbuff<<endl;
        cout<<"cmd [ "<<url_courant<<" ] > "<<flush;
    }
    return receptionUdp();
}

void Wiki::timer() {
//#include <unistd.h>
//#include <signal.h>
//#include <time.h>
//    struct sigaction act = {Alarm, 0, 0, 0};
//    void Alarm(int sig) {
//        cout<<"Alarme !! signal : "<<sig<<endl;
//    }
//
//    int main() {
//        struct timespec delai = {0, 500000000L};
//        sigaction(SIGALRM, &act, 0);
//        alarm(2);
//    }
}

