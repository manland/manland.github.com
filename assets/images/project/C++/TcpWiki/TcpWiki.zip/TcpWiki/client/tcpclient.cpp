#include "tcpclient.h"

TCPclient::TCPclient(int p) {
    port = p;
    id_socket = 0;
}

TCPclient::~TCPclient() {
}

int TCPclient::Exec(const string adresse_serveur) {
    return ConnexionSocket(adresse_serveur);
}

int TCPclient::ConnexionSocket(const string adresse_serveur) {
    if ((id_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0){
        perror("socket error");
        return 1;
    }

    bzero(&servaddr, sizeof(servaddr));//on met toute la structure a 0

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);

    char * addrserveur = "0";
    addrserveur = const_cast<char*>(adresse_serveur.c_str());
    if (inet_pton(AF_INET, addrserveur, &servaddr.sin_addr) <= 0){//inet_pton: convertit l'argument ASCII (Ex: 127.0.0.1) dans le bon format
        perror("inet_pton error");
        return 1;
    }

    if (connect(id_socket, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0){
        perror("connect error");
        cout<<"Aucun serveur trouvé pour l'adresse : "<<adresse_serveur<<" sur le port : "<<port<<endl;
        return 1;
    }
    return 0;
}

void TCPclient::Envoyer(const char * msgbuff) {
    int res = send(id_socket, msgbuff, (size_t)strlen(msgbuff), 0);
    if(res == -1) {
        perror("send error");
        return;
    }
}

char* TCPclient::Recevoir() {
    char msgbuff[1024] = "0";
    int res = recv(id_socket, &msgbuff, (size_t)sizeof(msgbuff), 0);
    if(res == -1) {
        perror("recv error");
    }
    return msgbuff;
}
