#ifndef WIKI_H
#define WIKI_H

#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <stdio.h>
#include <arpa/inet.h>

using namespace std;

#include "tcpclient.h"
#include "man.h"
#include "sha1.h"

class Wiki : public TCPclient
{
private:
    pthread_t thread;
    pthread_mutex_t verrou_boite_reception;
    string msg_reception;

    //udp
    int descripteur_udp;
    bool news;
protected:
    string url_courant;
public:
    Wiki(int);
    virtual ~Wiki();
    virtual string cryptageSha1(string);
    virtual int Exec(const string);
    virtual bool identification();
    virtual bool inscription();
    virtual char* Recevoir();
    virtual int commandes();
    virtual void modifierArticle(string, string);
    static void* startThreadRecevoir(void*);
    virtual void ReceptionExceptionnelle();
    virtual void afficherGhost();
    virtual void afficherPingouin();
    virtual void afficherBart();
    virtual void afficherTeteMort();
    virtual int ouvreSocketUDP();
    static void* startThreadRecevoirUDP(void*);
    virtual void receptionUdp();
    virtual void timer();
};

#endif // WIKI_H
