#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

#include "wiki.h"

int run(string, string);
bool fin = false;

int main(int argc, char *argv[]) {
    pid_t pid = fork ();
    if (pid > 0) {//pére
        int res = wait(NULL);
        if(res == -1)
            perror("Wait erreur");
        else {
//            if(fin)
//                execvp("./main", argv);
//            else
//                cout<<"bien fini"<<endl;
        }
    }
    else if (pid == 0) {//fils
        if(argc>2) {
            return run(argv[1], argv[2]);
        }
        return run("127.0.0.1", "77777");//10.42.43.1
    }
    else {//erreur
        cout<<"erreur de fork"<<endl;
    }

}

int run(string addresse_serveur, string port2) {
    int port = atoi(port2.c_str());
    Wiki * client = new Wiki(port);
    int res = 0;
    if(client->Exec(addresse_serveur) == 0) {
        cout<<"Vous êtes connecté au serveur. Veuillez vous identifier ou tapper inscription pour vous enregistrer :"<<endl;
        if(client->identification()) {
            int res = client->commandes();
            if(res == 0) {
                fin = true;
            }
        }
        else {
            if(client->identification()) {
                int res = client->commandes();
                if(res == 0) {
                    fin = true;
                }
            }
            cout<<"Mauvais pseudo ou pass !! Nous vous conseillons de rééssayer un peu plus tars..."<<endl;
            fin = true;
        }
    }
    return res;
}
