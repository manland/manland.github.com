#include "wiki.h"

Wiki::Wiki(int p) : TCPThreadServeur(p) {
    hierarchie_utilisateur = new HierarchieUtilisateur();
    hierarchie_doc = new HierarchieDoc();
    hierarchie_doc->lierDocProprios(hierarchie_utilisateur);
    hierarchie_doc->getCategorieRoot()->setAppartientA(hierarchie_utilisateur->getAdmin());

    descripteur_udp = ouvreSocketUDP();

    //Mémoire partagée contenant les sockets ouvertes afin de pouvoir les fermer en cas de crash
    key_t cle = ftok("keys", 1);
    mem_partagee_boites_reseau = shmget(cle, (size_t)sizeof(mem_partagee_boite_res_nom), IPC_CREAT|0666);
    mon_tab_boites_reseau = (mem_partagee_boite_res_nom*)shmat(mem_partagee_boites_reseau, NULL, 0);
    if((void*)mon_tab_boites_reseau == (void*)-1)
        perror("error de shmat dans le wiki");
    mon_tab_boites_reseau->boite_reseau_serveur_tcp = id_socket;
    mon_tab_boites_reseau->boite_reseau_serveur_udp = descripteur_udp;
}

Wiki::~Wiki() {
    close(descripteur_udp);
    if(shmdt(mon_tab_boites_reseau) == -1)
        perror("error de shmdt");
    if(shmctl(mem_partagee_boites_reseau, IPC_RMID, NULL) == -1)
        perror("error de shmctl");
    delete hierarchie_utilisateur;
    delete hierarchie_doc;
    delete [] utilisateurs_connectes;
    delete reponse;
    delete mon_tab_boites_reseau;
}

int Wiki::Exec() {
    int res = 0;
    res = InitialisationSocket();
    if(res != 1) {
        cout<<"Le serveur est correctement initialisé. Il est accessible sur votre réseaux par le port : "<<port<<endl;
        AttenteConnexion();
    }
    return res;
}

void Wiki::Recevoir(const int client) {
    bool sortie = false;
    char msgbuff[1024] = "0";

    int res = recv(descripteur_connexion[client], msgbuff, (size_t)sizeof(msgbuff), 0);

    if(res == -1) {
        perror("recv error");
    }
    //Si le client crach
    if(msgbuff[0] == '0' && strlen(msgbuff) == 1) {
        msgbuff[0] = '8';
        msgbuff[1] = '6';
    }

    //identification : 00#pseudo#mdp
    if(msgbuff[0] == '0' && msgbuff[1] == '0') {
        utilisateurs_connectes[client] = identification(client, msgbuff);
        if(utilisateurs_connectes[client]) {//Pour que le client ne se perturbe pas avec la réception d'un message
            //thread pour surveiller s'il y a des messages pour l'utilisateur
            WikiNumClient * temp = new WikiNumClient;
            temp->serveur = this;
            temp->id_client = client;
            pthread_create(&thread_file_msg, 0, Wiki::startThreadMessages, (void*)temp);
        }
        return Recevoir(client);
    }
    //inscription : 01#pseudo#mdp
    else if(msgbuff[0] == '0' && msgbuff[1] == '1') {
        inscription(client, msgbuff);
        if(utilisateurs_connectes[client]) {//Pour que le client ne se perturbe pas avec la réception d'un message
            //thread pour surveiller s'il y a des messages pour l'utilisateur
            WikiNumClient * temp = new WikiNumClient;
            temp->serveur = this;
            temp->id_client = client;
            pthread_create(&thread_file_msg, 0, Wiki::startThreadMessages, (void*)temp);
        }
        return Recevoir(client);
    }

    if(utilisateurs_connectes[client]) {//s'il est authentifié
        utilisateurs_connectes[client]->ajoutHistorique(msgbuff);//enregistrement dans le journal de son action
        if(utilisateurs_connectes[client]->getGroupe()->getNom() != hierarchie_utilisateur->getGroupeBannis()->getNom()) {
            //who : 03#who
            if(msgbuff[0] == '0' && msgbuff[1] == '3') {
                who(client);
            }
            //ls : 04#ls#chemin
            else if(msgbuff[0] == '0' && msgbuff[1] == '4') {
                ls(client, msgbuff);
            }
            //mkCat : 05#mkCat#chemin#nom
            else if(msgbuff[0] == '0' && msgbuff[1] == '5') {
                mkCat(client, msgbuff);
            }
            //mdCat : 06#mdCatD#chemin#nom#droitUtilisateurEcriture#droitUtilisateurLecture...
            else if(msgbuff[0] == '0' && msgbuff[1] == '6') {
                mdCatD(client, msgbuff);
            }
            //mdCat : 07#mdCat#chemin#nom#nouveau_nom
            else if(msgbuff[0] == '0' && msgbuff[1] == '7') {
                mdCat(client, msgbuff);
            }
            //find : 08#find#chemin#nom
            else if(msgbuff[0] == '0' && msgbuff[1] == '8') {
                find(client, msgbuff);
            }
            //find : 09#findR#chemin#nom
            else if(msgbuff[0] == '0' && msgbuff[1] == '9') {
                findR(client, msgbuff);
            }
            //rmCat : 10#rmCat#chemin#nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '0') {
                rmCat(client, msgbuff);
            }
            //rmCat : 11#mkArt#chemin#nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '1') {
                mkArt(client, msgbuff);
            }
            //mdArt : 12#mdArt#chemin#nom#nouveau_nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '2') {
                mdArt(client, msgbuff);
            }
            //rmArt : 13#rmArt#chemin#nom#nouveau_nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '3') {
                rmArt(client, msgbuff);
            }
            //mdArtD : 14#mdArt#chemin#nom#droits1#droits2...
            else if(msgbuff[0] == '1' && msgbuff[1] == '4') {
                mdArtD(client, msgbuff);
            }
            //mkGrp : 15#mkGrp#nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '5') {
                mkGrp(client, msgbuff);
            }
            //rmGrp : 16#rmGrp#nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '6') {
                rmGrp(client, msgbuff);
            }
            //lsG : 17#lsGrp
            else if(msgbuff[0] == '1' && msgbuff[1] == '7') {
                lsGroupe(client);
            }
            //mdGrp : 18#mdGrp#nom#nouveau_nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '8') {
                mdGrp(client, msgbuff);
            }
            //rjGrp : 19#rjGrp#nom
            else if(msgbuff[0] == '1' && msgbuff[1] == '9') {
                rjGrp(client, msgbuff);
            }
            //lsG -m : 20#lsG#-m
            else if(msgbuff[0] == '2' && msgbuff[1] == '0') {
                lsMonGroupe(client);
            }
            //21#accepter#nom
            else if(msgbuff[0] == '2' && msgbuff[1] == '1') {
                accepterUtilisateurDansSonGroupe(client, msgbuff);
            }
            //22#send#nom#texte
            else if(msgbuff[0] == '2' && msgbuff[1] == '2') {
                envoyerMessageA(client, msgbuff);
            }
            //23#lsDroit#chemin#nom
            else if(msgbuff[0] == '2' && msgbuff[1] == '3') {
                lsDroit(client, msgbuff);
            }
            //24#cat#chemin#nom
            else if(msgbuff[0] == '2' && msgbuff[1] == '4') {
                cat(client, msgbuff);
            }
            //25#quitGrp
            else if(msgbuff[0] == '2' && msgbuff[1] == '5') {
                quitGrp(client);
            }
            //26#uQuitGrp
            else if(msgbuff[0] == '2' && msgbuff[1] == '6') {
                uQuitGrp(client, msgbuff);
            }
            //27#crash
            else if(msgbuff[0] == '2' && msgbuff[1] == '7') {
                if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                    crash();
                }
                else {
                    Envoyer(client, "99#Seul l'administrateur du serveur peut effectuer cette opération.");
                }
            }
            //28#reboot
            else if(msgbuff[0] == '2' && msgbuff[1] == '8') {
                if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                    reboot();
                }
                else {
                    Envoyer(client, "99#Seul l'administrateur du serveur peut effectuer cette opération.");
                }
            }
            //29#banUti#nom
            else if (msgbuff[0] == '2' && msgbuff[1] == '9') {
                bannirUtilisateur(client, msgbuff);
            }
            //30#enregistrer
            else if (msgbuff[0] == '3' && msgbuff[1] == '0') {
                if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                    enregistrer(client);
                }
                else {
                    Envoyer(client, "Seul l'administrateur du serveur peut effectuer cette opération.");
                }
            }
            //31#banArt#chemin#nom
            else if (msgbuff[0] == '3' && msgbuff[1] == '1') {
                bannirArticle(client, msgbuff);
            }
            //32#ls-b
            else if(msgbuff[0] == '3' && msgbuff[1] == '2') {
                if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                    lsTextesEnAttenteBannis(client);
                }
                else {
                    Envoyer(client, "Seul l'administrateur du serveur peut effectuer cette opération.");
                }
            }
            //33#debanArt#chemin#nom
            else if(msgbuff[0] == '3' && msgbuff[1] == '3') {
                if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                    debanTextesEnAttenteBannis(client, msgbuff);
                }
                else {
                    Envoyer(client, "Seul l'administrateur du serveur peut effectuer cette opération.");
                }
            }
            //34#debanUti#nom
            else if(msgbuff[0] == '3' && msgbuff[1] == '4') {
                if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                    debanUtiEnAttenteBannis(client, msgbuff);
                }
                else {
                    Envoyer(client, "Seul l'administrateur du serveur peut effectuer cette opération.");
                }
            }
        }
        else {
            string s = "Vous êtes bannis !!";
            Envoyer(client, s.c_str());
        }
    }
    else {
        string s = "Vous n'êtes pas identifié !!";
        Envoyer(client, s.c_str());
    }
    //quitter : 86
    if(msgbuff[0] == '8' && msgbuff[1] == '6') {
        sortie = true;
        if(utilisateurs_connectes[client]) {
            hierarchie_utilisateur->enregistrerHistoriqueUtilisateur(utilisateurs_connectes[client]);
            utilisateurs_connectes[client]->setConnecte(false);
        }
        close(descripteur_connexion[client]);
        utilisateurs_connectes[client] = NULL;
        descripteur_connexion[client] = NULL;
        pthread_exit(NULL);
    }

    if(!sortie)
        return Recevoir(client);
}

void Wiki::onConnect(const int id_client) {
    TCPThreadServeur::onConnect(id_client);
}

HierarchieDoc* Wiki::getHierarchieDoc() {
    return hierarchie_doc;
}

HierarchieUtilisateur* Wiki::getHierarchieUtilisateur() {
    return hierarchie_utilisateur;
}

Utilisateur* Wiki::identification(const int client, const char * msgbuff) {//00#pseudo#pass
    Utilisateur * u = NULL;
    vector<string> * v = extractionDonnees(3, 2, '#', msgbuff);
    string reponse = "";
    char * identification = "0";
    if(v->size() > 1) {
        if(!u) {
            u = hierarchie_utilisateur->estUtilisateur(v->at(0) , v->at(1));
        }
        if(u) {
            reponse = "t";
            reponse = reponse + hierarchie_doc->getCategorieRoot()->getNom();
            utilisateurs_connectes[client] = u;
            u->setConnecte(true);

            //Mémoire partagée
            mon_tab_boites_reseau->boite_reseaux[client] = descripteur_connexion[client];
            mon_tab_boites_reseau->nom[client] = const_cast<char*>(u->getNom().c_str());

            //ajout du port et de l'ip de l'utilisateur
            u->setIp(utilisateur_ip[client]);
            u->setPort(utilisateur_port[client]);
        }
        else {
            reponse = "f";
        }
    }
    else {
        reponse = "Arguments insuffisants.";
    }
    identification = const_cast<char*>(reponse.c_str());
    Envoyer(client, identification);
    return u;
}

Utilisateur* Wiki::inscription(const int client, const char * msgbuff) {//01#pseudo#pass
    Utilisateur * u = NULL;
    vector<string> * v = extractionDonnees(3, 2, '#', msgbuff);
    string reponse = "";
    char * inscription= "0";
    if(v->size() > 1) {
        Utilisateur * u = NULL;
        u = hierarchie_utilisateur->estUtilisateur(v->at(0));
        if(!u) {
            u = hierarchie_utilisateur->ajouterUtilisateur(v->at(0), hierarchie_utilisateur->getGroupeRoot(), v->at(1), utilisateur_ip[client], utilisateur_port[client]);
            hierarchie_utilisateur->enregistrerUtilisateurEnDur(u);
            reponse = "t";
            reponse = reponse + hierarchie_doc->getCategorieRoot()->getNom();
            inscription = const_cast<char*>(reponse.c_str());
            utilisateurs_connectes[client] = u;
            u->setConnecte(true);

            //Mémoire partagée
            mon_tab_boites_reseau->boite_reseaux[client] = descripteur_connexion[client];
            mon_tab_boites_reseau->nom[client] = const_cast<char*>(u->getNom().c_str());
        }
        else {
            reponse = "f";
        }
    }
    else {
        reponse = "Arguments insuffisants.";
    }
    inscription = const_cast<char*>(reponse.c_str());
    Envoyer(client, inscription);
    return u;
}

void Wiki ::who(const int client) {
    reponse = "0";
    string s = "";
    for(int i=0; i<MAX_UTILISATEURS; i++) {
        if(utilisateurs_connectes[i]) {
            s = s + "[ " + utilisateurs_connectes[i]->getNom() + " ]     ";
        }
    }
    char * reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::ls(const int client, const char * msg) {//04#ls#chemin
    reponse = "0";
    string s = "";
    vector<string>* chemin = extractionDonnees(6, 1, '#', msg);
    if(chemin->size() > 0) {
        CategorieComposite * rep = extractionChemin(chemin->at(0));
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                if(aLeDroit("lecture", c, utilisateurs_connectes[client])) {
                    s = c->ls();
                    if(s == (c->getNom() + " : ")) {
                        s = s + "vide";
                    }
                }
                else {
                    s = "f#Vous n'avez pas le droit d'entrer dans cette catégorie.";
                }
            }
            else {
                s = "f#Vous ne pouvez pas entrer dans un article.";
            }
        }
        else {
            s = "f#La catégorie " + chemin->at(0) + " n'existe pas.";
        }
    }
    else {
        s = "f#Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mkCat(const int client, const char * msg) {//05#mkCat#chemin#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(9, 2, '#', msg);
    if(donnees->size() > 1) {
        CategorieComposite * rep = extractionChemin(donnees->at(0));
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                vector<CategorieComposite*> * v = c->find(donnees->at(1));
                if(v->size() == 0) {
                    Categorie * c1;
                    if(aLeDroit("ecriture", c, utilisateurs_connectes[client])) {
                        c->lock();
                        c1 = hierarchie_doc->ajouterCategorie(donnees->at(1), c, utilisateurs_connectes[client]);
                        c->unlock();
                        s = "Catégorie créée.";
                    }
                    else {
                        s = "Vous n'avez pas le droit de créer une catégorie dans la catégorie : " + donnees->at(1);;
                    }
                }
                else {
                    s = "Cette catégorie existe déjà.";
                }
            }
            else {
                s = "Pour créer une catégorie tapez la commande mkCat.";
            }
        }
        else {
            s = "La catégorie dans laquelle vous êtes n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mdCatD(const int client, const char * msg) {//06#mdCatD#chemin#nom#droits1#droits2...
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(10, -1, '#', msg);
    if(donnees->size() >= 11) {
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * rep = extractionChemin(concat_chemin_nom);
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                if(c->getProprietaire()->getNom() == utilisateurs_connectes[client]->getNom()) {
                    bool due = true;
                    bool dul = true;
                    bool dus = true;
                    bool dge = true;
                    bool dgl = true;
                    bool dgs = true;
                    bool dae = true;
                    bool dal = true;
                    bool das = true;
                    if(donnees->at(2) != "1")
                        due = false;
                    if(donnees->at(3) != "1")
                        dul = false;
                    if(donnees->at(4) != "1")
                        dus = false;
                    if(donnees->at(5) != "1")
                        dge = false;
                    if(donnees->at(6) != "1")
                        dgl = false;
                    if(donnees->at(7) != "1")
                        dgs = false;
                    if(donnees->at(8) != "1")
                        dae = false;
                    if(donnees->at(9) != "1")
                        dal = false;
                    if(donnees->at(10) != "1")
                        das = false;
                    c->lock();
                    c->changementDroits(due, dul, dus, dge, dgl, dgs, dae, dal, das);
                    c->unlock();
                    s = "Catégorie modifiée.";
                }
                else {
                    s = "Il faut être le propriétaire de la catégorie pour modifier ses droits.";
                }
            }
            else {
                s = "Pour modifier les droits d'un fichier veuillez entrer la commande mdArtD.";
            }
        }
        else {
            s = "Catégorie non trouvée !";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mdCat(const int client, const char * msg) {//07#mdCat#chemin#nom#nouveau_nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, 3, '#', msg);
    if(donnees->size() > 2) {
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * rep = extractionChemin(concat_chemin_nom);
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                if(aLeDroit("ecriture", c, utilisateurs_connectes[client])) {
                    c->lock();
                    c->setNom(donnees->at(2));
                    c->unlock();
                    s = "Catégorie modifiée.";
                }
                else {
                    s = "Vous n'avez pas le droit de modifier cette catégorie.";
                }
            }
            else {
                s = "Pour modifier un article veuillez entrer la commande mdArt.";
            }
        }
        else {
            s = "La catégorie dans laquelle vous êtes n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::find(const int client, const char * msg) {//08#find#chemin#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(8, 2, '#', msg);
    if(donnees->size() > 1) {
        CategorieComposite * rep = extractionChemin(donnees->at(0));
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                vector<CategorieComposite*> * v = c->find(donnees->at(1));
                if(v->size() > 0) {
                    for(int i=0; i<v->size(); i++) {
                        s = s + "[ " + v->at(i)->absoluteAdresse() + " ] ";
                    }
                }
                else {
                    s = donnees->at(1) + " non trouvé dans "+ donnees->at(0) +".";
                }
            }
            else {
                s = "Vous ne pouvez pas chercher dans un fichier.";
            }
        }
        else {
            s = "La catégorie dans laquelle vous êtes n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::findR(const int client, const char * msg) {//09#findR#chemin#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, 2, '#', msg);
    if(donnees->size() > 1) {
        CategorieComposite * rep = extractionChemin(donnees->at(0));
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                vector<CategorieComposite*> * v = c->findR(donnees->at(1));
                if(v->size() > 0) {
                    for(int i=0; i<v->size(); i++) {
                        s = s + "[ " + v->at(i)->absoluteAdresse() + " ] ";
                    }
                }
                else {
                    s = donnees->at(1) + " non trouvé dans "+ donnees->at(0) +" et ses sous-catégories.";
                }
            }
            else {
                s = "Vous ne pouvez pas chercher dans un fichier.";
            }
        }
        else {
            s = "La catégorie dans laquelle vous êtes n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::rmCat(const int client, const char * msg) {//10#rmCat#chemin#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, 2, '#', msg);
    if(donnees->size() > 1) {
        CategorieComposite * rep = extractionChemin(donnees->at(0));
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * a_sup = extractionChemin(concat_chemin_nom);
        if(rep && a_sup) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(c) {
                if(aLeDroit("suppression", a_sup, utilisateurs_connectes[client])) {
                    c->lock();
                    if(c->removeElement(a_sup)) {
                        s = a_sup->getNom() + " est bien supprimé";
                    }
                    else {
                        s = donnees->at(1) + " non trouvé dans "+ donnees->at(0) +" et ses sous-catégories.";
                    }
                    c->unlock();
                }
                else {
                    s = "Vous n'avez pas le droit de supprimer " + donnees->at(1) + ".";
                }
            }
            else {
                s = "Pour supprimer un fichier veuillez entrer la commande rmArt.";
            }
        }
        else {
            s = "La catégorie dans laquelle vous êtes n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mkArt(const int client, const char * msg) {//11#mkArt#chemin#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, 2, '#', msg);
    if(donnees->size() > 1) {
        if(donnees->at(1)[0] != '.') {
            CategorieComposite * rep = extractionChemin(donnees->at(0));
            if(rep) {
                Categorie * c = dynamic_cast<Categorie*>(rep);
                if(c) {
                    if(c->getNom() != donnees->at(1)) {
                        vector<CategorieComposite*> * v = c->find(donnees->at(1));
                        if(v->size() == 0) {
                            if(aLeDroit("ecriture", c, utilisateurs_connectes[client])) {
                                c->lock();
                                Article * a = hierarchie_doc->ajouterArticle(donnees->at(1), c, " ", utilisateurs_connectes[client]);
                                c->unlock();
                                a->lock();
                                s = "#t";
                                reponse = const_cast<char*>(s.c_str());
                                Envoyer(client, reponse);
                                char taille[1024] = "0";
                                int res = recv(descripteur_connexion[client], taille, (size_t)sizeof(taille), 0);
                                if(res < 0) {
                                    perror("recv dans mkArt");
                                }
                                int t = atoi(taille);
                                string contenue_texte = "";
                                while(contenue_texte.size() < t) {
                                    char msgbuff[1000] = "0";
                                    res = recv(descripteur_connexion[client], msgbuff, (size_t)sizeof(msgbuff), 0);
                                    if(res < 0) {
                                        perror("recv dans mdArt");
                                    }
                                    for(int i=0; i<strlen(msgbuff); i++) {
                                        contenue_texte = contenue_texte + msgbuff[i];
                                    }
                                }
                                a->setContenue(contenue_texte);
                                a->unlock();
                                s = donnees->at(1) + " bien enregistré.";
                            }
                            else {
                                s = "Vous n'avez pas le droit de créer un article dans la catégorie " + c->getNom() + ".";
                            }
                        }
                        else {
                            s = "Cet article existe déjà veuillez changer de nom ou le modifier.";
                        }
                    }
                    else {
                        s = "Vous ne pouvez pas appeler votre article du même nom que la catégorie qui le contient.";
                    }
                }
                else {
                    s = "Vous vous trouvez dans un fichier :~)??";
                }
            }
            else {
                s = "La catégorie dans laquelle vous êtes n'existe pas.";
            }
        }
        else {
            s = "Vous n'avez pas le droit de créer une catégorie avec comme première lettre un \".\".";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mdArt(const int client, const char * msg) {//12#mdArt#chemin#nom#nouveau_nom#attendre
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, -1, '#', msg);
    if(donnees->size() > 2) {
        string concac_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * art = extractionChemin(concac_chemin_nom);
        //met en attente l'utilisateur jusqu'à la libération de l'article avec -a
        bool attendre = false;
        if(donnees->size() == 4)
            if(donnees->at(3)  == "-a")
                attendre = true;

        if(art) {
            Article * a = dynamic_cast<Article*>(art);
            if(a) {
                bool pas_le_droit = false;
                if(aLeDroit("ecriture", a, utilisateurs_connectes[client])) {
                    if(!a->estLock() || attendre) {
                        a->lock();
                        a->setNom(donnees->at(2));
                        s = "#t";
                        reponse = const_cast<char*>(s.c_str());
                        Envoyer(client, reponse);
                        if(donnees->at(1) == donnees->at(2)) {
                            s = a->cat();
                            ostringstream out;
                            out<<s.size()<<'\0';
                            Envoyer(client, out.str().c_str());
                            char ok[1024] = "0";
                            int res = recv(descripteur_connexion[client], ok, (size_t)sizeof(ok), 0);
                            if(res < 0) {
                                perror("recv dans mdArt");
                            }
                            Envoyer(client, s.c_str());
                            char taille[1024] = "0";
                            res = recv(descripteur_connexion[client], taille, (size_t)sizeof(taille), 0);
                            if(res < 0) {
                                perror("recv dans mdArt");
                            }
                            int t = atoi(taille);
                            string contenue_texte = "";
                            while(contenue_texte.size() < t) {
                                char msgbuff[1000] = "0";
                                res = recv(descripteur_connexion[client], msgbuff, (size_t)sizeof(msgbuff), 0);
                                if(res < 0) {
                                    perror("recv dans mdArt");
                                }
                                for(int i=0; i<strlen(msgbuff); i++) {
                                    contenue_texte = contenue_texte + msgbuff[i];
                                }
                            }
                            a->setContenue(contenue_texte);
                        }
                        a->unlock();
                        s = donnees->at(2) + " bien modifié.";
                    }
                    else {
                        s = donnees->at(2) + " est actuellement en cours de modification.";
                    }
                }
                else {
                    s = "Vous n'avez pas le droit de modifier " + donnees->at(2) + ".";
                    pas_le_droit = true;
                }
            }
            else {
                s = "Pour modifier une catégorie veuillez entrer la commande mdCat";
            }

        }
        else {
            s = donnees->at(1) + " non trouvé.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::rmArt(const int client, const char * msg) {//13#rmArt#chemin#nom#attendre
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, -1, '#', msg);
    if(donnees->size() > 1) {
        CategorieComposite * rep = extractionChemin(donnees->at(0));
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * a_sup = extractionChemin(concat_chemin_nom);
        bool attendre = false;
        if(donnees->size()>2)
            if(donnees->at(2)  == "-a")
                attendre = true;
        if(donnees->size()>1) {
            Article * a = dynamic_cast<Article*>(a_sup);
            if(rep && a_sup) {
                Categorie * c = dynamic_cast<Categorie*>(rep);
                if(aLeDroit("suppression", a_sup, utilisateurs_connectes[client])) {
                    if(!c->estLock() || attendre) {
                        c->lock();
                        if(a_sup->getType() == "b") {
                            hierarchie_doc->retirerArticleEnAttenteBannis(a);
                        }
                        if(c->removeElement(a_sup)) {
                            s = a_sup->getNom() + " est bien supprimé";
                        }
                        else {
                            s = donnees->at(1) + " non trouvé dans "+ donnees->at(0) +" et ses sous-catégories.";
                        }
                        c->unlock();
                    }
                    else {
                        s = donnees->at(1) + " est actuellement en cours de modification par un autre utilisateur.";
                    }
                }
                else {
                    s = "Vous n'avez pas le droit de supprimer " + donnees->at(1) + ".";
                }
            }
            else {
                s = donnees->at(1) + " n'existe pas.";
            }
        }
        else {
            s = "Arguments insuffisants.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mdArtD(const int client, const char * msg) {//14#mdArtD#chemin#nom#droits1#droits2...
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(10, -1, '#', msg);
    if(donnees->size() >= 11) {
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * rep = extractionChemin(concat_chemin_nom);
        if(rep) {
            Article * a = dynamic_cast<Article*>(rep);
            if(a) {
                if(a->getProprietaire()->getNom() == utilisateurs_connectes[client]->getNom()) {
                    bool due = false;
                    bool dul = false;
                    bool dus = false;
                    bool dge = false;
                    bool dgl = false;
                    bool dgs = false;
                    bool dae = false;
                    bool dal = false;
                    bool das = false;
                    if(donnees->at(2) == "t" || donnees->at(2) == "1")
                        due = true;
                    if(donnees->at(3) == "t" || donnees->at(3) == "1")
                        dul = true;
                    if(donnees->at(4) == "t" || donnees->at(4) == "1")
                        dus = true;
                    if(donnees->at(5) == "t" || donnees->at(5) == "1")
                        dge = true;
                    if(donnees->at(6) == "t" || donnees->at(6) == "1")
                        dgl = true;
                    if(donnees->at(7) == "t" || donnees->at(7) == "1")
                        dgs = true;
                    if(donnees->at(8) == "t" || donnees->at(8) == "1")
                        dae = true;
                    if(donnees->at(9) == "t" || donnees->at(9) == "1")
                        dal = true;
                    if(donnees->at(10) == "t" || donnees->at(10) == "1")
                        das = true;
                    a->lock();
                    a->changementDroits(due, dul, dus, dge, dgl, dgs, dae, dal, das);
                    a->unlock();
                    s = "Article modifiée.";
                }
                else {
                    s = "Il faut être le propriétaire de l'article pour modifier ses droits.";
                }
            }
            else {
                s = "Pour changer les droits d'une catégorie entrez la commande mdCatD.";
            }
        }
        else {
            s = "Article non trouvée !";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::mkGrp(const int client, const char * msg) {//15#mkGrp#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(9, 1, '#', msg);
    if(donnees->size()>0) {
        if(!hierarchie_utilisateur->getGroupeRoot()->appartientParNom(donnees->at(0))) {
            vector<Groupe*> * v = hierarchie_utilisateur->getGroupeRoot()->tousMesGroupes();
            v->push_back(hierarchie_utilisateur->getGroupeRoot());
            bool trouve = false;
            for(int i=0; i<v->size() && !trouve; i++) {
                if(v->at(i)->getProprietaire())
                    if(v->at(i)->getProprietaire()->getNom() == utilisateurs_connectes[client]->getNom())
                        trouve = true;
            }
            if(!trouve) {
                Groupe * nouveau_groupe = hierarchie_utilisateur->ajouterGroupe(donnees->at(0), hierarchie_utilisateur->getGroupeRoot(), utilisateurs_connectes[client]);
                hierarchie_utilisateur->enregistrerGroupeEnDur(nouveau_groupe);
                hierarchie_utilisateur->enregistrerUtilisateursEnDur();
                s = "Groupe " + donnees->at(0) + " bien créé.";
            }
            else {
                s = "Vous êtes déjà le propriétaire du groupe : " + utilisateurs_connectes[client]->getGroupe()->getNom();
            }
        }
        else {
            s = "Ce groupe existe déjà veuillez changer de nom.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::rmGrp(const int client, const char * msg) {//16#rmGrp#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, 1, '#', msg);
    if(donnees->size()>0) {
        if(hierarchie_utilisateur->getGroupeRoot()->appartientParNom(donnees->at(0))) {
            vector<Groupe*> * v = hierarchie_utilisateur->getGroupeRoot()->tousMesGroupes();
            bool trouve = false;
            for(int i=0; i<v->size() && !trouve; i++) {
                if(v->at(i)->getProprietaire()) {
                    if(v->at(i)->getProprietaire()->getNom() == utilisateurs_connectes[client]->getNom()) {
                        vector<Utilisateur*> * utilisateurS = v->at(i)->tousMesUtilisateurs();//on informe tous les utilisateurs de la destruction du groupe
                        for(int j=0; j<utilisateurS->size(); j++) {
                            string temp = "99#Votre groupe a été supprimé, vous êtes désormet dans le groupe " + hierarchie_utilisateur->getGroupeRoot()->getNom() + ".";
                            utilisateurS->at(j)->envoyerMessage(temp);
                        }
                        hierarchie_utilisateur->getGroupeRoot()->removeElement(v->at(i));
                        trouve = true;
                        s = donnees->at(0) + " est bien supprimé.";
                    }
                }
            }
            if(!trouve) {
                s = "Aucun groupe sous votre responsabilité n'a été trouvé.";
            }
        }
        else {
            s = "Ce groupe n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::lsGroupe(const int client) {//17#lsGrp
    reponse = "0";
    string res = hierarchie_utilisateur->getGroupeRoot()->lsGroupe();
    reponse = const_cast<char*>(res.c_str());
    Envoyer(client, reponse);
}

void Wiki::mdGrp(const int client, const char * msg) {//18#mdGrp#nom#nouveau_nom
    reponse = "0";
    string s;
    vector<string>* donnees = extractionDonnees(9, 2, '#', msg);
    if(donnees->size()>1) {
        if(hierarchie_utilisateur->getGroupeRoot()->appartientParNom(donnees->at(0))) {
            vector<Groupe*> * v = hierarchie_utilisateur->getGroupeRoot()->tousMesGroupes();
            bool trouve = false;
            for(int i=0; i<v->size() && !trouve; i++) {
                if(v->at(i)->getProprietaire())
                    if(v->at(i)->getProprietaire()->getNom() == utilisateurs_connectes[client]->getNom()) {
                        v->at(i)->setNom(donnees->at(1));
                        trouve = true;
                        s = donnees->at(0) + " est bien modifié en " + donnees->at(1) + ".";
                        vector<Utilisateur*> * utilisateurS = v->at(i)->tousMesUtilisateurs();
                        for(int j=0; j<utilisateurS->size(); j++) {
                            string temp = "99#Votre groupe a changé de nom pour " + donnees->at(1) + ".";
                            utilisateurS->at(j)->envoyerMessage(temp);
                        }
                    }
            }
            if(!trouve) {
                s = "Aucun groupe sous votre responsabilité n'a été trouvé.";
            }
        }
        else {
            s = "Ce groupe n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::rjGrp(const int client, const char * msg) {//19#rjGrp#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(9, 1, '#', msg);
    if(donnees->size() > 0) {
        if(hierarchie_utilisateur->getGroupeRoot()->appartientParNom(donnees->at(0))) {
            vector<Groupe*> * v = hierarchie_utilisateur->getGroupeRoot()->tousMesGroupes();
            bool trouve = false;
            for(int i=0; i<v->size() && !trouve; i++) {
                if(v->at(i)->getNom() == donnees->at(0)) {
                    Utilisateur * proprio = v->at(i)->getProprietaire();
                    if(proprio) {
                        vector<Utilisateur*> * utilisateurS = proprio->getGroupe()->tousMesUtilisateursEnAttente();
                        ostringstream out;
                        out<<utilisateurS->size();
                        string temp = "99#" + out.str();
                        temp = temp + " utilisateur(s) souhaite(nt) entrer dans votre groupe, veuillez entrer la commande <accepter pseudo> pour voir le pseudo tapez <ls -mg>.";
                        proprio->envoyerMessage(temp);
                    }
                    if(utilisateurs_connectes[client]->estEnAttentePourRejoindreGroupe() == NULL) {
                        v->at(i)->ajouterMembreEnAttente(utilisateurs_connectes[client]);
                        utilisateurs_connectes[client]->mettreEnAttentePourRejoindreGroupe(v->at(i));
                        s = "Vous êtes en attente de validation pour entrer dans le groupe " + donnees->at(0) + ".";
                    }
                    else {
                        s = "Vous êtes déjà en attente de validation pour entrer dans un autre groupe.";
                    }
                    trouve = true;
                }
            }
        }
        else {
            s = "Ce groupe n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::lsMonGroupe(const int client) {//20#lsG#-m
    reponse = "0";
    string s = "";
    s = utilisateurs_connectes[client]->getGroupe()->ls();
    //Si c'est l'admin on lui envoie aussi le group Banni.
    if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
        s = s + hierarchie_utilisateur->getGroupeBannis()->ls();
    }
    char * reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::accepterUtilisateurDansSonGroupe(const int client, const char * msg) {//21#accepter#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(12, 1, '#', msg);
    if(donnees->size() > 0) {
        if(utilisateurs_connectes[client]->getNom() == utilisateurs_connectes[client]->getGroupe()->getProprietaire()->getNom()) {
            bool trouve = false;
            vector<Utilisateur*> * utilisateurS = utilisateurs_connectes[client]->getGroupe()->tousMesUtilisateursEnAttente();
            for(int i=0; i<utilisateurS->size(); i++) {
                if(utilisateurS->at(i)->getNom() == donnees->at(0)) {
                    trouve = true;
                    for(int i=0; i<utilisateurS->size(); i++) {
                        string temp = "99#L'utilisateur " + utilisateurS->at(i)->getNom() + " vient d'entrer dans votre groupe.";
                        utilisateurS->at(i)->envoyerMessage(temp);
                    }
                    utilisateurs_connectes[client]->getGroupe()->accepterUtilisateur(i);
                    string temp = "99#Vous venez d'être accepter dans le groupe " + utilisateurs_connectes[client]->getGroupe()->getNom() + ".";
                    utilisateurS->at(i)->envoyerMessage(temp);
                }
            }
            //Si c'est l'admin on vérifie dans le group Banni (pas de !trouve car s'il s'inscrit dans un groupe en meme temps alors il pourrait feinter).
            if(utilisateurs_connectes[client]->getNom() == hierarchie_utilisateur->getAdmin()->getNom()) {
                vector<Utilisateur*> * utilisateurS = hierarchie_utilisateur->getGroupeBannis()->tousMesUtilisateursEnAttente();
                for(int i=0; i<utilisateurS->size() && !trouve; i++) {
                    if(utilisateurS->at(i)->getNom() == donnees->at(0)) {
                        trouve = true;
                        hierarchie_utilisateur->getGroupeBannis()->accepterUtilisateur(i);
                    }
                }
            }
            if(trouve) {
                hierarchie_utilisateur->enregistrerUtilisateursEnDur();
                s = "Le membre " + donnees->at(0) + " a bien été ajouté dans votre groupe.";
            }
            else {
                s = "Le membre " + donnees->at(0) + " n'a pas demandé à entrer dans votre groupe.";
            }
        }
        else {
            s = "Vous n'êtes propriétaire d'aucun groupe.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::envoyerMessageA(const int client, const char * msg) {//22#send#nom#texte
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(8, 2, '#', msg);
    if(donnees->size() > 1) {
        Utilisateur * u = hierarchie_utilisateur->estUtilisateur(donnees->at(0));
        if(u) {
            string message = "98#";
            if(u->estConnecte())
                message = message + "[" + utilisateurs_connectes[client]->getNom() + "|conversation] ";
            else
                message = message + "[" + utilisateurs_connectes[client]->getNom() + "|mail] ";
            message = message + utilisateurs_connectes[client]->getNom() + " : ";
            message = message + donnees->at(1);
            u->envoyerMessage(message);
            if(u->estConnecte())
                s = "[" + u->getNom() + "|conversation] " + s;
            else
                s = "[" + u->getNom() + "|mail] " + s;
            s = "Message bien envoyé.";
        }
        else
            s = "Aucun utilisateur " + donnees->at(0) + " trouvé sur ce serveur.";
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::lsDroit(const int client, const char * msg) {//23#lsD#chemin
    reponse = "0";
    string s = "";
    vector<string>* donnes = extractionDonnees(7, 1, '#', msg);
    if(donnes->size() > 0) {
        CategorieComposite * rep = extractionChemin(donnes->at(0));
        if(rep) {
            Categorie * c = dynamic_cast<Categorie*>(rep);
            if(aLeDroit("lecture", c, utilisateurs_connectes[client])) {
                s = hierarchie_doc->lsDroit(c);
            }
            else {
                s = "Vous ne pouvez pas lister le contenue de cette catégorie.";
            }
        }
        else {
            s = "Catégorie " + donnes->at(0) + " non trouvée.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }


//-----------------------------------------------------------------------------------------------------------------
    string msgUDP = "Salut !!";
    char * temp = const_cast<char*>(msgUDP.c_str());
    envoieUdp(temp);
//-----------------------------------------------------------------------------------------------------------------
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::cat(const int client, const char * msg) {//24#cat#chemin#nom
    reponse = "0";
    string s = "";
    vector<string>* donnees = extractionDonnees(7, 2, '#', msg);
    if(donnees->size() > 1) {
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * rep = extractionChemin(concat_chemin_nom);
        if(rep) {
            Article * a = dynamic_cast<Article*>(rep);
            if(a) {
                if(aLeDroit("lecture", a , utilisateurs_connectes[client])) {
                    s = a->cat();
                    ostringstream out;
                    out<<s.size();
                    Envoyer(client, out.str().c_str());
                    char ok[1024] = "0";
                    int res = recv(descripteur_connexion[client], ok, (size_t)sizeof(ok), 0);
                    if(res < 0) {
                        perror("recv dans mdArt");
                    }
                }
                else {
                    s = "Vous n'avez pas le droit de lire cet article.";
                }
            }
            else {
                s = "Pour entrer dans une catégorie veuillez entrer la commande cd.";
            }
        }
        else {
            s = "Article non trouvé.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::quitGrp(const int client) {//25#quitGrp
    reponse = "0";
    string s = "";
    if(utilisateurs_connectes[client]->getGroupe()->removeElement(utilisateurs_connectes[client])) {
        hierarchie_utilisateur->getGroupeRoot()->addElement(utilisateurs_connectes[client]);
        s = "Vous êtes partis de votre groupe.";
    }
    else {
        s = "Vous êtes le propriétaire du groupe. Veuillez entrer la commande rmGrp pour supprimer votre groupe.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::uQuitGrp(const int client, const char * msg) {//26#uQuitGrp#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(12, 1, '#', msg);
    if(donnees->size()>0) {
        if(utilisateurs_connectes[client]->getGroupe()->getProprietaire()->getNom() == utilisateurs_connectes[client]->getNom()) {
            Utilisateur * u = utilisateurs_connectes[client]->getGroupe()->appartientUtilisateurParNom(donnees->at(0));
            if(u) {
                utilisateurs_connectes[client]->getGroupe()->removeElement(u);
                u->setGroupe(hierarchie_utilisateur->getGroupeRoot());
                string msg_util = "Le propriétaire du groupe " + utilisateurs_connectes[client]->getGroupe()->getProprietaire()->getNom() + " vous a bannis de son groupe.";
                u->envoyerMessage(msg_util.c_str());
                s = "Vous avez bannis " + donnees->at(0) + " de votre groupe.";
            }
            else {
                s = donnees->at(0) + " ne fait pas partis de vos membres.";
            }
        }
        else {
            s = "Vous n'êtes pas le propriétaire de votre groupe.";
        }
    }
    else {
        Envoyer(client, "Arguments insuffisants.");
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::envoieUdp(char * msg) {
    struct sockaddr_in serveur_addr;
    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_port = htons(port);
    serveur_addr.sin_addr.s_addr = /*inet_addr("10.0.2.255");*/htonl(INADDR_ANY);

    if(sendto(descripteur_udp, msg, sizeof(msg), 0, (struct sockaddr*) &serveur_addr, (int)sizeof(serveur_addr)) < 0)
        perror("sendTo udp");
}

int Wiki::ouvreSocketUDP() {
    descripteur_udp = socket(AF_INET, SOCK_DGRAM, /*0*/IPPROTO_UDP); // Créé socket UDP
    if(descripteur_udp == -1) {
        perror("Erreur lors de la création de la socket UDP\n");
        return -1;
    }
    /* Met la socket en mode broadcast */
    int on = 1;
    setsockopt(descripteur_udp, SOL_SOCKET, SO_BROADCAST, (char *)&on, sizeof(on));
    return descripteur_udp;
}

bool Wiki::aLeDroit(const string type, CategorieComposite * categorie_composite, Utilisateur * utilisateur) const {
    bool a_le_droit = false;
    if(type == "lecture") {
        if(categorie_composite && utilisateur && categorie_composite->getProprietaire()) {
            if((categorie_composite->getDroits().droit_lecture_utilisateur &&
                categorie_composite->getProprietaire()->getNom() == utilisateur->getNom()) ||
                (categorie_composite->getDroits().droit_lecture_groupe &&
                categorie_composite->getProprietaire()->getGroupe()->appartient(utilisateur)) ||
                categorie_composite->getDroits().droit_lecture_autre ||
                utilisateur->getNom() == hierarchie_utilisateur->getAdmin()->getNom())
                a_le_droit = true;
        }
    }
    else if(type == "ecriture") {
        if(categorie_composite && utilisateur && categorie_composite->getProprietaire()) {
            if((categorie_composite->getDroits().droit_ecriture_utilisateur &&
                categorie_composite->getProprietaire()->getNom() == utilisateur->getNom()) ||
                (categorie_composite->getDroits().droit_ecriture_groupe &&
                categorie_composite->getProprietaire()->getGroupe()->appartient(utilisateur)) ||
                categorie_composite->getDroits().droit_ecriture_autre ||
                utilisateur->getNom() == hierarchie_utilisateur->getAdmin()->getNom())
                a_le_droit = true;
        }
    }
    else if(type == "suppression") {
        if(categorie_composite && utilisateur && categorie_composite->getProprietaire()) {
            if((categorie_composite->getDroits().droit_suppression_utilisateur &&
                categorie_composite->getProprietaire()->getNom() == utilisateur->getNom()) ||
                (categorie_composite->getDroits().droit_suppression_groupe &&
                categorie_composite->getProprietaire()->getGroupe()->appartient(utilisateur)) ||
                categorie_composite->getDroits().droit_suppression_autre ||
                utilisateur->getNom() == hierarchie_utilisateur->getAdmin()->getNom())
                a_le_droit = true;
        }
    }
    return a_le_droit;
}

void Wiki::crash() {//27#crash
    Categorie * crash = NULL;
    crash->getDroits();
}

void Wiki::reboot() {//28#reboot
    hierarchie_doc->enregistrerEnDur();
    hierarchie_doc->enregistrerArticleEnAttenteBannis();
    hierarchie_utilisateur->enregistrerGroupesEnDur();
    hierarchie_utilisateur->enregistrerUtilisateursEnDur();
    hierarchie_utilisateur->enregistrerHistoriqueUtilisateurs();
    cout<<"L'enregistrement des données c'est bien déroulé... Redémarrage"<<endl;
    this->~Wiki();
}

void Wiki::bannirUtilisateur(const int client, const char * msg) {//29#banUti#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(10, 1, '#', msg);
    if(donnees->size() > 0) {
        Utilisateur * u = NULL;
        u = hierarchie_utilisateur->estUtilisateur(donnees->at(0));
        if(u) {
            if(!u->estEnAttentePourRejoindreGroupe()) {
                hierarchie_utilisateur->getGroupeBannis()->ajouterMembreEnAttente(u);
                s = "Vous avez demandé à bannir " + donnees->at(0) + " des membres.";
                string message = "99#";
                message = message + "Vous avez été dénoncé par un utilisateur. L'admin ";
                message = message + hierarchie_utilisateur->getAdmin()->getNom();
                message = message + " va vérifier votre historique. Vous pouvez lui envoyer un message (mail s'il est hors-ligne) avec la commande <send ";
                message = message + hierarchie_utilisateur->getAdmin()->getNom();
                message = message + " votre message>.";
                u->envoyerMessage(message);
                string message2 = "";
                message2 = "99#";
                message2 = message2 + "Un membre a été dénoncé. Regardez dans le dossier \"Utilisateur\" et plus particulièrement le fichier \"" + u->getNom() + "\". Vous pourez retrouver son pseudo en tapant <ls -mg>.";
                hierarchie_utilisateur->getGroupeBannis()->getProprietaire()->envoyerMessage(message2);

            }
            else {
                s = donnees->at(0) + " est déjà en demande d'être bannis.";
            }
        }
        else {
            s = donnees->at(0) + " ne fait pas partis des membres.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::enregistrer(const int client) {//30#enregistrer
    reponse = "0";
    string s = "";
    hierarchie_doc->enregistrerEnDur();
    hierarchie_doc->enregistrerArticleEnAttenteBannis();
    hierarchie_utilisateur->enregistrerGroupesEnDur();
    hierarchie_utilisateur->enregistrerUtilisateursEnDur();
    hierarchie_utilisateur->enregistrerHistoriqueUtilisateurs();
    s = "L'enregistrement des données c'est bien déroulé.";
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::bannirArticle(const int client, const char * msg) {//31#banArt#chemin#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(10, 2, '#', msg);
    if(donnees->size() > 1) {
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * rep = extractionChemin(concat_chemin_nom);
        if(rep) {
            Article * a = dynamic_cast<Article*>(rep);
            if(a) {
                if(hierarchie_doc->ajouterArticleEnAttenteBannis(a)) {
                    s = "Vous avez demandé à bannir " + donnees->at(1) + " des articles.";
                }
                else {
                    s = "Cet article est déjà en attente d'être bannis.";
                }
            }
            else {
                s = "Vous ne pouvez pas dire qu'une catégorie est à bannir.";
            }
        }
        else {
            s = donnees->at(1) + " n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::lsTextesEnAttenteBannis(const int client) {//32#ls-b
    reponse = "0";
    string s = "";
    s = hierarchie_doc->lsArticleEnAttenteBannis();
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::debanTextesEnAttenteBannis(const int client, const char * msg) {//33#debanArt#chemin#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(12, 2, '#', msg);
    if(donnees->size() > 1) {
        string concat_chemin_nom = donnees->at(0) + "/" + donnees->at(1);
        CategorieComposite * rep = extractionChemin(concat_chemin_nom);
        if(rep) {
            Article * a = dynamic_cast<Article*>(rep);
            if(a) {
                if(hierarchie_doc->retirerArticleEnAttenteBannis(a)) {
                    s = "Vous avez débanni " + donnees->at(1) + ".";
                }
                else {
                    s = "Cet article n'est pas en attente d'être bannis.";
                }
            }
            else {
                s = "Vous ne pouvez pas dire qu'une catégorie est à débannir.";
            }
        }
        else {
            s = donnees->at(1) + " n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

void Wiki::debanUtiEnAttenteBannis(const int client, const char * msg) {//34#debanUti#nom
    reponse = "0";
    string s = "";
    vector<string> * donnees = extractionDonnees(12, 1, '#', msg);
    if(donnees->size() > 0) {
        Utilisateur * u = hierarchie_utilisateur->estUtilisateur(donnees->at(0));
        if(u) {
            bool trouve = false;
            vector<Utilisateur*> * utilisateurS = hierarchie_utilisateur->getGroupeBannis()->tousMesUtilisateursEnAttente();
            for(int i=0; i<utilisateurS->size() && !trouve; i++) {
                if(u->getNom() == utilisateurS->at(i)->getNom()) {
                    u->mettreEnAttentePourRejoindreGroupe(NULL);
                    utilisateurS->erase(utilisateurS->begin() + i);
                    s = "Vous avez débanni " + donnees->at(1) + ".";
                    trouve = true;
                }
            }
            if(!trouve) {
                s = donnees->at(0) + " n'est pas en attente d'être bannis.";
            }
        }
        else {
            s = donnees->at(0) + " n'existe pas.";
        }
    }
    else {
        s = "Arguments insuffisants.";
    }
    reponse = const_cast<char*>(s.c_str());
    Envoyer(client, reponse);
}

vector<string>* Wiki::extractionDonnees(const int appartir_de, const int nb, const char carac, const char * msg) const {
    int count = 0;
    if(nb == -1) {
        for(int i=0; i<strlen(msg); i++) {
            if(msg[i] == carac)
                count++;
        }
    }
    else {
        count = nb;
    }
    vector<string> * v = new vector<string>;
    int h = appartir_de;//pour enlever xx# : le code de la fonction (si besoin est)
    for(int i=0; i<count; i++) {
        string temp = "";
        while(msg[h] != carac && h < strlen(msg)) {
            temp = temp + msg[h];
            h++;
        }
        v->push_back(temp);
        h++;//pour enlever le carac de séparation
    }
    return v;
}

CategorieComposite* Wiki::extractionChemin(const string chemin) const {
    int count = 0;
    Categorie * rep;
    Article * art;
    for(int i=0; i<chemin.size(); i++) {
        if(chemin[i] == '/')
            count++;
    }
    rep = hierarchie_doc->getCategorieRoot();
    bool erreur= false;
    if(count != 0) {
        char * temp = const_cast<char*>(chemin.c_str());
        vector<string>* chemin_divise = extractionDonnees(0, count+1, '/', temp);
        vector<CategorieComposite*> * v = new vector<CategorieComposite*>;
        for(int i=0; i<chemin_divise->size() && !erreur; i++) {
            if(chemin_divise->at(i) != hierarchie_doc->getCategorieRoot()->getNom()) {
                v = rep->find(chemin_divise->at(i));
                if(v->size()<0)
                    erreur = true;
                else {
                    bool trouve = false;
                    for(int j=0; j<v->size() && !trouve; j++) {
                        Categorie* c = dynamic_cast<Categorie*>(v->at(j));
                        Article * a = dynamic_cast<Article*>(v->at(j));
                        if(c) {
                            rep = c;
                            art = NULL;
                            trouve = true;
                        }
                        else if(a) {
                            art = a;
                            rep = NULL;
                            trouve = true;
                        }
                    }
                    if(!trouve)
                        erreur = true;
                }
            }
        }
    }
    if(erreur) {
        rep = NULL;
        art = NULL;
    }
    if(rep)
        return rep;
    else
        return art;
}

void* Wiki::startThreadMessages(void * obj) {
    WikiNumClient * strc = reinterpret_cast<WikiNumClient *>(obj);
    if(strc) {
        strc->serveur->verifierMessage(strc->id_client);
    }
}

void Wiki::verifierMessage(const int client) {
    if(utilisateurs_connectes[client]) {
        struct msgbuf {long etiq; char caractere[1024];} msg;
        key_t cle = ftok("keys", 1);
        int file = msgget(cle, IPC_CREAT|0666);
        char * nom = const_cast<char*>(utilisateurs_connectes[client]->getNom().c_str());
        int nombre = (int)nom;
        msg.etiq = nombre;
        int reception = msgrcv(file, &msg, (size_t)sizeof(msg.caractere), msg.etiq, 0);
        Envoyer(client, msg.caractere);
        return verifierMessage(client);
    }
    else
        pthread_exit(NULL);
}
