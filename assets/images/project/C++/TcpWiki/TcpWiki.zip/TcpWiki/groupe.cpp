#include "groupe.h"

Groupe::Groupe(string n, Groupe * p, Utilisateur * proprio) : GroupeComposite(n, p) {
    contenues = new vector<GroupeComposite*>;
    en_attente = new vector<Utilisateur*>;
    proprietaire = proprio;
}

Groupe::~Groupe() {
    for(int i=0; i<contenues->size(); i++) {
        delete contenues->at(i);
        contenues->erase(contenues->begin() + i);
    }
    delete contenues;
    for(int i=0; i<en_attente->size(); i++) {
        delete en_attente->at(i);
        en_attente->erase(en_attente->begin() + i);
    }
    delete en_attente;
    delete proprietaire;
}

int Groupe::nbElement() {
    return contenues->size();
}

Groupe* Groupe::addElement(GroupeComposite * c) {
    if(c->getParent() != NULL) {
        if(c->getParent()->getParent() != NULL) {//Si le groupe n'appartient pas au 1er groupe alors on le déplace
            c->setParent(c->getParent()->getParent());
            c->getParent()->contenues->push_back(c);
            return c->getParent();
        }
    }
    if(c->getParent() != NULL && c->getParent() != this) {
        c->getParent()->removeElement(c);
    }
    if(c->getParent() != this) {
        c->setParent(this);
    }
    Utilisateur * u = dynamic_cast<Utilisateur*>(c);
    if(u) {
        if(u->getGroupe()->getNom() != getNom()) {
            u->getGroupe()->removeElement(c);
        }
    }
    contenues->push_back(c);
    return this;
}

bool Groupe::removeElement(GroupeComposite * c) {
    int i = 0;
    bool trouve = false;
    while(i<contenues->size() && !trouve) {
        if(contenues->at(i) == c) {
            trouve = true;
        }
        else {
          i++;
        }
    }
    if(i==contenues->size() && !trouve) {
        return false;
    }
    Groupe * g = dynamic_cast<Groupe*>(contenues->at(i));
    if(g) {
        g->proprietaire->setGroupe(this);
        vector<Utilisateur*> * v = g->tousMesUtilisateurs();
        for(int i=0; i<v->size(); i++) {
            v->at(i)->setGroupe(this);
        }
    }
    contenues->erase(contenues->begin() + i);
    return true;
}

bool Groupe::appartient(GroupeComposite * c) {
    int i = 0;
    while(i<contenues->size()) {
        if(contenues->at(i) == c) {
            return true;
        }
        else {
          i++;
        }
    }
    return false;
}

bool Groupe::appartientParNom(string nom) {
    int i = 0;
    while(i<contenues->size()) {
        Groupe * g = dynamic_cast<Groupe*>(contenues->at(i));
        if(g) {
            if(g->getNom() == nom) {
                return true;
            }
            i++;
        }
        else {
          i++;
        }
    }
    return false;
}

Utilisateur* Groupe::appartientUtilisateurParNom(string nom) {
    int i = 0;
    while(i<contenues->size()) {
        Utilisateur * u = dynamic_cast<Utilisateur*>(contenues->at(i));
        if(u) {
            if(u->getNom() == nom) {
                return u;
            }
        }
        i++;
    }
    return NULL;
}

Utilisateur* Groupe::appartientUtilisateurParNomRecursif(string nom) {
    int i = 0;
    while(i<contenues->size()) {
        Utilisateur * u = dynamic_cast<Utilisateur*>(contenues->at(i));
        if(u) {
            if(u->getNom() == nom) {
                return u;
            }
        }
        else {
            Groupe * g = dynamic_cast<Groupe*>(contenues->at(i));
            if(g) {//cela marchera forcément mais un test ne coute rien
                Utilisateur * temp_u = g->appartientUtilisateurParNomRecursif(nom);
                if(temp_u) {//si la fonction n'a pas renvoyé NULL
                    return temp_u;
                }
            }
        }
        i++;
    }
    return NULL;
}

vector<Utilisateur*>* Groupe::tousMesUtilisateurs() {
    vector<Utilisateur*> * v = new vector<Utilisateur*>;
    int i = 0;
    while(i<contenues->size()) {
        Utilisateur * u = dynamic_cast<Utilisateur*>(contenues->at(i));
        if(u) {
            v->push_back(u);
        }
        i++;
    }
    return v;
}

vector<Utilisateur*>* Groupe::tousMesUtilisateursRecursif() {
    vector<Utilisateur*> * v = new vector<Utilisateur*>;
    int i = 0;
    if(proprietaire) {
        v->push_back(proprietaire);
    }
    while(i<contenues->size()) {
        Utilisateur * u = dynamic_cast<Utilisateur*>(contenues->at(i));
        if(u) {
            v->push_back(u);
        }
        else {
            Groupe * g = dynamic_cast<Groupe*>(contenues->at(i));
            if(g) {
                vector<Utilisateur*> * temp = g->tousMesUtilisateursRecursif();
                for(int h=0; h<temp->size(); h++) {
                    v->push_back(temp->at(h));
                }
            }
        }
        i++;
    }
    return v;
}

vector<Groupe*>* Groupe::tousMesGroupes() {
    vector<Groupe*> * v = new vector<Groupe*>;
    int i = 0;
    while(i<contenues->size()) {
        Groupe * g = dynamic_cast<Groupe*>(contenues->at(i));
        if(g) {
            v->push_back(g);
        }
        i++;
    }
    return v;
}

vector<Groupe*>* Groupe::tousMesGroupesRecursif() {
    vector<Groupe*> * v = new vector<Groupe*>;
    int i = 0;
    while(i<contenues->size()) {
        Groupe * g = dynamic_cast<Groupe*>(contenues->at(i));
        if(g) {
            v->push_back(g);
            vector<Groupe*> * temp = g->tousMesGroupesRecursif();
            for(int h=0; h<temp->size(); h++) {
                v->push_back(temp->at(h));
            }
        }
        i++;
    }
    return v;
}

Utilisateur* Groupe::getProprietaire() {
    return proprietaire;
}

void Groupe::setProprietaire(Utilisateur * u) {
    if(u) {
        if(u->getGroupe()) {
            u->getGroupe()->removeElement(u);
            u->setGroupe(this);
        }
        else {
            u->setGroupe(this);
        }
    }
    proprietaire = u;
}

string Groupe::lsGroupe() {
    string resultat = "Groupes : \n      ";
    vector<Groupe*> * v = tousMesGroupes();
    if(v->size()==0) {
        resultat = resultat + "Aucun groupe n'à encore été créé.";
    }
    else {
        for(int i=0; i<v->size(); i++) {
            resultat = resultat + "[" + v->at(i)->getNom() + "]\n      ";
        }
    }
    return resultat;
}

string Groupe::lsUtilisateur() {
    string resultat = getNom() + " : ";
    vector<Utilisateur*> * v = tousMesUtilisateurs();
    for(int i=0; i<v->size(); i++) {
        resultat = resultat + "[" + v->at(i)->getNom() + "]    ";
    }
    return resultat;
}

string Groupe::ls() {
    string resultat = "----Groupe : " + getNom() + "----\n";
    resultat = resultat + " | ----Connecté----\n";
    int compteur_utilisateurs = 0;
    if(proprietaire->estConnecte()) {
        resultat = resultat + " |   [Proprio|" + proprietaire->getNom() + "]    \n";
        compteur_utilisateurs++;
    }
    vector<Utilisateur*> * utilisateurS = tousMesUtilisateurs();
    for(int i=0; i<utilisateurS->size(); i++) {
        if(utilisateurS->at(i)->getNom()!=proprietaire->getNom() && utilisateurS->at(i)->estConnecte()) {
            resultat = resultat + " |     [" + utilisateurS->at(i)->getNom() + "]    \n";
            compteur_utilisateurs++;
        }
    }
    if(compteur_utilisateurs == 0) {
        resultat = resultat + " |     Il n'y a pas d'utilisateur connecté.\n";
    }
    compteur_utilisateurs = 0;
    resultat = resultat + " | ----Non Connecté----\n";
    if(!proprietaire->estConnecte()) {
        resultat = resultat + " |   [Proprio|" + proprietaire->getNom() + "]    \n";
        compteur_utilisateurs++;
    }
    for(int i=0; i<utilisateurS->size(); i++) {
        if(utilisateurS->at(i)->getNom()!=proprietaire->getNom() && !utilisateurS->at(i)->estConnecte()) {
            resultat = resultat + " |     [" + utilisateurS->at(i)->getNom() + "]    \n";
            compteur_utilisateurs++;
        }
    }
    if(compteur_utilisateurs == 0) {
        resultat = resultat + " |     Tous les utilisateurs sont connectés.\n";
    }
    if(en_attente->size()>0) {
        resultat = resultat + " | ----En attente----\n";
        for(int i=0; i<en_attente->size(); i++) {
            resultat = resultat + " |     [" + en_attente->at(i)->getNom() + "]    \n";
        }
    }
    return resultat;
}

void Groupe::setNom(string s) {
    nom = s;
}

void Groupe::ajouterMembreEnAttente(Utilisateur * u) {
    en_attente->push_back(u);
}

vector<Utilisateur*>* Groupe::tousMesUtilisateursEnAttente() {
    return en_attente;
}

void Groupe::accepterUtilisateur(int position) {
    addElement(en_attente->at(position));
    en_attente->at(position)->mettreEnAttentePourRejoindreGroupe(NULL);
    en_attente->erase(en_attente->begin() + position);
}
