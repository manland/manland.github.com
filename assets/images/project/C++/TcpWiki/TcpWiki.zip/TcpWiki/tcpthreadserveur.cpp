#include "tcpthreadserveur.h"

TCPThreadServeur::TCPThreadServeur(int p) : TCPserveur(p)
{
    nb_max_thread = 10;
//    pthread_mutex_t verrou = PTHREAD_MUTEX_INITIALIZER;
}

TCPThreadServeur::~TCPThreadServeur() {

}

void TCPThreadServeur::onConnect(const int id_client) {
    ServeurNumClient * temp = new ServeurNumClient;
    temp->serveur = this;
    temp->id_client = id_client;
    pthread_create(&thread, 0, TCPThreadServeur::startThreadRecevoir, (void*)temp);
//    pthread_create(&thread, 0, TCPThreadServeur::startThreadEnvoyer, (void*)temp);
}

void* TCPThreadServeur::startThreadEnvoyer(void * obj) {
    ServeurNumClient * strc = reinterpret_cast<ServeurNumClient *>(obj);
    if(strc) {
        strc->serveur->Envoyer(strc->id_client);
    }
}

void* TCPThreadServeur::startThreadRecevoir(void * obj) {
    ServeurNumClient * strc = reinterpret_cast<ServeurNumClient *>(obj);
    if(strc) {
        strc->serveur->Recevoir(strc->id_client);
    }
}
