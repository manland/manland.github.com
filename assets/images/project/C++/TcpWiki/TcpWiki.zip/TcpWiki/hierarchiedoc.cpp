#include "hierarchiedoc.h"

HierarchieDoc::HierarchieDoc() {
    categorie_root = new Categorie("root", NULL, NULL);
    liaison_doc_proprio = new vector<struc_catcomp_proprio>;
    categorie_root->restaurerDuDurRecursif(liaison_doc_proprio);
    articles_en_attente_bannis = new vector<string>;
    restaurerArticleEnAttenteBannis();
}

HierarchieDoc::~HierarchieDoc() {
    delete categorie_root;
    liaison_doc_proprio->clear();
    delete liaison_doc_proprio;
    articles_en_attente_bannis->clear();
    delete articles_en_attente_bannis;
}

Categorie* HierarchieDoc::ajouterCategorie(string nom, Categorie * parent, Utilisateur * appartient_a) {
    if(!parent)
        parent = categorie_root;
    Categorie * c = new Categorie(nom, parent, appartient_a);
    return c;
}

Article* HierarchieDoc::ajouterArticle(string nom, Categorie * parent, string contenu, Utilisateur * appartient_a) {
    if(!parent)
        parent = categorie_root;
    Article * a = new Article(nom, parent, contenu, appartient_a);
    return a;
}

void HierarchieDoc::enregistrerEnDur() {
    categorie_root->enregistrerEnDurRecursif();
}

void HierarchieDoc::enregistrerArticleEnDur(Article * a) {
    a->enregistrerEnDurRecursif();
}

Categorie* HierarchieDoc::getCategorieRoot() {
    return categorie_root;
}

string HierarchieDoc::ls(Categorie * c) {
    return c->ls();
}

string HierarchieDoc::lsDroit(Categorie * c) {
    return c->lsDroit();
}

void HierarchieDoc::lierDocProprios(HierarchieUtilisateur * hierarchie_utilisateur) {
    for(int i=0; i<liaison_doc_proprio->size(); i++) {
        Utilisateur * u = hierarchie_utilisateur->estUtilisateur(liaison_doc_proprio->at(i).proprio);
        if(u) {
            liaison_doc_proprio->at(i).cat->setAppartientA(u);
        }
    }
}

bool HierarchieDoc::ajouterArticleEnAttenteBannis(Article * a) {
    bool trouve = false;
    for(int i=0; i<articles_en_attente_bannis->size() && !trouve; i++) {
        if(articles_en_attente_bannis->at(i) == a->absoluteAdresse()) {
            trouve = true;
        }
    }
    if(!trouve) {
        a->setType("b");
        articles_en_attente_bannis->push_back(a->absoluteAdresse());
        enregistrerArticleEnAttenteBannis();
    }
    return !trouve;
}

bool HierarchieDoc::retirerArticleEnAttenteBannis(Article * a) {
    bool trouve = false;
    for(int i=0; i<articles_en_attente_bannis->size() && !trouve; i++) {
        if(articles_en_attente_bannis->at(i) == a->absoluteAdresse()) {
            trouve = true;
            a->setType("a");
            articles_en_attente_bannis->erase(articles_en_attente_bannis->begin() + i);
            enregistrerArticleEnAttenteBannis();
        }
    }
    return trouve;
}

string HierarchieDoc::lsArticleEnAttenteBannis() {
    string s = "";
    for(int i=0; i<articles_en_attente_bannis->size(); i++) {
        s = s + "[ " + articles_en_attente_bannis->at(i) + " ]    ";
    }
    if(s == "")
        s = "vide";
    return s;
}

void HierarchieDoc::enregistrerArticleEnAttenteBannis() {
    ofstream fichier("textes_bannis", ios::out | ios::trunc);//ouverture en écriture avec effacement des données
    if(fichier)
    {
        for(int i=0; i<articles_en_attente_bannis->size(); i++) {
            fichier<<articles_en_attente_bannis->at(i)<<endl;
        }
        fichier.close();
    }
    else
        cout<<"Erreur serveur : impossible d'ouvrir le fichier des textes_bannis en écriture !"<<endl;
}

void HierarchieDoc::restaurerArticleEnAttenteBannis() {
    ifstream fichier("textes_bannis", ios::in);//ouverture en lecture
    if(fichier) {
        string ligne = "";
        while(getline(fichier, ligne)) {//tant qu'il y a des lignes à lire
            CategorieComposite * c = find(ligne);
            if(c) {
                Article * a = dynamic_cast<Article*>(c);
                if(a) {
                    articles_en_attente_bannis->push_back(a->absoluteAdresse());
                    a->setType("b");
                }
            }
            else {
                cout<<"fichier bannis : "<<ligne<<" n'a pas été trouvé dans la hiérarchie."<<endl;
            }
        }
        fichier.close();
    }
    else
        cout<<"Erreur serveur : impossible d'ouvrir le fichier des textes_bannis en lecture !"<<endl;
}

CategorieComposite* HierarchieDoc::find(const string chemin) {
    int count = 0;
    Categorie * rep = getCategorieRoot();
    Article * art;
    for(int i=0; i<chemin.size(); i++) {
        if(chemin[i] == '/')
            count++;
    }
    bool erreur= false;
    if(count != 0) {
        count++;
        vector<string> * chemin_divise = new vector<string>;
        int h = 0;
        for(int i=0; i<count; i++) {
            string temp = "";
            while(chemin[h] != '/' && h < chemin.size()) {
                temp = temp + chemin[h];
                h++;
            }
            chemin_divise->push_back(temp);
            h++;//pour enlever le carac de séparation
        }
        vector<CategorieComposite*> * v = new vector<CategorieComposite*>;
        for(int i=0; i<chemin_divise->size() && !erreur; i++) {
            if(chemin_divise->at(i) != getCategorieRoot()->getNom()) {
                v = rep->find(chemin_divise->at(i));
                if(v->size()<0)
                    erreur = true;
                else {
                    bool trouve = false;
                    for(int j=0; j<v->size() && !trouve; j++) {
                        Categorie * c = dynamic_cast<Categorie*>(v->at(j));
                        Article * a = dynamic_cast<Article*>(v->at(j));
                        if(c) {
                            rep = c;
                            art = NULL;
                            trouve = true;
                        }
                        else if(a) {
                            art = a;
                            rep = NULL;
                            trouve = true;
                        }
                    }
                    if(!trouve)
                        erreur = true;
                }
            }
        }
    }
    if(erreur) {
        rep = NULL;
        art = NULL;
    }
    if(rep)
        return rep;
    else
        return art;
}
