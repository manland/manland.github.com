#include "utilisateur.h"

Utilisateur::Utilisateur(string n, Groupe * p, string pwd, string i, int po) : GroupeComposite(n, p) {
    mot_de_passe = pwd;
    ip = i;
    port = po;
    est_en_attente_pour_rejoindre_groupe = false;
    est_connecte = false;
    historique = new vector<string>();
    char * c = const_cast<char*>(n.c_str());
    id_file_message = (long)c;
}

Utilisateur::~Utilisateur() {
    historique->clear();
    delete historique;
}

string Utilisateur::getMotDePasse() {
    return mot_de_passe;
}

Groupe* Utilisateur::getGroupe() {
    return parent;
}

void Utilisateur::setGroupe(Groupe * p) {
    parent = p;
}

string Utilisateur::getIp() {
    return ip;
}

int Utilisateur::getPort() {
    return port;
}

void Utilisateur::setIp(string i) {
    ip = i;
}

void Utilisateur::setPort(int p) {
    port = p;
}

Groupe* Utilisateur::estEnAttentePourRejoindreGroupe() {
    return est_en_attente_pour_rejoindre_groupe;
}

void Utilisateur::mettreEnAttentePourRejoindreGroupe(Groupe * g) {
    est_en_attente_pour_rejoindre_groupe = g;
}

bool Utilisateur::estConnecte() {
    return est_connecte;
}

void Utilisateur::setConnecte(bool b) {
    est_connecte = b;
}

void Utilisateur::ajoutHistorique(string s) {
    string ss = s;
    historique->push_back(ss);
}

void Utilisateur::envoyerMessage(string text) {
    struct msgbuf {long etiq; char caractere[1024];} msg;
    key_t cle = ftok("keys", 1);
    int file = msgget(cle, IPC_CREAT|0666);
    msg.etiq = id_file_message;
    for(int i=0; i<text.size(); i++) {
        msg.caractere[i] = text[i];
    }
    int envoi = msgsnd(file, &msg, (size_t)sizeof(msg.caractere), 0);
    if(envoi == -1) {
        cout<<"erreur d'envoie dans la file de message"<<endl;
    }
}

vector<string>* Utilisateur::getHistorique() {
    return historique;
}


