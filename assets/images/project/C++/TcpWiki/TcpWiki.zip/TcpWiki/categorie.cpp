#include "categorie.h"

Categorie::Categorie(string n, Categorie * p, Utilisateur * appa) : CategorieComposite(n, p, appa) {
    contenues = new vector<CategorieComposite*>;
    type = "+";
    type_par_defaut = "+";
}

Categorie::~Categorie() {
    for(int i=0; i<contenues->size(); i++) {
        delete contenues->at(i);
        contenues->erase(contenues->begin() + i);
    }
    delete contenues;
}

string Categorie::ls() {
    string resultat = getNom() + " : ";
    for(int i=0; i<contenues->size(); i++) {
        resultat = resultat + "[" + contenues->at(i)->getType() + " | " + contenues->at(i)->getNom() + "]    ";
    }
    return resultat;
}

int Categorie::nbElement() {
    return contenues->size();
}

vector<CategorieComposite*>* Categorie::find(string s) {
    vector<CategorieComposite*> * res = new vector<CategorieComposite*>;
    for(int i=0; i<contenues->size(); i++) {
        bool b = contenues->at(i)->getNom() == s;
        if(b) {
            res->push_back(contenues->at(i));
        }
    }
    return res;
}

vector<CategorieComposite*>* Categorie::findR(string s) {
    vector<CategorieComposite*> * res = new vector<CategorieComposite*>;
    for(int i=0; i<contenues->size(); i++) {
        if(contenues->at(i)->getNom() == s)
            res->push_back(contenues->at(i));
        Categorie * c = dynamic_cast<Categorie*>(contenues->at(i));
        if(c) {
            vector<CategorieComposite*> * v = c->findR(s);
            for(int h=0; h<v->size(); h++) {
                res->push_back(v->at(h));
            }
        }
    }
    return res;
}

Categorie* Categorie::addElement(CategorieComposite * c) {
    if(c->getParent() != NULL && c->getParent() != this) {
        c->getParent()->removeElement(c);
    }
    if(c->getParent() != this) {
        c->setParent(this);
    }
    contenues->push_back(c);
    return this;
}

bool Categorie::removeElement(CategorieComposite * c) {
    int i = 0;
    bool trouve = false;
    while(i<contenues->size() && !trouve) {
        if(contenues->at(i) == c) {
            trouve = true;
        }
        else {
          i++;
        }
    }
    if(trouve) {
        Article * a = dynamic_cast<Article*>(contenues->at(i));
        if(a) {
            if(unlink(contenues->at(i)->absoluteAdresse().c_str()) < 0) {//supprime un fichier
                    perror("unlink");
            }
        }
        else {
            if(rmdir(contenues->at(i)->absoluteAdresse().c_str()) < 0) {//supprime un repertoir
                perror("rmdir");
            }
        }
        contenues->erase(contenues->begin() + i);
    }
    return trouve;
}

int Categorie::size() {
    int resultat = 0;
    for(int i=0; i<contenues->size(); i++) {
        resultat = resultat + contenues->at(i)->size();
    }
    return resultat;
}

void Categorie::enregistrerEnDurRecursif() {
    if(mkdir(absoluteAdresse().c_str() , (mode_t)0760) < 0) {//0_user_group_autre : execution:1, écriture:2, lecture:4
        string absaddr = absoluteAdresse() + "/." + getNom();
        ofstream fichier(absaddr.c_str(), ios::out | ios::trunc);//ouverture en écriture avec effacement du fichier ouvert
        if(fichier)
        {
            fichier<<getProprietaire()->getNom()<<"#";
            fichier<<getDroits().droit_ecriture_utilisateur<<"#";
            fichier<<getDroits().droit_lecture_utilisateur<<"#";
            fichier<<getDroits().droit_suppression_utilisateur<<"#";
            fichier<<getDroits().droit_ecriture_groupe<<"#";
            fichier<<getDroits().droit_lecture_groupe<<"#";
            fichier<<getDroits().droit_suppression_groupe<<"#";
            fichier<<getDroits().droit_ecriture_autre<<"#";
            fichier<<getDroits().droit_lecture_autre<<"#";
            fichier<<getDroits().droit_suppression_autre<<"#"<<endl;
            fichier.close();
        }
        else
            cout<<"Impossible d'ouvrir le fichier des droits de la catégorie en écriture pour "<<absaddr<<endl;
        for(int i=0; i<contenues->size(); i++) {
            contenues->at(i)->enregistrerEnDurRecursif();
        }
    }
    else {//Obligé car si le répertoir existe déjà alor il renvoi une erreur
        string absaddr = absoluteAdresse() + "/." + getNom();
        ofstream fichier(absaddr.c_str(), ios::out | ios::trunc);//ouverture en écriture avec effacement du fichier ouvert
        if(fichier)
        {
            fichier<<getProprietaire()->getNom()<<"#";
            fichier<<getDroits().droit_ecriture_utilisateur<<"#";
            fichier<<getDroits().droit_lecture_utilisateur<<"#";
            fichier<<getDroits().droit_suppression_utilisateur<<"#";
            fichier<<getDroits().droit_ecriture_groupe<<"#";
            fichier<<getDroits().droit_lecture_groupe<<"#";
            fichier<<getDroits().droit_suppression_groupe<<"#";
            fichier<<getDroits().droit_ecriture_autre<<"#";
            fichier<<getDroits().droit_lecture_autre<<"#";
            fichier<<getDroits().droit_suppression_autre<<"#"<<endl;
            fichier.close();
        }
        else
            cout<<"Impossible d'ouvrir le fichier des droits de la catégorie en écriture pour "<<absaddr<<endl;
        for(int i=0; i<contenues->size(); i++) {
            contenues->at(i)->enregistrerEnDurRecursif();
        }
    }
}

void Categorie::restaurerDuDurRecursif(vector<struc_catcomp_proprio> * struc_catcomp_pro) {
    DIR * dir = opendir(absoluteAdresse().c_str());
    if(dir) {
        struct dirent * fichiers = readdir(dir);
        while(fichiers) {
            string nom_fichier = fichiers->d_name;
            if(nom_fichier != "." && nom_fichier != "..") {
                string absoAddr = absoluteAdresse() + "/" + nom_fichier;
                DIR * dir2 = opendir(absoAddr.c_str());
                CategorieComposite * c = NULL;
                if(dir2) {//c'est un dossier
                    c = new Categorie(nom_fichier, this, NULL);
                    if(closedir(dir2) < 0)
                        perror("closedir2");
                }
                else {//c'est un fichier
                    string nom_fichier_temp = "." + getNom();
                    if(nom_fichier_temp == nom_fichier) {//si le nom du fichier est le même que le nom de la catégorie alors il contient le nom du proprio et les droits
                        string absaddr = absoluteAdresse() + "/." + getNom();
                        ifstream fichier(absaddr.c_str(), ios::in);
                        if(fichier) {
                            string ligne = "";
                            getline(fichier, ligne);
                            string proprio = "";
                            bool dul = false;
                            bool due = false;
                            bool dus = false;
                            bool dgl = false;
                            bool dge = false;
                            bool dgs = false;
                            bool dal = false;
                            bool dae = false;
                            bool das = false;
                            int i=0;
                            int var = 0;
                            while(i<ligne.size()) {
                                if(ligne[i] == '#') {
                                    var++;
                                    i++;
                                }
                                if(var == 0) {
                                    proprio = proprio + ligne[i];
                                }
                                else if(var == 1) {
                                    if(ligne[i] == '1')
                                        due = true;
                                }
                                else if(var == 2) {
                                    if(ligne[i] == '1')
                                        dul = true;
                                }
                                else if(var == 3) {
                                    if(ligne[i] == '1')
                                        dus = true;
                                }
                                else if(var == 4) {
                                    if(ligne[i] == '1')
                                        dge = true;
                                }
                                else if(var == 5) {
                                    if(ligne[i] == '1')
                                        dgl = true;
                                }
                                else if(var == 6) {
                                    if(ligne[i] == '1')
                                        dgs = true;
                                }
                                else if(var == 7) {
                                    if(ligne[i] == '1')
                                        dae = true;
                                }
                                else if(var == 8) {
                                    if(ligne[i] == '1')
                                        dal = true;
                                }
                                else if(var == 9) {
                                    if(ligne[i] == '1')
                                        das = true;
                                }
                                i++;
                            }
                            struc_catcomp_proprio p;
                            p.cat = this;
                            p.proprio = proprio;
                            struc_catcomp_pro->push_back(p);
                            changementDroits(due, dul, dus, dge, dgl, dgs, dae, dal, das);
                            fichier.close();
                        }
                        else
                            cout<<"Impossible d'ouvrir le fichier des droits de la catégorie en lecture !"<<endl;
                    }
                    else {
                        c = new Article(nom_fichier, this, "", NULL);
                    }
                }
                if(c) {
                    c->restaurerDuDurRecursif(struc_catcomp_pro);
                }
            }

            fichiers = readdir(dir);//on lit le répertoir suivant
        }
        if(closedir(dir) < 0)
            perror("closedir");
    }
    else
        perror("opendir");
}

string Categorie::lsDroit() {
    string resultat = getNom() + " : Droits :\n";
    string deu = "0";
    string dlu = "0";
    string dsu = "0";
    string deg = "0";
    string dlg = "0";
    string dsg = "0";
    string deo = "0";
    string dlo = "0";
    string dso = "0";
        resultat = resultat + "     [a=article, +=catégorie | proprio | nom | deu | dlu | dsu | deg | dlg | dsg | deo | dlo | dso]\n";
    for(int i=0; i<contenues->size(); i++) {
        deu = "0";
        dlu = "0";
        dsu = "0";
        deg = "0";
        dlg = "0";
        dsg = "0";
        deo = "0";
        dlo = "0";
        dso = "0";
        if(contenues->at(i)->getDroits().droit_ecriture_utilisateur) {
            deu = "1";
        }
        if(contenues->at(i)->getDroits().droit_lecture_utilisateur) {
            dlu = "1";
        }
        if(contenues->at(i)->getDroits().droit_suppression_utilisateur) {
            dsu = "1";
        }
        if(contenues->at(i)->getDroits().droit_ecriture_groupe) {
            deg = "1";
        }
        if(contenues->at(i)->getDroits().droit_lecture_groupe) {
            dlg = "1";
        }
        if(contenues->at(i)->getDroits().droit_suppression_groupe) {
            dsg = "1";
        }
        if(contenues->at(i)->getDroits().droit_ecriture_autre) {
            deo = "1";
        }
        if(contenues->at(i)->getDroits().droit_lecture_autre) {
            dlo = "1";
        }
        if(contenues->at(i)->getDroits().droit_suppression_autre) {
            dso = "1";
        }
        string proprio = "";
        if(contenues->at(i)->getProprietaire())
            proprio = contenues->at(i)->getProprietaire()->getNom();
        else
            proprio = "0";
        resultat = resultat + "     [" + contenues->at(i)->getType() + " | " + proprio + " | " + contenues->at(i)->getNom() + " | " + deu + " | " + dlu + " | " + dsu + " | " + deg + " | " + dlg + " | " + dsg + " | " + deo + " | " + dlo + " | " + dso + "]\n";
    }
    return resultat;
}
