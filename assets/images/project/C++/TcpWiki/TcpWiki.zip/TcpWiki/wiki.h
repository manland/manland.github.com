#ifndef WIKI_H
#define WIKI_H

#include <sys/shm.h>
#include <sys/msg.h>
#include <stdlib.h>
#include <string>
#include <sstream>
using namespace std;

#include "tcpthreadserveur.h"
#include "hierarchieutilisateur.h"
#include "hierarchiedoc.h"

struct mem_partagee_boite_res_nom {
    int boite_reseaux[MAX_UTILISATEURS];
    char* nom[MAX_UTILISATEURS];
    int boite_reseau_serveur_tcp;
    int boite_reseau_serveur_udp;
};

class Wiki;
struct WikiNumClient {
    Wiki * serveur;
    int id_client;
};

class Wiki : public TCPThreadServeur
{
private:
    HierarchieUtilisateur * hierarchie_utilisateur;
    HierarchieDoc * hierarchie_doc;
    Utilisateur * utilisateurs_connectes[MAX_UTILISATEURS];
    pthread_t thread;//thread qui surveille les message à envoyer/client
    char * reponse;
    //udp
    int descripteur_udp;
    //mémoire partagée
    mem_partagee_boite_res_nom * mon_tab_boites_reseau;
    int mem_partagee_boites_reseau;
    //file de message
    pthread_t thread_file_msg;
public:
    Wiki(int);
    ~Wiki();
    int Exec();
    virtual void Recevoir(const int);
    virtual void onConnect(const int);
    virtual HierarchieDoc* getHierarchieDoc();
    virtual HierarchieUtilisateur* getHierarchieUtilisateur();
    virtual Utilisateur* identification(const int, const char*);
    virtual Utilisateur* inscription(const int, const char*);
    virtual void who(const int);
    virtual void ls(const int, const char*);
    virtual void mkCat(const int, const char*);
    virtual void mdCatD(const int, const char*);
    virtual void mdCat(const int, const char*);
    virtual void find(const int, const char*);
    virtual void findR(const int, const char*);
    virtual void rmCat(const int, const char*);
    virtual void mkArt(const int, const char*);
    virtual void mdArt(const int, const char*);
    virtual void rmArt(const int, const char*);
    virtual void mdArtD(const int, const char*);
    virtual void mkGrp(const int, const char*);
    virtual void rmGrp(const int, const char*);
    virtual void lsGroupe(const int);
    virtual void mdGrp(const int, const char*);
    virtual void rjGrp(const int, const char*);
    virtual void lsMonGroupe(const int);
    virtual void accepterUtilisateurDansSonGroupe(const int, const char*);
    virtual void envoyerMessageA(const int, const char*);
    virtual void lsDroit(const int, const char*);
    virtual void cat(const int, const char*);
    virtual void quitGrp(const int);
    virtual void uQuitGrp(const int, const char*);
    virtual void envoieUdp(char*);
    virtual int ouvreSocketUDP();
    virtual bool aLeDroit(const string, CategorieComposite*, Utilisateur*) const;
    virtual void crash();
    virtual void reboot();
    virtual void bannirUtilisateur(const int, const char*);
    virtual void enregistrer(const int);
    virtual void bannirArticle(const int, const char*);
    virtual void lsTextesEnAttenteBannis(const int);
    virtual void debanTextesEnAttenteBannis(const int, const char*);
    virtual void debanUtiEnAttenteBannis(const int, const char*);
    virtual vector<string>* extractionDonnees(const int, const int, const char, const char*) const;
    virtual CategorieComposite* extractionChemin(const string) const;
    static void* startThreadMessages(void*);
    virtual void verifierMessage(const int);
};

#endif // WIKI_H
