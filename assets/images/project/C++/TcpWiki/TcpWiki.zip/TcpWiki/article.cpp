#include "hierarchiedoc.h"
#include "article.h"

Article::Article(string n, Categorie * p, string c, Utilisateur * appa) : CategorieComposite(n, p, appa) {
    contenu = c;
    type = "a";
    type_par_defaut = "a";
}

Article::~Article() {

}

string Article::cat() {
    return contenu;
}

void Article::setContenue(string c) {
    contenu = c;
}

int Article::size() {
    return contenu.size();
}

void Article::enregistrerEnDurRecursif() {
    ofstream fichier(absoluteAdresse().c_str(), ios::out | ios::trunc);//ouverture en écriture avec effacement du fichier ouvert
    if(fichier)
    {
        fichier<<getProprietaire()->getNom()<<"#";
        fichier<<getDroits().droit_ecriture_utilisateur<<"#";
        fichier<<getDroits().droit_lecture_utilisateur<<"#";
        fichier<<getDroits().droit_suppression_utilisateur<<"#";
        fichier<<getDroits().droit_ecriture_groupe<<"#";
        fichier<<getDroits().droit_lecture_groupe<<"#";
        fichier<<getDroits().droit_suppression_groupe<<"#";
        fichier<<getDroits().droit_ecriture_autre<<"#";
        fichier<<getDroits().droit_lecture_autre<<"#";
        fichier<<getDroits().droit_suppression_autre<<"#"<<endl;
        fichier<<contenu<<endl;
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en écriture !"<<endl;
}

void Article::restaurerDuDurRecursif(vector<struc_catcomp_proprio> * struc_catcomp_pro) {
    ifstream fichier(absoluteAdresse().c_str(), ios::in);//ouverture en lecture
    if(fichier) {
        contenu = "";
        string ligne = "";
        int compteur = 0;
        while(getline(fichier, ligne)) {//tant qu'il y a des lignes à lire
            if(compteur == 0) {
                compteur++;
                string proprio = "";
                bool dul = false;
                bool due = false;
                bool dus = false;
                bool dgl = false;
                bool dge = false;
                bool dgs = false;
                bool dal = false;
                bool dae = false;
                bool das = false;
                int i=0;
                int var = 0;
                while(i<ligne.size()) {
                    if(ligne[i] == '#') {
                        var++;
                        i++;
                    }
                    if(var == 0) {
                        proprio = proprio + ligne[i];
                    }
                    else if(var == 1) {
                        if(ligne[i] == '1')
                            due = true;
                    }
                    else if(var == 2) {
                        if(ligne[i] == '1')
                            dul = true;
                    }
                    else if(var == 3) {
                        if(ligne[i] == '1')
                            dus = true;
                    }
                    else if(var == 4) {
                        if(ligne[i] == '1')
                            dge = true;
                    }
                    else if(var == 5) {
                        if(ligne[i] == '1')
                            dgl = true;
                    }
                    else if(var == 6) {
                        if(ligne[i] == '1')
                            dgs = true;
                    }
                    else if(var == 7) {
                        if(ligne[i] == '1')
                            dae = true;
                    }
                    else if(var == 8) {
                        if(ligne[i] == '1')
                            dal = true;
                    }
                    else if(var == 9) {
                        if(ligne[i] == '1')
                            das = true;
                    }
                    i++;
                }
                struc_catcomp_proprio p;
                p.cat = this;
                p.proprio = proprio;
                struc_catcomp_pro->push_back(p);
                changementDroits(due, dul, dus, dge, dgl, dgs, dae, dal, das);
            }
            else {
                contenu = contenu + ligne + "\n";
            }
        }
        fichier.close();
    }
    else
        cout<<"Impossible d'ouvrir le fichier des utilisateurs en écriture !"<<endl;
}
