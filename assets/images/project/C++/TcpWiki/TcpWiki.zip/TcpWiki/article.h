#ifndef ARTICLE_H
#define ARTICLE_H

#include <sstream>
#include <fstream>

#include "categoriecomposite.h"

class Article : public virtual CategorieComposite {
private:
    string contenu;
public:
    Article(string = "", Categorie* = NULL, string = "", Utilisateur* = NULL);
    virtual ~Article();
    virtual string cat();
    virtual void setContenue(string);
    virtual int size();
    virtual void enregistrerEnDurRecursif();
    virtual void restaurerDuDurRecursif(vector<struc_catcomp_proprio>*);
};

#endif // ARTICLE_H
