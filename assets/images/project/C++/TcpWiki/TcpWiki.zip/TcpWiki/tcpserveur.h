#ifndef TCPSERVEUR_H
#define TCPSERVEUR_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <stdio.h>
#include <iostream>
using namespace std;

#ifndef MAX_UTILISATEURS
    #define MAX_UTILISATEURS 100
#endif

class TCPserveur
{
private:

protected:
    int id_socket;
    int descripteur_connexion[MAX_UTILISATEURS];
    int utilisateur_port[MAX_UTILISATEURS];
    char * utilisateur_ip[MAX_UTILISATEURS];
    int port;
    struct sockaddr_in servaddr;
    sockaddr_in information_sur_la_source;
public:
    TCPserveur(int);
    virtual ~TCPserveur();
    virtual int Exec();
    virtual int InitialisationSocket();
    virtual void AttenteConnexion();
    virtual void Envoyer(const int);
    virtual void Envoyer(const int, const char*);
    virtual void Recevoir(const int);
    virtual void onConnect(int) = 0;
    virtual int trouverUnePlace() const;//pour trouver une place dans le tab descripteur_connexion
};

#endif // TCPSERVEUR_H
