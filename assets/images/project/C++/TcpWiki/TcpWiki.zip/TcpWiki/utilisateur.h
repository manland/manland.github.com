#ifndef UTILISATEUR_H
#define UTILISATEUR_H

#include <sys/msg.h>

#include "groupecomposite.h"

class Utilisateur : public GroupeComposite {
private:
    string mot_de_passe;
    string ip;
    int port;
    Groupe * est_en_attente_pour_rejoindre_groupe;
    bool est_connecte;
    vector<string> * historique;
    long id_file_message;
public:
    Utilisateur(string = "", Groupe* = NULL, string = "", string = "", int = -1);
    virtual ~Utilisateur();
    virtual string getMotDePasse();
    virtual Groupe* getGroupe();
    virtual void setGroupe(Groupe*);
    virtual string getIp();
    virtual int getPort();
    virtual void setIp(string);
    virtual void setPort(int);
    virtual Groupe * estEnAttentePourRejoindreGroupe();
    virtual void mettreEnAttentePourRejoindreGroupe(Groupe *);
    virtual bool estConnecte();
    virtual void setConnecte(bool);
    virtual void ajoutHistorique(string);
    virtual void envoyerMessage(string);
    virtual vector<string>* getHistorique();
};

#endif // UTILISATEUR_H
