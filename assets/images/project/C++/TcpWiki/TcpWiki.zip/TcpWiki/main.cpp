#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/shm.h>

#include "wiki.h"

int main(int argc, char *argv[]) {

//    key_t cle = ftok("keys", 1);
//            int mem_partagee = shmget(cle, (size_t)sizeof(mem_partagee_boite_res_nom), IPC_CREAT|0666);
//            mem_partagee_boite_res_nom * mon_tab = (mem_partagee_boite_res_nom*)shmat(mem_partagee, NULL, 0);
//            if((void*)mon_tab == (void*)-1)
//                perror("error de shmat dans la main");
//            else {
//    if(shmdt(mon_tab) == -1)
//                    perror("error de shmdt");
//                if(shmctl(mem_partagee, IPC_RMID, NULL) == -1)
//                    perror("error de shmctl");
//            }

    pid_t pid = fork ();
    if (pid > 0) {//pére
        int res = wait(NULL);
        if(res == -1)
            perror("Wait erreur");
        else {
            key_t cle = ftok("keys", 1);
            int mem_partagee_boites_reseau = shmget(cle, (size_t)sizeof(mem_partagee_boite_res_nom), IPC_CREAT|0666);
            mem_partagee_boite_res_nom * mon_tab_boites_reseau = (mem_partagee_boite_res_nom*)shmat(mem_partagee_boites_reseau, NULL, 0);
            if((void*)mon_tab_boites_reseau == (void*)-1)
                perror("error de shmat dans la main");
            else {
                close(mon_tab_boites_reseau->boite_reseau_serveur_tcp);
                close(mon_tab_boites_reseau->boite_reseau_serveur_udp);
                for(int i=0; i<MAX_UTILISATEURS; i++) {
                    close(mon_tab_boites_reseau->boite_reseaux[i]);
                }
                if(shmdt(mon_tab_boites_reseau) == -1)
                    perror("error de shmdt");
                if(shmctl(mem_partagee_boites_reseau, IPC_RMID, NULL) == -1)
                    perror("error de shmctl");
            }
        cout<<"Le seveur à subit un crash et doit redémarer."<<endl;
        cout<<"Veuillez attendre 60sc..."<<endl;
        sleep(15);
        cout<<"50sc..."<<endl;
        sleep(10);
        cout<<"40sc..."<<endl;
        sleep(10);
        cout<<"30sc..."<<endl;
        sleep(10);
        cout<<"20sc..."<<endl;
        sleep(10);
        cout<<"10sc..."<<endl;
        sleep(1);
        cout<<"9sc..."<<endl;
        sleep(1);
        cout<<"8sc..."<<endl;
        sleep(1);
        cout<<"7sc..."<<endl;
        sleep(1);
        cout<<"6sc..."<<endl;
        sleep(1);
        cout<<"5sc..."<<endl;
        sleep(1);
        cout<<"4sc..."<<endl;
        sleep(1);
        cout<<"3sc..."<<endl;
        sleep(1);
        cout<<"2sc..."<<endl;
        sleep(1);
        cout<<"1sc..."<<endl;
        sleep(1);
        cout<<"0sc..."<<endl;
        cout<<"Je redémarre."<<endl;
            execvp("./main", argv);
        }
    }
    else if (pid == 0) {//fils
         Wiki * serveur = new Wiki(77777);
//        mkdir("test", (mode_t)0760);//0_user_group_autre : execution:1, écriture:2, lecture:4

        string msgUDP = "Salut !!";
        char * temp = const_cast<char*>(msgUDP.c_str());
        serveur->envoieUdp(temp);
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!test!UDP!!!!!!!!!!!!!!!!!!!

        return serveur->Exec();
    }
    else {//erreur
        cout<<"erreur de fork"<<endl;
    }
    return 0;
}


