#ifndef CATEGORIECOMPOSITE_H
#define CATEGORIECOMPOSITE_H

#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>
#include <stdio.h>
#include <string>
#include <pthread.h>
using namespace std;

#include "utilisateur.h"

class Categorie;
class CategorieComposite;

struct struc_catcomp_proprio {
    string proprio;
    CategorieComposite * cat;
};

struct Droits {
    bool droit_ecriture_utilisateur;
    bool droit_lecture_utilisateur;
    bool droit_suppression_utilisateur;
    bool droit_ecriture_groupe;
    bool droit_lecture_groupe;
    bool droit_suppression_groupe;
    bool droit_ecriture_autre;
    bool droit_lecture_autre;
    bool droit_suppression_autre;
};

class CategorieComposite
{
protected:
    string nom;
    Categorie * parent;
    string type;//A = article, + = catégorie
    string type_par_defaut;
    Utilisateur * appartient_a;
    Droits droits;
    pthread_mutex_t verrou;
    bool est_lock;

public:
    CategorieComposite(string = "", Categorie* = NULL, Utilisateur* = NULL);
    virtual ~CategorieComposite();
    virtual string getNom();
    virtual void setNom(string);
    virtual string absoluteAdresse();
    virtual Categorie* getParent();
    virtual void setParent(Categorie*);
    virtual string getType();
    virtual Droits getDroits();
    virtual Utilisateur* getProprietaire();
    virtual void changementDroits(bool = true, bool = true, bool = true, bool = true, bool = true, bool = true, bool = true, bool = true, bool = true);
    virtual int size() = 0;
    virtual void enregistrerEnDurRecursif() = 0;
    virtual void restaurerDuDurRecursif(vector<struc_catcomp_proprio>*) = 0;
    virtual void setAppartientA(Utilisateur*);
    virtual void lock();
    virtual void unlock();
    virtual bool estLock();
    virtual void setType(string);
};

#endif // CATEGORIECOMPOSITE_H
