#include "categoriecomposite.h"
#include "categorie.h"

CategorieComposite::CategorieComposite(string n, Categorie * p, Utilisateur * appa) {
    nom = n;
    parent = p;
    if(parent != NULL) {
        parent->addElement(this);
    }
    appartient_a = appa;
    droits.droit_ecriture_utilisateur = true;
    droits.droit_lecture_utilisateur = true;
    droits.droit_suppression_utilisateur = true;
    droits.droit_ecriture_groupe = true;
    droits.droit_lecture_groupe = true;
    droits.droit_suppression_groupe = true;
    droits.droit_ecriture_autre = true;
    droits.droit_lecture_autre = true;
    droits.droit_suppression_autre = true;

    pthread_mutex_t verrou2 = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_init(&verrou, NULL);
    est_lock = false;
}

CategorieComposite::~CategorieComposite() {
    delete parent;
    delete appartient_a;
}

string CategorieComposite::getNom() {
    return nom;
}

void CategorieComposite::setNom(string n) {
    nom = n;
}

string CategorieComposite::absoluteAdresse() {
    string resultat = nom;
    Categorie * p = getParent();
    while(p!=NULL) {
        resultat = p->nom + "/" + resultat;
        p = p->getParent();
    }
    return resultat;
}

Categorie* CategorieComposite::getParent() {
    return parent;
}

void CategorieComposite::setParent(Categorie * c) {
    parent = c;
}

string CategorieComposite::getType() {
    return type;
}

Droits CategorieComposite::getDroits() {
    return droits;
}

Utilisateur* CategorieComposite::getProprietaire() {
    return appartient_a;
}

void CategorieComposite::changementDroits(bool deu, bool dlu, bool dsu, bool deg, bool dlg, bool dsg, bool dea, bool dla, bool dsa) {
    droits.droit_ecriture_utilisateur = deu;
    droits.droit_lecture_utilisateur = dlu;
    droits.droit_suppression_utilisateur = dsu;
    droits.droit_ecriture_groupe = deg;
    droits.droit_lecture_groupe = dlg;
    droits.droit_suppression_groupe = dsg;
    droits.droit_ecriture_autre = dea;
    droits.droit_lecture_autre = dla;
    droits.droit_suppression_autre = dsa;
}

void CategorieComposite::setAppartientA(Utilisateur * u) {
    appartient_a = u;
}

void CategorieComposite::lock() {
    type = "L";
    est_lock = true;
    int i = pthread_mutex_lock(&verrou);
}

void CategorieComposite::unlock() {
    type = type_par_defaut;
    est_lock = false;
    int i = pthread_mutex_unlock(&verrou);
}

bool CategorieComposite::estLock() {
    return est_lock;
}

void CategorieComposite::setType(string s) {
    type = s;
}

