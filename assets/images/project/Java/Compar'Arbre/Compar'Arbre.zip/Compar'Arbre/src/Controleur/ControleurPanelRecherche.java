package Controleur;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import Coeur.AbstractNoeud;
import Coeur.InfosFichier;
import Graphique.HistoriqueRecherche;
import Graphique.PanelCouleur;
import Graphique.PanelRecherche;
import Graphique.TabOngletRecherche;
import Graphique.ZoneDesktop;

public class ControleurPanelRecherche implements ActionListener,MouseListener, ChangeListener
{
	private Vector<HistoriqueRecherche> historique_recherche;
	private Color couleur_courante;
	private HistoriqueRecherche histo;
	
	private Vector<AbstractNoeud> resultat_intersection;

	private PanelRecherche panel_recherche;
	
	public ControleurPanelRecherche(PanelRecherche panel_recherche) 
	{
		super();
		this.panel_recherche = panel_recherche;
		historique_recherche = new Vector<HistoriqueRecherche>();
		couleur_courante = Color.cyan;
	}


	@Override
	public void actionPerformed(ActionEvent event) 
	{
		JComboBox combo =null; 
		try{
			combo = ((JComboBox)(event.getSource()));
		}
		catch (ClassCastException e) {
			JCheckBox check_box = null;
			try{
				check_box = ((JCheckBox)(event.getSource()));
			}
			catch(ClassCastException c){
				JButton btn = null;
				try{
					btn = ((JButton)(event.getSource()));
				}
				catch(ClassCastException v){
					v.printStackTrace();
					return;
				}
				if(btn==panel_recherche.getBtn_recherche())
				{
					rechercher();
				}
				return;
			}
			if(check_box == panel_recherche.getCheck_box_modifications())
			{
				if(check_box.isSelected())
				{
					panel_recherche.getJour_fin().setEnabled(true);
					panel_recherche.getMois_fin().setEnabled(true);
					panel_recherche.getAnnee_fin().setEnabled(true);
					panel_recherche.getLabel_fin().setEnabled(true);

				}
				else
				{
					panel_recherche.getJour_fin().setEnabled(false);
					panel_recherche.getMois_fin().setEnabled(false);
					panel_recherche.getAnnee_fin().setEnabled(false);
					panel_recherche.getLabel_fin().setEnabled(false);
				}
			}
			else if(check_box == panel_recherche.getNom_checkBox())
			{
				if(check_box.isSelected())
				{
					panel_recherche.getNom().setEnabled(true);
					panel_recherche.getChoix_nom().setEnabled(true);
					panel_recherche.getBtn_recherche().setEnabled(true);
				}
				else
				{
					panel_recherche.getNom().setEnabled(false);
					panel_recherche.getChoix_nom().setEnabled(false);
				}
			}
			else if(check_box == panel_recherche.getDate_checkBox())
			{
				if(check_box.isSelected())
				{
					panel_recherche.getJour_debut().setEnabled(true);
					panel_recherche.getMois_debut().setEnabled(true);
					panel_recherche.getAnnee_debut().setEnabled(true);
					panel_recherche.getCheck_box_modifications().setEnabled(true);
					panel_recherche.getCheck_box_modifications().setSelected(false);
					panel_recherche.getPrecision_date().setEnabled(true);
					panel_recherche.getBtn_recherche().setEnabled(true);
				}
				else
				{
					panel_recherche.getJour_debut().setEnabled(false);
					panel_recherche.getMois_debut().setEnabled(false);
					panel_recherche.getAnnee_debut().setEnabled(false);
					panel_recherche.getJour_fin().setEnabled(false);
					panel_recherche.getMois_fin().setEnabled(false);
					panel_recherche.getAnnee_fin().setEnabled(false);
					panel_recherche.getPrecision_date().setEnabled(false);
					panel_recherche.getCheck_box_modifications().setEnabled(false);
					panel_recherche.getCheck_box_modifications().setSelected(false);
				}
			}
			else if(check_box == panel_recherche.getExtension_checkBox())
			{
				if(check_box.isSelected())
				{
					panel_recherche.getExtension().setEnabled(true);
					panel_recherche.getBtn_recherche().setEnabled(true);
				}
				else
					panel_recherche.getExtension().setEnabled(false);
			}
			else if(check_box == panel_recherche.getPoids_checkBox())
			{
				if(check_box.isSelected())
				{
					panel_recherche.getPoids_comboBox().setEnabled(true);
					panel_recherche.getPoids_min_textField().setEnabled(true);
					if(panel_recherche.getPoids_comboBox().getSelectedItem().equals("Entre"))
					{
						panel_recherche.getPoids_label_et().setEnabled(true);
						panel_recherche.getPoids_max_textField().setEnabled(true);
					}
					panel_recherche.getBtn_recherche().setEnabled(true);
				}
				else
				{
					panel_recherche.getPoids_comboBox().setEnabled(false);
					panel_recherche.getPoids_min_textField().setEnabled(false);
					panel_recherche.getPoids_label_et().setEnabled(false);
					panel_recherche.getPoids_max_textField().setEnabled(false);
				}
			}
			else if(check_box == panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtn_intersection())
			{
				if(check_box.isSelected())
				{
					panel_recherche.getTab_onglet_recherche().getPanel_selection().getPoints_communs().setEnabled(true);
					panel_recherche.getBtn_recherche().setEnabled(true);
					//intersection();
				}
				else
					panel_recherche.getTab_onglet_recherche().getPanel_selection().getPoints_communs().setEnabled(false);
			}
			return;
		}
		if(combo==panel_recherche.getMois_debut())
		{
			// remplissage des jours :
			if(panel_recherche.getMois_debut().getSelectedIndex() == 0 || 
			   panel_recherche.getMois_debut().getSelectedIndex() == 2 || 
			   panel_recherche.getMois_debut().getSelectedIndex() == 4 || 
			   panel_recherche.getMois_debut().getSelectedIndex() == 6 || 
			   panel_recherche.getMois_debut().getSelectedIndex() == 7 || 
			   panel_recherche.getMois_debut().getSelectedIndex() == 9 || 
			   panel_recherche.getMois_debut().getSelectedIndex() == 11)
			{
				for(int i=1; i<32; i++)
				{
					panel_recherche.getVecteurJours().add(i);
				}
			}
			else if (panel_recherche.getMois_debut().getSelectedIndex()==1)
			{
				for(int i=1; i<29; i++)
				{
					panel_recherche.getVecteurJours().add(i);
				}
			}
			else
			{
				for(int i=1; i<31; i++)
				{
					panel_recherche.getVecteurJours().add(i);
				}
			}
			panel_recherche.getJour_debut().setModel(new DefaultComboBoxModel(panel_recherche.getVecteurJours()));

		}
		else if(combo==panel_recherche.getMois_fin())
		{
			// remplissage des jours :
			if(panel_recherche.getMois_fin().getSelectedIndex() == 0 || 
			   panel_recherche.getMois_fin().getSelectedIndex() == 2 || 
			   panel_recherche.getMois_fin().getSelectedIndex() == 4 || 
			   panel_recherche.getMois_fin().getSelectedIndex() == 6 || 
			   panel_recherche.getMois_fin().getSelectedIndex() == 7 || 
			   panel_recherche.getMois_fin().getSelectedIndex() == 9 || 
			   panel_recherche.getMois_fin().getSelectedIndex() == 11)
			{
				for(int i=1; i<32; i++)
				{
					panel_recherche.getVecteurJours().add(i);
				}
			}
			else if (panel_recherche.getMois_fin().getSelectedIndex()==1)
			{
				for(int i=1; i<29; i++)
				{
					panel_recherche.getVecteurJours().add(i);
				}
			}
			else
			{
				for(int i=1; i<31; i++)
				{
					panel_recherche.getVecteurJours().add(i);
				}
			}
			panel_recherche.getJour_fin().setModel(new DefaultComboBoxModel(panel_recherche.getVecteurJours()));
		}
		else if(combo == panel_recherche.getExtension())
		{
			String nouvelle_extension = ((JComboBox)(event.getSource())).getEditor().getItem().toString();
			if(panel_recherche.getListe_extension().contains(nouvelle_extension))
			{
				combo.setSelectedItem(nouvelle_extension);
			}
			else
			{
				panel_recherche.getListe_extension().addElement(nouvelle_extension);
				combo.setModel(new DefaultComboBoxModel(panel_recherche.getListe_extension()));
				combo.setSelectedItem(nouvelle_extension);
			}
		}
		else if(combo == panel_recherche.getPoids_comboBox())
		{
			if(panel_recherche.getPoids_comboBox().getSelectedItem()=="Entre")
			{
				panel_recherche.getPoids_max_textField().setEnabled(true);
				panel_recherche.getPoids_label_et().setEnabled(true);
			}
			else
			{
				panel_recherche.getPoids_max_textField().setEnabled(false);
				panel_recherche.getPoids_label_et().setEnabled(false);
			}
		}
	}


	@Override
	public void mouseClicked(MouseEvent event) 
	{
		PanelCouleur pc =null; 
		try{
			pc = ((PanelCouleur)(event.getSource()));
		}
		catch (ClassCastException e) {
			e.printStackTrace();
			return;
		}
		if(pc==panel_recherche.getPanel_couleur())
		{
			couleur_courante = pc.getCouleur_courante();
			Color c = pc.getColor_chooser().showDialog(panel_recherche,"choisir couleur",pc.getCouleur_courante());
			if(c==null)
			{
				couleur_courante = pc.getCouleur_courante();
			}
			else
			{
				couleur_courante = c;
				pc.setCouleur_courante(c);
				pc.repaint();
			}
		}
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	public void rechercher()
	{
		ZoneDesktop zone_desktop = ((ZoneDesktop)(panel_recherche.getInternal_frame_recherche().getParent()));
		Vector<Vector<AbstractNoeud>> vect_resultat = new Vector<Vector<AbstractNoeud>>();
		Vector<AbstractNoeud> resultat_total = new Vector<AbstractNoeud>();
		Vector<AbstractNoeud> noeud_peres = new Vector<AbstractNoeud>();
		int case_cochee = 0;
		
		// affectation des noeuds peres :
		if(panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtn_arbre1().isSelected() && panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtn_arbre2().isSelected())
		{
			for(int i=0; i<zone_desktop.getVecteur_frame_onglet().size();i++)
			{
				noeud_peres.add(zone_desktop.getVecteur_frame_onglet().get(i).getTab_onglet().getPanelOnglet().getNoeudRoot());
			}
		}
		else if(panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtn_arbre1().isSelected())
		{
			noeud_peres.add(zone_desktop.getVecteur_frame_onglet().get(0).getTab_onglet().getPanelOnglet().getNoeudRoot());
		}
		else if(panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtn_arbre2().isSelected())
		{
			noeud_peres.add(zone_desktop.getVecteur_frame_onglet().get(1).getTab_onglet().getPanelOnglet().getNoeudRoot());
		}
		else if (panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtn_intersection().isSelected() || 
				 panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtnArbre1MoinsArbre2().isSelected() ||
				 panel_recherche.getTab_onglet_recherche().getPanel_selection().getBtnArbre2MoinsArbre1().isSelected())
		{
			noeud_peres.addAll(rechercheDansIntersection(panel_recherche.getTab_onglet_recherche().getPanel_selection().getControleur().getResultat()));
		}
		
		
		histo.setIntersection_couleur(panel_recherche.getTab_onglet_recherche().getPanel_selection().getControleur().getCouleur_courante());
		
		// on fait la recherche
		if(!panel_recherche.getNom_checkBox().isSelected() && !panel_recherche.getExtension_checkBox().isSelected() && !panel_recherche.getDate_checkBox().isSelected() && !panel_recherche.getPoids_checkBox().isSelected())
		{
			panel_recherche.getBtn_recherche().setEnabled(false);
		}
		else
		{
			panel_recherche.getBtn_recherche().setEnabled(true);
			if(panel_recherche.getNom_checkBox().isSelected()) // le nom est coché
			{
				case_cochee++;
				if(panel_recherche.getChoix_nom().getSelectedItem()=="Exact")
				{
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParNomExact(noeud_peres, panel_recherche.getNom().getText()));
					histo.setRecherche_par_nom_exact(true);
					histo.setNom(panel_recherche.getNom().getText());
				}
				else
				{
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParNomContient(noeud_peres, panel_recherche.getNom().getText()));
					histo.setRecherche_par_nom_contient(true);
					histo.setNom(panel_recherche.getNom().getText());
				}
			}
			if(panel_recherche.getExtension_checkBox().isSelected()) // l'extension est coché
			{
				case_cochee++;
				vect_resultat.add(RechercheDansPlusieursArbres.rechercheParExtension(noeud_peres, panel_recherche.getExtension().getSelectedItem().toString()));
				histo.setRecherche_par_extension(true);
				histo.setExtension(panel_recherche.getExtension().getSelectedItem().toString());
			}
			if(panel_recherche.getDate_checkBox().isSelected())
			{
				case_cochee++;
				Calendar calendrier = Calendar.getInstance();
				calendrier.set(Integer.parseInt(panel_recherche.getAnnee_debut().getSelectedItem().toString()),Integer.parseInt(panel_recherche.getMois_debut().getSelectedItem().toString())-1,Integer.parseInt(panel_recherche.getJour_debut().getSelectedItem().toString()));
				Date date_debut = calendrier.getTime();
				if(!panel_recherche.getCheck_box_modifications().isSelected()) // on fait une recherche pour le jour concerné
				{
					if(panel_recherche.getPrecision_date().getSelectedItem() == "le")
					{	
						vect_resultat.add(RechercheDansPlusieursArbres.rechercheParDate(noeud_peres, date_debut));
						histo.setRecherche_par_date_modif_exacte(true);
						histo.setDate_debut(date_debut.toString());
					}
					else if(panel_recherche.getPrecision_date().getSelectedItem() == "avant")
					{	
						vect_resultat.add(RechercheDansPlusieursArbres.rechercheParDateAvant(noeud_peres, date_debut));
						histo.setRecherche_par_date_modif_avant(true);
						histo.setDate_debut(date_debut.toString());
					}
					else if(panel_recherche.getPrecision_date().getSelectedItem() == "après")
					{	
						vect_resultat.add(RechercheDansPlusieursArbres.rechercheParDateApres(noeud_peres, date_debut));
						histo.setRecherche_par_date_modif_apres(true);
						histo.setDate_debut(date_debut.toString());
					}
				}
				else	// on veut une date de fin d'intervalle de modification
				{
					Calendar calendrierFin = Calendar.getInstance();
					calendrierFin.set(Integer.parseInt(panel_recherche.getAnnee_fin().getSelectedItem().toString()),Integer.parseInt(panel_recherche.getMois_fin().getSelectedItem().toString())-1,Integer.parseInt(panel_recherche.getJour_fin().getSelectedItem().toString()));
					Date date_fin = calendrier.getTime();
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParDateEntre(noeud_peres, date_debut, date_fin));
					histo.setRecherche_par_date_modif_entre(true);
					histo.setDate_debut(date_debut.toString());
					histo.setDate_fin(date_fin.toString());
				}
			}
			if(panel_recherche.getPoids_checkBox().isSelected())
			{
				case_cochee++;
				String poids_min = panel_recherche.getPoids_min_textField().getText();
				if(panel_recherche.getPoids_comboBox().getSelectedItem()=="De") // poids exact
				{
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParPoidsExact(noeud_peres, poids_min));
					histo.setRecherche_par_poids_exact(true);
					histo.setPoids_debut(poids_min);
				}
				else if(panel_recherche.getPoids_comboBox().getSelectedItem()=="inférieur à")
				{
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParPoidsInferieur(noeud_peres, poids_min));
					histo.setRecherche_par_poids_inferieur(true);
					histo.setPoids_debut(poids_min);
				}
				else if(panel_recherche.getPoids_comboBox().getSelectedItem()=="supérieur à")
				{
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParPoidsSuperieur(noeud_peres, poids_min));
					histo.setRecherche_par_poids_superieur(true);
					histo.setPoids_debut(poids_min);
				}
				else // on cherche dans une fourchette de poids
				{
					String poids_max = panel_recherche.getPoids_max_textField().getText();
					vect_resultat.add(RechercheDansPlusieursArbres.rechercheParPoidsEntre(noeud_peres, poids_min, poids_max));
					histo.setRecherche_par_poids_entre(true);
					histo.setPoids_debut(poids_min);
					histo.setPoids_fin(poids_max);
				}
			}
			resultat_total = RechercheDansPlusieursArbres.rechercheMultiple(vect_resultat);
			Vector<Vector<String>> vec_donnees = panel_recherche.getTab_onglet_recherche().getPanel_legende().getDonnees();
			Vector<String> vec_colonnes = panel_recherche.getTab_onglet_recherche().getPanel_legende().getNom_colonnes();
			JTable tab =panel_recherche.getTab_onglet_recherche().getPanel_legende().getTableau();
			histo.setNb_case_cochee(case_cochee);
			if(resultat_total.size()>0)
			{
				histo.setRecherche_couleur(panel_recherche.getPanel_couleur().getCouleur_courante());
				vec_donnees.add(histo.remplirDonneeTableau());
				
				tab.setModel(new DefaultTableModel(vec_donnees,vec_colonnes));
				
			}
			historique_recherche.add(histo);
			System.out.println(tab.getRowCount());
			for(int i=0;i<tab.getRowCount();i++)
			{
				System.out.println(vec_donnees.size());
				System.out.println(case_cochee);
				tab.setRowHeight(i,historique_recherche.get(i).getNb_case_cochee()*30);
				System.out.println(tab.getRowHeight(i));
			}
			TableColumn column = null;
			for (int i=0; i<tab.getColumnCount(); i++) {
			    column = tab.getColumnModel().getColumn(i);
			    if (i == 0) {
			    	column.setMaxWidth(50);
			    	column.setMinWidth(50);
			    	column.setWidth(50);
			        column.setPreferredWidth(50);
			    } else {
			    	column.setMinWidth(115);
			    	column.setWidth(115);
			        column.setPreferredWidth(115);
			    }
			}
			// coloration :
			for(int i=0; i<resultat_total.size();i++)
			{
				resultat_total.get(i).setCouleurFond(couleur_courante);
			}
		}
	}
	
	
	public Vector<AbstractNoeud> intersection()
	{
		ZoneDesktop zone_desktop = ((ZoneDesktop)(panel_recherche.getInternal_frame_recherche().getParent()));
		resultat_intersection = new Vector<AbstractNoeud>();
		AbstractNoeud noeud_arbre1 = null;
		AbstractNoeud noeud_arbre2 = null;
		if(zone_desktop.getVecteur_frame_onglet().size()>1) {
			noeud_arbre1 = zone_desktop.getVecteur_frame_onglet().get(0).getTab_onglet().getPanelOnglet().getNoeudRoot();
			noeud_arbre2 = zone_desktop.getVecteur_frame_onglet().get(1).getTab_onglet().getPanelOnglet().getNoeudRoot();
		}
		
		if(noeud_arbre1 != null && noeud_arbre2 != null) {
			if(panel_recherche.getTab_onglet_recherche().getPanel_selection().getPoints_communs().getSelectedItem() == "Nom")
			{
				resultat_intersection.addAll(noeud_arbre1.intersectionParNomAvec(noeud_arbre2));
			}
			else if(panel_recherche.getTab_onglet_recherche().getPanel_selection().getPoints_communs().getSelectedItem() == "Poids")
			{
				resultat_intersection.addAll(noeud_arbre1.intersectionParPoidsAvec(noeud_arbre2));
			}
			else if(panel_recherche.getTab_onglet_recherche().getPanel_selection().getPoints_communs().getSelectedItem() == "Date")
			{
				resultat_intersection.addAll(noeud_arbre1.intersectionParDateAvec(noeud_arbre2));
			}
		}
		
		return resultat_intersection;
	}
	
	public Vector<AbstractNoeud> rechercheDansIntersection(Vector<AbstractNoeud> vec)
	{
		Vector<AbstractNoeud> vec_res = new Vector<AbstractNoeud>();
		int case_cochee = 0;
		// on fait la recherche
		if(!panel_recherche.getNom_checkBox().isSelected() && !panel_recherche.getExtension_checkBox().isSelected() && !panel_recherche.getDate_checkBox().isSelected() && !panel_recherche.getPoids_checkBox().isSelected())
		{
			panel_recherche.getBtn_recherche().setEnabled(false);
		}
		else
		{
			panel_recherche.getBtn_recherche().setEnabled(true);
			for(int i=0; i<vec.size();i++)
			{
				if(panel_recherche.getNom_checkBox().isSelected()) // le nom est coché
				{
					case_cochee++;
					String nom = panel_recherche.getNom().getText();
					if(panel_recherche.getChoix_nom().getSelectedItem()=="Exact")
					{
						if(vec.get(i).getFichier().getNom().equals(nom))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_nom_exact(true);
							histo.setNom(nom);
							
						}
					}
					else
					{
						if(vec.get(i).getFichier().getNom().contains(nom))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_nom_contient(true);
							histo.setNom(nom);
						}
					}
				}
				if(panel_recherche.getExtension_checkBox().isSelected()) // l'extension est coché
				{
					case_cochee++;
					if(vec.get(i).isFeuille())
					{
						if(((InfosFichier)(vec.get(i).getFichier())).getExtension().equals(panel_recherche.getExtension().getSelectedItem().toString()));
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_extension(true);
							histo.setExtension(panel_recherche.getExtension().getSelectedItem().toString());
						}
					}
				}
				if(panel_recherche.getDate_checkBox().isSelected())
				{
					case_cochee++;
					Calendar calendrier = Calendar.getInstance();
					calendrier.set(Integer.parseInt(panel_recherche.getAnnee_debut().getSelectedItem().toString()),Integer.parseInt(panel_recherche.getMois_debut().getSelectedItem().toString())-1,Integer.parseInt(panel_recherche.getJour_debut().getSelectedItem().toString()));
					Date date_debut = calendrier.getTime();
					if(!panel_recherche.getCheck_box_modifications().isSelected()) // on fait une recherche pour le jour concerné
					{
						if(panel_recherche.getPrecision_date().getSelectedItem() == "le")
						{	
							if(vec.get(i).getFichier().getDerniereModification().equals(date_debut));
							{
								vec_res.add(vec.get(i));
								histo.setRecherche_par_date_modif_exacte(true);
								histo.setDate_debut(date_debut.toString());
							}
						}
						else if(panel_recherche.getPrecision_date().getSelectedItem() == "avant")
						{	
							if(vec.get(i).getFichier().getDerniereModification().before(date_debut))
							{
								vec_res.add(vec.get(i));
								histo.setRecherche_par_date_modif_avant(true);
								histo.setDate_debut(date_debut.toString());
							}
						}
						else if(panel_recherche.getPrecision_date().getSelectedItem() == "après")
						{	
							if(vec.get(i).getFichier().getDerniereModification().after(date_debut))
							{
								vec_res.add(vec.get(i));
								histo.setRecherche_par_date_modif_apres(true);
								histo.setDate_debut(date_debut.toString());
							}
						}
					}
					else	// on veut une date de fin d'intervalle de modification
					{
						
						Calendar calendrierFin = Calendar.getInstance();
						calendrierFin.set(Integer.parseInt(panel_recherche.getAnnee_fin().getSelectedItem().toString()),Integer.parseInt(panel_recherche.getMois_fin().getSelectedItem().toString())-1,Integer.parseInt(panel_recherche.getJour_fin().getSelectedItem().toString()));
						Date date_fin = calendrier.getTime();
						if(vec.get(i).getFichier().getDerniereModification().after(date_debut) && resultat_intersection.get(i).getFichier().getDerniereModification().before(date_fin))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_date_modif_entre(true);
							histo.setDate_debut(date_debut.toString());
							histo.setDate_fin(date_fin.toString());
						}
					}
				}
				if(panel_recherche.getPoids_checkBox().isSelected())
				{
					case_cochee++;
					String poids_min = panel_recherche.getPoids_min_textField().getText();
					if(panel_recherche.getPoids_comboBox().getSelectedItem()=="De") // poids exact
					{
						if(vec.get(i).getFichier().getTaille()==Integer.parseInt(poids_min))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_poids_exact(true);
							histo.setPoids_debut(poids_min);
						}
					}
					else if(panel_recherche.getPoids_comboBox().getSelectedItem()=="inférieur à")
					{
						if(vec.get(i).getFichier().getTaille() < Integer.parseInt(poids_min))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_poids_inferieur(true);
							histo.setPoids_debut(poids_min);
						}
					}
					else if(panel_recherche.getPoids_comboBox().getSelectedItem()=="supérieur à")
					{
						if(vec.get(i).getFichier().getTaille() > Integer.parseInt(poids_min))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_poids_superieur(true);
							histo.setPoids_debut(poids_min);
						}
					}
					else // on cherche dans une fourchette de poids
					{
						String poids_max = panel_recherche.getPoids_max_textField().getText();
						if(vec.get(i).getFichier().getTaille() > Integer.parseInt(poids_min) && resultat_intersection.get(i).getFichier().getTaille() < Integer.parseInt(poids_max))
						{
							vec_res.add(vec.get(i));
							histo.setRecherche_par_poids_superieur(true);
							histo.setPoids_debut(poids_min);
							histo.setPoids_fin(poids_max);
						}
					}
				}
				histo.setNb_case_cochee(case_cochee);
			}
//			// coloration :
			for(int i=0; i<vec_res.size();i++)
			{
				vec_res.get(i).setCouleurFond(couleur_courante);
			}
		}
		return vec_res;
	}
	


	// est appelée quand on change d'onglet et quand l'onglet sur lequel on va est l'onglet de recherche.
	@Override
	public void stateChanged(ChangeEvent event) 
	{
		TabOngletRecherche tab_pan = null;
		try
		{
			tab_pan = ((TabOngletRecherche)(event.getSource()));
		}catch (ClassCastException e) {
			e.printStackTrace();
			return;
		}
		if(tab_pan==panel_recherche.getTab_onglet_recherche())
		{
			histo= new HistoriqueRecherche();
			if(tab_pan.getSelectedComponent()==panel_recherche)
			{
				String str = "<html>";
				if(tab_pan.getPanel_selection().getBtn_arbre1().isSelected())
				{
					str+=" Arbre1"+"<br>";
					histo.setArbre1(true);
				}
				if(tab_pan.getPanel_selection().getBtn_arbre2().isSelected())
				{
					str+=" Arbre2 "+"<br>";
					histo.setArbre2(true);
				}
				if(tab_pan.getPanel_selection().getBtn_intersection().isSelected())
				{
					str+=" Intersection des deux arbres par :"+"<br>";
					if(tab_pan.getPanel_selection().getPoints_communs().getSelectedItem().equals("Nom"))
					{
						str+=" nom"+"<br>";
						histo.setIntersection_par_nom(true);
					}
					else if(tab_pan.getPanel_selection().getPoints_communs().getSelectedItem().equals("Date"))
					{
						str+="Date"+"<br>";
						histo.setIntersection_par_date(true);
					}
					else
					{
						str+="Poids"+"<br>";
						histo.setIntersection_par_poids(true);
					}
				}
				if(tab_pan.getPanel_selection().getBtnArbre1MoinsArbre2().isSelected())
				{
					str+="Objet de a1 non dans a2 <br>";
					histo.setObjet_a1_non_a2(true);
				}
				if(tab_pan.getPanel_selection().getBtnArbre2MoinsArbre1().isSelected())
				{
					str+="Objet de a2 non dans a1 <br>";
					histo.setObjet_a2_non_a1(true);
				}
				str+="</html>";
				panel_recherche.getType_selection().setText(str);
//				intersection();
			}
		}
	}
	

	// ---------------------------------------------------------------------------
	// 								Accesseurs :
	// ---------------------------------------------------------------------------
	public Vector<HistoriqueRecherche> getHistorique_recherche() { return historique_recherche; }
	public void setHistorique_recherche(Vector<HistoriqueRecherche> historiqueRecherche) { historique_recherche = historiqueRecherche; }

 
	public Vector<AbstractNoeud> getResultat_intersection() { return resultat_intersection; } 
	public void setResultat_intersection(Vector<AbstractNoeud> resultatIntersection) { 	resultat_intersection = resultatIntersection; }
	
	
	
}
