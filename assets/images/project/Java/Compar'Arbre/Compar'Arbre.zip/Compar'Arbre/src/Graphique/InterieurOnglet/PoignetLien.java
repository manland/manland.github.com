package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.swing.JComponent;

import Coeur.AbstractNoeud;
import Coeur.IEcouteurModele;
import Coeur.Noeud;

public class PoignetLien extends JComponent implements IEcouteurModele, MouseListener, MouseMotionListener {
	private PanelOnglet panel_onglet;
	private AbstractNoeud noeud;
	private Color fond = Color.white;
	private Color texte = Color.lightGray;
	private int decalage_x = 0;
	private int decalage_y = 0;
	private int decalage_x_on_screen = 0;
	private int decalage_y_on_screen = 0;
	private Vector<IEcouteurPoignetLien> ecouteurs;
	
	public PoignetLien(PanelOnglet panel_onglet, AbstractNoeud noeud) {
		this.panel_onglet = panel_onglet;
		this.noeud = noeud;
		addMouseListener(this);
		addMouseMotionListener(this);
		noeud.ajouterEcouteurModele(this);
		deplacement(noeud.getX(), noeud.getY());
		setSize(new Dimension(20, 8));
		ecouteurs = new Vector<IEcouteurPoignetLien>();
	}
	
	public void ajouterEcouteur(IEcouteurPoignetLien ecouteur) {
		ecouteurs.add(ecouteur);
	}
	
	public AbstractNoeud getNoeud() {
		return noeud;
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setPaint(fond);
		g2d.fillRect(0, 0, getWidth(), getHeight());
		g2d.setPaint(texte);
//		g2d.setFont(g2d.getFont().deriveFont((float)getHeight()-10));
		String a_dessiner = "---";
		g2d.drawString(a_dessiner, (getWidth()-(g2d.getFontMetrics().stringWidth(a_dessiner)))/2, (getHeight()/2)+3);
	}
	
	public void fireDeplacement() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).deplacementPoignet(getX(), getY());
		}
	}
	
	public void fireSelection(boolean selectionne) {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementSelection(selectionne);
		}
	}
	
	public void fireVisible(boolean visible) {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementVisibilite(visible);
		}
	}
	
	public void fireChangementCouleurFond(Color couleurFond) {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementCouleurFond(couleurFond);
		}
	}
	
	public void fireChangementCouleurTexte(Color couleurTexte) {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementCouleurTexte(couleurTexte);
		}
	}
	
	public void fireChangementPere(AbstractNoeud noeud) {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementDePere(noeud);
		}
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	@Override
	public void mouseExited(MouseEvent e) {
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}

	@Override
	public void mousePressed(MouseEvent event) {
		decalage_x = event.getX();
		decalage_y = event.getY();
		decalage_x_on_screen = event.getXOnScreen();
		decalage_y_on_screen = event.getYOnScreen();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		Vector<NoeudGraphique> v = panel_onglet.getTousEnfants(getBounds());
		if(v.size() == 0) {
			deplacement(noeud.getX(), noeud.getY());
		}
		for(int i=0; i<v.size(); i++) {
			Noeud n = null;
			try {
				n = (Noeud)v.get(i).getModele();
			}
			catch(ClassCastException cce) {
				deplacement(noeud.getX(), noeud.getY());
			}
			if(n != null) {
				noeud.setPere(n);
				n.ajouterEnfant(noeud);
				fireChangementPere(n);
				deplacement(noeud.getX(), noeud.getY());
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
		int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
		setLocation(getX() - deplacement_x - decalage_x, getY() - deplacement_y - decalage_y);
		fireDeplacement();
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementSelection(boolean selectionne) {
		if(selectionne) {
			fond = Color.black;
			texte = Color.white;
		}
		else {
			fond = Color.lightGray;
			texte = Color.white;
		}
		repaint();
		fireSelection(selectionne);
	}

	@Override
	public void changementVisibilite(boolean visible) {
		setVisible(visible);
		fireVisible(visible);
	}

	@Override
	public void deplacement(int x, int y) {
		//au_dessus_du_fils
		setLocation(noeud.getX()+((noeud.getLargeur()-getWidth())/2), noeud.getY()-getHeight());
		repaint();
	}

	@Override
	public void redimensionnement(int largeur, int hauteur) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void changementCouleurFond(Color couleur_fond) {
		fond = couleur_fond;
		repaint();
		fireChangementCouleurFond(couleur_fond);
	}

	@Override
	public void changementCouleurBordure(Color couleur_bordure) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementCouleurTexte(Color couleur_texte) {
		texte = couleur_texte;
		repaint();
		fireChangementCouleurTexte(couleur_texte);
	}

}
