package Controleur;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;

import Coeur.AbstractNoeud;
import Graphique.PanelCouleur;
import Graphique.PanelSelection;
import Graphique.ZoneDesktop;

public class ControleurPanelSelection implements ActionListener, MouseListener
{

	private PanelSelection panel_selection;
	private Color couleur_courante;
	private Vector<AbstractNoeud> resultat;
	
	public ControleurPanelSelection(PanelSelection panel_selection) 
	{
		super();
		this.panel_selection = panel_selection;
		couleur_courante = Color.magenta;
	}


	@Override
	public void actionPerformed(ActionEvent event) 
	{
		JCheckBox check_box = null;
		try{
			check_box = ((JCheckBox)(event.getSource()));
		}
		catch(ClassCastException c){
			JButton btn = null;
			try{
				btn = ((JButton)(event.getSource()));
			}catch (ClassCastException a) {
			c.printStackTrace();
			}
			if(btn==panel_selection.getBtn_valider())
			{
				afficherIntersection();
			}
				return;
		}
		if(panel_selection.getBtn_intersection().isSelected())
		{
			if(check_box.isSelected())
			{
				panel_selection.getBtn_valider().setEnabled(true);
			}
		}
		if( panel_selection.getBtnArbre1MoinsArbre2().isSelected())
		{
			if(check_box.isSelected())
			{
				panel_selection.getBtn_valider().setEnabled(true);
			}
		}
		if( panel_selection.getBtnArbre2MoinsArbre1().isSelected())
		{
			if(check_box.isSelected())
			{
				panel_selection.getBtn_valider().setEnabled(true);
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent event) {
		PanelCouleur pc =null; 
		try{
			pc = ((PanelCouleur)(event.getSource()));
		}
		catch (ClassCastException e) {
			e.printStackTrace();
			return;
		}
		if(pc==panel_selection.getPanel_couleur())
		{
			couleur_courante = pc.getCouleur_courante();
			Color c = pc.getColor_chooser().showDialog(panel_selection,"choisir couleur",pc.getCouleur_courante());
			if(c==null)
			{
				couleur_courante = pc.getCouleur_courante();
			}
			else
			{
				couleur_courante = c;
				pc.setCouleur_courante(c);
				panel_selection.getTab_onglet_recherche().getPanel_recherche().getControleur().intersection();
				pc.repaint();
			}
		}
	}


	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public Vector<AbstractNoeud> interObjetA1NonDansA2()
	{
		ZoneDesktop zone_desktop = ((ZoneDesktop)(panel_selection.getTab_onglet_recherche().getPanel_recherche().getInternal_frame_recherche().getParent()));
		Vector<AbstractNoeud> resultat_intersection = panel_selection.getTab_onglet_recherche().getPanel_recherche().getControleur().intersection();
		AbstractNoeud noeud_arbre1 = zone_desktop.getVecteur_frame_onglet().get(0).getTab_onglet().getPanelOnglet().getNoeudRoot();
		Vector<AbstractNoeud> vec_arbre1 = noeud_arbre1.toutLArbreEnVecteur();
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		
		
		res = vec_arbre1;
		int i=0;
		while (i<res.size())
		{
			for(int j=0;j<resultat_intersection.size();j++)
			{
				if(res.get(i).getFichier().getNom().equals(resultat_intersection.get(j).getFichier().getNom()))
				{
					res.remove(res.get(i));
					i--;
					j=resultat_intersection.size();
				}
			}
			i++;
		}
		for (int a = 0; a <res.size(); a++) {
			res.get(a).setCouleurBordure(couleur_courante);
		}
		return res;
	}
	
	
	public Vector<AbstractNoeud> interObjetA2NonDansA1()
	{
		ZoneDesktop zone_desktop = ((ZoneDesktop)(panel_selection.getTab_onglet_recherche().getPanel_recherche().getInternal_frame_recherche().getParent()));
		Vector<AbstractNoeud> resultat_intersection = panel_selection.getTab_onglet_recherche().getPanel_recherche().getControleur().intersection();
		AbstractNoeud noeud_arbre2 = zone_desktop.getVecteur_frame_onglet().get(1).getTab_onglet().getPanelOnglet().getNoeudRoot();
		Vector<AbstractNoeud> vec_arbre2 = noeud_arbre2.toutLArbreEnVecteur();
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		
		res = vec_arbre2;
		
		int i=0;
		while (i<res.size())
		{
			for(int j=0;j<resultat_intersection.size();j++)
			{
				if(res.get(i).getFichier().getNom().equals(resultat_intersection.get(j).getFichier().getNom()))
				{
					res.remove(res.get(i));
					i--;
					j=resultat_intersection.size();
				}
			}
			i++;
		}
		for (int a = 0; a <res.size(); a++) {
			res.get(a).setCouleurBordure(couleur_courante);
		}
		return res;
	}
	
	public void afficherIntersection()
	{
		resultat = new Vector<AbstractNoeud>();
		ControleurPanelRecherche controleur_panel_recherche= panel_selection.getTab_onglet_recherche().getPanel_recherche().getControleur();
		Vector<AbstractNoeud> res_inter = controleur_panel_recherche.intersection();
		if(panel_selection.getBtn_intersection().isSelected())
		{
			resultat.addAll(res_inter);
			for(int i=0; i< res_inter.size(); i++)
			{
				res_inter.get(i).setCouleurBordure(couleur_courante);
			}
		}
		if(panel_selection.getBtnArbre1MoinsArbre2().isSelected())
		{
			resultat.addAll(interObjetA1NonDansA2());
		}
		if(panel_selection.getBtnArbre2MoinsArbre1().isSelected())
		{
		   resultat.addAll(interObjetA2NonDansA1());
		}
	}
	
	
	// ------------------------------------------------------------------------
	// 								Accesseur :
	// ------------------------------------------------------------------------
	public Color getCouleur_courante() { return couleur_courante; } 
	public void setCouleur_courante(Color couleurCourante) { couleur_courante = couleurCourante; }


	public Vector<AbstractNoeud> getResultat() { return resultat; } 
	public void setResultat(Vector<AbstractNoeud> resultat) { this.resultat = resultat; }

	
	
}
