package Controleur;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import Graphique.BarreAdresse;
import Graphique.BarreOutil;
import Graphique.BarreStatut;
import Graphique.InternalFrameOnglet;

public class ControleurBarreAdresse implements ActionListener, CaretListener, ComponentListener
{
	private BarreAdresse barre_adresse;
	private ImageIcon icon_cadenas;
	private boolean adresse_deja_entree=false;
	private boolean adresse_correcte=false;
	
	public ControleurBarreAdresse(BarreAdresse barre_adresse)
	{ 
		super();
		this.barre_adresse=barre_adresse;
		icon_cadenas = new ImageIcon("Images/Barre_Outil/cadenas.png");
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		JButton btn = null;
		try {
			btn = ((JButton)(event.getSource()));
		}
		catch (Exception e) {
			JTextField jt = null;
			try {
				jt = ((JTextField)(event.getSource()));
			}
			catch (ClassCastException t)
			{
				t.printStackTrace();
				return;
			}
			if(jt==barre_adresse.getText_field_adr_dossier())
			{
				chargerDossier();
				if(adresse_correcte)
				{
					((BarreOutil)(barre_adresse.getParent())).getBtn_recherche().setEnabled(true);
					if(((BarreOutil)(barre_adresse.getParent())).getControleur().isDeuxieme_fenetre_deja_affichee())
					{
						((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getPoints_communs().setEnabled(true);
						((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtn_arbre2().setEnabled(true);
						((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtn_intersection().setEnabled(true);
						((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtnArbre1MoinsArbre2().setEnabled(true);
						((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtnArbre2MoinsArbre1().setEnabled(true);
					}
				}
			}
			if(jt==barre_adresse.getText_field_lien_dossier())
			{
				barre_adresse.getText_field_niveau_dossier().requestFocus();
			}
			if(jt==barre_adresse.getText_field_niveau_dossier())
			{
				barre_adresse.getText_field_adr_dossier().requestFocus();
			}
			return;
		}
		if(btn==barre_adresse.getBtn_ok_dossier())
		{
			chargerDossier();
			if(adresse_correcte)
			{
				((BarreOutil)(barre_adresse.getParent())).getBtn_recherche().setEnabled(true);
				if(((BarreOutil)(barre_adresse.getParent())).getControleur().isDeuxieme_fenetre_deja_affichee())
				{
					((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtn_arbre2().setEnabled(true);
					((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtn_intersection().setEnabled(true);
					((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtnArbre1MoinsArbre2().setEnabled(true);
					((BarreOutil)(barre_adresse.getParent())).getZone_desktop().getInternal_frame_recherche().getTab_onglet_recherche().getPanel_selection().getBtnArbre2MoinsArbre1().setEnabled(true);
				}
			}
		}
		if(btn==barre_adresse.getBtn_ouvrir_fenetre())
		{
			barre_adresse.getFrame_onglet().setVisible(true);
		}
	}
	
	


	// se déroule kan il y a un changement dans le textfield de l'adresse
	@Override
	public void caretUpdate(CaretEvent event) 
	{
		JTextField tf = null;
		try {
			tf = ((JTextField)(event.getSource()));
		}
		catch (Exception e) {
			e.printStackTrace();
			return;
		}
		if(tf==barre_adresse.getText_field_adr_dossier())
		{
			if(!adresse_correcte)
			{
				barre_adresse.getText_field_adr_dossier().setForeground(Color.black);
				barre_adresse.getText_field_adr_dossier().setBorder(BorderFactory.createLineBorder(Color.gray));
				BarreStatut.changerLabel("");
			}
		}
		
	}

	@Override
	public void componentHidden(ComponentEvent event) {
		InternalFrameOnglet frame_onglet = null;
		try{
			frame_onglet = ((InternalFrameOnglet)(event.getSource()));
		}catch (ClassCastException c)
		{
			c.printStackTrace();
			return;
		}
		if(!frame_onglet.isVisible())
		{
			barre_adresse.getBtn_ouvrir_fenetre().setVisible(true);
		}
		
	}

	@Override
	public void componentMoved(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentResized(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentShown(ComponentEvent event) {
		InternalFrameOnglet frame_onglet = null;
		try{
			frame_onglet = ((InternalFrameOnglet)(event.getSource()));
		}catch (ClassCastException c)
		{
			c.printStackTrace();
			return;
		}
		if(frame_onglet.isVisible())
		{
			barre_adresse.getFrame_onglet().toBack();
			barre_adresse.getBtn_ouvrir_fenetre().setVisible(false);
		}
	}
	
	
	
	
	public void chargerDossier()
	{
		// on teste d'abbord si le chemin passé en parametre existe :
		File directory = new File(barre_adresse.getText_field_adr_dossier().getText());
		if(!directory.exists() || !directory.isDirectory()) 
		{
			barre_adresse.getText_field_adr_dossier().setForeground(Color.red);
			barre_adresse.getText_field_adr_dossier().setBorder(BorderFactory.createLineBorder(Color.red));
			BarreStatut.changerLabel("L'adresse entrée n'est pas valide");
			adresse_correcte=false;
		}
		else   // le chemin est correct, on charge le dossier
		{
			adresse_correcte=true;
			if(!adresse_deja_entree)	// premier passage de l'adresse
			{
				String str_lien = barre_adresse.getText_field_lien_dossier().getText();
				if(str_lien.equals("")) 	// si rien n'est entré dans les liens on fixe arbitrairement les liens a 0
				{
					str_lien="0";
					barre_adresse.getText_field_lien_dossier().setText("0");
				}	
				int nb_lien_max = Integer.parseInt(str_lien);
				String str_niveau_max = barre_adresse.getText_field_niveau_dossier().getText();
				if(str_niveau_max.equals("")) 	// si rien n'est entré dans les niveaux on fixe arbitrairement le niveau a 1
				{
					str_niveau_max="1";
					barre_adresse.getText_field_niveau_dossier().setText("1");
				}
				int nb_niveau_max = Integer.parseInt(str_niveau_max);
				barre_adresse.getFrame_onglet().getTab_onglet().getPanelOnglet().clear();
				// on transforme le bouton d'ajout en cadenas et on grise les textfield
				barre_adresse.getFrame_onglet().getTab_onglet().getPanelOnglet().charger(barre_adresse.getText_field_adr_dossier().getText(),nb_lien_max,nb_niveau_max);
				barre_adresse.getBtn_ok_dossier().setIcon(icon_cadenas);
				barre_adresse.getText_field_adr_dossier().setEnabled(false);
				barre_adresse.getText_field_lien_dossier().setEnabled(false);
				barre_adresse.getText_field_niveau_dossier().setEnabled(false);
				adresse_deja_entree= true;
			}
			else	// on clique sur le cadenas
			{
				// permet d'afficher une boite de dialogue
				int reponse = JOptionPane.showConfirmDialog(
					barre_adresse.getFrame_onglet(),
				    "Etes vous sur de vouloir modifier l'adresse du dossier parent ?"+"\n"
				    +"En cliquant sur Oui, vous perdrez toutes les modifications réalisées jusqu'à maintenant...",
				    "Attention !",
				    JOptionPane.YES_NO_OPTION);
				
				// test, quoi faire en cas de oui ou non :
				if(reponse == JOptionPane.YES_OPTION)
				{
					// effacer le fond du panel, le textfield lien, le textfield niveau, le textfield adresse
					barre_adresse.getFrame_onglet().getTab_onglet().getPanelOnglet().clear();
					barre_adresse.getBtn_ok_dossier().setIcon(barre_adresse.getIcon_ok_dossier());
					barre_adresse.getText_field_lien_dossier().setText("");
					barre_adresse.getText_field_niveau_dossier().setText("");
					barre_adresse.getText_field_adr_dossier().setEnabled(true);
					barre_adresse.getText_field_lien_dossier().setEnabled(true);
					barre_adresse.getText_field_niveau_dossier().setEnabled(true);
					adresse_deja_entree=false;
				}
			}
		}
	}

	
	// accesseurs : 
	public boolean isAdresse_correcte() { return adresse_correcte; 	}
	public void setAdresse_correcte(boolean adresseCorrecte) { 	adresse_correcte = adresseCorrecte; }
	
	
}