package Graphique.InterieurOnglet;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;
import javax.swing.Timer;

import Coeur.AbstractNoeud;

public class BoutonsNoeud extends JComponent implements ActionListener, ComponentListener, MouseListener, MouseMotionListener {
	private Rectangle rectangle_plus;
	private Rectangle rectangle_moins;
	private Rectangle rectangle_info;
	private Rectangle rectangle_loupe;
	
	private int lpr;
	private int hpr;
	private int x1pr;
	private int y1pr;
	private int x2pr;
	private int y2pr;
	private int x3pr;
	private int y3pr;
	private int x4pr;
	private int y4pr;
	
	private NoeudGraphique noeud;
	private PanelOnglet panel_onglet;
	private Timer timer;
	
	public BoutonsNoeud(PanelOnglet panel) {
		this.panel_onglet = panel;
		Dimension dimension = new Dimension(20, 20);
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
		
		addMouseListener(this);
		addMouseMotionListener(this);
		addComponentListener(this);
		
		timer = new Timer(100, this);
		timer.start();
	}
	
	public NoeudGraphique getNoeud() {
		return noeud;
	}
	
	public void setNoeud(NoeudGraphique noeud) {
		this.noeud = noeud;
		setLocation(noeud.getModele().getX(), noeud.getModele().getY());
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Dimension dimension = null;
		if(noeud != null) {
			dimension = new Dimension(noeud.getModele().getLargeur(), 20);
		}
		else {
			dimension = new Dimension(20, 20);
		}
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
		lpr = 20;//lpr = largeur_petit_rectangle
		hpr = 20;//hpr = hauteur_petit_rectangle
		x1pr = (getWidth()-(lpr*4))/2;//xpr = x_petit_rectangle du 1er rectangle
		y1pr = 0;//y1pr = y_petit_rectangle du 1er rectangle
		x2pr = x1pr+lpr;
		y2pr = 0;
		x3pr = x2pr+lpr;
		y3pr = 0;
		x4pr = x3pr+lpr;
		y4pr = 0;
		
		rectangle_plus = new Rectangle(x1pr, y1pr, lpr, hpr);
		rectangle_moins = new Rectangle(x2pr, y2pr, lpr, hpr);
		rectangle_info = new Rectangle(x3pr, y3pr, lpr, hpr);
		rectangle_loupe = new Rectangle(x4pr, y4pr, lpr-1, hpr);
		
		Color bordure = null;
		Color fond = null;
		try {
			bordure = new Color(255, 255, 255, (255*cpt_transparance)/10);
			fond = new Color(0, 0, 0, (255*cpt_transparance)/10);
		}
		catch(IllegalArgumentException e) {
			System.out.println(cpt_transparance);
		}
		
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setPaint(fond);
		g2d.fill(rectangle_plus);
		g2d.fill(rectangle_moins);
		g2d.fill(rectangle_info);
		g2d.fill(rectangle_loupe);
		
		g2d.setPaint(bordure);
		g2d.draw(rectangle_plus);
		g2d.drawLine(x1pr+5, y1pr+(hpr/2), x1pr+lpr-5, y1pr+(hpr/2));
		g2d.drawLine(x1pr+(lpr/2), y1pr+5, x1pr+(lpr/2), y1pr+hpr-5);
		
		g2d.draw(rectangle_moins);
		g2d.drawLine(x2pr+5, y2pr+(hpr/2), x2pr+lpr-5, y2pr+(hpr/2));
		
		g2d.draw(rectangle_info);
		g2d.drawString("!", x3pr+(lpr-g2d.getFontMetrics().stringWidth("!"))/2, y3pr+hpr-3);
		
		g2d.draw(rectangle_loupe);
		g2d.drawOval(x4pr+7, y4pr+5, 5, 5);
		g2d.drawLine(x4pr+12, y4pr+10, x4pr+14, y4pr+12);
	}

	@Override
	public void mouseClicked(MouseEvent event) {
		if(rectangle_plus.contains(event.getPoint())) {
			noeud.getModele().afficherTousMesFils();
		}
		else if(rectangle_moins.contains(event.getPoint())) {
			noeud.getModele().cacherTousMesFils();
		}
		else if(rectangle_info.contains(event.getPoint())) {
			panel_onglet.dessinerInfosNoeud(noeud.getModele());
		}
		else if(rectangle_loupe.contains(event.getPoint())) {
			setToolTipText("Clickez pour donner le focus à ce lien");
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {
		if(e.getY() < getHeight()) {
			setVisible(false);
			timer.stop();
			noeud.remettreAuBonZOrder();
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent event) {
		if(rectangle_plus.contains(event.getPoint())) {
			setToolTipText("Clickez pour ouvrir tous ses fils");
		}
		else if(rectangle_moins.contains(event.getPoint())) {
			setToolTipText("Clickez pour fermer tous ses fils");
		}
		else if(rectangle_info.contains(event.getPoint())) {
			setToolTipText("Clickez pour afficher les informations");
		}
		else if(rectangle_loupe.contains(event.getPoint())) {
			setToolTipText("Clickez pour donner le focus à ce lien");
		}
	}

	@Override
	public void componentHidden(ComponentEvent e) {
		cpt_transparance = 0;
		timer.stop();
	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void componentShown(ComponentEvent e) {
		if(cpt_transparance == 0) {
			timer.start();
		}
	}

	private int cpt_transparance = 0;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		cpt_transparance++;
		setLocation(getX(), noeud.getModele().getY()-(cpt_transparance*2));
		if(cpt_transparance==10) {
			timer.stop();
		}
		repaint();
	}
	
}
