package Graphique;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class BarreStatut extends JPanel
{
	 private static JLabel label_statut;

	 public BarreStatut()
	 {
		label_statut= new JLabel("Barre état");
		this.add(label_statut);
	 }
	 
	 public static void changerLabel(String s)
	 {
		 label_statut.setText(s);
	 }

}
