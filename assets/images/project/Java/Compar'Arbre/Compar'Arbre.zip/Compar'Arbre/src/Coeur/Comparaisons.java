package Coeur;

public class Comparaisons {

	private Noeud arbre1;
	private Noeud arbre2;
	
	public Comparaisons(Noeud arbre1, Noeud arbre2) {
		this.arbre1 = arbre1;
		this.arbre2 = arbre2;
	}
	
	public Noeud intersection() {
		Noeud res = null;
		
		return res;
	}
	
	public Noeud arbre1PriveAbre2() {
		Noeud res = null;
		
		return res;
	}
	
	public Noeud arbre2PriveArbre1() {
		Noeud res = null;
		
		return res;
	}
}
