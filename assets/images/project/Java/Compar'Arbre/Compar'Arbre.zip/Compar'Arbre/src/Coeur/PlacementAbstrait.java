package Coeur;

public abstract class PlacementAbstrait {

	protected Noeud noeud;
	protected int rang_actuel = 1;
	
	protected int largeur_max;
	protected int hauteur_max;
	
	private int ancienne_largeur;
	private int ancienne_hauteur;
	
	public PlacementAbstrait(Noeud noeud_pere, int largeur_max, int hauteur_max) {
		noeud = noeud_pere;
		this.largeur_max = largeur_max;
		this.hauteur_max = hauteur_max;
		ancienne_largeur = largeur_max;
		ancienne_hauteur = hauteur_max;
	}
	
	abstract public void placement(AbstractNoeud noeud);
	
	protected void attributionRangOrdreSuffixe(AbstractNoeud noeud) {
		if(noeud.isNoeud()) {
			Noeud n = (Noeud)noeud;
			if(n.getNbEnfant()>0) {
				for(int i=0; i<n.getNbEnfant(); i++) {
					attributionRangOrdreSuffixe(n.getEnfant(i));
				}
			}
			n.setRang(rang_actuel);
			rang_actuel++;
		}
		else {
			noeud.setRang(rang_actuel);
			rang_actuel++;
		}
	}
	
	protected void attributionRangOrdrePrefixe(AbstractNoeud noeud) {
		if(noeud.isNoeud()) {
			Noeud n = (Noeud)noeud;
			n.setRang(rang_actuel);
			rang_actuel++;
			if(n.getNbEnfant()>0) {
				for(int i=0; i<n.getNbEnfant(); i++) {
					attributionRangOrdrePrefixe(n.getEnfant(i));
				}
			}
		}
		else {
			noeud.setRang(rang_actuel);
			rang_actuel++;
		}
	}
	
	protected void attributionRangOrdreInfixe(AbstractNoeud noeud) {
		if(noeud.isNoeud()) {
			Noeud n = (Noeud)noeud;
			if(n.getNbEnfant()>0) {
				int moitie_enfants = (int)n.getNbEnfant()/2;
				if(moitie_enfants < 1) {
					moitie_enfants = 1;
				}
				for(int i=0; i<moitie_enfants; i++) {
					attributionRangOrdreInfixe(n.getEnfant(i));
				}
				n.setRang(rang_actuel);
				rang_actuel++;
				for(int i=moitie_enfants; i<n.getNbEnfant(); i++) {
					attributionRangOrdreInfixe(n.getEnfant(i));
				}
			}
			else {
				n.setRang(rang_actuel);
				rang_actuel++;
			}
		}
		else {
			noeud.setRang(rang_actuel);
			rang_actuel++;
		}
	}
	
	protected void placementCentreInitiale(AbstractNoeud noeud) {
		noeud.setX(noeud.getX()+(ancienne_largeur/2)-(noeud.getLargeur()/2));
		noeud.setY(noeud.getY()+ancienne_hauteur-(noeud.getHauteur()/2));
		
		if(noeud.isNoeud()) {
			Noeud n = (Noeud) noeud;
			for(int i=0; i<n.getNbEnfant(); i++) {
				placementCentreInitiale(n.getEnfant(i));
			}
		}
	}
	
	public void placementCentre(AbstractNoeud noeud, int largeur, int hauteur) {
		int deplacement_largeur_de = ancienne_largeur - largeur;
		noeud.setX(noeud.getX()-deplacement_largeur_de/2);
		int deplacement_hauteur_de = ancienne_hauteur - hauteur;
		noeud.setY(noeud.getY()-deplacement_hauteur_de/2);
		
		if(noeud.isNoeud()) {
			Noeud n = (Noeud) noeud;
			for(int i=0; i<n.getNbEnfant(); i++) {
				placementCentre(n.getEnfant(i), largeur, hauteur);
			}
		}
	}

	public void setAncienne_largeur(int ancienneLargeur) {
		ancienne_largeur = ancienneLargeur;
	}

	public void setAncienne_hauteur(int ancienneHauteur) {
		ancienne_hauteur = ancienneHauteur;
	}
	
	
}
