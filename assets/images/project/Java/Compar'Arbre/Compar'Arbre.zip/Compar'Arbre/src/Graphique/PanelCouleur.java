package Graphique;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JColorChooser;
import javax.swing.JPanel;
import javax.swing.colorchooser.ColorSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class PanelCouleur extends JPanel
{
	private Color couleur_courante;
	private JColorChooser color_chooser;
	
	public PanelCouleur(JColorChooser color_chooser) 
	{
		super();
		this.color_chooser=color_chooser;
		color_chooser.setColor(color_chooser.getColor());
		couleur_courante = color_chooser.getColor();
	
	// Add listener on model to detect changes to selected color 
	ColorSelectionModel model = color_chooser.getSelectionModel(); 
	model.addChangeListener(new ChangeListener() 
	{ 
		public void stateChanged(ChangeEvent evt) 
		{ 
			ColorSelectionModel model = (ColorSelectionModel)evt.getSource(); 
			// Get the new color value 
			couleur_courante = model.getSelectedColor(); 
		} 
	}); 
	// Set a preferred size 
		Dimension taille = new Dimension(20,20);
		setPreferredSize(taille); 
		setMinimumSize(taille);
		setMaximumSize(taille);
		setSize(taille);
	} 

// Paint current color 
	public void paint(Graphics g) 
	{ 
		g.setColor(couleur_courante); g.fillRect(0, 0, getWidth()-1, getHeight()-1); 
	}


	// accesseurs :
	public Color getCouleur_courante() { return couleur_courante; }
	public void setCouleur_courante(Color couleurCourante) { couleur_courante = couleurCourante; }

	public JColorChooser getColor_chooser() { return color_chooser; }
	public void setColor_chooser(JColorChooser colorChooser) { color_chooser = colorChooser; } 
		
	
	
}
