package Coeur;

public abstract class AbstractChargeur {

	protected Noeud noeud_pere;
	protected int nb_liens_max;
	protected int nb_liens_totaux;
	protected int profondeur;
	
	public AbstractChargeur(String url, int nb_liens, int profondeur) {
		this.nb_liens_max = nb_liens;
		this.nb_liens_totaux = 0;
		this.profondeur = profondeur;
		noeud_pere = new Noeud(url, null, 1);
	}
	
	public Noeud getNoeudPere() {
		return noeud_pere;
	}
	
	public String toString() {
		return noeud_pere.toString();
	}
}
