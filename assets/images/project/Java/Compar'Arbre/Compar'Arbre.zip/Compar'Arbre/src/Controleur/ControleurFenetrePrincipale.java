package Controleur;

import java.awt.Window;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Vector;

import javax.swing.JInternalFrame;

import Graphique.FenetrePrincipale;
import Graphique.InternalFrameOnglet;

public class ControleurFenetrePrincipale implements ComponentListener, WindowListener
{
	
	private FenetrePrincipale fenetre_principale;
	private int recherche_pos_x;
	private int recherche_pos_y;

	public ControleurFenetrePrincipale(FenetrePrincipale fenetrePrincipale) {
		super();
		fenetre_principale = fenetrePrincipale;
		recherche_pos_x = 0;
		recherche_pos_y = 0;
	}

	@Override
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentResized(ComponentEvent e) 
	{
		float largeur_fenetre = fenetre_principale.getWidth();
		float hauteur_fenetre = fenetre_principale.getHeight();
		if(fenetre_principale.getBarre_outil().getControleur().isDeuxieme_fenetre_deja_affichee())
		{
			Vector<InternalFrameOnglet> tab_frame = fenetre_principale.getZone_desktop().getVecteur_frame_onglet();
			int cpt_fenetre=0;
				for(int i=0; i<tab_frame.size(); i++)
				{
						tab_frame.get(i).setSize((int)largeur_fenetre/2,(int)hauteur_fenetre-115);
						tab_frame.get(i).setLocation(cpt_fenetre*tab_frame.get(i).getWidth(),0);
						cpt_fenetre++;
						recherche_pos_x = fenetre_principale.getZone_desktop().getInternal_frame_recherche().getX();
						recherche_pos_y = fenetre_principale.getZone_desktop().getInternal_frame_recherche().getY();
						fenetre_principale.getZone_desktop().getInternal_frame_recherche().setLocation(recherche_pos_x,recherche_pos_y);
				}
		}
		else
		{
			if(largeur_fenetre==fenetre_principale.getDimension_initiale().getWidth() && hauteur_fenetre==fenetre_principale.getDimension_initiale().getHeight())
			{
				fenetre_principale.getZone_desktop().getInternal_frame_onglet().setSize((int)largeur_fenetre,480);
			}
			else
			{
				fenetre_principale.getZone_desktop().getInternal_frame_onglet().setSize((int)largeur_fenetre,(int)hauteur_fenetre-115);
			}
		}
		

		
	}

	@Override
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent e) {
		 Window win = e.getWindow();
	     win.setVisible(false);
	     System.exit(0);
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

}
