package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.ScrollPane;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Stack;
import java.util.Vector;

import javax.print.attribute.Size2DSyntax;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Coeur.AbstractNoeud;
import Coeur.ChargeurDossier;
import Coeur.IEcouteurModele;
import Coeur.Noeud;
import Coeur.PlacementAbstrait;
import Coeur.PlacementRadial;
import Coeur.PlacementSimple;
import Coeur.PlacementSimpleVertical;

public class PanelOnglet extends JLayeredPane implements MouseListener, MouseMotionListener, IEcouteurModele {
	private JScrollPane parent;
	private Dimension taille_onglet;
	private PlacementAbstrait placement;
	private Noeud noeud_root;
	private BoutonsNoeud boutons_noeud = null;
	private InfosNoeud infos_noeud = null;
	private ZoomComponent zoom_component = null;
	private Boolean placement_zoom = false;
	private SelectionComponent selection_component = null;
	private Boolean placement_selection = false;
	private ComponentAide component_aide;
	
	private int plus_petit_x = 0;
	private int plus_grand_x = 0;
	private int plus_petit_y = 0;
	private int plus_grand_y = 0;
	
	private double largeur_cercle = 800;
	private double hauteur_cercle = 350;
	
	private double ancien_facteur_largeur = largeur_cercle / 200;
	private double ancien_facteur_hauteur = hauteur_cercle / 200;
	
	private int premier_pressed_x;
	private int premier_pressed_y;
	private MenuPanelOnglet menu;
	
	public PanelOnglet() {
		super();
		setLayout(null);
		this.setBackground(new Color(255,255,255));
		this.setName("Onglet");
		taille_onglet = new Dimension(500,500);
		this.setMinimumSize(taille_onglet);
		this.setSize(taille_onglet);
		this.setPreferredSize(taille_onglet);
		addMouseListener(this);
		addMouseMotionListener(this);
		component_aide = new ComponentAide();
		add(component_aide);
		menu = new MenuPanelOnglet(this);
	}
	
	public AbstractNoeud getNoeudRoot() {
		return noeud_root;
	}
	
	public JScrollPane getParentScrollPane() {
		return parent;
	}
	
	public void setParent(JScrollPane parent) {
		this.parent = parent;
	}
	
	public void setInfoNoeud(InfosNoeud info) {
		this.infos_noeud = info;
	}
	
	public BoutonsNoeud getBoutonsNoeud() {
		return boutons_noeud;
	}
	
	public ComponentAide getComponentAide() {
		return component_aide;
	}
	
	public void clear() {
		removeAll();
		boutons_noeud = null;
		infos_noeud = null;
		zoom_component = null;
		selection_component = null;
		component_aide = null;
		if(component_aide == null) {
			component_aide = new ComponentAide();
			add(component_aide);
		}
		repaint();
	}
	
	private void placerEtAjouterNoeud() {
		component_aide.setVisible(false);
//		placement = new PlacementSimple(c.getNoeudPere(), getParent().getWidth()-100, getParent().getHeight()-100);
//		placement = new PlacementSimpleVertical(c.getNoeudPere(), getParent().getWidth()-100, getParent().getHeight()-100);
		placement = new PlacementRadial(noeud_root, (int)largeur_cercle, (int)hauteur_cercle);
		construireAjouterNoeudGraphique(noeud_root);
		taille_onglet = new Dimension((plus_grand_x-plus_petit_x)+(noeud_root.getLargeur()*2),(plus_grand_y-plus_petit_y)+(noeud_root.getHauteur()*2));
		this.setMinimumSize(taille_onglet);
		this.setSize(taille_onglet);
		this.setPreferredSize(taille_onglet);
		repaint();
	}
	
	private void construireAjouterNoeudGraphique(AbstractNoeud noeud) {
		if(noeud.getX()<plus_petit_x) {
			plus_petit_x = noeud.getX();
		}
		if(noeud.getX()>plus_grand_x) {
			plus_grand_x = noeud.getX();
		}
		if(noeud.getY()<plus_petit_y) {
			plus_petit_y = noeud.getY();
		}
		if(noeud.getY()>plus_grand_y) {
			plus_grand_y = noeud.getY();
		}
		noeud.ajouterEcouteurModele(this);
		NoeudGraphique pere_graphique = new NoeudGraphique(this, noeud);
		add(pere_graphique, 0);
		if(noeud.getPere() != null) {
			PoignetLien poignet = new PoignetLien(this, noeud);
			add(poignet);
			LienGraphique lien = new LienGraphique(this, noeud.getPere(), poignet);
			add(lien, -1);
		}
		if(noeud.isNoeud()) {
			Noeud n = (Noeud) noeud;
			for(int i=0; i<n.getNbEnfant(); i++) {
				construireAjouterNoeudGraphique(n.getEnfant(i));
//				if(i>0) {
//					add(new LienGraphiqueFreres(n.getEnfant(i-1), n.getEnfant(i)), -1);
//				}
			}
		}
		validate();
	}
	
	public void charger(String url_a_charger, int nb_lien_max, int nb_profondeur_max) {
		ChargeurDossier c = new ChargeurDossier(url_a_charger, nb_lien_max, nb_profondeur_max);
		noeud_root = c.getNoeudPere();
		placerEtAjouterNoeud();
	}
	
	public AbstractNoeud perePlusProcheDansVecteur(AbstractNoeud noeud, Vector<AbstractNoeud> v) {
		if(noeud.getPere() == null) {
			return null;
		}
		else {
			if(v.contains(noeud.getPere())) {
				return noeud.getPere();
			}
			else {
				return perePlusProcheDansVecteur(noeud.getPere(), v);
			}
		}
	}
	
	public void construireArbre(Noeud noeud_root, Vector<AbstractNoeud> v) {
		HashMap<AbstractNoeud, AbstractNoeud> noeuds_peres = new HashMap<AbstractNoeud, AbstractNoeud>();
		for(int i=0; i<v.size(); i++) {
			AbstractNoeud clone_noeud = v.get(i).clone();
			AbstractNoeud pere_noeud = perePlusProcheDansVecteur(v.get(i), v);
			if(pere_noeud == null) {
				noeud_root.ajouterEnfant(clone_noeud);
				clone_noeud.setPere(noeud_root);
				if(clone_noeud.isNoeud()) {
					noeuds_peres.put(v.get(i), clone_noeud);
				}
			}
			else {
				AbstractNoeud noeud_pere_plus_proche = noeuds_peres.get(pere_noeud);
				((Noeud)noeud_pere_plus_proche).ajouterEnfant(clone_noeud);
				clone_noeud.setPere((Noeud)noeud_pere_plus_proche);
				if(clone_noeud.isNoeud()) {
					noeuds_peres.put(v.get(i), clone_noeud);
				}
			}
		}
	}
	
	public void construireArbre(Vector<AbstractNoeud> noeud, Vector<AbstractNoeud> noeud2) {
		String url1 = "";
		if(noeud != null) {
			url1 = noeud.get(0).getFichier().getUrl();
		}
		String url2 = "";
		if(noeud2 != null) {
			url2 = noeud2.get(0).getFichier().getUrl();
		}
		String [] tab_url_1 = url1.split("/");
		String [] tab_url_2 = url2.split("/");
		String url = "/";
		boolean dif = false;
		for(int i=0; i<tab_url_1.length && i<tab_url_2.length && !dif; i++) {
			if(tab_url_1[i].equals(tab_url_2[i])) {
				url += "/"+tab_url_1[i];
			}
			else{
				dif = true;
			}
		}
		if(!dif) {
			noeud.remove(0);
			if(noeud2 != null) {
				noeud2.remove(0);
			}
		}
		noeud_root = new Noeud(url, null, 1);
		construireArbre(noeud_root, noeud);
		if(noeud2!=null) {
			construireArbre(noeud_root, noeud2);
		}
		placerEtAjouterNoeud();
	}
	
	public void enregistrer(String url) {
		noeud_root.enregistrer(url);
	}
	
	public void restaurerArbre(String url) {
		noeud_root = AbstractNoeud.restaurerArbre(url);
		placerEtAjouterNoeud();
	}
	
	public void dessinerBoutonsNoeud(NoeudGraphique noeud) {
		if(boutons_noeud == null) {
			boutons_noeud = new BoutonsNoeud(this);
			add(boutons_noeud, 0);
		}
		boutons_noeud.setNoeud(noeud);
		boutons_noeud.setVisible(true);
		try {
			setComponentZOrder(boutons_noeud, 1);
		}
		catch(IllegalArgumentException e) {
			System.out.println(getComponentZOrder(boutons_noeud));
		}
		boutons_noeud.repaint();
	}
	
	public void enleverBoutonsNoeud() {
		if(boutons_noeud != null) {
			boutons_noeud.setVisible(false);
		}
	}
	
	public void dessinerInfosNoeud(AbstractNoeud noeud) {
		if(infos_noeud == null) {
			infos_noeud = new InfosNoeud(this);
			add(infos_noeud, 0);
		}
		infos_noeud.setInfos(noeud);
		infos_noeud.setLocation(noeud.getX(), noeud.getY()+noeud.getHauteur());
		infos_noeud.setVisible(true);
		setComponentZOrder(infos_noeud, 0);
		infos_noeud.repaint();
	}
	
	public void zoom(int largeur, int hauteur) {
		double facteur_largeur = largeur_cercle / largeur;
		double facteur_hauteur = hauteur_cercle / hauteur;
		ancien_facteur_largeur = facteur_largeur;
		ancien_facteur_hauteur = facteur_hauteur;
		largeur_cercle = largeur_cercle * facteur_largeur;
		hauteur_cercle = hauteur_cercle * facteur_hauteur;
		int x_noeud_root = noeud_root.getX();
		int y_noeud_root = noeud_root.getY();
		int x_selection_component = selection_component.getX();
		int y_selection_component = selection_component.getY();
		for(int i=0; i<getComponentCount(); i++) {
			NoeudGraphique n = null;
			Boolean cast_a_marche = true;
			try {
				n = (NoeudGraphique)getComponent(i);
			}
			catch(ClassCastException e) {
				cast_a_marche = false;
			}
			if(cast_a_marche) {
				double nouveau_x = facteur_largeur * (n.getModele().getX() - x_selection_component);
				n.getModele().setX((int)nouveau_x);
				double nouveau_y = facteur_hauteur * (n.getModele().getY() - y_selection_component);
				n.getModele().setY((int)nouveau_y);
				n.getModele().setLargeur(n.getModele().getLargeur()*(int)facteur_largeur);
				n.getModele().setHauteur(n.getModele().getHauteur()*(int)facteur_hauteur);
			}
		}
		selection_component.setLocation((int)(selection_component.getX()*facteur_largeur), (int)(selection_component.getY()*facteur_hauteur));
		selection_component.setSize(selection_component.getWidth()*(int)facteur_largeur, selection_component.getHeight()*(int)facteur_hauteur);
		noeud_root.setXPlusEnfants((int)(-(-noeud_root.getX()+x_noeud_root*facteur_largeur)));
		noeud_root.setYPlusEnfants((int)(-(-noeud_root.getY()+y_noeud_root*facteur_hauteur)));
		scrollRectToVisible(selection_component.getReelBounds());
	}
	
	public void zoomMoins() {
		double facteur_largeur = 1/ancien_facteur_largeur;
		double facteur_hauteur = 1/ancien_facteur_hauteur;
		largeur_cercle = largeur_cercle * facteur_largeur;
		hauteur_cercle = hauteur_cercle * facteur_hauteur;
		int x_noeud_root = noeud_root.getX();
		int y_noeud_root = noeud_root.getY();
		for(int i=0; i<getComponentCount(); i++) {
			NoeudGraphique n = null;
			Boolean cast_a_marche = true;
			try {
				n = (NoeudGraphique)getComponent(i);
			}
			catch(ClassCastException e) {
				cast_a_marche = false;
			}
			if(cast_a_marche) {
				double nouveau_x = facteur_largeur * n.getModele().getX();
				n.getModele().setX((int)nouveau_x);
				double nouveau_y = facteur_hauteur * n.getModele().getY();
				n.getModele().setY((int)nouveau_y);
				int nouvelle_largeur = n.getModele().getLargeur()/(int)ancien_facteur_largeur;
				n.getModele().setLargeur(nouvelle_largeur);
				int nouvelle_hauteur = n.getModele().getHauteur()/(int)ancien_facteur_hauteur;
				n.getModele().setHauteur(nouvelle_hauteur);
			}
		}
		selection_component.setLocation((int)(selection_component.getX()/ancien_facteur_largeur), (int)(selection_component.getY()/ancien_facteur_hauteur));
		selection_component.setSize((int)(selection_component.getWidth()/ancien_facteur_largeur), (int)(selection_component.getHeight()/ancien_facteur_hauteur));
		noeud_root.setXPlusEnfants((int)(-(-noeud_root.getX()+x_noeud_root/ancien_facteur_largeur)));
		noeud_root.setYPlusEnfants((int)(-(-noeud_root.getY()+y_noeud_root/ancien_facteur_hauteur)));
		scrollRectToVisible(selection_component.getReelBounds());
	}

	@Override
	public void mouseClicked(MouseEvent event) {
		if(event.getClickCount() == 1 && event.getButton() == 3) {
			menu.show(this, event.getX(), event.getY());
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getButton() == 1 && !placement_selection) {
			premier_pressed_x = e.getX();
			premier_pressed_y = e.getY();
			if(selection_component != null) {
				remove(selection_component);
				repaint();
			}
			selection_component = new SelectionComponent(this);
			add(selection_component);
			moveToFront(selection_component);
			selection_component.setLocation(e.getX(), e.getY());
			placement_selection = true;
		}
		else if(e.getButton() == 2 && !placement_zoom) {
			premier_pressed_x = e.getX();
			premier_pressed_y = e.getY();
			if(zoom_component != null) {
				zoom_component.toutRemettreALaNormale();
				remove(zoom_component);
				validate();
			}
			zoom_component = new ZoomComponent(this);
			add(zoom_component);
			moveToFront(zoom_component);
			zoom_component.setLocation(e.getX(), e.getY());
			placement_zoom = true;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if(e.getButton() == 1 && placement_selection) {
			placement_selection = false;
			setComponentZOrder(selection_component, 0);
			Vector<NoeudGraphique> v = getTousEnfantsContenus(selection_component.getBounds());
			for(int i=0; i<v.size(); i++) {
				setComponentZOrder(v.get(i), 0);
			}
		}
		else if(e.getButton() == 2 && placement_zoom) {
			placement_zoom = false;
//			zoom_component.calculerFisheye(getTousEnfants(zoom_component.getBounds()));
			zoom_component.zoomSimple(getTousEnfants(zoom_component.getBounds()));
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if(placement_selection) {
			int largeur = e.getX() - premier_pressed_x;
			int hauteur = e.getY() - premier_pressed_y;
			if(largeur < 0) {
				largeur = premier_pressed_x - e.getX();
				selection_component.setLocation(e.getX(), selection_component.getY());
			}
			if(hauteur < 0) {
				hauteur = premier_pressed_y - e.getY();
				selection_component.setLocation(selection_component.getX(), e.getY());
			}
			selection_component.setSize(largeur, hauteur);
		}
		if(placement_zoom) {
			int largeur = e.getX() - premier_pressed_x;
			int hauteur = e.getY() - premier_pressed_y;
			if(largeur < 0) {
				largeur = premier_pressed_x - e.getX();
				zoom_component.setLocation(e.getX(), zoom_component.getY());
			}
			if(hauteur < 0) {
				hauteur = premier_pressed_y - e.getY();
				zoom_component.setLocation(zoom_component.getX(), e.getY());
			}
			zoom_component.setSize(largeur, hauteur);
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		
	}
	
	public Vector<NoeudGraphique> getTousEnfants(Rectangle position) {
		Vector<NoeudGraphique> res = new Vector<NoeudGraphique>();
		for(int i=0; i<getComponentCount(); i++) {
			NoeudGraphique n = null;
			Boolean cast_a_marche = true;
			try {
				n = (NoeudGraphique)getComponent(i);
			}
			catch(ClassCastException e) {
				cast_a_marche = false;
			}
			if(cast_a_marche) {
				if(position.intersects(getComponent(i).getBounds())) {
					res.add(n);
				}
			}
		}
		return res;
	}
	
	public Vector<NoeudGraphique> getTousEnfantsContenus(Rectangle position) {
		Vector<NoeudGraphique> res = new Vector<NoeudGraphique>();
		for(int i=0; i<getComponentCount(); i++) {
			NoeudGraphique n = null;
			Boolean cast_a_marche = true;
			try {
				n = (NoeudGraphique)getComponent(i);
			}
			catch(ClassCastException e) {
				cast_a_marche = false;
			}
			if(cast_a_marche) {
				if(position.contains(getComponent(i).getBounds())) {
					res.add(n);
				}
			}
		}
		return res;
	}
	
	@Override
	public void changementSelection(boolean selectionne) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementVisibilite(boolean visible) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deplacement(int x, int y) {
		if(x<plus_petit_x) {
			plus_petit_x = x;
		}
		if(x>plus_grand_x) {
			plus_grand_x = x;
		}
		if(y<plus_petit_y) {
			plus_petit_y = y;
		}
		if(y>plus_grand_y) {
			plus_grand_y = y;
		}
		taille_onglet = new Dimension((plus_grand_x-plus_petit_x)+(noeud_root.getLargeur()*2),(plus_grand_y-plus_petit_y)+(noeud_root.getHauteur()*2));
		if(taille_onglet.getWidth() != getWidth() || taille_onglet.getHeight() != getHeight()) {
			this.setMinimumSize(taille_onglet);
			this.setSize(taille_onglet);
			this.setPreferredSize(taille_onglet);
			validate();
		}
	}

	@Override
	public void redimensionnement(int largeur, int hauteur) {
		// TODO Auto-generated method stub
	}

	@Override
	public void changementCouleurBordure(Color couleurBordure) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementCouleurFond(Color couleurFond) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementCouleurTexte(Color couleurTexte) {
		// TODO Auto-generated method stub
		
	}
}
