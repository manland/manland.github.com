package Graphique;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel ;
import javax.swing.JSeparator;

import Controleur.ControleurPanelSelection;

public class PanelSelection extends JPanel 
{
	private Box VBox_generale;
	
	// bouton selections :
	private JPanel panel_ensemble_check_box;
	private JLabel type_de_selection;
	private JCheckBox btn_intersection;
	private JComboBox points_communs;
	private JCheckBox btn_arbre1_moins_arbre2;
	private JCheckBox btn_arbre2_moins_arbre1;
	private JCheckBox btn_arbre1;
	private JCheckBox btn_arbre2;
	
	// couleur associée a la selection :
	private JLabel label_couleur;
	private PanelCouleur panel_couleur;
	private JColorChooser color_chooser;
	
	private ControleurPanelSelection controleur;
	
	private JButton btn_valider;

	private TabOngletRecherche tab_onglet_recherche;
	
	// constructeur : 
	public PanelSelection(TabOngletRecherche tab_onglet_recherche) 
	{
		super();
		this.setName("Selection");
		controleur = new ControleurPanelSelection(this);
		this.tab_onglet_recherche = tab_onglet_recherche;
		initialistation();
	}




	public void initialistation()
	{
		VBox_generale = Box.createVerticalBox();
		
		// box qui contient les check box
		panel_ensemble_check_box = new JPanel(new GridLayout(9,1));
		
		// boutons 
		type_de_selection = new JLabel("Type de selection");
		JLabel point_communs =  new JLabel("Points communs :");
		btn_intersection = new JCheckBox("Intersection");
		btn_arbre1_moins_arbre2 = new JCheckBox("Objets de A1 non dans A2");
		btn_arbre2_moins_arbre1= new JCheckBox("Objets de A2 non dans A1");
		btn_arbre1 = new JCheckBox("Arbre 1");
		btn_arbre2 = new JCheckBox("Arbre2");
		
		btn_arbre1.setSelected(true);
		btn_arbre2.setSelected(false);
		btn_arbre2_moins_arbre1.setSelected(false);
		btn_arbre1_moins_arbre2.setSelected(false);
		btn_intersection.setSelected(false);
		
		btn_intersection.setEnabled(false);
		btn_arbre1_moins_arbre2.setEnabled(false);
		btn_arbre2_moins_arbre1.setEnabled(false);
		
		btn_arbre1.addActionListener(controleur);
		btn_arbre2.addActionListener(controleur);
		btn_intersection.addActionListener(controleur);
		btn_arbre1_moins_arbre2.addActionListener(controleur);
		btn_arbre2_moins_arbre1.addActionListener(controleur);
	
		
		Box hBox_intersection = Box.createHorizontalBox();
		Vector<String> liste_points_communs = new Vector<String>();
		liste_points_communs.add("Nom");
		liste_points_communs.add("Poids");
		liste_points_communs.add("Date");
		points_communs = new JComboBox(liste_points_communs);
		points_communs.setSelectedItem(liste_points_communs.get(0));
		Dimension taille_pts_commun = new Dimension(70,25);
		points_communs.setPreferredSize(taille_pts_commun);
		points_communs.setMaximumSize(taille_pts_commun);
		points_communs.setMinimumSize(taille_pts_commun);
		points_communs.setSize(taille_pts_commun);
		points_communs.setEnabled(false);
		
		hBox_intersection.add(point_communs);
		hBox_intersection.add(points_communs);
		
		Box hBox = Box.createVerticalBox();
	
		btn_arbre2.setEnabled(false);
		
		// couleur chooser : 
		color_chooser = new JColorChooser(Color.magenta);
		panel_couleur = new PanelCouleur(color_chooser);
		panel_couleur.addMouseListener(controleur);
		hBox_intersection.add(panel_couleur);
	
		panel_ensemble_check_box.add(type_de_selection,"Center");
		panel_ensemble_check_box.add(btn_arbre1);
		panel_ensemble_check_box.add(btn_arbre2);
		panel_ensemble_check_box.add(new JSeparator());
		panel_ensemble_check_box.add(hBox_intersection);
		panel_ensemble_check_box.add(btn_intersection);
		panel_ensemble_check_box.add(btn_arbre1_moins_arbre2);
		panel_ensemble_check_box.add(btn_arbre2_moins_arbre1);
		
		btn_valider = new JButton("Valider");
		btn_valider.setEnabled(false);
		btn_valider.addActionListener(controleur);
		
		panel_ensemble_check_box.add(btn_valider);
		
		VBox_generale.add(panel_ensemble_check_box);
		VBox_generale.add(hBox);
		this.add(VBox_generale);
	}
	
	
	// ACCESSEURS :
	public JCheckBox getBtn_intersection() { return btn_intersection; }
	public void setBtn_intersection(JCheckBox btnInter) { btn_intersection = btnInter; }

	public JCheckBox getBtnArbre1MoinsArbre2() { return btn_arbre1_moins_arbre2; } 
	public void setBtn_moins1(JCheckBox btnMoins1) { btn_arbre1_moins_arbre2 = btnMoins1; }

	public JCheckBox getBtnArbre2MoinsArbre1() { return btn_arbre2_moins_arbre1; }
	public void setBtn_moins2(JCheckBox btnMoins2) { btn_arbre2_moins_arbre1 = btnMoins2; }
	
	public JCheckBox getBtn_arbre1() { return btn_arbre1; } 
	public void setBtn_arbre1(JCheckBox btnArbre1) { btn_arbre1 = btnArbre1; }

	public JCheckBox getBtn_arbre2() { return btn_arbre2; } 
	public void setBtn_arbre2(JCheckBox btnArbre2) { btn_arbre2 = btnArbre2; }
	
	public JComboBox getPoints_communs() { return points_communs; }
	public void setPoints_communs(JComboBox pointsCommuns) { points_communs = pointsCommuns; }

	public ControleurPanelSelection getControleur() {  return controleur; } 
	public void setControleur(ControleurPanelSelection controleur) {  this.controleur = controleur; }

	public TabOngletRecherche getTab_onglet_recherche() { return tab_onglet_recherche; }
	public void setTab_onglet_recherche(TabOngletRecherche tabOngletRecherche) { tab_onglet_recherche = tabOngletRecherche; }

	public PanelCouleur getPanel_couleur() { return panel_couleur; }
	public void setPanel_couleur(PanelCouleur panelCouleur) { panel_couleur = panelCouleur;	}

	public JButton getBtn_valider() {	return btn_valider;}
	public void setBtn_valider(JButton btnValider) {btn_valider = btnValider;} 
	
	
	
	
}
