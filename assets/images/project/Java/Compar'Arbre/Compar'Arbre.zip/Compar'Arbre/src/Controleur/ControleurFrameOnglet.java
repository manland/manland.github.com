package Controleur;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import Graphique.InternalFrameOnglet;
import Graphique.ZoneDesktop;

public class ControleurFrameOnglet implements FocusListener 
{
	private InternalFrameOnglet internal_frame_onglet;

	public ControleurFrameOnglet(InternalFrameOnglet internal_frame_onglet) 
	{
		super();
		this.internal_frame_onglet = internal_frame_onglet;
	}

	@Override
	public void focusGained(FocusEvent e) 
	{
		if(((ZoneDesktop)(internal_frame_onglet.getDesktopPane())).getInternal_frame_recherche().isVisible())
		{
			((ZoneDesktop)(internal_frame_onglet.getDesktopPane())).getInternal_frame_recherche().toFront();
		}
	}

	@Override
	public void focusLost(FocusEvent e) {
	}

}
