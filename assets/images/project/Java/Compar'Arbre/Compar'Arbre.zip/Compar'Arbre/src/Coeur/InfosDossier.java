package Coeur;

import java.io.File;

public class InfosDossier extends AbstractInfos {

	public InfosDossier(File file) {
		super(file);
	}
	
	public long getTaille() {
		File [] subFile = fichier.listFiles();
		long res = 0;
		if(subFile != null) {
			for(int i=0; i<subFile.length; i++) {
				if(subFile[i].isFile()) {
					res += subFile[i].length();
				}
			}
		}
		return res;
	}

}
