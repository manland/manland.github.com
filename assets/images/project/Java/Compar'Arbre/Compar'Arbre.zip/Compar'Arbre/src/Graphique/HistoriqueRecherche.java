package Graphique;

import java.awt.Color;
import java.util.Vector;

public class HistoriqueRecherche 
{
	// pour le type de selection :
	private boolean arbre1 = false;
	private boolean arbre2 = false;
	private boolean intersection_par_nom = false;
	private boolean intersection_par_poids= false;
	private boolean intersection_par_date= false;
	private boolean objet_a1_non_a2= false;
	private boolean objet_a2_non_a1= false;
	private Color intersection_couleur;
	
	// pour le type de recherche :
	private boolean recherche_par_nom_exact= false;
	private boolean recherche_par_nom_contient= false;
	private String nom;
	private boolean recherche_par_extension= false;
	private String extension;
	private boolean recherche_par_date_modif_exacte= false;
	private boolean recherche_par_date_modif_avant= false;
	private boolean recherche_par_date_modif_apres= false;
	private boolean recherche_par_date_modif_entre= false;
	private String date_debut;
	private String date_fin;
	private boolean recherche_par_poids_exact= false;
	private boolean recherche_par_poids_inferieur= false;
	private boolean recherche_par_poids_superieur= false;
	private boolean recherche_par_poids_entre= false;
	private String poids_debut;
	private String poids_fin;
	private Color recherche_couleur;
	
	private int nb_case_cochee;
	
	public HistoriqueRecherche() {
		super();
		nb_case_cochee = 0;
	}


	public Vector<String> remplirDonneeTableau()
	{
		Vector<String> resultat = new Vector<String>();
		
		resultat.add(afficherCouleur());
		resultat.add(afficherSelection());
		resultat.add(afficherRecherche());
		
		return resultat;
	}
	
	
	public String afficherSelection()
	{
		String str = "<html>";
		if(isArbre1())
		{
			str += "Arbre1 <br>";
		}
		if(isArbre2())
		{
			str += "Arbre2 <br>";
		}
		if(isIntersection_par_date())
		{
			str += "Intersection par date <br>";
		}
		if(isIntersection_par_nom())
		{
			str += "Intersection par nom <br>";
		}
		if(isIntersection_par_poids())
		{
			str += "Intersection par poids <br>";
		}
		if(isObjet_a1_non_a2())
		{
			str += "Objet de a1 non dans a2 <br>";
		}
		if(isObjet_a2_non_a1())
		{
			str += "Objet de a2 non dans a1 <br>";
		}
		str+="</html>";
		return str;
	}
	
	
	public String afficherRecherche()
	{
		String str= "<html>";
		if(isRecherche_par_date_modif_apres())
		{
			str += "modification après le : "+getDate_debut()+"<br>";
		}
		if(isRecherche_par_date_modif_avant())
		{
			str += "modification avant le : "+getDate_debut()+"<br>";
		}
		if(isRecherche_par_date_modif_exacte())
		{
			str += "modification le : "+getDate_debut()+"<br>";
		}
		if(isRecherche_par_date_modif_entre())
		{
			str += "modification entre : "+getDate_debut()+" et "+getDate_fin()+"<br>";
		}
		if(isRecherche_par_extension())
		{
			str += "extension : "+getExtension()+"<br>";
		}
		if(isRecherche_par_nom_contient())
		{
			str += "le nom contient : "+getNom()+"<br>";
		}
		if(isRecherche_par_nom_exact())
		{
			str += "nom : "+getNom()+"<br>";
		}
		if(isRecherche_par_poids_entre())
		{
			str += "poids compris entre : "+getPoids_debut()+" et "+getPoids_fin()+"<br>";
		}
		if(isRecherche_par_poids_exact())
		{
			str += "poids : "+getPoids_debut()+"<br>";
		}
		if(isRecherche_par_poids_inferieur())
		{
			str += "poids inférieur à : "+getPoids_debut()+"<br>";
		}
		if(isRecherche_par_poids_superieur())
		{
			str += "poids supérieur à : "+getPoids_debut()+"<br>";
		}
		str+="</html>";
		return str;
	}
	
	public String afficherCouleur()
	{		
		String couleur = Integer.toHexString(getRecherche_couleur().getRGB());
		couleur = couleur.substring(2);		
		String str = "";
		str+="<html><p bgcolor=\"#"+couleur+"\"> <font color=\"#"+couleur+"\">";
		str+="couleur ";
		str+="</font></p></center> </html>";
		return str;
		
	}
	
	// ----------------------------------------------------------------------------
	//									Accesseurs :
	// ----------------------------------------------------------------------------
	public boolean isArbre1() { return arbre1; } 
	public void setArbre1(boolean arbre1) { this.arbre1 = arbre1; } 

	public boolean isArbre2() { return arbre2; }
	public void setArbre2(boolean arbre2) { this.arbre2 = arbre2; } 

	public boolean isIntersection_par_nom() { return intersection_par_nom; }
	public void setIntersection_par_nom(boolean intersectionParNom) {intersection_par_nom = intersectionParNom; }

	public boolean isIntersection_par_poids() { return intersection_par_poids; } 
	public void setIntersection_par_poids(boolean intersectionParPoids) { intersection_par_poids = intersectionParPoids; }

	public boolean isIntersection_par_date() { return intersection_par_date; } 
	public void setIntersection_par_date(boolean intersectionParDate) { intersection_par_date = intersectionParDate; } 

	public boolean isObjet_a1_non_a2() { return objet_a1_non_a2; } 
	public void setObjet_a1_non_a2(boolean objetA1NonA2) { 	objet_a1_non_a2 = objetA1NonA2; } 
	
	
	
	public boolean isObjet_a2_non_a1() {
		return objet_a2_non_a1;
	}


	public void setObjet_a2_non_a1(boolean objetA2NonA1) {
		System.out.println("dans le set ");
		objet_a2_non_a1 = objetA2NonA1;
	}


	public boolean isRecherche_par_nom_exact() { return recherche_par_nom_exact; } 
	public void setRecherche_par_nom_exact(boolean rechercheParNomExact) { recherche_par_nom_exact = rechercheParNomExact; }

	public boolean isRecherche_par_nom_contient() { return recherche_par_nom_contient; }
	public void setRecherche_par_nom_contient(boolean rechercheParNomContient) { recherche_par_nom_contient = rechercheParNomContient; 	}

	public String getNom() { return nom; }
	public void setNom(String nom) { this.nom = nom; }

 	public boolean isRecherche_par_extension() { return recherche_par_extension; } 
	public void setRecherche_par_extension(boolean rechercheParExtension) { recherche_par_extension = rechercheParExtension; } 

	public String getExtension() { 	return extension; } 
	public void setExtension(String extension) { this.extension = extension; } 

	public boolean isRecherche_par_date_modif_exacte() { return recherche_par_date_modif_exacte; }
	public void setRecherche_par_date_modif_exacte(boolean rechercheParDateModifExacte) {recherche_par_date_modif_exacte = rechercheParDateModifExacte;	}

	public boolean isRecherche_par_date_modif_avant() { return recherche_par_date_modif_avant; } 
	public void setRecherche_par_date_modif_avant(boolean rechercheParDateModifAvant) { recherche_par_date_modif_avant = rechercheParDateModifAvant; }

	public boolean isRecherche_par_date_modif_apres() { return recherche_par_date_modif_apres; }
	public void setRecherche_par_date_modif_apres(boolean rechercheParDateModifApres) { recherche_par_date_modif_apres = rechercheParDateModifApres; }

	public boolean isRecherche_par_date_modif_entre() { return recherche_par_date_modif_entre; }
	public void setRecherche_par_date_modif_entre(boolean rechercheParDateModifEntre) { recherche_par_date_modif_entre = rechercheParDateModifEntre; }

	public String getDate_debut() { return date_debut; }
	public void setDate_debut(String dateDebut) { date_debut = dateDebut; }

	public String getDate_fin() { return date_fin; } 
	public void setDate_fin(String dateFin) { date_fin = dateFin; }

	public String getPoids_debut() { return poids_debut; } 
	public void setPoids_debut(String poidsDebut) { poids_debut = poidsDebut; } 

	public String getPoids_fin() { return poids_fin; }
	public void setPoids_fin(String poidsFin) { poids_fin = poidsFin; }

	public boolean isRecherche_par_poids_exact() { return recherche_par_poids_exact; } 
	public void setRecherche_par_poids_exact(boolean rechercheParPoidsExact) { recherche_par_poids_exact = rechercheParPoidsExact; } 

	public boolean isRecherche_par_poids_inferieur() { return recherche_par_poids_inferieur; } 
	public void setRecherche_par_poids_inferieur(boolean rechercheParPoidsInferieur) { 	recherche_par_poids_inferieur = rechercheParPoidsInferieur;} 

	public boolean isRecherche_par_poids_superieur() { return recherche_par_poids_superieur; } 
	public void setRecherche_par_poids_superieur(boolean rechercheParPoidsSuperieur) { recherche_par_poids_superieur = rechercheParPoidsSuperieur; }

	public boolean isRecherche_par_poids_entre() { return recherche_par_poids_entre; } 
	public void setRecherche_par_poids_entre(boolean rechercheParPoidsEntre) { recherche_par_poids_entre = rechercheParPoidsEntre; }

	public Color getIntersection_couleur() { return intersection_couleur; } 
	public void setIntersection_couleur(Color intersectionCouleur) { intersection_couleur = intersectionCouleur; }
	
	public Color getRecherche_couleur() { return recherche_couleur; } 
	public void setRecherche_couleur(Color rechercheCouleur) { recherche_couleur = rechercheCouleur; }


	public int getNb_case_cochee() { return nb_case_cochee; } 
	public void setNb_case_cochee(int nbCaseCochee) {  nb_case_cochee = nbCaseCochee; }
	
	
}
