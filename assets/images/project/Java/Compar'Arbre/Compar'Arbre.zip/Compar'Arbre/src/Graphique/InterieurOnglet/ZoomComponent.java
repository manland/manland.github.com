package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.jws.Oneway;
import javax.swing.JComponent;

import Coeur.InfosFichier;

public class ZoomComponent extends JComponent implements MouseListener, MouseMotionListener {
	private PanelOnglet panel_onglet;
	private int decalage_x = 0;
	private int decalage_y = 0;
	private Vector<NoeudGraphique> ancien_enfants = null;
	private NoeudGraphique noeud_zoom = null;
	private Point ancienne_position_noeud_zoom = null;
	private Dimension ancienne_taille_noeud_zoom = null;
	
	public ZoomComponent(PanelOnglet panel_onglet) {
		this.panel_onglet = panel_onglet;
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	public void calculerFisheye(Vector<NoeudGraphique> enfants) {
		System.out.println(enfants.size());
		Point O = new Point(getX() + (getWidth()/2), getY() + (getHeight()/2));
		for(int i=0; i<enfants.size(); i++) {
			Point M = new Point(enfants.get(i).getX(), enfants.get(i).getY());
			Point S = calculerS(O.x, M.x, O.y, M.y);
			Point newM = null;
			double OM = distanceEntre(O.x, M.x, O.y, M.y);
			double OS = distanceEntre(O.x, S.x, O.y, S.y);
			double k = OM / OS;
			int d = 5;
			double OMp = OS * ((1+d)/(d+(1/k)));
			
			
			//2 = M; 1=S; 3=O
			int a = (M.x - S.x)*2 + (M.y - S.y)*2;
			int b = 2 * (((M.x - S.x)*(S.x - O.x)) + ((M.y - S.y)*(S.y - O.y)));
			double c = Math.pow(O.x, 2) + Math.pow(O.y, 2) + Math.pow(S.x, 2) + Math.pow(S.y, 2) - 2*((O.x * S.x)+(O.y * S.y)) - Math.pow(OMp, 2);
			
			double delta = Math.pow(b, 2)-(4*a*c);
			
			if(delta>0) {
				newM = new Point();
			}
		}
	}
	
	public void zoomSimple(Vector<NoeudGraphique> enfants) {
//		if(ancien_enfants != null) {
//			toutRemettreALaNormale();
//		}
//		if(enfants.size()>0) {
//			int moitie = enfants.size()/2;
//			for(int i=0; i<moitie; i++) {
//				enfants.get(i).getModele().setVisible(false);
//			}
//			NoeudGraphique n = enfants.get(enfants.size()/2);
//			if(!n.equals(noeud_zoom)) {
//				ancienne_position_noeud_zoom = new Point(n.getLocation());
//				ancienne_taille_noeud_zoom = new Dimension(n.getSize());
//				noeud_zoom = n;
//			}
//			n.getModele().setLargeur((int)ancienne_taille_noeud_zoom.getWidth()*2);
//			n.getModele().setHauteur((int)ancienne_taille_noeud_zoom.getHeight()*2);
//			n.getModele().setX(getX()+(getWidth()/2)-(n.getWidth()/2));
//			n.getModele().setY(getY()+(getHeight()/2)-(n.getHeight()/2));
//			for(int i=moitie+1; i<enfants.size(); i++) {
//				enfants.get(i).getModele().setVisible(false);
//			}
//			ancien_enfants = enfants;
			
		if(ancien_enfants != null) {
			toutRemettreALaNormale();
		}
		if(enfants.size()>0) {
			double distance = distanceEntre(enfants.get(0).getModele().getX(), (int)getBounds().getCenterX(), enfants.get(0).getModele().getY(), (int)getBounds().getCenterY());
			if(!enfants.get(0).equals(noeud_zoom)) {
				if(noeud_zoom != null) {
					remettreALaNormaleNoeudZoom();
				}
				noeud_zoom = enfants.get(0);
				ancienne_position_noeud_zoom = new Point(noeud_zoom.getLocation());
				ancienne_taille_noeud_zoom = new Dimension(noeud_zoom.getSize());
			}
				noeud_zoom.getModele().setLargeur((int)ancienne_taille_noeud_zoom.getWidth()*2);
				noeud_zoom.getModele().setHauteur((int)ancienne_taille_noeud_zoom.getHeight()*2);
				noeud_zoom.getModele().setX(getX()+(getWidth()/2)-(noeud_zoom.getModele().getLargeur()/2));
				noeud_zoom.getModele().setY(getY()+(getHeight()/2)-(noeud_zoom.getModele().getHauteur()/2));
			
			for(int i=1; i<enfants.size(); i++) {
				double distance2 = distanceEntre(enfants.get(i).getModele().getX(), (int)getBounds().getCenterX(), enfants.get(i).getModele().getY(), (int)getBounds().getCenterY());
				if(distance2 < distance) {
					distance = distance2;
					remettreALaNormaleNoeudZoom();
					noeud_zoom.getModele().setVisible(false);
					noeud_zoom = enfants.get(i);
					ancienne_position_noeud_zoom = new Point(noeud_zoom.getModele().getX(), noeud_zoom.getModele().getY());
					ancienne_taille_noeud_zoom = new Dimension(noeud_zoom.getSize());
					noeud_zoom.getModele().setLargeur((int)ancienne_taille_noeud_zoom.getWidth()*2);
					noeud_zoom.getModele().setHauteur((int)ancienne_taille_noeud_zoom.getHeight()*2);
					noeud_zoom.getModele().setX(getX()+(getWidth()/2)-(noeud_zoom.getWidth()/2));
					noeud_zoom.getModele().setY(getY()+(getHeight()/2)-(noeud_zoom.getHeight()/2));
				}
				else {
					enfants.get(i).getModele().setVisible(false);
				}
			}
			ancien_enfants = enfants;
		}
		else {
			if(noeud_zoom != null) {
				remettreALaNormaleNoeudZoom();
				noeud_zoom = null;
			}
		}
	}
	
	public static double distanceEntre(int x1, int x2, int y1, int y2) {
		return Math.sqrt(Math.pow((x2-x1), 2)+Math.pow((y2-y1), 2));
	}
	
	private Point calculerS(int x1, int x2, int y1, int y2) {
		Point res = new Point();
		int dh = x1 - x2;
		int dv = y1 - y2;
		int a;
		int b;
		if(dh != 0) {//y = ax + b
			a = dv / dh;
			b = y1 - (a * x1);
			res.setLocation(getX(), (a * getX())+b);
		}
		else {//x = ay + b ====> y = (x-b)/a
			a = dh / dv;
			b = x1 - (a * y1);
			res.setLocation(getX(), (getX()-b)/a);
		}
		return res;
	}
	
	public void toutRemettreALaNormale() {
		if(ancien_enfants != null) {
			for(int i=0; i<ancien_enfants.size(); i++) {
				ancien_enfants.get(i).getModele().setVisible(true);
			}
		}
	}
	
	public void remettreALaNormaleNoeudZoom() {
		noeud_zoom.getModele().setX(ancienne_position_noeud_zoom.x);
		noeud_zoom.getModele().setY(ancienne_position_noeud_zoom.y);
		noeud_zoom.getModele().setLargeur((int)ancienne_taille_noeud_zoom.getWidth());
		noeud_zoom.getModele().setHauteur((int)ancienne_taille_noeud_zoom.getHeight());
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Color bordure = new Color(0, 0, 0);
		Color fond = new Color(255, 255, 255);
		
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setPaint(bordure);
		g2d.drawOval(0, 0, getWidth()-1, getHeight()-1);
	}
	
	@Override
	public void mouseClicked(MouseEvent event) {
		if(event.getClickCount()>=2 && event.getButton() == 2) {
			if(ancien_enfants != null) {
				for(int i=0; i<ancien_enfants.size(); i++) {
					ancien_enfants.get(i).getModele().setVisible(true);
					if(ancien_enfants.get(i) == noeud_zoom) {
						noeud_zoom.getModele().setX(ancienne_position_noeud_zoom.x);
						noeud_zoom.getModele().setY(ancienne_position_noeud_zoom.y);
						noeud_zoom.getModele().setLargeur((int)ancienne_taille_noeud_zoom.getWidth());
						noeud_zoom.getModele().setHauteur((int)ancienne_taille_noeud_zoom.getHeight());
					}
				}
			}
			getParent().remove(this);
		}
		else {
			if(noeud_zoom != null) {
				noeud_zoom.mouseClicked(event);
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent event) {
		decalage_x = event.getX();
		decalage_y = event.getY();
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
		int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
		setLocation(getX() - deplacement_x - decalage_x, getY() - deplacement_y - decalage_y);
		zoomSimple(panel_onglet.getTousEnfants(getBounds()));
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		panel_onglet.mouseMoved(e);
	}

}
