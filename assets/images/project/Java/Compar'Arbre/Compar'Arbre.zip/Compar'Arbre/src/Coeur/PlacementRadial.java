package Coeur;

public class PlacementRadial extends PlacementAbstrait {
	
	private int nombre_de_noeud;
	private int ecart_entre_2_rayon;
	
	public PlacementRadial(Noeud noeud_pere, int largeur_max, int hauteur_max) {
		super(noeud_pere, largeur_max, hauteur_max);
		attributionRangOrdreInfixe(noeud);
		int p = Noeud.getProfondeurMax(noeud);
		nombre_de_noeud = noeud.getNbEnfantRecursif();
		int l = noeud.getLargeur();
		ecart_entre_2_rayon = (Math.min(largeur_max, hauteur_max)-l)/p;
		placement(noeud);
		placementCentreInitiale(noeud);
	}
	
	public void placement(AbstractNoeud noeud) {
		int ro = noeud.getProfondeur()*ecart_entre_2_rayon;
		double teta = noeud.getRang() * ((2*Math.PI)/nombre_de_noeud);
		noeud.setX((int) (ro*Math.cos(teta)));
		noeud.setY((int) (ro*Math.sin(teta)));
		
		if(noeud.isNoeud()) {
			Noeud n = (Noeud) noeud;
			for(int i=0; i<n.getNbEnfant(); i++) {
				placement(n.getEnfant(i));
			}
		}
	}
}
