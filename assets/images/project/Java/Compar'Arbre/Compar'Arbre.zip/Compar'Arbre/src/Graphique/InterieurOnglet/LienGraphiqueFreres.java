package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JComponent;

import Coeur.AbstractNoeud;
import Coeur.IEcouteurModele;

public class LienGraphiqueFreres extends JComponent implements IEcouteurModele {
	private AbstractNoeud noeud_frere;
	private AbstractNoeud noeud_frere2;
	
	public LienGraphiqueFreres(AbstractNoeud noeud_frere, AbstractNoeud noeud_frere2) {
		this.noeud_frere = noeud_frere;
		this.noeud_frere.ajouterEcouteurModele(this);
		this.noeud_frere2 = noeud_frere2;
		this.noeud_frere2.ajouterEcouteurModele(this);
		
		calibre();
	}
	
	protected void paintComponent(Graphics g) {
		calibre();
		
		Color bordure = new Color(0, 0, 0);
		if(!noeud_frere2.getSelectionne()) {
			bordure = Color.lightGray;
		}
		Graphics2D g2d = (Graphics2D)g;
		g2d.setPaint(bordure);
		if((noeud_frere.getXMilieu()<noeud_frere2.getXMilieu() && noeud_frere.getYBas()<noeud_frere2.getY()) ||
				(noeud_frere.getXMilieu()>noeud_frere2.getXMilieu() && noeud_frere.getYBas()>noeud_frere2.getY())) {
			//le lien va de gauche a droite
			g.drawLine(0, 0, getWidth(), getHeight());
		}
		else {
			//le lien va de droite à gauche
			g.drawLine(0, getHeight(), getWidth(), 0);
		}
		
	}
	
	private void calibre() {
		Dimension dimension = new Dimension(
				Math.max(noeud_frere.getX()+noeud_frere.getLargeur(), noeud_frere2.getX())-
					Math.min(noeud_frere.getX()+noeud_frere.getLargeur(), noeud_frere2.getX()), 
				Math.max(noeud_frere.getY(), noeud_frere2.getY())-
					Math.min(noeud_frere.getY(), noeud_frere2.getY()));
			
			if(dimension.getWidth() <= 0) {
				dimension.setSize(1, dimension.getHeight());
			}
			if(dimension.getHeight() <= 0) {
				dimension.setSize(dimension.getWidth(), 1);
			}
		
		setLocation(Math.min(noeud_frere.getX(), noeud_frere2.getX()), 
				Math.min(noeud_frere.getY(), noeud_frere2.getY()));
		
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
	}

	@Override
	public void changementSelection(boolean selectionne) {
		repaint();
	}

	@Override
	public void deplacement(int x, int y) {
		calibre();
		repaint();
	}

	@Override
	public void redimensionnement(int largeur, int hauteur) {
		repaint();
	}

	@Override
	public void changementVisibilite(boolean visible) {
		setVisible(visible);
	}

	@Override
	public void changementCouleurBordure(Color couleurBordure) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementCouleurFond(Color couleurFond) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementCouleurTexte(Color couleurTexte) {
		// TODO Auto-generated method stub
		
	}
}
