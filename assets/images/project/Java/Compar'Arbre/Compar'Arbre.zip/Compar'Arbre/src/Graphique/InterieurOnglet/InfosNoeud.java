package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.ImageIcon;
import javax.swing.JComponent;

import Coeur.AbstractInfos;
import Coeur.AbstractNoeud;
import Coeur.InfosFichier;

public class InfosNoeud extends JComponent implements MouseListener, MouseMotionListener {
	private PanelOnglet panel_onglet = null;
	private AbstractInfos infos;
	private Rectangle rectangle_quitter;
	private Rectangle rectangle_epingler;
	private int decalage_x = 0;
	private int decalage_y = 0;
	private int decalage_x_on_screen = 0;
	private int decalage_y_on_screen = 0;
	private boolean epingle = false;
	
	public InfosNoeud(PanelOnglet parent) {
		this.panel_onglet = parent;
		Dimension dimension = new Dimension(400, 200);
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
		
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	public void setInfos(AbstractNoeud noeud) {
		this.infos = noeud.getFichier();
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Color bordure = new Color(0, 0, 0);
		Color fond = new Color(255, 255, 255);
		
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setPaint(fond);
		g2d.fillRect(0, 0, getWidth(), getHeight());
		g2d.setPaint(bordure);
		g2d.drawRect(0, 0, getWidth()-1, getHeight()-1);
		
		rectangle_quitter = new Rectangle(getWidth()-15, 0, 15, 15);
		rectangle_epingler = new Rectangle(getWidth()-30, 0, 15, 15);

		g2d.draw(rectangle_quitter);
		g2d.drawLine(rectangle_quitter.x, rectangle_quitter.y, rectangle_quitter.x+rectangle_quitter.width, rectangle_quitter.y+rectangle_quitter.height);
		g2d.drawLine(rectangle_quitter.x+rectangle_quitter.width, rectangle_quitter.y, rectangle_quitter.x, rectangle_quitter.y+rectangle_quitter.height);
		g2d.draw(rectangle_quitter);
		g2d.drawLine(rectangle_quitter.x, rectangle_quitter.y, rectangle_quitter.x+rectangle_quitter.width, rectangle_quitter.y+rectangle_quitter.height);
		if(!epingle) {
			Image image = new ImageIcon("Images/epingle.gif").getImage();
			g2d.drawImage(image, rectangle_epingler.x, rectangle_epingler.y, rectangle_epingler.width, rectangle_epingler.height, this);
		}
		else {
			g2d.fillOval(rectangle_epingler.x+2, rectangle_epingler.y+2, rectangle_epingler.width-5, rectangle_epingler.height-5);
		}
		
		g2d.setPaint(bordure);
		g2d.drawString(infos.getNom(), (getWidth()/2)-(g2d.getFontMetrics().stringWidth(infos.getNom())/2), g2d.getFontMetrics().getHeight());
		if(infos.isDossier()) {
			g2d.drawString("Dossier", 10, g2d.getFontMetrics().getHeight()*2);
		}
		else {
			g2d.drawString("Fichier", 10, g2d.getFontMetrics().getHeight()*2);
		}
		g2d.drawString("URL : "+infos.getUrl(), 10, g2d.getFontMetrics().getHeight()*3);
		g2d.drawString("Taille : "+infos.getTailleToString(), 10, g2d.getFontMetrics().getHeight()*4);
		String date = new SimpleDateFormat().format(infos.getDerniereModification());
		g2d.drawString("Dernière modification : "+date, 10, g2d.getFontMetrics().getHeight()*5);
		if(infos.isFichier()) {
			InfosFichier infos_fichier = (InfosFichier)infos;
			if(!infos_fichier.getExtension().isEmpty()) {
				g2d.drawString("Extension : "+infos_fichier.getExtension(), 10, g2d.getFontMetrics().getHeight()*6);
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent event) {
		if(rectangle_quitter.contains(event.getPoint())) {
			setVisible(false);
		}
		else if(rectangle_epingler.contains(event.getPoint())) {
			epingle = !epingle;
			panel_onglet.setInfoNoeud(null);
			repaint();
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent event) {
		decalage_x = event.getX();
		decalage_y = event.getY();
		decalage_x_on_screen = event.getXOnScreen();
		decalage_y_on_screen = event.getYOnScreen();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		if(getCursor().getType() == Cursor.DEFAULT_CURSOR && !epingle) {
			int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
			int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
			setLocation(getX() - deplacement_x - decalage_x, getY() - deplacement_y - decalage_y);
		}
		else if(!epingle) {
			if(decalage_x_on_screen > evt.getXOnScreen() && getCursor().getType() == Cursor.W_RESIZE_CURSOR) {
				setSize(getWidth() - (decalage_x_on_screen - evt.getXOnScreen()), getHeight());
			}
			else if(decalage_x_on_screen > evt.getXOnScreen()) {//retaille a gauche
				setSize(getWidth() + (decalage_x_on_screen - evt.getXOnScreen()), getHeight());
				setLocation(getX() - (decalage_x_on_screen - evt.getXOnScreen()), getY());
			}
			else if(decalage_x_on_screen < evt.getXOnScreen() && getCursor().getType() == Cursor.W_RESIZE_CURSOR) {
				setSize(getWidth() + (evt.getXOnScreen() - decalage_x_on_screen), getHeight());
			}
			else if(decalage_x_on_screen < evt.getXOnScreen()) {//retaille a gauche
				setSize(getWidth() - (evt.getXOnScreen() - decalage_x_on_screen), getHeight());
				setLocation(getX() + (evt.getXOnScreen() - decalage_x_on_screen), getY());
			}
			decalage_x_on_screen = evt.getXOnScreen();
			if(decalage_y_on_screen > evt.getYOnScreen() && getCursor().getType() == Cursor.N_RESIZE_CURSOR) {
				setSize(getWidth(), getHeight() - (decalage_y_on_screen - evt.getYOnScreen()));
			}
			else if(decalage_y_on_screen > evt.getYOnScreen()) {//retaille en haut
				setSize(getWidth(), getHeight() + (decalage_y_on_screen - evt.getYOnScreen()));
				setLocation(getX(), getY() - (decalage_y_on_screen - evt.getYOnScreen()));
			}
			else if(decalage_y_on_screen < evt.getYOnScreen() && getCursor().getType() == Cursor.N_RESIZE_CURSOR) {
				setSize(getWidth(), getHeight() + (evt.getYOnScreen() - decalage_y_on_screen));
			}
			else if(decalage_y_on_screen < evt.getYOnScreen()) {//retaille en haut
				setSize(getWidth(), getHeight() - (evt.getYOnScreen() - decalage_y_on_screen));
				setLocation(getX(), getY() + (evt.getYOnScreen() - decalage_y_on_screen));
			}
			decalage_y_on_screen = evt.getYOnScreen();
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		if(rectangle_quitter.contains(e.getPoint())) {
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
		else if(rectangle_epingler.contains(e.getPoint())) {
			setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
		}
		else if(e.getX() >= 0 && e.getX() <= 5) {
			setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
		}
		else if(e.getX() >= getWidth()-5 && e.getX() <= getWidth()) {
			setCursor(new Cursor(Cursor.W_RESIZE_CURSOR));
		}
		else if(e.getY() >= 0 && e.getY() <= 5) {
			setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
		}
		else if(e.getY() >= getHeight()-5 && e.getY() <= getHeight()) {
			setCursor(new Cursor(Cursor.N_RESIZE_CURSOR));
		}
		else {
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
}
