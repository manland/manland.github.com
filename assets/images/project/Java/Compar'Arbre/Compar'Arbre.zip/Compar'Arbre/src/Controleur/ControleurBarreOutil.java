package Controleur;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.util.Vector;

import javax.swing.JButton;

import Coeur.AbstractNoeud;
import Graphique.BarreOutil;
import Graphique.InternalFrameOnglet;
import Graphique.InternalFrameRecherche;

public class ControleurBarreOutil implements ActionListener, ComponentListener
{

	private BarreOutil barre_outil;
	private int posX_recherche;
	private int posY_recherche;
	private boolean deuxieme_fenetre_deja_affichee;
	
	public ControleurBarreOutil(BarreOutil barre_outil) 
	{
		super();
		this.barre_outil=barre_outil;
		deuxieme_fenetre_deja_affichee = false;
	}

	@Override
	public void actionPerformed(ActionEvent event) 
	{
		JButton btn = null;
		try {
			btn = ((JButton)(event.getSource()));
		}
		catch (Exception e) {
			e.printStackTrace();
			return;
		}
		if (btn==barre_outil.getBtn_plus() && !deuxieme_fenetre_deja_affichee)
		{
			int largeur_frame_init = barre_outil.getZone_desktop().getInternal_frame_onglet().getWidth();
			int hauteur_frame_init = barre_outil.getZone_desktop().getInternal_frame_onglet().getHeight();
			int moitie_taille_frame_init = (int)largeur_frame_init/2;
			
			InternalFrameOnglet nouvelle_frame = new InternalFrameOnglet();
			barre_outil.getZone_desktop().getInternal_frame_onglet().setSize(moitie_taille_frame_init,hauteur_frame_init);
			barre_outil.getZone_desktop().getInternal_frame_onglet().setLocation(0, 0);
			nouvelle_frame.setSize(barre_outil.getZone_desktop().getInternal_frame_onglet().getWidth(),barre_outil.getZone_desktop().getInternal_frame_onglet().getHeight());
			nouvelle_frame.setLocation(barre_outil.getZone_desktop().getInternal_frame_onglet().getWidth()-6,barre_outil.getZone_desktop().getInternal_frame_onglet().getY());
			
			barre_outil.getBarre_adresse_dossier2().setFrame_onglet(nouvelle_frame);
			barre_outil.getZone_desktop().add(nouvelle_frame);
			barre_outil.getBarre_adresse_dossier2().setVisible(true);
			deuxieme_fenetre_deja_affichee=true;
			
			barre_outil.getZone_desktop().ajouterOngletAVecteur(nouvelle_frame);
			if(deuxieme_fenetre_deja_affichee)
			{
				barre_outil.getBtn_plus().setEnabled(false);
			}
		}
		else if(btn==barre_outil.getBtn_recherche())
		{
			barre_outil.getZone_desktop().getInternal_frame_recherche().setLocation(posX_recherche, posY_recherche);
			barre_outil.getZone_desktop().getInternal_frame_recherche().setVisible(true);
			barre_outil.getZone_desktop().getInternal_frame_recherche().toFront();
		}
		else if(btn==barre_outil.getBtn_troisieme_arbre())
		{
			InternalFrameOnglet nouvelle_frame = new InternalFrameOnglet();
			barre_outil.getZone_desktop().add(nouvelle_frame);
			Vector<InternalFrameOnglet> v = barre_outil.getZone_desktop().getVecteur_frame_onglet();
			Vector<AbstractNoeud> noeud = v.get(0).getTab_onglet().getPanelOnglet().getNoeudRoot().tousLesNoeudsSelectionnes();
			Vector<AbstractNoeud> noeud2 = null;
			if(v.size()>1) {
				noeud2 = v.get(1).getTab_onglet().getPanelOnglet().getNoeudRoot().tousLesNoeudsSelectionnes();
			}
			nouvelle_frame.getTab_onglet().getPanelOnglet().construireArbre(noeud, noeud2);
			nouvelle_frame.moveToFront();
		}
	}

	
	// accesseurs :
	public boolean isDeuxieme_fenetre_deja_affichee() { return deuxieme_fenetre_deja_affichee; }
	public void setDeuxieme_fenetre_deja_affichee(boolean deuxiemeFenetreDejaAffichee) {deuxieme_fenetre_deja_affichee = deuxiemeFenetreDejaAffichee; 	}

	@Override
	public void componentHidden(ComponentEvent event) {
		
		InternalFrameRecherche frame_recherche = null;
		try{
			frame_recherche = ((InternalFrameRecherche)(event.getSource()));
		}catch (ClassCastException c)
		{
			c.printStackTrace();
			return;
		}
		posX_recherche = frame_recherche.getX();
		posY_recherche = frame_recherche.getY();
		if(!frame_recherche.isVisible() && (barre_outil.getBarre_adresse_dossier1().getControleur().isAdresse_correcte() || barre_outil.getBarre_adresse_dossier2().getControleur().isAdresse_correcte()))
		{
			barre_outil.getBtn_recherche().setEnabled(true);
		}
	}

	@Override
	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentResized(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void componentShown(ComponentEvent event) {
		InternalFrameRecherche frame_recherche = null;
		try{
			frame_recherche = ((InternalFrameRecherche)(event.getSource()));
		}catch (ClassCastException c)
		{
			c.printStackTrace();
			return;
		}
		if(frame_recherche.isVisible())
		{
			barre_outil.getBtn_recherche().setEnabled(false);
		}
		
	}
	
	
	
	

}
