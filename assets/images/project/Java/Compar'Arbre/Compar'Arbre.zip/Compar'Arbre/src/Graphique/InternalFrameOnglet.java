package Graphique;

import javax.swing.JInternalFrame;

import Controleur.ControleurFrameOnglet;


public class InternalFrameOnglet extends JInternalFrame 
{
	private TabOnglet tab_onglet;
	private ControleurFrameOnglet controleur;
	
	public InternalFrameOnglet() {
		super();
		tab_onglet = new TabOnglet();
		controleur = new ControleurFrameOnglet(this);
		this.add(tab_onglet);
		this.setResizable(true);
		this.setClosable(true);
		this.setIconifiable(true);
		this.setMaximizable(true);
		this.setTitle("Zone de travail :");
		this.setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);
		this.setFocusable(true);
		this.addFocusListener(controleur);
		this.setSize(700, 500);
		this.setVisible(true);
	}

	public TabOnglet getTab_onglet() {
		return tab_onglet;
	}

	public void setTab_onglet(TabOnglet tabOnglet) {
		tab_onglet = tabOnglet;
	}
	
	
	
}
