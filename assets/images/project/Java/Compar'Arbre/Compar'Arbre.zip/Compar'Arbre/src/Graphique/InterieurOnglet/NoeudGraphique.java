package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;

import javax.jws.Oneway;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.Timer;

import Coeur.AbstractNoeud;
import Coeur.IEcouteurModele;
import Coeur.Noeud;

public class NoeudGraphique extends JComponent implements IEcouteurModele, MouseListener, MouseMotionListener
{

	private static final long serialVersionUID = 9180447189095916552L;
	private AbstractNoeud modele;
	private DragSource dragSource;
	private int decalage_x;
	private int decalage_y;
	private PanelOnglet panel_onglet;
	private int type_bouton_souris;
	private Color fond = Color.white;
	private Color texte = Color.lightGray;
	private Color bordure = Color.lightGray;
	private int ancien_z_order = -1; 
	MenuNoeudGraphique menu;
	
	public NoeudGraphique(PanelOnglet panel, AbstractNoeud noeud_modele) {
		this.panel_onglet = panel;
		this.modele = noeud_modele;
		redimensionnement(modele.getLargeur(), modele.getHauteur());
		deplacement(modele.getX(), modele.getY());
		modele.ajouterEcouteurModele(this);
		addMouseListener(this);
		addMouseMotionListener(this);
		menu = new MenuNoeudGraphique(this);
	}
	
	public void setCouleurTexte(Color c) {
		texte = c;
		repaint();
	}
	public void setCouleurFond(Color c) {
		fond = c;
		repaint();
	}
	public void setCouleurBordure(Color c) {
		bordure = c;
		repaint();
	}
	
	public void remettreAuBonZOrder() {
		panel_onglet.setComponentZOrder(this, ancien_z_order);
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D)g;
//		if(modele.getLargeur() < g2d.getFontMetrics().stringWidth(modele.getFichier().getNom())) {
//			modele.setLargeur(g2d.getFontMetrics().stringWidth(modele.getFichier().getNom()));
//		}
		g2d.setPaint(fond);
		g2d.fillRect(0, 0, getWidth()-1, getHeight()-1);
		g2d.setPaint(bordure);
		g2d.drawRect(0, 0, getWidth()-1, getHeight()-1);
		g2d.setPaint(texte);
		g2d.setFont(g2d.getFont().deriveFont((float)getHeight()-10));
		String a_dessiner = modele.getFichier().getNom();
		if(a_dessiner.length()>8) {
			a_dessiner = a_dessiner.substring(0, 8);
			a_dessiner = a_dessiner + "...";
		}
		g2d.drawString(a_dessiner, (getWidth()-(g2d.getFontMetrics().stringWidth(a_dessiner)))/2, (getHeight()/2)+(g2d.getFontMetrics().getHeight()/4));
	}

	public AbstractNoeud getModele() {
		return modele;
	}

	@Override
	public void changementSelection(boolean selectionne) {
		if(!selectionne) {
			texte = Color.lightGray;
			bordure = Color.lightGray;
		}
		else {
			texte = Color.black;
			bordure = Color.black;
			panel_onglet.setComponentZOrder(this, 0);
		}
		repaint();
	}

	@Override
	public void deplacement(int x, int y) {
		setLocation(x, y);
		repaint();
	}

	@Override
	public void redimensionnement(int largeur, int hauteur) {
		Dimension dimension = new Dimension(largeur, hauteur);
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
		repaint();
	}
	
	@Override
	public void changementVisibilite(boolean visible) {
		setVisible(visible);
	}
	
	@Override
	public void changementCouleurFond(Color couleur_fond) {
		this.fond = couleur_fond;
		repaint();
	}
	
	@Override
	public void changementCouleurBordure(Color couleur_bordure) {
		this.bordure = couleur_bordure;
		repaint();
	}

	@Override
	public void changementCouleurTexte(Color couleur_texte) {
		this.texte = couleur_texte;
		repaint();
	}
	
	public String toString() {
		return "x="+getX()+";y="+getY()+";largeur="+getWidth()+";hauteur="+getHeight()+";";
	}

	@Override
	public void mouseClicked(MouseEvent event) {
		if(event.getClickCount() == 1 && event.getButton() == 1) {
			modele.setSelectionne(!modele.getSelectionne());
		}
		else if(event.getClickCount() == 1 && event.getButton() == 2) {
			panel_onglet.dessinerBoutonsNoeud(this);
		}
		else if(event.getClickCount() == 1 && event.getButton() == 3) {
			menu.show(this, event.getX(), event.getY());
		}
		if(event.getClickCount()>=2) {
			if(!modele.getSelectionne()) {
				modele.selectionMoiEtTousMesFils();
			}
			else {
				modele.deselectionMoiEtTousMesFils();
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent event) {
		ancien_z_order = panel_onglet.getComponentZOrder(this);
		panel_onglet.setComponentZOrder(this, 0);
		panel_onglet.repaint();
	}

	@Override
	public void mouseExited(MouseEvent e) {
		if(e.getY() > 0 || panel_onglet.getBoutonsNoeud() == null) {
			panel_onglet.setComponentZOrder(this, ancien_z_order);
			panel_onglet.enleverBoutonsNoeud();
		}
		else if(e.getY() > 0 || panel_onglet.getBoutonsNoeud() != null) {
			if(panel_onglet.getBoutonsNoeud().getNoeud() != this) {
				panel_onglet.setComponentZOrder(this, ancien_z_order);
				panel_onglet.enleverBoutonsNoeud();
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent event) {
		decalage_x = event.getX();
		decalage_y = event.getY();
		type_bouton_souris = event.getButton();
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
		int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
		if(type_bouton_souris == 1) {//click droit
			modele.setX(getX() - deplacement_x - decalage_x);
			modele.setY(getY() - deplacement_y - decalage_y);
		}
		else if(type_bouton_souris == 3) {//click gauche
//			if(modele.getX() - (deplacement_x + decalage_x) >= 0) {
				modele.setXPlusEnfants(deplacement_x + decalage_x);
//			}
//			if(modele.getY() - (deplacement_y + decalage_y) >= 0) {
				modele.setYPlusEnfants(deplacement_y + decalage_y);
//			}
		}
	}

	@Override
	public void mouseMoved(MouseEvent event) {
		
	}
}
