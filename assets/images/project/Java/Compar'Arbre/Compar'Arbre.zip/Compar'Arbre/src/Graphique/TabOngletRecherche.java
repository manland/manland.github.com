package Graphique;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

public class TabOngletRecherche extends JTabbedPane
{
	private PanelRecherche panel_recherche;
	private PanelSelection panel_selection;
	private PanelLegende panel_legende;
	private InternalFrameRecherche parent_recherche;

	public TabOngletRecherche(InternalFrameRecherche parent_recherche) 
	{
		super();
		this.parent_recherche = parent_recherche;
		panel_recherche = new PanelRecherche(parent_recherche);
		panel_recherche.setTab_onglet_recherche(this);
		panel_selection = new PanelSelection(this);
		panel_legende = new PanelLegende(this);
		
		
		this.addChangeListener(panel_recherche.getControleur());
		
		this.add(panel_selection);
		this.add(panel_recherche);
		this.add(panel_legende);
	}

	// ACCESSEURS :
	public PanelRecherche getPanel_recherche() { return panel_recherche; }
	public void setPanel_recherche(PanelRecherche panelRecherche) { panel_recherche = panelRecherche; }

	public PanelSelection getPanel_selection() { return panel_selection; }
	public void setPanel_selection(PanelSelection panelSelection) { panel_selection = panelSelection; }

	public PanelLegende getPanel_legende() { return panel_legende; }
	public void setPanel_legende(PanelLegende panelLegende) { panel_legende = panelLegende; }
	
	
}
