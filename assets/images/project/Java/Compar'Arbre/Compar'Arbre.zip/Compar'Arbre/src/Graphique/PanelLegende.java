package Graphique;

import java.awt.Dimension;
import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.text.TableView.TableRow;

public class PanelLegende extends JPanel 
{
	private JTable tableau;
	private Vector<Vector<String>> donnees;
	private Vector<String> nom_colonnes;
	
	// frame parent : 
	TabOngletRecherche parent_tab_onglet_recherche;

	public PanelLegende(TabOngletRecherche parent_tab_onglet_recherche) {
		super();
		Dimension dim = new Dimension(200,420);
		this.setPreferredSize(dim);
		this.setMaximumSize(dim);
		this.setMinimumSize(dim);
		this.setSize(dim);
		this.parent_tab_onglet_recherche = parent_tab_onglet_recherche;
		this.setName("Légende");
		
		donnees = new Vector<Vector<String>>();
		nom_colonnes = new Vector<String>();
		nom_colonnes.add("Couleur");
		nom_colonnes.add("Selection");
		nom_colonnes.add("Recherche");
		tableau = new JTable(donnees, nom_colonnes);

		Dimension d = new Dimension(275,360);
		tableau.setPreferredSize(d);
		tableau.setMaximumSize(d);
		tableau.setMinimumSize(d);
		tableau.setSize(d);
			
		JScrollPane scrollPane = new JScrollPane(tableau);
		scrollPane.setPreferredSize(d);
		scrollPane.setMaximumSize(d);
		scrollPane.setMinimumSize(d);
		scrollPane.setSize(d);	
		tableau.setFillsViewportHeight(true);
		
		
		TableColumn column = null;
		for (int i=0; i<tableau.getColumnCount(); i++) {
		    column = tableau.getColumnModel().getColumn(i);
		    if (i == 0) {
		    	column.setMaxWidth(30);
		    	column.setMinWidth(30);
		    	column.setWidth(30);
		        column.setPreferredWidth(30);
		    } else {
		        column.setPreferredWidth(100);
		    }
		}

		
		this.add(scrollPane);
		
	}

	
	// accesseur :
	public Vector<Vector<String>> getDonnees() { return donnees; } 
	public void setDonnees(Vector<Vector<String>> donnees) { this.donnees = donnees; }

	public JTable getTableau() { return tableau; } 
	public void setTableau(JTable tableau) { this.tableau = tableau; }

	public Vector<String> getNom_colonnes() { return nom_colonnes; } 
	public void setNom_colonnes(Vector<String> nomColonnes) { nom_colonnes = nomColonnes; }
	
}
