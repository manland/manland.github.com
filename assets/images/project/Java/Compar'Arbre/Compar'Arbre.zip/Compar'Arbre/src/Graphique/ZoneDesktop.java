package Graphique;


import java.util.Vector;
import javax.swing.JDesktopPane;

public class ZoneDesktop extends JDesktopPane {
	
	private InternalFrameOnglet internal_frame_onglet;
	private InternalFrameRecherche internal_frame_recherche;
	private FenetrePrincipale fenetre_principale;
	private Vector<InternalFrameOnglet> vecteur_frame_onglet;
	
	public ZoneDesktop(FenetrePrincipale fenetre_principale) throws Exception {
		super();
		this.setPreferredSize(fenetre_principale.getPreferredSize());
		this.setMinimumSize(fenetre_principale.getMinimumSize());
		this.setMaximumSize(fenetre_principale.getMaximumSize());

		vecteur_frame_onglet = new Vector<InternalFrameOnglet>();
		
		internal_frame_onglet = new InternalFrameOnglet();
		internal_frame_onglet.setLocation(0, 0);
		this.fenetre_principale = fenetre_principale;
		this.setDragMode(OUTLINE_DRAG_MODE);
		internal_frame_recherche = new InternalFrameRecherche();
		internal_frame_recherche.addComponentListener(fenetre_principale.getBarre_outil().getControleur());
		this.ajouterOngletAVecteur(internal_frame_onglet);
		setLocation(500,0);
		
		this.setLayout(null);
		internal_frame_recherche.setVisible(false);
		this.add(internal_frame_onglet);
		this.add(internal_frame_recherche);
		internal_frame_recherche.moveToFront();
		internal_frame_recherche.toFront();
	}

	public void ajouterOngletAVecteur(InternalFrameOnglet frame_onglet)
	{
		vecteur_frame_onglet.add(frame_onglet);
	}
	
	public void retirerFrameOnglet(InternalFrameOnglet frame_onglet)
	{
		for(int i=0; i<vecteur_frame_onglet.size();i++)
		{
			if(vecteur_frame_onglet.get(i)==frame_onglet)
			{
				vecteur_frame_onglet.remove(i);
			}
		}
	}
	
	// accesseurs :
	public InternalFrameOnglet getInternal_frame_onglet() { return internal_frame_onglet; } 
	public void setInternal_frame_onglet(InternalFrameOnglet internalFrameOnglet) { internal_frame_onglet = internalFrameOnglet; }

	public InternalFrameRecherche getInternal_frame_recherche() { return internal_frame_recherche; 	}
	public void setInternal_frame_recherche(InternalFrameRecherche internalFrameRecherche) { internal_frame_recherche = internalFrameRecherche; 	}

	public FenetrePrincipale getFenetre_principale() { 	return fenetre_principale; 	}
 	public void setFenetre_principale(FenetrePrincipale fenetrePrincipale) { fenetre_principale = fenetrePrincipale; 	}

	public Vector<InternalFrameOnglet> getVecteur_frame_onglet() { return vecteur_frame_onglet; }
	public void setVecteur_frame_onglet(Vector<InternalFrameOnglet> vecteurFrameOnglet) {vecteur_frame_onglet = vecteurFrameOnglet;	}
 	
	
 	
 	
 	
}
