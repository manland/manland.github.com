package Graphique;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import Controleur.ControleurBarreAdresse;
import Controleur.ControleurBarreOutil;


public class BarreOutil extends JToolBar
{
	private static final long serialVersionUID = 1L;	

	// Barre outil pour les dossiers : 
	BarreAdresse barre_adresse_dossier1;
	BarreAdresse barre_adresse_dossier2;
	// controleurs pour les barres d'adresse : 
	ControleurBarreAdresse controleur_barre_adresse1;
	ControleurBarreAdresse controleur_barre_adresse2;
	
	// ---------------------------------------------------------
	// BOUTONS :
	// pour le plus onglet :
	private JButton btn_plus;
	private ImageIcon icon_plus;
	
	// pour le bouton focus :
	private JButton btn_focus;
	private ImageIcon icon_focus;
	
	// pour le bouton recherche :
	private JButton btn_recherche;
	private ImageIcon icon_recherche;
	
	// pour ajouter la troisieme fenetre;
	private JButton btn_troisieme_arbre;
	private ImageIcon icon_troisieme_arbre;
	 
	
	// controleur : 
	private ControleurBarreOutil controleur;
	private ZoneDesktop zone_desktop;
	
	public BarreOutil() 
	{
		super();
		controleur = new ControleurBarreOutil(this);
		zone_desktop = null;
		Dimension taille_barre_outil = new Dimension(500,40);
		this.setMinimumSize(taille_barre_outil);
		this.setMaximumSize(taille_barre_outil);
		this.setSize(taille_barre_outil);
		this.setPreferredSize(taille_barre_outil);
		initialisation();
	}

	private void initialisation() 
	{
		Dimension taille_bouton = new Dimension(30, 30);
		
		barre_adresse_dossier1 = new BarreAdresse();
		barre_adresse_dossier2 = new BarreAdresse();
		controleur_barre_adresse1 =new ControleurBarreAdresse(barre_adresse_dossier1);
		controleur_barre_adresse2 = new ControleurBarreAdresse(barre_adresse_dossier2);
		
		if(zone_desktop!=null)
		{
			barre_adresse_dossier1.setFrame_onglet(zone_desktop.getInternal_frame_onglet());
		}
		
		this.add(barre_adresse_dossier1);
		this.addSeparator();
		barre_adresse_dossier2.setVisible(false);
		this.add(barre_adresse_dossier2);
		this.addSeparator();
		
		// bouton focus :
		icon_focus = new ImageIcon("Images/Barre_Outil/zoom.png");
		btn_focus = new JButton(icon_focus);
		btn_focus.setMinimumSize(taille_bouton);
		btn_focus.setMaximumSize(taille_bouton);
		btn_focus.setSize(taille_bouton);
		btn_focus.setPreferredSize(taille_bouton);
		btn_focus.setVisible(false);
		this.add(btn_focus);
		
		// btn ajout de troisieme fenetre :
		icon_troisieme_arbre = new ImageIcon("Images/Barre_Outil/arbre.png");
		btn_troisieme_arbre = new JButton(icon_troisieme_arbre);
		btn_troisieme_arbre.addActionListener(controleur);
		this.add(btn_troisieme_arbre);
		
		// bouton plus :
		icon_plus = new ImageIcon("Images/Barre_Outil/plus.png");
		btn_plus = new JButton(icon_plus);
		btn_plus.setMinimumSize(taille_bouton);
		btn_plus.setMaximumSize(taille_bouton);
		btn_plus.setSize(taille_bouton);
		btn_plus.setPreferredSize(taille_bouton);
		btn_plus.addActionListener(controleur);
		this.add(btn_plus);
		 
		//bouton recherche :
		icon_recherche = new ImageIcon("Images/Barre_Outil/chercher.png");
		btn_recherche = new JButton(icon_recherche);
		btn_recherche.setMinimumSize(new Dimension(36, 30));
		btn_recherche.setMaximumSize(new Dimension(36, 30));
		btn_recherche.setSize(new Dimension(36, 30));
		btn_recherche.setPreferredSize(new Dimension(36, 30));
		btn_recherche.setEnabled(false);
		btn_recherche.setToolTipText("Afficher le panel de recherche");
		btn_recherche.addActionListener(controleur);
		this.add(btn_recherche);
		
		
	
	}
	
	// accesseurs :
	public BarreAdresse getBarre_adresse_dossier1() {return barre_adresse_dossier1; 	}
	public void setBarre_adresse_dossier1(BarreAdresse barreAdresseDossier1) { barre_adresse_dossier1 = barreAdresseDossier1;	}

	public BarreAdresse getBarre_adresse_dossier2() { return barre_adresse_dossier2; } 
	public void setBarre_adresse_dossier2(BarreAdresse barreAdresseDossier2) {	barre_adresse_dossier2 = barreAdresseDossier2; 	}

	public JButton getBtn_plus() { return btn_plus; } 
	public void setBtn_plus(JButton btnPlus) { btn_plus = btnPlus; } 

	public ImageIcon getIcon_plus() { return icon_plus; } 
	public void setIcon_plus(ImageIcon iconPlus) { icon_plus = iconPlus; } 

	public JButton getBtn_focus() { return btn_focus; } 
	public void setBtn_focus(JButton btnFocus) { btn_focus = btnFocus; }

	public ImageIcon getIcon_focus() { return icon_focus; } 
	public void setIcon_focus(ImageIcon iconFocus) { icon_focus = iconFocus; }


	public JButton getBtn_recherche() { return btn_recherche; } 
	public void setBtn_recherche(JButton btnRecherche) { btn_recherche = btnRecherche; 	}

	public ControleurBarreOutil getControleur() { return controleur; }
	public void setControleur(ControleurBarreOutil controleur) { this.controleur = controleur; 	}

	public ZoneDesktop getZone_desktop() { return zone_desktop; }
	public void setZone_desktop(ZoneDesktop zoneDesktop) { zone_desktop = zoneDesktop; barre_adresse_dossier1.setFrame_onglet(zoneDesktop.getInternal_frame_onglet()); 	}

	public JButton getBtn_troisieme_arbre() { return btn_troisieme_arbre; } 
	public void setBtn_troisieme_arbre(JButton btnTroisiemeArbre) { btn_troisieme_arbre = btnTroisiemeArbre; }

	
	
}
