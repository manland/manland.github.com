package Graphique;
import java.awt.Dimension;
import javax.swing.JFrame;

import Controleur.ControleurFenetrePrincipale;


public class FenetrePrincipale extends JFrame
{
	private static final long serialVersionUID = 1L;
	private BarreMenu barre_menu;
	private BarreOutil barre_outil;
	private ZoneDesktop zone_desktop;
	private BarreStatut barre_statut;

	private ControleurFenetrePrincipale controleur;
	
	private Dimension dimension_initiale;
	
	public FenetrePrincipale(String nomFenetre) throws Exception
    {
 		super(nomFenetre);
 		controleur = new ControleurFenetrePrincipale(this);
 		dimension_initiale = new Dimension(1055, 600);
 		this.setPreferredSize(dimension_initiale);
 		this.setSize(new Dimension(dimension_initiale));
 		this.setMinimumSize(new Dimension(dimension_initiale));
 		barre_menu= new BarreMenu(this);
 		barre_outil = new BarreOutil();
 		zone_desktop = new ZoneDesktop(this);
 		barre_outil.setZone_desktop(zone_desktop);
 		barre_statut = new BarreStatut();
 		
 		this.addComponentListener(controleur);
 		this.addWindowListener(controleur);
 			
 		this.add(zone_desktop);	
 		this.setJMenuBar(barre_menu);
 		this.add(barre_outil,"North");
 		this.add(barre_statut,"South");

	}

	public BarreMenu getBarre_menu() { return barre_menu; }
	public void setBarre_menu(BarreMenu barreMenu) { barre_menu = barreMenu; }

	public BarreOutil getBarre_outil() { return barre_outil; } 
	public void setBarre_outil(BarreOutil barreOutil) { barre_outil = barreOutil; }

	public ZoneDesktop getZone_desktop() { return zone_desktop; } 
	public void setZone_desktop(ZoneDesktop zoneDesktop) { zone_desktop = zoneDesktop; }

	public Dimension getDimension_initiale() { return dimension_initiale; }
	public void setDimension_initiale(Dimension dimensionInitiale) { dimension_initiale = dimensionInitiale; }
	
	
	
}
