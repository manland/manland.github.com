package Coeur;

import java.util.Vector;

public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ChargeurDossier c = new ChargeurDossier("/home/manland", 10, 1);
		ChargeurDossier c2 = new ChargeurDossier("/home/manland", 1000, 1);
		c.getNoeudPere().enregistrer("/home/manland/Bureau/arbre.ca");
		Noeud n = AbstractNoeud.restaurerArbre("/home/manland/Bureau/arbre.ca");
		System.out.println(n);
	}

}
