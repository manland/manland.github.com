package Graphique.InterieurOnglet;

import java.awt.Color;

import Coeur.AbstractNoeud;

public interface IEcouteurPoignetLien {
	public void changementSelection(boolean selectionne);
	public void changementVisibilite(boolean visible);
	public void changementCouleurFond(Color couleurFond);
	public void changementCouleurTexte(Color couleurTexte);
	public void deplacementPoignet(int x, int y);
	public void changementDePere(AbstractNoeud pere);
}
