package Coeur;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Feuille extends AbstractNoeud {
	
	public Feuille(AbstractInfos file, Noeud pere, int profondeur) {
		super(file, pere, profondeur);
	}
	
	public Feuille(String file, Noeud pere, int profondeur) {
		super(new InfosDossier(new File(file)), pere, profondeur);
	}
	
	public String toStringPourEnregistrer() {
		String res = "feuille;;"+fichier.getUrl()+";;";
		if(getPere() != null) {
			res += getPere().getFichier().getUrl();
		}
		else {
			res += "null";
		}
		res += ";;"+profondeur+"\n";
		return res;
	}
	
	public AbstractNoeud clone() {
		return new Feuille(new InfosFichier(new File(fichier.getUrl())), null, profondeur);
	}
}
