package Coeur;

import java.io.File;

public class ChargeurDossier extends AbstractChargeur {

	public ChargeurDossier(String url, int nb_liens, int profondeur) {
		super(url, nb_liens, profondeur);
		charger(noeud_pere);
	}
	
	private void charger(Noeud noeud) {
		File directory = new File(noeud.getUrl());
		if(!directory.exists()) {
			System.out.println("Le répertoire '"+noeud.getUrl()+"' n'existe pas");
		}
		else if(!directory.isDirectory()) {
			System.out.println("Le chemin '"+noeud.getUrl()+"' correspond à un fichier et non à un répertoire");
		}
		else {
			File[] subfiles = directory.listFiles();
			if(subfiles != null) {
				for(int i=0 ; i<subfiles.length; i++) {
					if(nb_liens_totaux+1 <= nb_liens_max || nb_liens_max == 0) {
						noeud.ajouterEnfant(subfiles[i]);
						nb_liens_totaux++;
					}
				}
				for(int i=0; i<noeud.getNbEnfant(); i++) {
					if(noeud.getEnfant(i).isNoeud() && (noeud.getProfondeur()+1 <= this.profondeur || profondeur == 0)) {
						charger((Noeud)noeud.getEnfant(i));
					}
				}
			}
		}
	}

}
