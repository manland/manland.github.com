package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.text.SimpleDateFormat;

import javax.swing.ImageIcon;
import javax.swing.JComponent;

import Coeur.InfosFichier;

public class ComponentAide extends JComponent implements MouseListener, MouseMotionListener {
	private Rectangle rectangle_quitter;
	private int decalage_x = 0;
	private int decalage_y = 0;
	private int decalage_x_on_screen = 0;
	private int decalage_y_on_screen = 0;
	
	public ComponentAide() {
		Dimension dimension = new Dimension(680, 390);
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
		setLocation(150, 20);
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Color bordure = Color.black;
		
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setPaint(bordure);
		g2d.drawRect(0, 0, getWidth()-1, getHeight()-1);
		
		rectangle_quitter = new Rectangle(getWidth()-15, 0, 15, 15);

		g2d.draw(rectangle_quitter);
		g2d.drawLine(rectangle_quitter.x, rectangle_quitter.y, rectangle_quitter.x+rectangle_quitter.width, rectangle_quitter.y+rectangle_quitter.height);
		g2d.drawLine(rectangle_quitter.x+rectangle_quitter.width, rectangle_quitter.y, rectangle_quitter.x, rectangle_quitter.y+rectangle_quitter.height);
		g2d.draw(rectangle_quitter);
		g2d.drawLine(rectangle_quitter.x, rectangle_quitter.y, rectangle_quitter.x+rectangle_quitter.width, rectangle_quitter.y+rectangle_quitter.height);
		
		g2d.setPaint(bordure);
		g2d.drawString("Aide", (getWidth()/2)-(g2d.getFontMetrics().stringWidth("Aide")/2), g2d.getFontMetrics().getHeight());
		
		g2d.drawString("Application : ", 10, g2d.getFontMetrics().getHeight()*3);
		String a1 = "Eléments = le nombre d'éléments maximum qui seront analysés, 0 pour une infinité";
		g2d.drawString(a1, 30, g2d.getFontMetrics().getHeight()*4);
		String a2 = "Niveaux = le nombre de niveaux maximum qui seront analysés, 0 pour une infinité";
		g2d.drawString(a2, 30, g2d.getFontMetrics().getHeight()*5);
		String a3 = "Adresse du dossier = l'url de départ pour l'analyse des dossiers et fichiers";
		g2d.drawString(a3, 30, g2d.getFontMetrics().getHeight()*6);
		String a4 = "Arbre = permet de créer l'arbre résultant des sélections de ce panel et d'un deuxième s'il y en a un";
		g2d.drawString(a4, 30, g2d.getFontMetrics().getHeight()*7);
		String a5 = "Plus = permet d'ouvrir un autre onglet, 2 au maximum";
		g2d.drawString(a5, 30, g2d.getFontMetrics().getHeight()*8);
		String a6 = "Jumelles = permet d'ouvrir le panneau de recherche";
		g2d.drawString(a6, 30, g2d.getFontMetrics().getHeight()*9);
		
		g2d.drawString("Panel : ", 10, g2d.getFontMetrics().getHeight()*11);
		String pgpd = "Presse gauche + déplacement = création d'un cadre de sélection et/ou zoom";
		g2d.drawString(pgpd, 30, g2d.getFontMetrics().getHeight()*12);
		String pgpd1 = "Double clic gauche pour le fermer";
		g2d.drawString(pgpd1, 50, g2d.getFontMetrics().getHeight()*13);
		String pgpd2 = "Déplacement : presse gauche + déplacement";
		g2d.drawString(pgpd2, 50, g2d.getFontMetrics().getHeight()*14);
		String pgpd3 = "Déplacement + enfants sélectionnés : presse droit + déplacement";
		g2d.drawString(pgpd3, 50, g2d.getFontMetrics().getHeight()*15);
		String pmpd = "Presse milieu + déplacement = création d'une bulle de zoom";
		g2d.drawString(pmpd, 30, g2d.getFontMetrics().getHeight()*16);
		String pmpd1 = "Double clic milieu pour la fermer";
		g2d.drawString(pmpd1, 50, g2d.getFontMetrics().getHeight()*17);
		String cd = "Clic droit = menu contextuel";
		g2d.drawString(cd, 30, g2d.getFontMetrics().getHeight()*18);
		
		g2d.drawString("Noeud : ", 10, g2d.getFontMetrics().getHeight()*20);
		String ncg = "Clic gauche = sélection du noeud";
		g2d.drawString(ncg, 30, g2d.getFontMetrics().getHeight()*21);
		String ncm = "Clic milieu = boutons des commandes les plus utilisées apparaissent";
		g2d.drawString(ncm, 30, g2d.getFontMetrics().getHeight()*22);
		String ncd = "Clic droit = menu contextuel";
		g2d.drawString(ncd, 30, g2d.getFontMetrics().getHeight()*23);
		String ndcg = "Double clic gauche = sélection du noeud et de tous ses enfants";
		g2d.drawString(ndcg, 30, g2d.getFontMetrics().getHeight()*24);
		
		g2d.drawString("Poignée sur un noeud : ", 10, g2d.getFontMetrics().getHeight()*26);
		String poignet = "Presse gauche + déplacement = si la poignée est lachée sur un noeud, celui-ci devient le père";
		g2d.drawString(poignet, 30, g2d.getFontMetrics().getHeight()*27);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(rectangle_quitter.contains(e.getPoint())) {
			setVisible(false);
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent event) {
		decalage_x = event.getX();
		decalage_y = event.getY();
		decalage_x_on_screen = event.getXOnScreen();
		decalage_y_on_screen = event.getYOnScreen();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		if(getCursor().getType() == Cursor.DEFAULT_CURSOR) {
			int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
			int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
			setLocation(getX() - deplacement_x - decalage_x, getY() - deplacement_y - decalage_y);
		}
		else if(decalage_x_on_screen > evt.getXOnScreen() && getCursor().getType() == Cursor.W_RESIZE_CURSOR) {
			setSize(getWidth() - (decalage_x_on_screen - evt.getXOnScreen()), getHeight());
		}
		else if(decalage_x_on_screen > evt.getXOnScreen()) {//retaille a gauche
			setSize(getWidth() + (decalage_x_on_screen - evt.getXOnScreen()), getHeight());
			setLocation(getX() - (decalage_x_on_screen - evt.getXOnScreen()), getY());
		}
		else if(decalage_x_on_screen < evt.getXOnScreen() && getCursor().getType() == Cursor.W_RESIZE_CURSOR) {
			setSize(getWidth() + (evt.getXOnScreen() - decalage_x_on_screen), getHeight());
		}
		else if(decalage_x_on_screen < evt.getXOnScreen()) {//retaille a gauche
			setSize(getWidth() - (evt.getXOnScreen() - decalage_x_on_screen), getHeight());
			setLocation(getX() + (evt.getXOnScreen() - decalage_x_on_screen), getY());
		}
		else if(decalage_y_on_screen > evt.getYOnScreen() && getCursor().getType() == Cursor.N_RESIZE_CURSOR) {
			setSize(getWidth(), getHeight() - (decalage_y_on_screen - evt.getYOnScreen()));
		}
		else if(decalage_y_on_screen > evt.getYOnScreen()) {//retaille en haut
			setSize(getWidth(), getHeight() + (decalage_y_on_screen - evt.getYOnScreen()));
			setLocation(getX(), getY() - (decalage_y_on_screen - evt.getYOnScreen()));
		}
		else if(decalage_y_on_screen < evt.getYOnScreen() && getCursor().getType() == Cursor.N_RESIZE_CURSOR) {
			setSize(getWidth(), getHeight() + (evt.getYOnScreen() - decalage_y_on_screen));
		}
		else if(decalage_y_on_screen < evt.getYOnScreen()) {//retaille en haut
			setSize(getWidth(), getHeight() - (evt.getYOnScreen() - decalage_y_on_screen));
			setLocation(getX(), getY() + (evt.getYOnScreen() - decalage_y_on_screen));
		}
		decalage_x_on_screen = evt.getXOnScreen();
		decalage_y_on_screen = evt.getYOnScreen();
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		if(rectangle_quitter.contains(e.getPoint())) {
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
		else if(e.getX() >= 0 && e.getX() <= 5) {
			setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
		}
		else if(e.getX() >= getWidth()-5 && e.getX() <= getWidth()) {
			setCursor(new Cursor(Cursor.W_RESIZE_CURSOR));
		}
		else if(e.getY() >= 0 && e.getY() <= 5) {
			setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
		}
		else if(e.getY() >= getHeight()-5 && e.getY() <= getHeight()) {
			setCursor(new Cursor(Cursor.N_RESIZE_CURSOR));
		}
		else {
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
}
