package Graphique;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.image.TileObserver;
import java.util.Vector;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import Controleur.ControleurPanelRecherche;

public class PanelRecherche extends JPanel 
{
	private Box vBox_generale;
	private Vector<Integer> vecteur_jours;
	private Vector<Integer> mois;
	private Vector<Integer> annees;
	
	// recherche :
	private JPanel mon_panel_recherche;
	private JLabel label_recherche;
	
	// par nom : 
	private Box hBox_nom;
	private JCheckBox nom_checkBox;
	private JTextField nom;
	private JComboBox choix_nom;
	private Vector<String> liste_choix;
	
	// par extension :
	private Box hBox_extension;
	private JCheckBox extension_checkBox;
	private JComboBox extension;
	private Vector<String> liste_extension;
	
	// par date : 
	private Box hBox_debut;
	private Box hBox_fin;
	private JCheckBox date_checkBox;
	private JLabel label_fin;
	private JComboBox jour_debut;
	private JComboBox mois_debut;
	private JComboBox annee_debut;
	private JCheckBox check_box_modifications;
	private JComboBox jour_fin;
	private JComboBox mois_fin;
	private JComboBox annee_fin;
	private JComboBox precision_date;
	private Vector<String> liste_precision;
	
	// par poids : 
	private Box h_box_poids;
	private JCheckBox poids_checkBox;
	private JTextField poids_min_textField;
	private JTextField poids_max_textField;
	private JComboBox poids_comboBox;
	private Vector<String> liste_poids;
	private JLabel poids_label_et;
	
	// couleur associée a la recherche :
	private JLabel label_couleur;
	private PanelCouleur panel_couleur;
	private JColorChooser color_chooser;
	
	private JButton btn_recherche;
	private GridBagConstraints c;
	
	// type de recherche en référence à l'onglet selection : 
	JLabel label_type_selection;
	JLabel type_selection;
	
	// controleur :
	private ControleurPanelRecherche controleur;
	private InternalFrameRecherche internal_frame_recherche;
	private TabOngletRecherche tab_onglet_recherche;	
	
	public PanelRecherche(InternalFrameRecherche internal_frame_recherche) 
	{
		super(new GridBagLayout());
		controleur = new ControleurPanelRecherche(this);

		this.setName("Recherche");
		c = new GridBagConstraints();
		mois = new Vector<Integer>();
		annees = new Vector<Integer>();
		vecteur_jours = new Vector<Integer>();
		this.internal_frame_recherche = internal_frame_recherche;
		tab_onglet_recherche = null;
		initialisation();
	}
	
	public void initialisation()
	{			
		// creation de la box generale, qui contiendra toutes les autres box :
		vBox_generale = Box.createVerticalBox();
	
		// type de selection :
		JPanel panel_type = new JPanel(new GridLayout(1,1)); 
		label_type_selection = new JLabel("<html>Type de selection :<br> </html>");
		type_selection = new JLabel();
		panel_type.add(label_type_selection);
		panel_type.add(type_selection);
		
		vBox_generale.add(panel_type);
		// recherche :
		mon_panel_recherche = new JPanel(new GridLayout(10,1));
		label_recherche = new JLabel("Recherche : ");
		mon_panel_recherche.add(label_recherche);
	
		
		// par nom : 
		hBox_nom = Box.createHorizontalBox();
		nom_checkBox = new JCheckBox("Nom : ");
		nom = new JTextField();
		nom.setPreferredSize(new Dimension(100,25));
		nom.setMinimumSize(new Dimension(100,25));
		nom.setSize(new Dimension(100,25));
		nom.setMaximumSize(new Dimension(100,25));
		liste_choix=new Vector<String>();
		liste_choix.add("Exact");
		liste_choix.add("Contient");
		choix_nom = new JComboBox(liste_choix);
		choix_nom.setSelectedItem(liste_choix.get(0));
		Dimension taille_choix=new Dimension(88,25);
		choix_nom.setPreferredSize(taille_choix);
		choix_nom.setMinimumSize(taille_choix);
		choix_nom.setSize(taille_choix);
		choix_nom.setMaximumSize(taille_choix);
		nom.setEnabled(false);
		choix_nom.setEnabled(false);
		nom_checkBox.addActionListener(controleur);
		hBox_nom.add(nom_checkBox);
		hBox_nom.add(nom);
		hBox_nom.add(choix_nom);
		
		// par extension :
		hBox_extension = Box.createHorizontalBox();
		liste_extension = new Vector<String>();
		liste_extension.add("mp3");
		liste_extension.add("java");
		liste_extension.add("txt");
		extension_checkBox = new JCheckBox("Extension : ");
		extension= new JComboBox(liste_extension);
		extension.setPreferredSize(new Dimension(100,25));
		extension.setMinimumSize(new Dimension(100,25));
		extension.setSize(new Dimension(100,25));
		extension.setMaximumSize(new Dimension(100,25));
		extension.setEditable(true);
		extension.setEnabled(false);
		extension_checkBox.addActionListener(controleur);
		extension.addActionListener(controleur);
		hBox_extension.add(extension_checkBox);
		hBox_extension.add(extension);
		
		// par date :
		// remplissage combobox mois :
		liste_precision = new Vector<String>();
		liste_precision.add("avant");
		liste_precision.add("après");
		liste_precision.add("le");
		precision_date = new JComboBox(liste_precision);
		Dimension taille_combo = new Dimension(68,25);
		precision_date.setPreferredSize(taille_combo);
		precision_date.setMaximumSize(taille_combo);
		precision_date.setMinimumSize(taille_combo);
		precision_date.setSize(taille_combo);
		precision_date.setSelectedIndex(2);
		precision_date.setEnabled(false);
		
		for(int i=1; i< 13 ; i++)
		{
			mois.add(i);
		}
		for (int i=1900; i<2200; i++)
		{
			annees.add(i);
		}
		hBox_debut= Box.createHorizontalBox();
		hBox_fin=Box.createHorizontalBox();
		date_checkBox = new JCheckBox("Date de modification :");
		label_fin = new JLabel("Au : ");
		jour_debut = new JComboBox();
		jour_debut.setPreferredSize(new Dimension(45,25));
		jour_debut.setMinimumSize(new Dimension(45,25));
		jour_debut.setSize(new Dimension(45,25));
		jour_debut.setMaximumSize(new Dimension(45,25));
		mois_debut = new JComboBox(mois);
		mois_debut.setPreferredSize(new Dimension(45,25));
		mois_debut.setMinimumSize(new Dimension(45,25));
		mois_debut.setSize(new Dimension(45,25));
		mois_debut.setMaximumSize(new Dimension(45,25));
		mois_debut.addActionListener(controleur);
		annee_debut = new JComboBox(annees);
		annee_debut.setPreferredSize(new Dimension(60,25));
		annee_debut.setMinimumSize(new Dimension(60,25));
		annee_debut.setSize(new Dimension(60,25));
		annee_debut.setMaximumSize(new Dimension(60,25));
		jour_debut.setEnabled(false);
		mois_debut.setEnabled(false);
		annee_debut.setEnabled(false);
		
		
		check_box_modifications = new JCheckBox();
		check_box_modifications.addActionListener(controleur);
		check_box_modifications.setSelected(false);
		check_box_modifications.setEnabled(false);
		jour_fin= new JComboBox();  
		jour_fin.setPreferredSize(new Dimension(45,25));
		jour_fin.setMinimumSize(new Dimension(45,25));
		jour_fin.setSize(new Dimension(45,25));
		jour_fin.setMaximumSize(new Dimension(45,25));
		mois_fin = new JComboBox(mois);
		mois_fin.setPreferredSize(new Dimension(45,25));
		mois_fin.setMinimumSize(new Dimension(45,25));
		mois_fin.setSize(new Dimension(45,25));
		mois_fin.setMaximumSize(new Dimension(45,25));
		mois_fin.addActionListener(controleur);
		annee_fin= new JComboBox(annees);
		annee_fin.setPreferredSize(new Dimension(60,25));
		annee_fin.setMinimumSize(new Dimension(60,25));
		annee_fin.setSize(new Dimension(60,25));
		annee_fin.setMaximumSize(new Dimension(60,25));
		annee_debut.setSelectedItem(annees.get(110));
		mois_debut.setSelectedIndex(0);
		mois_fin.setSelectedIndex(0);
		annee_fin.setSelectedIndex(110);
		jour_fin.setEnabled(false);
		mois_fin.setEnabled(false);
		annee_fin.setEnabled(false);
		hBox_debut.add(precision_date);
		hBox_debut.add(jour_debut);
		hBox_debut.add(mois_debut);
		hBox_debut.add(annee_debut);
		hBox_fin.add(check_box_modifications);
		hBox_fin.add(label_fin);
		hBox_fin.add(jour_fin);
		hBox_fin.add(mois_fin);
		hBox_fin.add(annee_fin);
		

		
		date_checkBox.addActionListener(controleur);
		
		mon_panel_recherche.add(hBox_nom);
		mon_panel_recherche.add(hBox_extension);
		mon_panel_recherche.add(date_checkBox);
		mon_panel_recherche.add(hBox_debut);
		mon_panel_recherche.add(hBox_fin);
		
		
		// par poids : 
		h_box_poids = Box.createHorizontalBox();
		poids_checkBox = new JCheckBox("Poids :");
		poids_min_textField = new JTextField();
		poids_max_textField = new JTextField();
		Dimension taille_text_field_poids = new Dimension(60,25);
		poids_min_textField.setPreferredSize(taille_text_field_poids);
		poids_min_textField.setMaximumSize(taille_text_field_poids);
		poids_min_textField.setMinimumSize(taille_text_field_poids);
		poids_min_textField.setSize(taille_text_field_poids);
		
		poids_max_textField.setPreferredSize(taille_text_field_poids);
		poids_max_textField.setMaximumSize(taille_text_field_poids);
		poids_max_textField.setMinimumSize(taille_text_field_poids);
		poids_max_textField.setSize(taille_text_field_poids);
		
		liste_poids = new Vector<String>();
		poids_label_et = new JLabel(" et ");
		liste_poids.add("De");
		liste_poids.add("inférieur à");
		liste_poids.add("supérieur à");
		liste_poids.add("Entre");
		poids_comboBox  = new JComboBox(liste_poids);
		Dimension taille_poids_checkBox = new Dimension(108,25);
		poids_comboBox.setPreferredSize(taille_poids_checkBox);
		poids_comboBox.setMaximumSize(taille_poids_checkBox);
		poids_comboBox.setMinimumSize(taille_poids_checkBox);
		poids_comboBox.setSize(taille_poids_checkBox);
		poids_comboBox.setSelectedItem(liste_poids.get(0));
		poids_comboBox.addActionListener(controleur);
		
		poids_comboBox.setEnabled(false);
		poids_max_textField.setEnabled(false);
		poids_min_textField.setEnabled(false);
		poids_label_et.setEnabled(false);
		
		poids_checkBox.addActionListener(controleur);
		
		h_box_poids.add(poids_comboBox);
		h_box_poids.add(poids_min_textField);
		h_box_poids.add(poids_label_et);
		h_box_poids.add(poids_max_textField);
	
		mon_panel_recherche.add(poids_checkBox);
		mon_panel_recherche.add(h_box_poids);
		
		// couleur chooser : 
		color_chooser = new JColorChooser(Color.cyan);
		label_couleur = new JLabel("Couleur associée : ");
		panel_couleur = new PanelCouleur(color_chooser);
		panel_couleur.addMouseListener(controleur);
		Box hBox_couleur = Box.createHorizontalBox();
		hBox_couleur.add(label_couleur);
		hBox_couleur.add(panel_couleur);
		
		mon_panel_recherche.add(hBox_couleur);
		
		// bouton de recherche :
		btn_recherche = new JButton("Recherche");
		btn_recherche.addActionListener(controleur);
		btn_recherche.setEnabled(false);
		mon_panel_recherche.add(btn_recherche);
		
		// on ajoute toutes les differentes box dans la box generale
		vBox_generale.add(new JSeparator());
		vBox_generale.add(mon_panel_recherche);
		this.add(vBox_generale,c);
	}
	

	public Vector<Integer> getVecteurJours() { return vecteur_jours; }
	public void setVecteur_jours(Vector<Integer> vecteur_jours) { this.vecteur_jours = vecteur_jours;}

	public JComboBox getJour_debut() { return jour_debut; }
	public void setJour_debut(JComboBox jourDebut) { jour_debut = jourDebut; }

	public JComboBox getMois_debut() {  return mois_debut; 	} 
	public void setMois_debut(JComboBox moisDebut) { mois_debut = moisDebut; }

	public JComboBox getAnnee_debut() {  return annee_debut; } 
	public void setAnnee_debut(JComboBox anneeDebut) { annee_debut = anneeDebut; }

	public JComboBox getJour_fin() { return jour_fin; } 
	public void setJour_fin(JComboBox jourFin) { jour_fin = jourFin; }

	public JComboBox getMois_fin() { return mois_fin; } 
	public void setMois_fin(JComboBox moisFin) { mois_fin = moisFin; }

	public JComboBox getAnnee_fin() {  return annee_fin; }
	public void setAnnee_fin(JComboBox anneeFin) {  annee_fin = anneeFin; }

	public JButton getBtn_recherche() { return btn_recherche; }
	public void setBtn_recherche(JButton btnRecherche) { btn_recherche = btnRecherche; }

	public JCheckBox getCheck_box_modifications() { return check_box_modifications; }
	public void setCheck_box_modifications(JCheckBox checkBoxModifications) { check_box_modifications = checkBoxModifications; }

	public JLabel getLabel_fin() { return label_fin; }
	public void setLabel_fin(JLabel labelFin) { label_fin = labelFin; }

	public JComboBox getExtension() { return extension; }
	public void setExtension(JComboBox extension) { this.extension = extension; }

	public Vector<String> getListe_extension() { return liste_extension; }
	public void setListe_extension(Vector<String> listeExtension) { liste_extension = listeExtension; }

	public InternalFrameRecherche getInternal_frame_recherche() { return internal_frame_recherche; }
	public void setInternal_frame_recherche(InternalFrameRecherche internalFrameRecherche) { 
		internal_frame_recherche = internalFrameRecherche;
	}

	public PanelCouleur getPanel_couleur() { return panel_couleur; }
	public void setPanel_couleur(PanelCouleur panelCouleur) { panel_couleur = panelCouleur; }

	public JCheckBox getNom_checkBox() { return nom_checkBox; }
	public void setNom_checkBox(JCheckBox nomCheckBox) { nom_checkBox = nomCheckBox;}

	public JCheckBox getExtension_checkBox() { return extension_checkBox; }
	public void setExtension_checkBox(JCheckBox extensionCheckBox) { extension_checkBox = extensionCheckBox; }

	public JCheckBox getDate_checkBox() { return date_checkBox; } 
	public void setDate_checkBox(JCheckBox dateCheckBox) { date_checkBox = dateCheckBox;}

	public JTextField getNom() { return nom; }
	public void setNom(JTextField nom) { this.nom = nom; }

	public JComboBox getPrecision_date() { return precision_date; }
	public void setPrecision_date(JComboBox precisionDate) { precision_date = precisionDate;}

	public JCheckBox getPoids_checkBox() { return poids_checkBox; }
	public void setPoids_checkBox(JCheckBox poidsCheckBox) { poids_checkBox = poidsCheckBox; }

	public JTextField getPoids_min_textField() { return poids_min_textField; } 
	public void setPoids_min_textField(JTextField poidsMinTextField) {poids_min_textField = poidsMinTextField; }

	public JTextField getPoids_max_textField() { return poids_max_textField;} 
	public void setPoids_max_textField(JTextField poidsMaxTextField) { poids_max_textField = poidsMaxTextField; }

	public JComboBox getPoids_comboBox() { return poids_comboBox;} 
	public void setPoids_comboBox(JComboBox poidsComboBox) {poids_comboBox = poidsComboBox;}

	public Vector<String> getListe_poids() { return liste_poids;} 
	public void setListe_poids(Vector<String> listePoids) { liste_poids = listePoids; }

	public JLabel getPoids_label_et() { return poids_label_et; } 
	public void setPoids_label_et(JLabel poidsLabelEt) { poids_label_et = poidsLabelEt; }

	public ControleurPanelRecherche getControleur() { return controleur; }
	public void setControleur(ControleurPanelRecherche controleur) { this.controleur = controleur; }

	public TabOngletRecherche getTab_onglet_recherche() { return tab_onglet_recherche; } 
	public void setTab_onglet_recherche(TabOngletRecherche tabOngletRecherche) { 
		tab_onglet_recherche = tabOngletRecherche;
	}

	public JLabel getType_selection() { return type_selection; }
	public void setType_selection(JLabel typeSelection) { type_selection = typeSelection; }

	public JComboBox getChoix_nom() { return choix_nom; }
	public void setChoix_nom(JComboBox choixNom) { 	choix_nom = choixNom; 	} 
}
