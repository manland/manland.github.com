package Coeur;

import java.io.File;

public class InfosFichier  extends AbstractInfos {

	public InfosFichier(File file) {
		super(file);
	}
	
	public long getTaille() {
		return fichier.length();
	}
	
	public String getExtension() {
		String res = "";
		if(fichier.getName().contains(".")) {
			res = fichier.getName().substring(fichier.getName().lastIndexOf(".")+1);
		}
		return res;
	}

}
