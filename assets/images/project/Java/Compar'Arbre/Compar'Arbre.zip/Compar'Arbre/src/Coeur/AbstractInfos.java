package Coeur;

import java.io.File;
import java.util.Calendar;
import java.util.Date;

public abstract class AbstractInfos {

	protected File fichier;
	
	public AbstractInfos(File file) {
		fichier = file;
	}

	public File getFichier() {
		return fichier;
	}

	public void setFichier(File fichier) {
		this.fichier = fichier;
	}
	
	public boolean isDossier() {
		return fichier.isDirectory();
	}
	
	public boolean isFichier() {
		return fichier.isFile();
	}
	
	public String getUrl() {
		return fichier.getPath();
	}
	
	public String getNom() {
		String res = fichier.getName();
		if(isFichier()) {
			InfosFichier i = (InfosFichier)this;
			String ext = i.getExtension();
			if(!ext.isEmpty() && fichier.getName().lastIndexOf(".")!=0) {
				res = res.substring(0, fichier.getName().lastIndexOf("."));
			}
		}
		return res;
	}
	
	public boolean estCache() {
		return fichier.isHidden();
	}
	
	public Date getDerniereModification() {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(fichier.lastModified());
		return cal.getTime();
	}
	
	public abstract long getTaille();
	
	public String getTailleToString() {
		long t = 100*1000000000;
		if(getTaille()<1000) {
			return ""+getTaille()+" o";
		}
		else if(getTaille()<1000000) {
			return ""+getTaille()/1000+" Ko";
		}
		else if(getTaille()<1000000000) {
			return ""+getTaille()/1000000+" Mo";
		}
		else if(getTaille()<t) {
			return ""+getTaille()/1000000000+" Go";
		}
		else {
			return ""+getTaille()+" o";
		}
	}
	
}
