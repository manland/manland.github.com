package Graphique;

import java.awt.TextField;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JToolBar;

public class BarreOutilRecherche extends JToolBar 
{
	private Box vBox;
	private Box hBox_recherche;
	
	// bouton selections :
	private JButton btn_inter;
	private JButton btn_moins1;
	private JButton btn_moins2;
	
	
	// recherche :
	private TextField text_field_recherche;
	private JLabel label_recherche;
	
	public BarreOutilRecherche() {
		super();
		initialisation();
	}
	
	public void initialisation()
	{
		vBox = Box.createVerticalBox();
		hBox_recherche = Box.createHorizontalBox();
		
		// boutons 
		btn_inter = new JButton("N1 ^ N2");
		btn_moins1 = new JButton("N1 \\ N2");
		btn_moins2 = new JButton("N2 \\ N1");
		
		vBox.add(btn_inter);
		vBox.add(btn_moins1);
		vBox.add(btn_moins2);
		
		// recherche :
		label_recherche = new JLabel("Recherche :");
		text_field_recherche = new TextField();
		hBox_recherche.add(label_recherche);
		hBox_recherche.add(text_field_recherche);
	
		vBox.add(hBox_recherche);
		
		this.add(vBox);
	}
	
}
