package Coeur;

public class PlacementSimpleVertical extends PlacementAbstrait {

	public PlacementSimpleVertical (Noeud noeud_pere, int largeur_max, int hauteur_max) {
		super(noeud_pere, largeur_max, hauteur_max);
		rang_actuel = 1;
		attributionRangOrdreInfixe(noeud);
		placement(noeud);
	}

	@Override
	public void placement(AbstractNoeud noeud) {
		noeud.setY(noeud.getRang()*(noeud.getHauteur()+10));
		noeud.setX(noeud.getProfondeur()*(noeud.getLargeur()+30));
		
		if(noeud.isNoeud()) {
			Noeud n = (Noeud) noeud;
			for(int i=0; i<n.getNbEnfant(); i++) {
				placement(n.getEnfant(i));
			}
		}
	}
}
