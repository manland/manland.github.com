package Graphique;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import Controleur.ControleurTabOnglet;
import Graphique.InterieurOnglet.PanelOnglet;


public class TabOnglet extends JTabbedPane
{
	private PanelOnglet onglet;
	private JScrollPane scroll_pane;
	
	// controleur :
	private ControleurTabOnglet controleur;

	public TabOnglet() 
	{
		super();
		controleur = new ControleurTabOnglet(this);
		onglet = new PanelOnglet();
		scroll_pane = new JScrollPane(onglet);
		
		onglet.setParent(scroll_pane);
		
		this.setMinimumSize(onglet.getMinimumSize());
		this.setSize(onglet.getSize());
		this.setPreferredSize(onglet.getPreferredSize());
		
		this.add(scroll_pane);
		this.addMouseListener(controleur);
	}

	public PanelOnglet getPanelOnglet() 
	{
		return onglet;
	}

	public void setPanelOnglet(PanelOnglet onglet) 
	{
		this.onglet = onglet;
	}

}
