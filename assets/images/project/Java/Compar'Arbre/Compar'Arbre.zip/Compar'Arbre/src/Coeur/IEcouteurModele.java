package Coeur;

import java.awt.Color;

public interface IEcouteurModele {
	public void changementSelection(boolean selectionne);
	public void changementVisibilite(boolean visible);
	public void deplacement(int x, int y);
	public void redimensionnement(int largeur, int hauteur);
	public void changementCouleurFond(Color couleur_fond);
	public void changementCouleurTexte(Color couleur_texte);
	public void changementCouleurBordure(Color couleur_bordure);
}
