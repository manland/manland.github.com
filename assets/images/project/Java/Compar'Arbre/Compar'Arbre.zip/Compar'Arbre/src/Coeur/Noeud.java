package Coeur;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

public class Noeud extends AbstractNoeud {
	
	private Vector<AbstractNoeud> enfants;
	
	public Noeud(AbstractInfos file, Noeud pere, int profondeur) {
		super(file, pere, profondeur);
		enfants = new Vector<AbstractNoeud>();
	}
	
	public Noeud(String file, Noeud pere, int profondeur) {
		super(new InfosDossier(new File(file)), pere, profondeur);
		enfants = new Vector<AbstractNoeud>();
	}
	
	public AbstractNoeud getEnfant(int i) {
		return enfants.get(i);
	}

	public Vector<AbstractNoeud> getEnfants() {
		return enfants;
	}

	public void setEnfants(Vector<AbstractNoeud> enfants) {
		this.enfants = enfants;
	}

	public void ajouterEnfant(AbstractNoeud noeud) {
		enfants.add(noeud);
	}
	
	public AbstractNoeud ajouterEnfant(File file) {
		AbstractNoeud noeud = null;
		if(file.isDirectory()) {
			noeud = new Noeud(new InfosDossier(file), this, profondeur+1);
		}
		else {
			noeud = new Feuille(new InfosFichier(file), this, profondeur+1);
		}
		enfants.add(noeud);
		return noeud;
	}
	
	public int getNbEnfant() {
		return enfants.size();
	}
	
	public int getNbEnfantRecursif() {
		int res = enfants.size();
		for(int i=0; i<enfants.size(); i++) {
			if(enfants.get(i).isNoeud()) {
				res += ((Noeud)enfants.get(i)).getNbEnfantRecursif();
			}
		}
		return res;
	}
	
	public int plusEnfantsPossible() {
		int res = enfants.size();
		for(int i=0; i<enfants.size(); i++) {
			if(enfants.get(i).isNoeud()) {
				int temp = ((Noeud)enfants.get(i)).getNbEnfantRecursif();
				if(temp > res) {
					res = temp;
				}
			}
		}
		return res;
	}
	
	public boolean isRoot() {
		if(pere != null) {
			return false;
		}
		return true;
	}
	
	public Boolean contient(AbstractNoeud noeud) {
		Boolean res = false;
		for(int i=0; i<enfants.size(); i++) {
			if(noeud.equals(enfants.get(i))) {
				return true;
			}
		}
		return res;
	}
	
	public Boolean contientRecursif(AbstractNoeud noeud) {
		Boolean res = false;
		res = contient(noeud);
		if(!res) {
			for(int i=0; i<enfants.size() && !res; i++) {
				if(enfants.get(i).isNoeud()) {
					res = ((Noeud)enfants.get(i)).contientRecursif(noeud);
				}
			}
		}
		return res;
	}
	
	public String toStringPourEnregistrer() {
		String res = "noeud;;"+fichier.getUrl()+";;";
		if(getPere() != null) {
			res += getPere().getFichier().getUrl();
		}
		else {
			res += "null";
		}
		res += ";;"+profondeur+"\n";
		for(int i=0; i<getNbEnfant(); i++) {
			res += getEnfant(i).toStringPourEnregistrer();
		}
		return res;
	}
	
	public AbstractNoeud clone() {
		return new Noeud(new InfosDossier(new File(fichier.getUrl())), null, profondeur);
	}
	
	public String toString() {
		String res = super.toString();
		if(enfants.size() > 0) {
			for(int i=0; i<enfants.size(); i++) {
				res += enfants.get(i);
			}
		}
		return res;
	}
	
}
