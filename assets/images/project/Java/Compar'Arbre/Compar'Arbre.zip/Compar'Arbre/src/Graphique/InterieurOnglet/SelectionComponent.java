package Graphique.InterieurOnglet;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;

import javax.jws.Oneway;
import javax.swing.JComponent;

public class SelectionComponent extends JComponent implements MouseListener, MouseMotionListener {
	private PanelOnglet panel_onglet;
	private int decalage_x = 0;
	private int decalage_y = 0;
	private int decalage_x_on_screen = 0;
	private int decalage_y_on_screen = 0;
	private Rectangle rectangle_plus;
	private Rectangle rectangle_moins;
	private Rectangle rectangle_info;
	private Rectangle rectangle_loupe;
	private int lpr;
	private int hpr;
	private int x1pr;
	private int y1pr;
	private int x2pr;
	private int y2pr;
	private int x3pr;
	private int y3pr;
	private int x4pr;
	private int y4pr;
	
	public SelectionComponent(PanelOnglet panel_onglet) {
		this.panel_onglet = panel_onglet;
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		lpr = getWidth()/4;//lpr = largeur_petit_rectangle
		hpr = 30;//hpr = hauteur_petit_rectangle
		x1pr = 0;//xpr = x_petit_rectangle du 1er rectangle
		y1pr = 0;//y1pr = y_petit_rectangle du 1er rectangle
		x2pr = x1pr+lpr;
		y2pr = 0;
		x3pr = x2pr+lpr;
		y3pr = 0;
		x4pr = x3pr+lpr;
		y4pr = 0;
		
		rectangle_plus = new Rectangle(x1pr, y1pr, lpr, hpr);
		rectangle_moins = new Rectangle(x2pr, y2pr, lpr, hpr);
		rectangle_info = new Rectangle(x3pr, y3pr, lpr, hpr);
		rectangle_loupe = new Rectangle(x4pr, y4pr, lpr, hpr);
		
		Color fond = new Color(0, 0, 0);
		Color bordure = new Color(255, 255, 255);
		
		Graphics2D g2d = (Graphics2D)g;
		
		g2d.setPaint(fond);
		g2d.drawRect(0, 0, getWidth()-1, getHeight()-1);
		g2d.fill(rectangle_plus);
		g2d.fill(rectangle_moins);
		g2d.fill(rectangle_info);
		g2d.fill(rectangle_loupe);
		
		g2d.setPaint(bordure);
		g2d.draw(rectangle_plus);
		g2d.drawString("+", x1pr+(lpr-g2d.getFontMetrics().stringWidth("+"))/2, (y1pr+hpr/2)+(g2d.getFontMetrics().getHeight()/2));
		
		g2d.draw(rectangle_moins);
		g2d.drawString("-", x2pr+(lpr-g2d.getFontMetrics().stringWidth("-"))/2, (y2pr+hpr/2)+(g2d.getFontMetrics().getHeight()/2));
		
		g2d.draw(rectangle_info);
		g2d.drawString("-", x3pr+(lpr-g2d.getFontMetrics().stringWidth("-"))/2, (y3pr+hpr/2)+(g2d.getFontMetrics().getHeight()/2));
		g2d.drawOval(x3pr+lpr/2+g2d.getFontMetrics().stringWidth("-"), y3pr+(hpr/2), 5, 5);
		g2d.drawLine(x3pr+(lpr/2)+5+g2d.getFontMetrics().stringWidth("-"), y3pr+(hpr/2)+5, x3pr+(lpr/2)+7+g2d.getFontMetrics().stringWidth("-"), y3pr+(hpr/2)+7);
		
		g2d.draw(rectangle_loupe);
		g2d.drawString("+", x4pr+(lpr-g2d.getFontMetrics().stringWidth("+"))/2, (y4pr+hpr/2)+(g2d.getFontMetrics().getHeight()/2));
		g2d.drawOval(x4pr+lpr/2+g2d.getFontMetrics().stringWidth("+"), y4pr+(hpr/2), 5, 5);
		g2d.drawLine(x4pr+(lpr/2)+5+g2d.getFontMetrics().stringWidth("+"), y4pr+(hpr/2)+5, x4pr+(lpr/2)+7+g2d.getFontMetrics().stringWidth("+"), y4pr+(hpr/2)+7);

	}
	
	public Rectangle getReelBounds() {
		return super.getBounds();
	}
	
	public Rectangle getBounds() {
		Rectangle rect = super.getBounds();
		rect.setLocation((int)rect.getX(), (int)rect.getY()+30);
		rect.setSize((int)rect.getWidth(), (int)rect.getHeight()-30);
		return rect;
	}

	@Override
	public void mouseClicked(MouseEvent event) {
		if(event.getClickCount() >= 2) {
			getParent().remove(this);
		}
		if(rectangle_plus.contains(event.getPoint())) {
			Vector<NoeudGraphique> v = panel_onglet.getTousEnfantsContenus(getBounds());
			for(int i=0; i<v.size();i++) {
				v.get(i).getModele().setSelectionne(true);
			}
			panel_onglet.moveToFront(this);
		}
		else if(rectangle_moins.contains(event.getPoint())) {
			Vector<NoeudGraphique> v = panel_onglet.getTousEnfantsContenus(getBounds());
			for(int i=0; i<v.size();i++) {
				v.get(i).getModele().setSelectionne(false);
			}
			panel_onglet.moveToFront(this);
		}
		else if(rectangle_info.contains(event.getPoint())) {
			panel_onglet.zoomMoins();
		}
		else if(rectangle_loupe.contains(event.getPoint())) {
			panel_onglet.zoom(getWidth(), getHeight());
		}
		else {
			panel_onglet.mouseClicked(event);
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	private int dernier_bouton_presse;

	@Override
	public void mousePressed(MouseEvent event) {
		decalage_x = event.getX();
		decalage_y = event.getY();
		decalage_x_on_screen = event.getXOnScreen();
		decalage_y_on_screen = event.getYOnScreen();
		dernier_bouton_presse = event.getButton();
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent evt) {
		if(getCursor().getType() == Cursor.DEFAULT_CURSOR && dernier_bouton_presse == 1) {
			int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
			int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
			setLocation(getX() - deplacement_x - decalage_x, getY() - deplacement_y - decalage_y);
			panel_onglet.setComponentZOrder(this, 0);
			Vector<NoeudGraphique> v = panel_onglet.getTousEnfantsContenus(getBounds());
			for(int i=0; i<v.size(); i++) {
				panel_onglet.setComponentZOrder(v.get(i), 0);
			}
		}
		else if(getCursor().getType() == Cursor.DEFAULT_CURSOR && dernier_bouton_presse == 3) {
			int deplacement_x = getLocationOnScreen().x - evt.getXOnScreen();
			int deplacement_y = getLocationOnScreen().y - evt.getYOnScreen();
			setLocation(getX() - deplacement_x - decalage_x, getY() - deplacement_y - decalage_y);
			panel_onglet.setComponentZOrder(this, 0);
			Vector<NoeudGraphique> v = panel_onglet.getTousEnfantsContenus(getBounds());
			for(int i=0; i<v.size(); i++) {
				if(v.get(i).getModele().getSelectionne()) {
					v.get(i).getModele().setX(v.get(i).getModele().getX() - deplacement_x - decalage_x);
					v.get(i).getModele().setY(v.get(i).getModele().getY() - deplacement_y - decalage_y);
				}
			}
		}
		else if(dernier_bouton_presse == 1) {
			if(decalage_x_on_screen > evt.getXOnScreen() && getCursor().getType() == Cursor.W_RESIZE_CURSOR) {
				setSize(getWidth() - (decalage_x_on_screen - evt.getXOnScreen()), getHeight());
			}
			else if(decalage_x_on_screen > evt.getXOnScreen()) {//retaille a gauche
				setSize(getWidth() + (decalage_x_on_screen - evt.getXOnScreen()), getHeight());
				setLocation(getX() - (decalage_x_on_screen - evt.getXOnScreen()), getY());
			}
			else if(decalage_x_on_screen < evt.getXOnScreen() && getCursor().getType() == Cursor.W_RESIZE_CURSOR) {
				setSize(getWidth() + (evt.getXOnScreen() - decalage_x_on_screen), getHeight());
			}
			else if(decalage_x_on_screen < evt.getXOnScreen()) {//retaille a gauche
				setSize(getWidth() - (evt.getXOnScreen() - decalage_x_on_screen), getHeight());
				setLocation(getX() + (evt.getXOnScreen() - decalage_x_on_screen), getY());
			}
			decalage_x_on_screen = evt.getXOnScreen();
			if(decalage_y_on_screen > evt.getYOnScreen() && getCursor().getType() == Cursor.N_RESIZE_CURSOR) {
				setSize(getWidth(), getHeight() - (decalage_y_on_screen - evt.getYOnScreen()));
			}
			else if(decalage_y_on_screen > evt.getYOnScreen()) {//retaille en haut
				setSize(getWidth(), getHeight() + (decalage_y_on_screen - evt.getYOnScreen()));
				setLocation(getX(), getY() - (decalage_y_on_screen - evt.getYOnScreen()));
			}
			else if(decalage_y_on_screen < evt.getYOnScreen() && getCursor().getType() == Cursor.N_RESIZE_CURSOR) {
				setSize(getWidth(), getHeight() + (evt.getYOnScreen() - decalage_y_on_screen));
			}
			else if(decalage_y_on_screen < evt.getYOnScreen()) {//retaille en haut
				setSize(getWidth(), getHeight() - (evt.getYOnScreen() - decalage_y_on_screen));
				setLocation(getX(), getY() + (evt.getYOnScreen() - decalage_y_on_screen));
			}
			decalage_y_on_screen = evt.getYOnScreen();
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		panel_onglet.mouseMoved(e);
		
		if(rectangle_plus.contains(e.getPoint())) {
			setToolTipText("Clickez pour sélectionner tous les noeuds contenues dans ce rectangle");
		}
		else if(rectangle_moins.contains(e.getPoint())) {
			setToolTipText("Clickez pour désélectionner tous les noeuds contenues dans ce rectangle");
		}
		else if(rectangle_info.contains(e.getPoint())) {
			setToolTipText("Clickez pour zoomer en arrière");
		}
		else if(rectangle_loupe.contains(e.getPoint())) {
			setToolTipText("Clickez pour zoomer en avant");
		}
		
		if(e.getX() >= 0 && e.getX() <= 5) {
			setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
		}
		else if(e.getX() >= getWidth()-5 && e.getX() <= getWidth()) {
			setCursor(new Cursor(Cursor.W_RESIZE_CURSOR));
		}
		else if(e.getY() >= 0 && e.getY() <= 5) {
			setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
		}
		else if(e.getY() >= getHeight()-5 && e.getY() <= getHeight()) {
			setCursor(new Cursor(Cursor.N_RESIZE_CURSOR));
		}
		else {
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			panel_onglet.mouseMoved(e);
		}
	}
}
