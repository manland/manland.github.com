package Coeur;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChargeurPageInternet extends AbstractChargeur {
	
	public ChargeurPageInternet(String url, int nb_liens, int profondeur) {
		super(url, nb_liens, profondeur);
		charger(noeud_pere);
	}
	
	public void charger(Noeud noeud) {
		URL url = null;
		try {
			url = new URL(noeud.getUrl());
		} 
		catch (MalformedURLException e) {
			e.printStackTrace();
		}
		InputStreamReader ipsr = null;
		try {
			ipsr = new InputStreamReader(url.openStream());
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		BufferedReader br = new BufferedReader(ipsr);
		String line = null;
		StringBuffer buffer = new StringBuffer();
		try {
			while ((line = br.readLine()) != null) {
				buffer.append(line).append('\n');
			}
			br.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
		//Recherche des sous_liens
		Pattern lien = Pattern.compile("<a href=\"(http://[^\"]*)\".*>(.*)</a>");
		Matcher liens_trouve = lien.matcher(buffer);
		while(liens_trouve.find() && nb_liens_totaux+1 <= nb_liens_max) {
			String str_lien = liens_trouve.group(1);
//			if(!noeud_pere.contient(str_lien)) {
//			    noeud.ajouterEnfant(str_lien);
//			    nb_liens_totaux++;
//			}
		}
		for(int i=0; i<noeud.getNbEnfant(); i++) {
			if(noeud.getEnfants().get(i).getProfondeur()+1 <= this.profondeur) {
//				charger(noeud.getEnfants().get(i));
			}
		}
	}

}
