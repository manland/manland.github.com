package Graphique;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;

import Controleur.ControleurBarreAdresse;

public class BarreAdresse extends JPanel
{
	// Hbox contenant tous les boutons :
	private Box hBox;

	// pour les liens
	private JLabel label_lien_dossier;
	private JTextField text_field_lien_dossier;

	// pour les niveaux
	private JLabel label_niveau_dossier;
	private JTextField text_field_niveau_dossier;
	
	// pour l'adresse du site :
	private JLabel label_adr_dossier1;
	private JLabel label_adr_dossier2;
	private JTextField text_field_adr_dossier;
	private ImageIcon icon_ok_dossier;
	private JButton btn_ok_dossier;
	
	// bouton permettant de réafficher la fenetre qui a été fermée :
	private JButton btn_ouvrir_fenetre;
	private ImageIcon icon_ouvrir_fenetre;
	
	// controleur :
	ControleurBarreAdresse controleur;
	
	InternalFrameOnglet frame_onglet;
	
	public BarreAdresse() 
	{
		super();
		controleur = new ControleurBarreAdresse(this);
		frame_onglet = null;
		initialisation();
		
	}
	
	public void initialisation()
	{
		Dimension taille_text_field = new Dimension(30, 30);
		Dimension taille_text_field_large = new Dimension(150, 30);
		Dimension taille_bouton = new Dimension(30, 30);
		
		// intialisation de l'hBox:
		hBox = Box.createHorizontalBox();
		
		// pour les liens
		label_lien_dossier = new JLabel("Eléments");
		text_field_lien_dossier = new JTextField();
		text_field_lien_dossier.setMinimumSize(taille_text_field);
		text_field_lien_dossier.setMaximumSize(taille_text_field);
		text_field_lien_dossier.setSize(taille_text_field);
		text_field_lien_dossier.setPreferredSize(taille_text_field);
		// ajout des controleurs 
		text_field_lien_dossier.addActionListener(controleur);
		hBox.add(label_lien_dossier);
		hBox.add(text_field_lien_dossier);
		
		
		hBox.add(new JSeparator());   
		
		// pour les niveau
		label_niveau_dossier = new JLabel("Niveaux");
		text_field_niveau_dossier = new JTextField();
		text_field_niveau_dossier.addActionListener(controleur);
		text_field_niveau_dossier.setMinimumSize(taille_text_field);
		text_field_niveau_dossier.setMaximumSize(taille_text_field);
		text_field_niveau_dossier.setSize(taille_text_field);
		text_field_niveau_dossier.setPreferredSize(taille_text_field);
		hBox.add(label_niveau_dossier);
		hBox.add(text_field_niveau_dossier);
		
		
		hBox.add(new JSeparator());
		
		// pour l'adresse du site :
		Box vbox_adr_dossier = Box.createVerticalBox();
		label_adr_dossier1 = new JLabel("Adresse"); 
		label_adr_dossier2=new JLabel("du dossier :");
		text_field_adr_dossier = new JTextField();
		icon_ok_dossier = new ImageIcon("Images/Barre_Outil/ok.png");
		btn_ok_dossier = new JButton(icon_ok_dossier);
		btn_ok_dossier.setMinimumSize(taille_bouton);
		btn_ok_dossier.setMaximumSize(taille_bouton);
		btn_ok_dossier.setSize(taille_bouton);
		btn_ok_dossier.setPreferredSize(taille_bouton);
		text_field_adr_dossier.setMinimumSize(taille_text_field_large);
		text_field_adr_dossier.setMaximumSize(taille_text_field_large);
		text_field_adr_dossier.setSize(taille_text_field_large);
		text_field_adr_dossier.setPreferredSize(taille_text_field_large);
		// ajout des controleurs :
		btn_ok_dossier.addActionListener(controleur);
		text_field_adr_dossier.addActionListener(controleur);
		text_field_adr_dossier.addCaretListener(controleur);
		
		// bouton permettant de reouvrir la fenetre qui a été fermée :
		icon_ouvrir_fenetre = new ImageIcon("Images/Barre_Outil/fenetre6.png");
		btn_ouvrir_fenetre = new JButton(icon_ouvrir_fenetre);
		btn_ouvrir_fenetre.setMinimumSize(taille_bouton);
		btn_ouvrir_fenetre.setMaximumSize(taille_bouton);
		btn_ouvrir_fenetre.setSize(taille_bouton);
		btn_ouvrir_fenetre.setPreferredSize(taille_bouton);
		btn_ouvrir_fenetre.setVisible(false);
		btn_ouvrir_fenetre.addActionListener(controleur);
		
		vbox_adr_dossier.add(label_adr_dossier1);
		vbox_adr_dossier.add(label_adr_dossier2);
		hBox.add(vbox_adr_dossier);
		hBox.add(text_field_adr_dossier);
		hBox.add(btn_ok_dossier);
		hBox.add(btn_ouvrir_fenetre);
		this.add(hBox);
	}

	
	// accesseurs :
	public JTextField getText_field_lien_dossier() { return text_field_lien_dossier; }
	public void setText_field_lien_dossier(JTextField textFieldLienDossier) { text_field_lien_dossier = textFieldLienDossier; }

	public JTextField getText_field_niveau_dossier() { return text_field_niveau_dossier; }
	public void setText_field_niveau_dossier(JTextField textFieldNiveauDossier) { text_field_niveau_dossier = textFieldNiveauDossier; }

	public JTextField getText_field_adr_dossier() { return text_field_adr_dossier; }
	public void setText_field_adr_dossier(JTextField textFieldAdrDossier) { text_field_adr_dossier = textFieldAdrDossier; }

	public JButton getBtn_ok_dossier() {  return btn_ok_dossier; }
	public void setBtn_ok_dossier(JButton btnOkDossier) { btn_ok_dossier = btnOkDossier; }
 
	public ImageIcon getIcon_ok_dossier() { return icon_ok_dossier; }
	public void setIcon_ok_dossier(ImageIcon iconOkDossier) { icon_ok_dossier = iconOkDossier; 	}

	public InternalFrameOnglet getFrame_onglet() { 	return frame_onglet; }
	public void setFrame_onglet(InternalFrameOnglet frame_onglet) {	
		this.frame_onglet = frame_onglet; 
		frame_onglet.addComponentListener(controleur);
	}

	public JButton getBtn_ouvrir_fenetre() { return btn_ouvrir_fenetre; }
	public void setBtn_ouvrir_fenetre(JButton btnOuvrirFenetre) { btn_ouvrir_fenetre = btnOuvrirFenetre; 	}

	public ControleurBarreAdresse getControleur() { return controleur; }
	public void setControleur(ControleurBarreAdresse controleur) { this.controleur = controleur; }

	
	
	
	
}
