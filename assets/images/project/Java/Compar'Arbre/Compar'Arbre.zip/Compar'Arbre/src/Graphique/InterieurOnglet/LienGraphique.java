package Graphique.InterieurOnglet;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Line2D;

import javax.swing.JComponent;

import Coeur.AbstractNoeud;
import Coeur.IEcouteurModele;

public class LienGraphique extends JComponent implements IEcouteurPoignetLien {

	private AbstractNoeud noeud_pere;
	private PoignetLien poignet;
	private Color bordure = Color.lightGray;
	private PanelOnglet panel_onglet;
	
	public LienGraphique(PanelOnglet parent, AbstractNoeud noeud_pere, PoignetLien poignet) {
		this.panel_onglet = parent;
		this.noeud_pere = noeud_pere;
		this.poignet = poignet;
		poignet.ajouterEcouteur(this);
		calibre();
	}
	
	protected void paintComponent(Graphics g) {
		calibre();
		Graphics2D g2d = (Graphics2D)g;
		g2d.setPaint(bordure);
		int poignet_x_milieu = poignet.getX()+(poignet.getWidth()/2);
		if((noeud_pere.getXMilieu()<poignet_x_milieu && noeud_pere.getYBas()<poignet.getY()) ||
				(noeud_pere.getXMilieu()>poignet_x_milieu && noeud_pere.getYBas()>poignet.getY())) {
			//le lien va de gauche a droite
			g.drawLine(0, 0, getWidth(), getHeight());
		}
		else {
			//le lien va de droite à gauche
			g.drawLine(0, getHeight(), getWidth(), 0);
		}
		
	}
	
	private void calibre() {
		int poignet_x_milieu = poignet.getX()+(poignet.getWidth()/2);
		Dimension dimension = new Dimension(Math.max(noeud_pere.getXMilieu(), poignet_x_milieu)-
				Math.min(noeud_pere.getXMilieu(), poignet_x_milieu), 
				Math.max(noeud_pere.getYBas(), poignet.getY())-
				Math.min(noeud_pere.getYBas(), poignet.getY()));
		if(dimension.getWidth() <= 0) {
			dimension.setSize(1, dimension.getHeight());
		}
		if(dimension.getHeight() <= 0) {
			dimension.setSize(dimension.getWidth(), 1);
		}
		
		setLocation(Math.min(noeud_pere.getXMilieu(), poignet_x_milieu), 
				Math.min(noeud_pere.getYBas(), poignet.getY()));
		
		setSize(dimension);
		setPreferredSize(dimension);
		setMaximumSize(dimension);
		setMinimumSize(dimension);
	}

	@Override
	public void changementSelection(boolean selectionne) {
		if(!selectionne) {
			bordure = Color.lightGray;
		}
		else {
			bordure = Color.black;
		}
		repaint();
	}

	@Override
	public void changementVisibilite(boolean visible) {
		setVisible(visible);
	}

	@Override
	public void changementCouleurFond(Color couleurFond) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changementCouleurTexte(Color couleurTexte) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deplacementPoignet(int x, int y) {
		repaint();
	}

	@Override
	public void changementDePere(AbstractNoeud pere) {
		this.noeud_pere = pere;
		repaint();
	}
}
