package Controleur;

import java.util.Date;
import java.util.Vector;

import Coeur.AbstractNoeud;

public class RechercheDansPlusieursArbres 
{

	public RechercheDansPlusieursArbres()
	{
		super();
	}

	
	public static Vector<AbstractNoeud> rechercheParNomExact(Vector<AbstractNoeud> tous_les_noeuds, String nom)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAvecNom(nom));
		}
		return res;
	}
	
	public static Vector<AbstractNoeud> rechercheParNomContient(Vector<AbstractNoeud> tous_les_noeuds, String nom)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsContenantMot(nom));
		}
		return res;
	}
	
	public static Vector<AbstractNoeud> rechercheParExtension(Vector<AbstractNoeud> tous_les_noeuds, String ext)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherToutesFeuillesExtension(ext));
		}
		return res;		
	}

	public static Vector<AbstractNoeud> rechercheParDate(Vector<AbstractNoeud> tous_les_noeuds, Date date)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAyantDateDeModif(date));
		}
		return res;		
	}
	
	public static Vector<AbstractNoeud> rechercheParDateAvant(Vector<AbstractNoeud> tous_les_noeuds, Date date)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAyantDateDeModifAvant(date));
		}
		return res;		
	}
	
	public static Vector<AbstractNoeud> rechercheParDateApres(Vector<AbstractNoeud> tous_les_noeuds, Date date)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAyantDateDeModifApres(date));
		}
		return res;		
	}
	
	public static Vector<AbstractNoeud> rechercheParDateEntre(Vector<AbstractNoeud> tous_les_noeuds, Date date_debut,Date date_fin)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAyantDateDeModifEntre(date_debut, date_fin));
		}
		return res;		
	}
	
	public static Vector<AbstractNoeud> rechercheParPoidsExact(Vector<AbstractNoeud> tous_les_noeuds, String poids)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAvecPoids(Integer.parseInt(poids)));
		}
		return res;		
	}

	public static Vector<AbstractNoeud> rechercheParPoidsInferieur(Vector<AbstractNoeud> tous_les_noeuds, String poids)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAvecPoidsInf(Integer.parseInt(poids)));
		}
		return res;		
	}
	
	public static Vector<AbstractNoeud> rechercheParPoidsSuperieur(Vector<AbstractNoeud> tous_les_noeuds, String poids)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAvecPoidsSup(Integer.parseInt(poids)));
		}
		return res;		
	}
	
	public static Vector<AbstractNoeud> rechercheParPoidsEntre(Vector<AbstractNoeud> tous_les_noeuds, String poids_min, String poids_max)
	{
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		for(int i=0; i<tous_les_noeuds.size(); i++)
		{
			res.addAll(tous_les_noeuds.get(i).rechercherTousNoeudsAvecPoidsEntre(Integer.parseInt(poids_min),Integer.parseInt(poids_max)));
		}
		return res;		
	}
	
	// en parametre lui passé : vecteur de recherche 
	public static Vector<AbstractNoeud> rechercheMultiple(Vector<Vector<AbstractNoeud>> vec_recherche)
	{		
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		System.out.println("ds fct taille vec :"+vec_recherche.size());
		if(vec_recherche.size()>=2)
		{
			res = vec_recherche.get(0);	 // on récupere la premiere recherche
			for(int i=1; i<vec_recherche.size(); i++)
			{
				// on ne retient que ce qui est commun :
				res.retainAll(vec_recherche.get(i));
			}
		}
		else
		{
			res = vec_recherche.get(0);
		}
		return res;
		
	}
	
}
