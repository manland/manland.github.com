package Graphique.InterieurOnglet;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class MenuPanelOnglet extends JPopupMenu implements ActionListener {
	private PanelOnglet panel_onglet;
	
	public MenuPanelOnglet(PanelOnglet panel_onglet) {
		this.panel_onglet = panel_onglet;
		
		JMenuItem item = new JMenuItem("Afficher l'aide");
		item.addActionListener(this);
		add(item);
		addSeparator();
		item = new JMenuItem("Sélectionner tous les noeuds");
		item.addActionListener(this);
		add(item);
		item = new JMenuItem("Désélectionner tous les noeuds");
		item.addActionListener(this);
		add(item);
		addSeparator();
		item = new JMenuItem("Afficher toutes les informations (cachées)");
		item.addActionListener(this);
		add(item);
		item = new JMenuItem("Cacher toutes les informations");
		item.addActionListener(this);
		add(item);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		JMenuItem item = null;
		try {
			item = (JMenuItem)e.getSource();
		}
		catch(ClassCastException cce) {
			return;
		}
		if(item.getText().equals("Afficher l'aide")) {
			panel_onglet.getComponentAide().setVisible(true);
		}
		else if(item.getText().equals("Sélectionner tous les noeuds")) {
			if(panel_onglet.getNoeudRoot() != null) {
				panel_onglet.getNoeudRoot().selectionMoiEtTousMesFils();
			}
		}
		else if(item.getText().equals("Désélectionner tous les noeuds")) {
			if(panel_onglet.getNoeudRoot() != null) {
				panel_onglet.getNoeudRoot().deselectionMoiEtTousMesFils();
			}
		}
		else if(item.getText().equals("Afficher toutes les informations (cachées)")) {
			Component [] components = panel_onglet.getComponents();
			for(int i=0; i<components.length; i++) {
				InfosNoeud n = null;
				try {
					n = (InfosNoeud)components[i];
				}
				catch(ClassCastException cce) {
					;
				}
				if(n != null) {
					n.setVisible(true);
				}
			}
		}
		else if(item.getText().equals("Cacher toutes les informations")) {
			Component [] components = panel_onglet.getComponents();
			for(int i=0; i<components.length; i++) {
				InfosNoeud n = null;
				try {
					n = (InfosNoeud)components[i];
				}
				catch(ClassCastException cce) {
					;
				}
				if(n != null) {
					n.setVisible(false);
				}
			}
		}
	}

}
