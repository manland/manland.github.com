package Coeur;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

public abstract class AbstractNoeud implements Cloneable {
	protected AbstractInfos fichier;
	protected Noeud pere;
	protected int profondeur;
	protected boolean selectionne;
	protected boolean visible;
	private Vector<IEcouteurModele> ecouteurs;
	private int x;
	private int y;
	private int largeur;
	private int hauteur;
	private int largeur_min;
	private int hauteur_min;
	private int rang;
	private Color couleur_fond;
	private Color couleur_texte;
	private Color couleur_bordure;
	
	public AbstractNoeud(AbstractInfos file, Noeud pere, int profondeur) {
		this.fichier = file;
		this.pere = pere;
		this.profondeur = profondeur;
		ecouteurs = new Vector<IEcouteurModele>();
		x = 0;
		y = 0;
		largeur = 80;
		hauteur = 20;
		largeur_min = 80;
		hauteur_min = 20;
		rang = 0;
		selectionne = false;
		visible = true;
	}
	
	public abstract AbstractNoeud clone();
	
	public void ajouterEcouteurModele(IEcouteurModele ecouteur) {
		ecouteurs.add(ecouteur);
	}
	
	public Noeud getPere() {
		return pere;
	}

	public void setPere(Noeud pere) {
		this.pere = pere;
	}
	
	public int getProfondeur() {
		return profondeur;
	}

	public void setProfondeur(int profondeur) {
		this.profondeur = profondeur;
	}
	
	public boolean isNoeud() {
		return fichier.isDossier();
	}
	
	public boolean isFeuille() {
		return fichier.isFichier();
	}
	
	public String getUrl() {
		return fichier.getUrl();
	}
	
	public AbstractInfos getFichier() {
		return fichier;
	}
	
	public Color getCouleurFond() {
		return couleur_fond;
	}
	
	public void setCouleurFond(Color c) {
		couleur_fond = c;
		fireCouleurFond();
	}
	
	public void fireCouleurFond() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementCouleurFond(couleur_fond);
		}
	}
	
	public Color getCouleurTexte() {
		return couleur_texte;
	}
	
	public void setCouleurTexte(Color c) {
		couleur_texte = c;
		fireCouleurTexte();
	}
	
	public void fireCouleurTexte() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementCouleurTexte(couleur_texte);
		}
	}
	
	public Color getCouleurBordure() {
		return couleur_bordure;
	}
	
	public void setCouleurBordure(Color c) {
		couleur_bordure = c;
		fireCouleurBordure();
	}
	
	public void fireCouleurBordure() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementCouleurBordure(couleur_bordure);
		}
	}
	
	public boolean getSelectionne() {
		return selectionne;
	}
	
	public void setSelectionne(boolean selectionne) {
		this.selectionne = selectionne;
		fireSelectionne();
	}
	
	public void fireSelectionne() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementSelection(selectionne);
		}
	}
	
	public boolean getVisible() {
		return visible;
	}
	
	public void setVisible(boolean visible) {
		this.visible = visible;
		fireVisible();
	}
	
	public void fireVisible() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).changementVisibilite(visible);
		}
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
		fireDeplacement();
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		this.y = y;
		fireDeplacement();
	}
	
	public void setXPlusEnfants(int x) {
		this.x = this.x - x;
		fireDeplacement();
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).setXPlusEnfants(x);
			}
		}
	}
	
	public void setXPlusEnfantsSansDecalage(int x) {
		this.x = x;
		fireDeplacement();
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).setXPlusEnfants(x);
			}
		}
	}
	
	public void setYPlusEnfants(int y) {
		this.y = this.y - y;
		fireDeplacement();
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).setYPlusEnfants(y);
			}
		}
	}
	
	public void setYPlusEnfantsSansDecalage(int y) {
		this.y = y;
		fireDeplacement();
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).setYPlusEnfants(y);
			}
		}
	}
	
	public void fireDeplacement() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).deplacement(x, y);
		}
	}
	
	public int getLargeur() {
		return largeur;
	}
	
	public void setLargeur(int largeur) {
		this.largeur = largeur;
		fireRedimensionnement();
	}
	
	public int getHauteur() {
		return hauteur;
	}
	
	public void setHauteur(int hauteur) {
		this.hauteur = hauteur;
		fireRedimensionnement();
	}
	
	public void fireRedimensionnement() {
		for(int i=0; i<ecouteurs.size(); i++) {
			ecouteurs.get(i).redimensionnement(largeur, hauteur);
		}
	}
	
	public int getXMilieu() {
		return x+(largeur/2);
	}
	
	public int getYBas() {
		return y+hauteur;
	}
	
	public void setRang(int rang) {
		this.rang = rang;
	}
	
	public int getRang() {
		return rang;
	}
	
	public static int getProfondeurMax(AbstractNoeud noeud) {
		if(noeud.isNoeud()) {
			Noeud n = (Noeud)noeud;
			if(n.getNbEnfant()>0) {
				int max = getProfondeurMax(n.getEnfant(0));
				for(int i=1; i<n.getNbEnfant(); i++) {
					int prof = getProfondeurMax(n.getEnfant(i));
					if(max < prof) {
						max = prof;
					}
				}
				return max;
			}
		}
		return noeud.getProfondeur();
	}
	
	public void selectionMoiEtTousMesFils() {
		setSelectionne(true);
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).selectionMoiEtTousMesFils();
			}
		}
	}
	
	public void deselectionMoiEtTousMesFils() {
		setSelectionne(false);
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).deselectionMoiEtTousMesFils();
			}
		}
	}
	
	public void cacherTousMesFils() {
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).cacherMoiEtTousMesFils();
			}
		}
	}
	
	public void cacherMoiEtTousMesFils() {
		setVisible(false);
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).cacherMoiEtTousMesFils();
			}
		}
	}
	
	public void afficherTousMesFils() {
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).afficherMoiEtTousMesFils();
			}
		}
	}
	
	public void afficherMoiEtTousMesFils() {
		setVisible(true);
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				n.getEnfant(i).afficherMoiEtTousMesFils();
			}
		}
	}
	
	public void zoom(double facteur) {
		int largeur_apres_zoom = (int)(largeur*facteur);
		int hauteur_apres_zoom = (int)(hauteur*facteur);
		if(largeur_apres_zoom >= largeur_min && hauteur_apres_zoom >= hauteur_min) {
			setLargeur(largeur_apres_zoom);
			setHauteur(hauteur_apres_zoom);
		}
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAvecNom(String nom) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getNom().equals(nom)) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAvecNom(nom));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsContenantMot(String mot) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getNom().contains(mot)) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsContenantMot(mot));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAyantDateDeModif(Date date) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		Calendar mon_cal = Calendar.getInstance();
		mon_cal.setTime(getFichier().getDerniereModification());
		if (mon_cal.get(Calendar.YEAR) == cal.get(Calendar.YEAR) && 
			mon_cal.get(Calendar.MONTH) == cal.get(Calendar.MONTH) && 
			mon_cal.get(Calendar.DATE) == cal.get(Calendar.DATE)) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAyantDateDeModif(date));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAyantDateDeModifAvant(Date date) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getDerniereModification().before(date)) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAyantDateDeModifAvant(date));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAyantDateDeModifApres(Date date) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getDerniereModification().after(date)) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAyantDateDeModifApres(date));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAyantDateDeModifEntre(Date date, Date date2) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getDerniereModification().after(date) && getFichier().getDerniereModification().before(date2)) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAyantDateDeModifApres(date));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherToutesFeuillesExtension(String extension) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		Noeud n = (Noeud)this;
		if(n != null) {
			for(int i=0; i<n.getNbEnfant(); i++) {
				if(n.getEnfant(i).isFeuille()) {
					if(((InfosFichier)n.getEnfant(i).getFichier()).getExtension().equals(extension)) {
						res.add((Feuille)n.getEnfant(i));
					}
				}
				else {
					res.addAll(((Noeud)n.getEnfant(i)).rechercherToutesFeuillesExtension(extension));
				}
			}
		}
		else {
			Feuille f = (Feuille)this;
			if(f.equals(extension)) {
				res.add(this);
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAvecPoids(int poids) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getTaille() == poids) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAvecPoids(poids));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAvecPoidsSup(int poids) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getTaille() > poids) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAvecPoidsSup(poids));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAvecPoidsInf(int poids) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getTaille() < poids) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAvecPoidsInf(poids));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> rechercherTousNoeudsAvecPoidsEntre(int poids, int poids2) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(getFichier().getTaille() > poids && getFichier().getTaille() < poids2) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).rechercherTousNoeudsAvecPoidsSup(poids));
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> toutLArbreEnVecteur() {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		res.add(this);
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).toutLArbreEnVecteur());
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> tousLesNoeudsSelectionnes() {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		if(selectionne) {
			res.add(this);
		}
		if(isNoeud()) {
			Noeud n = (Noeud)this;
			for(int i=0; i<n.getNbEnfant(); i++) {
				res.addAll(n.getEnfant(i).tousLesNoeudsSelectionnes());
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> intersectionParNomAvec(AbstractNoeud un_autre_arbre) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		Vector<AbstractNoeud> cet_arbre = toutLArbreEnVecteur();
		for(int i=0; i<cet_arbre.size(); i++) {
			Vector<AbstractNoeud> res_autre_arbre = un_autre_arbre.rechercherTousNoeudsAvecNom(cet_arbre.get(i).getFichier().getNom());
			if(res_autre_arbre.size()>0) {
				res.add(cet_arbre.get(i));
				for(int j=0; j<res_autre_arbre.size(); j++) {
					res.add(res_autre_arbre.get(j));
				}
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> intersectionParPoidsAvec(AbstractNoeud un_autre_arbre) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		Vector<AbstractNoeud> cet_arbre = toutLArbreEnVecteur();
		for(int i=0; i<cet_arbre.size(); i++) {
			Vector<AbstractNoeud> res_autre_arbre = un_autre_arbre.rechercherTousNoeudsAvecPoids((int)cet_arbre.get(i).getFichier().getTaille());
			if(res_autre_arbre.size()>0) {
				res.add(cet_arbre.get(i));
				for(int j=0; j<res_autre_arbre.size(); j++) {
					res.add(res_autre_arbre.get(j));
				}
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> intersectionParDateAvec(AbstractNoeud un_autre_arbre) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		Vector<AbstractNoeud> cet_arbre = toutLArbreEnVecteur();
		for(int i=0; i<cet_arbre.size(); i++) {
			Vector<AbstractNoeud> res_autre_arbre = un_autre_arbre.rechercherTousNoeudsAyantDateDeModif(cet_arbre.get(i).getFichier().getDerniereModification());
			if(res_autre_arbre.size()>0) {
				res.add(cet_arbre.get(i));
				for(int j=0; j<res_autre_arbre.size(); j++) {
					res.add(res_autre_arbre.get(j));
				}
			}
		}
		return res;
	}
	
	public Vector<AbstractNoeud> intersectionParExtensionAvec(AbstractNoeud un_autre_arbre) {
		Vector<AbstractNoeud> res = new Vector<AbstractNoeud>();
		Vector<AbstractNoeud> cet_arbre = toutLArbreEnVecteur();
		for(int i=0; i<cet_arbre.size(); i++) {
			if(cet_arbre.get(i).isFeuille()) {
				InfosFichier f = (InfosFichier)this.getFichier();
				Vector<AbstractNoeud> res_autre_arbre = un_autre_arbre.rechercherToutesFeuillesExtension(f.getExtension());
				if(res_autre_arbre.size()>0) {
					res.add(cet_arbre.get(i));
					for(int j=0; j<res_autre_arbre.size(); j++) {
						res.add(res_autre_arbre.get(j));
					}
				}
			}
		}
		return res;
	}
	
	public abstract String toStringPourEnregistrer();
	
	public void enregistrer(String url) {
		try { 
			FileWriter lu = new FileWriter(url);
			BufferedWriter out = new BufferedWriter(lu);
			out.write(toStringPourEnregistrer());
			out.close();
		 } 
		catch (IOException er) {
			er.printStackTrace();
		}
	}
	
	public static Noeud restaurerArbre(String url) {
		Noeud noeud_root = null;
		HashMap<String, Noeud> les_noeud_restaures = new HashMap<String, Noeud>();
		try{
			InputStream ips=new FileInputStream(url); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;
			while ((ligne=br.readLine())!=null){
				String [] coupe = ligne.split(";;");
				String type = coupe[0];
				String url_noeud = coupe[1];
				String url_pere = coupe[2];
				int profondeur = Integer.parseInt(coupe[3]);
				if(type.equals("noeud") && url_pere.equals("null")) {
					noeud_root = new Noeud(new InfosDossier(new File(url_noeud)), null, profondeur);
					les_noeud_restaures.put(url_noeud, noeud_root);
				}
				else if(type.equals("noeud")) {//noeud
					Noeud noeud_pere = les_noeud_restaures.get(url_pere);
					if(noeud_pere != null) {
						Noeud n = new Noeud(new InfosDossier(new File(url_noeud)), noeud_pere, profondeur);
						noeud_pere.ajouterEnfant(n);
						les_noeud_restaures.put(url_noeud, n);
					}
				}
				else {//feuille
					Noeud noeud_pere = les_noeud_restaures.get(url_pere);
					if(noeud_pere != null) {
						Feuille f = new Feuille(new InfosFichier(new File(url_noeud)), noeud_pere, profondeur);
						noeud_pere.ajouterEnfant(f);
					}
				}
			}
			br.close(); 
		}		
		catch (Exception e){
			System.out.println(e.toString());
		}
		return noeud_root;
	}
	
	public String toString() {
		String res = "";
		for(int e=0; e<profondeur; e++) {
			res += "\t";
		}
		res += fichier.getUrl();
		res += " (profondeur:" + profondeur + "; rang:"+rang+")\n";
		return res;
	}
}
