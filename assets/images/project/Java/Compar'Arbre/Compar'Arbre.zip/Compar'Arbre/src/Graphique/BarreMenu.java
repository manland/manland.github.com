package Graphique;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;


public class BarreMenu extends JMenuBar implements ActionListener
{
	// menu fichier :
	private JMenu menu_fichier;
	private JMenuItem nouveau_paneau;
	private JMenuItem ouvrir;
	private JMenuItem enregistrer;
	private JMenuItem quitter;
	
	// menu edition : 
	private JMenu menu_edition;
	private JMenuItem recherche;
	private JMenuItem coller;
	
	// menu aide: 
	private JMenu menu_aide;
	private JMenuItem afficher_aide_panel;
	
	private FenetrePrincipale fenetre_principale;
	
	public BarreMenu(FenetrePrincipale fenetre_principale) throws HeadlessException {
		super();
		this.fenetre_principale = fenetre_principale;
		initialisation();
	}


	private void initialisation() 
	{
		// menu fichier 
		menu_fichier = new JMenu("Fichier");	
		nouveau_paneau = new JMenuItem("Nouveau panneau");
		nouveau_paneau.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
		nouveau_paneau.addActionListener(this);
		ouvrir = new JMenuItem("Ouvrir");
		ouvrir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		ouvrir.addActionListener(this);
		enregistrer = new JMenuItem("Enregistrer");
		enregistrer.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
		enregistrer.addActionListener(this);
		quitter = new JMenuItem("Quitter");
		quitter.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
		quitter.addActionListener(this);
		
		menu_fichier.add(nouveau_paneau);
		menu_fichier.add(ouvrir);
		menu_fichier.add(enregistrer);
		menu_fichier.addSeparator();
		menu_fichier.add(quitter);
	
		
		// menu edition
		menu_edition = new JMenu("Affichage");
		recherche = new JMenuItem("Recherche");
		recherche.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
		recherche.addActionListener(this);
		coller = new JMenuItem("Coller");
		coller.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
		coller.addActionListener(this);
		menu_edition.add(recherche);
		menu_edition.add(coller);
		
		
		// menu aide
		menu_aide = new JMenu("Aide");
		afficher_aide_panel = new JMenuItem("Afficher l'aide");
		afficher_aide_panel.addActionListener(this);
		menu_aide.add(afficher_aide_panel);
		
		 	
		this.add(menu_fichier);
		this.add(menu_edition);
		this.add(menu_aide);
	}


	@Override
	public void actionPerformed(ActionEvent event) 
	{
		try {
			JMenuItem item = ((JMenuItem)(event.getSource()));
			if(item == nouveau_paneau)
			{
				if(!fenetre_principale.getBarre_outil().getControleur().isDeuxieme_fenetre_deja_affichee()) {
					int largeur_frame_init = fenetre_principale.getZone_desktop().getInternal_frame_onglet().getWidth();
					int hauteur_frame_init = fenetre_principale.getZone_desktop().getInternal_frame_onglet().getHeight();
					int moitie_taille_frame_init = (int)largeur_frame_init/2;
					
					InternalFrameOnglet nouvelle_frame = new InternalFrameOnglet();
					fenetre_principale.getZone_desktop().getInternal_frame_onglet().setSize(moitie_taille_frame_init,hauteur_frame_init);
					fenetre_principale.getZone_desktop().getInternal_frame_onglet().setLocation(0, 0);
					nouvelle_frame.setSize(fenetre_principale.getZone_desktop().getInternal_frame_onglet().getWidth(),fenetre_principale.getZone_desktop().getInternal_frame_onglet().getHeight());
					nouvelle_frame.setLocation(fenetre_principale.getZone_desktop().getInternal_frame_onglet().getWidth()-6,fenetre_principale.getZone_desktop().getInternal_frame_onglet().getY());
					
					fenetre_principale.getBarre_outil().getBarre_adresse_dossier2().setFrame_onglet(nouvelle_frame);
					fenetre_principale.getZone_desktop().add(nouvelle_frame);
					fenetre_principale.getBarre_outil().getBarre_adresse_dossier2().setVisible(true);
					fenetre_principale.getBarre_outil().getControleur().setDeuxieme_fenetre_deja_affichee(true);
					
					fenetre_principale.getZone_desktop().ajouterOngletAVecteur(nouvelle_frame);
					if(fenetre_principale.getBarre_outil().getControleur().isDeuxieme_fenetre_deja_affichee())
					{
						fenetre_principale.getBarre_outil().getBtn_plus().setEnabled(false);
						nouveau_paneau.setEnabled(false);
					}
				}
			}
			else if(item == ouvrir)
			{
				JFileChooser chooser = new JFileChooser();
				int returnVal = chooser.showOpenDialog(chooser);
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			    	fenetre_principale.getZone_desktop().getInternal_frame_onglet().getTab_onglet().getPanelOnglet().clear();
			    	fenetre_principale.getBarre_outil().getBarre_adresse_dossier1().getText_field_adr_dossier().setText(chooser.getSelectedFile().getAbsolutePath());
			    	fenetre_principale.getZone_desktop().getInternal_frame_onglet().getTab_onglet().getPanelOnglet().restaurerArbre(chooser.getSelectedFile().getAbsolutePath());
			    }
			}
			else if(item == enregistrer)
			{
				JFileChooser chooser = new JFileChooser();
				int returnVal = chooser.showOpenDialog(chooser);
			    if(returnVal == JFileChooser.APPROVE_OPTION) {
			    	fenetre_principale.getZone_desktop().getInternal_frame_onglet().getTab_onglet().getPanelOnglet().enregistrer(chooser.getSelectedFile().getAbsolutePath());
			    }
			}
			else if(item == quitter)
			{
				System.exit(0);				
			}
			else if(item == recherche)
			{
				fenetre_principale.getZone_desktop().getInternal_frame_recherche().setVisible(true);
			}
			else if(item == afficher_aide_panel)
			{
				fenetre_principale.getZone_desktop().getInternal_frame_onglet().getTab_onglet().getPanelOnglet().getComponentAide().setVisible(true);
			}
		}
		catch (Exception t)
		{
			System.out.println("erreur");
		}			
	}
}
