package Graphique;

import javax.swing.JDesktopPane;
import javax.swing.SwingUtilities;

public class main {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		JDesktopPane desktop = new JDesktopPane();
		FenetrePrincipale fenetre_principale = new FenetrePrincipale("Compar'Arbre");
		
	 	  try {
	 //       UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	// Pour les inconditionnels de motif/CDE
//			UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
	          
// par celui du systeme:  
	//            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
// GTK :  UIManager.setLookAndFeel("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
//metal :  UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");

			SwingUtilities.updateComponentTreeUI(fenetre_principale);
		  } catch (Exception exc2) {
			    exc2.printStackTrace();
			    System.err.println("Could not load LookAndFeel: ");
			    exc2.printStackTrace();
		 }
		
		
		fenetre_principale.pack();
		fenetre_principale.setVisible(true);
	}
}
