package Graphique;

import java.awt.Container;
import javax.swing.JInternalFrame;

public class InternalFrameRecherche extends JInternalFrame 
{
	private TabOngletRecherche tab_onglet_recherche;
	private Container c;

	public InternalFrameRecherche()
	{
		super();
		this.setResizable(true);
		this.setClosable(true);
		this.setIconifiable(false);
		this.setMaximizable(false);
		this.setTitle("Recherche");
		this.setSize(285,425);
		this.setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);
		initialisation();
		this.setVisible(true);
	}
	
	public void initialisation()
	{	
		c=this.getContentPane();
		tab_onglet_recherche = new TabOngletRecherche(this);
		c.add(tab_onglet_recherche);
	}

	public TabOngletRecherche getTab_onglet_recherche() { return tab_onglet_recherche; }
 	public void setTab_onglet_recherche(TabOngletRecherche tabOngletRecherche) { tab_onglet_recherche = tabOngletRecherche;	}
	
	
	
}
