package Controleur;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import Graphique.TabOnglet;

public class ControleurTabOnglet implements MouseListener
{
	private TabOnglet tab_onglet;

	public ControleurTabOnglet(TabOnglet tabOnglet) {
		super();
		tab_onglet = tabOnglet;
	}


	@Override
	public void mouseClicked(MouseEvent e) {
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	// accesseurs :
	public TabOnglet getTab_onglet() {  return tab_onglet; }
	public void setTab_onglet(TabOnglet tabOnglet) { tab_onglet = tabOnglet; }

}
