package Graphique.InterieurOnglet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import Coeur.AbstractNoeud;
import Coeur.Noeud;

public class MenuNoeudGraphique extends JPopupMenu implements ActionListener {
	private NoeudGraphique noeud;
	
	public MenuNoeudGraphique(NoeudGraphique noeud) {
		this.noeud = noeud;
		
		JMenuItem item_afficher_info = new JMenuItem("Afficher informations");
		item_afficher_info.addActionListener(this);
		add(item_afficher_info);
		addSeparator();
		JMenuItem item_selectionner = new JMenuItem("Sélectionner");
		item_selectionner.addActionListener(this);
		add(item_selectionner);
		JMenuItem item_deselectionner = new JMenuItem("Déselectionner");
		item_deselectionner.addActionListener(this);
		add(item_deselectionner);
		if(noeud.getModele().isNoeud()) {
			Noeud n = (Noeud)noeud.getModele();
			if(n.getNbEnfant() > 0) {
				addSeparator();
				JMenuItem item_selectionner_plus_enfant = new JMenuItem("Sélectionner + enfant(s)");
				item_selectionner_plus_enfant.addActionListener(this);
				add(item_selectionner_plus_enfant);
				JMenuItem item_deselectionner_plus_enfant = new JMenuItem("Déselectionner + enfant(s)");
				item_deselectionner_plus_enfant.addActionListener(this);
				add(item_deselectionner_plus_enfant);
				addSeparator();
				JMenuItem item_afficher_enfant = new JMenuItem("Afficher enfant(s)");
				item_afficher_enfant.addActionListener(this);
				add(item_afficher_enfant);
				JMenuItem item_cacher_enfant = new JMenuItem("Cacher enfant(s)");
				item_cacher_enfant.addActionListener(this);
				add(item_cacher_enfant);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JMenuItem item = null;
		try {
			item = (JMenuItem)e.getSource();
		}
		catch(ClassCastException cce) {
			return;
		}
		if(item.getText().equals("Afficher informations")) {
			((PanelOnglet)noeud.getParent()).dessinerInfosNoeud(noeud.getModele());
		}
		else if(item.getText().equals("Sélectionner")) {
			noeud.getModele().setSelectionne(true);
		}
		else if(item.getText().equals("Déselectionner")) {
			noeud.getModele().setSelectionne(false);
		}
		else if(item.getText().equals("Sélectionner + enfant(s)")) {
			noeud.getModele().selectionMoiEtTousMesFils();
		}
		else if(item.getText().equals("Déselectionner + enfant(s)")) {
			noeud.getModele().deselectionMoiEtTousMesFils();
		}
		else if(item.getText().equals("Afficher enfant(s)")) {
			noeud.getModele().afficherTousMesFils();
		}
		else if(item.getText().equals("Cacher enfant(s)")) {
			noeud.getModele().cacherTousMesFils();
		}
	}
}
