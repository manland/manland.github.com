package same;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class StatuBar extends JPanel {

	//Attributs
	/**
	 * Permet la sérialisation.
	 */
	private static final long serialVersionUID = 678275533729192620L;
	/**
	 * Label affichant le nombres de jetons vivants.
	 * @see JLabel
	 */
	private JLabel nbJetons;
	/**
	 * Label affichant le score de la sélection en cours.
	 * @see JLabel
	 */
	private JLabel scoreSelection;
	/**
	 * Label affichant le score de la partie.
	 * @see JLabel
	 */
	private JLabel score;
	
	//Constructeur
	/**
	 * Créer la statuBar contenant les 3 JLabel.
	 */
	public StatuBar() {
		nbJetons = new JLabel("nombre de jetons : 0");
		nbJetons.setVisible(true);
		
		scoreSelection = new JLabel("score de la sélection : 0");
		scoreSelection.setVisible(true);
		
		score = new JLabel("score : 0");
		score.setVisible(true);
		
		BorderLayout bl = new BorderLayout();
		setLayout(bl);

		bl.setHgap(50);
		
		add(nbJetons, BorderLayout.LINE_START);
		add(scoreSelection, BorderLayout.CENTER);
		add(score, BorderLayout.LINE_END);
		
		setVisible(true);
	}
	
	//getters & setters
	/**
	 * @param i pour mettre à jours le label du nombre de jetons vivants.
	 */
	public void setNbJetons(int i) {
		nbJetons.setText("nombre de jetons : "+i);
	}
	
	/**
	 * @param i pour mettre à jours le label du score du nombre de jetons sélectionnés.
	 */
	public void setScoreSelection(int i) {
		scoreSelection.setText("score de la sélection : "+i);
	}
	
	/**
	 * @param i pour mettre à jours le label du score.
	 */
	public void setScore(int i) {
		score.setText("score : "+i);
	}
}
