package same;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.io.Serializable;
import java.util.Random;

/**
 * Gère et dessine les pions, fait le relet entre le panneau et les pions.
 * @author Romain Maneschi
 */
public class Grille implements Serializable {

	//Attributs
	 /**
	  * Permet la sérialisation.
	  */
	private static final long serialVersionUID = -2616496253680783809L;
	 /**
	  * Nombre de colonnes de la matrix pions.
	  */
	private static final int nbColonne = 15;
	/**
	 * Nombre de lignes de la matrix pions.
	 */
	private static final int nbLigne = 10;
	/**
	 * Matrix qui contient tous les pions.
	 * Pions[nbColonne][nbLigne]
	 * @see #nbColonne
	 * @see #nbLigne
	 */
	private Pion pions[][];
	/**
	 * Permet de dessiner la couleure de sélection des cases si au moins une case est sélectionnée.
	 */
	private boolean selectionne = false;
	/**
	 * Le score de la partie en cours.
	 */
	private int score;
	/**
	 * Le score de la sélection en cours.
	 */
	private int scoreSelection;
	/**
	 * La 1ere couleur possible pour un pion.
	 */
	private final static Color color1 = new Color(255, 0, 0);
	/**
	 * La 2eme couleur possible pour un pion.
	 */
	private final static Color color2 = new Color(0, 255, 0);
	/**
	 * La 3eme couleur possible pour un pion.
	 */
	private final static Color color3 = new Color(0, 0, 255);
	/**
	 * Si nous souhaitons afficher des images à la place des couleures il suffit de décommenter ces lignes.
	 * Mais cette fonctionnalité n'as pu être implentée faute de temps
	 */
//	private final static Image image1 = Toolkit.getDefaultToolkit().getImage("boulle1.png");
//	private final static Image image2 = Toolkit.getDefaultToolkit().getImage("boulle2.png");
//	private final static Image image3 = Toolkit.getDefaultToolkit().getImage("boulle3.png");
	
	//Constructeur
	/**
	 * Créer une nouvelle grille contenant {@link #nbColonne}*{@link #nbLigne} pions.
	 */
	public Grille() {
		pions = new Pion[nbColonne][nbLigne];
		alea();
		score = 0;
		scoreSelection = 0;
	}

	//Getters & Setters
	 /**
	  * @return le nombre de colonnes de la matrix pions.
	  */
	public int getNbColonne() {
		return nbColonne;
	}
	 /**
	  * @return le nombre de lignes de la matrix de pions.
	  */
	public int getNbLigne() {
		return nbLigne;
	}
	/** 
	 * @return vrai(true) si au moins un pion est sélectionné faux(false) sinon.
	 * @see #setSelectionne(boolean)
	 */
	public boolean getSelectionne() {
		return selectionne;
	}
	/**
	 * Permet de dire à la grille si elle est sélectionnée.
	 * @param s place la grille comme ayant au moins un point sélectionné.
	 * @see #getSelectionne()
	 */
	public void setSelectionne(boolean s) {
		selectionne = s;
	}
	/**
	 * Sert à donner une taille au panneau.
	 * @return retourne la taille du coté d'un point.
	 */
	public int getCotePion() {
		return pions[0][0].getCote();
	}
	/**
	 * Appel la fonction mettreAJour pour initialiser le score.
	 * @return le score de la partie en cours
	 */
	public int getScore(){ 
		mettreAJour();
		return score;
	}
	/**
	 * Appel la fonction mettreAJour pour initialiser le nombre de pionts sélectionnés.
	 * @return le nombre de points correspondant.
	 */
	public int getScoreSelection(){ 
		mettreAJour();
		return scoreSelection;
	}
	/**
	 * Compte le nombre de pions non morts et le retourne.
	 * @return le nombre de pions détruits.
	 */
	public int getNbVivant() {
		int count = 0;
		for(int i=0; i<nbColonne;i++) {
			for (int h=0; h<nbLigne; h++) {
				if(!getPion(i, h).isMort()) 
					count++;
			}
		}
		return count;
	}
	/**
	 * Retourne la référence du pion se trouvant sur ligne l et la conne c de la matrix {@link #pions}.
	 * @param l numéro de la ligne du pion.
	 * @param c numéro de la colonne du pion.
	 * @return la référence du pion[l][c].
	 */
	public Pion getPion(int l, int c) {
		return pions[l][c];
	}
	
	//Méhotdes Privées
	/**
	 * Permet de mettre à jour soit le score soit le score de la sélection en cours.
	 */
	private void mettreAJour() {
		int count = 0;
		for(int i=0; i<nbColonne;i++) {
			for (int h=0; h<nbLigne; h++) {
				if(getPion(i, h).isSelectionne()) 
					count++;
			}
		}
		if(selectionne) {
			scoreSelection = (count-2)*(count-2);
		}
		else {
			score = score + scoreSelection;
			scoreSelection = 0;
		}
	}
	
	/**
	 * Permet d'assigner aux pions une couleure tirée aléatoirement.
	 * !! fonction à modifier pour utiliser des Images !!
	 * !! 		 		juste décommenter      		!!
	 */
	private void alea() {
		int t[] = new int[150];
		for (int i=0; i<150; i++) {
			if(i<50)
				t[i] = 1;
			else if(i>=50 && i<100) 
				t[i] = 2;
			else
				t[i] = 3;
		}
		
		Random aleatoire=new Random();
		
		int coul = 0;
		Color color;
//		Image image;
		for(int i=0; i<nbColonne; i++) {
			for(int h=0; h<nbLigne; h++) {
				coul = t[aleatoire.nextInt(t.length)];
				if(coul == 1) {
					color = color1;
//					image = image1;
				}
				else if(coul == 2) {
					color = color2;
//					image = image2;
				}
				else {
					color = color3;
//					image = image3;
				}
				pions[i][h] = new Pion(/*image,*/ color);
			}
		}
	}
	
	/**
	 * Efface le pion se trouvant en p.X comme colonne et p.Y comme ligne du graphics g.
	 * @param g Graphics où est dessiné la grille de pion.
	 * @param p Point p permettant de retouver le pion a dessiner.
	 */
	private void effacePion (Graphics g, Point p) {
		Color c = pions[p.x][p.y].getCouleur();
		
		pions[p.x][p.y].setSelectionne(false);
		pions[p.x][p.y].setMort(true);
		pions[p.x][p.y].dessine(p.x*pions[p.x][p.y].getCote(), p.y*pions[p.x][p.y].getCote(), g);
		if(p.y-1>=0)
			if(pions[p.x][p.y-1].isSelectionne() && 
				pions[p.x][p.y-1].getCouleur().equals(c)) {
				effacePion(g, new Point(p.x, p.y-1));
		}
		if(p.y+1<nbLigne)
			if(pions[p.x][p.y+1].isSelectionne() && 
				pions[p.x][p.y+1].getCouleur().equals(c))
				effacePion(g, new Point(p.x, p.y+1));
		if(p.x-1>=0)
			if(pions[p.x-1][p.y].isSelectionne() && 
				pions[p.x-1][p.y].getCouleur().equals(c)){
				effacePion(g, new Point(p.x-1, p.y));
		}
		if(p.x+1<nbColonne)
			if(pions[p.x+1][p.y].isSelectionne() && 
				pions[p.x+1][p.y].getCouleur().equals(c))
				effacePion(g, new Point(p.x+1, p.y));
	}
	
	/**
	 * Permet de déplacer les pions ayant x comme colonne dans la matrix {@link #pions}.
	 * @param x Colonne a tasser.
	 * @param g Graphics où est dessiné la grille de pion.
	 */
	private void tasserColonne(int x, Graphics g) {
		for(int y=0; y<nbLigne; y++) {
			if(pions[x][y].isMort()) {
				for (int i=y; i>0; i--) {
					if(!pions[x][i-1].isMort()) {
						pions[x][i] = new Pion(pions[x][i-1].getCouleur());
						effacePion(g, new Point(x, i-1));
						pions[x][i].dessine(x*pions[x][y].getCote(), i*pions[x][y].getCote(), g);
					}
				}
				effacePion(g, new Point(x, 0));
			}
		}
	}
	
	/**
	 * Utilise {@link #tasserColonne(int, Graphics)} pour déplacer les pions de haut en bas.
	 * @param g Graphics où est dessiné la grille de pion.
	 */
	private void tasserVertical(Graphics g) {
		for(int x=0; x<nbColonne; x++) {//de haut en bas
			tasserColonne(x, g);
		}
	}

	/**
	 * Permet de déplacer les pions de droite à gauche.
	 * @param g Graphics où est dessiné la grille de pion.
	 */
	private void tasserHorizontal(Graphics g) {
		for (int i=nbColonne-1; i>=0; i--) {//de droite à gauche
			if(pions[i][nbLigne-1].isMort()){
				for(int x=i; x<nbColonne; x++) {
					for(int y=0; y<nbLigne; y++) {
							if(!pions[x][y].isMort()) {
								pions[x-1][y] = new Pion(pions[x][y].getCouleur());
								effacePion(g, new Point(x, y));
								pions[x-1][y].dessine((x-1)*pions[x-1][y].getCote(), y*pions[x-1][y].getCote(), g);
							}
					}
				}
			}
		}
	}
	
	//Méthodes Publiques
	/**
	 * Appel la méthode dessine pour chaque pions.
	 * @param g Graphics où est dessiné la grille de pion.
	 */
	public void dessine (Graphics g) {
		for(int i=0; i<nbColonne; i++) {
			for(int h=0; h<nbLigne; h++) {
				pions[i][h].dessine(i*getCotePion(), h*getCotePion(), g);
			}
		}
	}

	/**
	 * Appel la méthode dessine du pion ayant comme x p.X et comme y p.Y dans la matrix pions.
	 * @param g Graphics où est dessiné la grille de pion.
	 * @param p Point p permettant de retouver le pion a dessiner.
	 */
	public void dessinePion (Graphics g, Point p) {
		Color c = pions[p.x][p.y].getCouleur();
		if(!pions[p.x][p.y].isSelectionne()) {
			pions[p.x][p.y].setSelectionne(true);
			pions[p.x][p.y].dessine(p.x*getCotePion(), p.y*getCotePion(), g);
			if(p.y-1>=0)
				if(!pions[p.x][p.y-1].isSelectionne() && 
					pions[p.x][p.y-1].getCouleur().equals(c) &&
					!pions[p.x][p.y-1].isMort()) {
				dessinePion(g, new Point(p.x, p.y-1));
			}
			if(p.y+1<nbLigne)
				if(!pions[p.x][p.y+1].isSelectionne() && 
					pions[p.x][p.y+1].getCouleur().equals(c) &&
					!pions[p.x][p.y+1].isMort())
				dessinePion(g, new Point(p.x, p.y+1));
			if(p.x-1>=0)
				if(!pions[p.x-1][p.y].isSelectionne() && 
					pions[p.x-1][p.y].getCouleur().equals(c) &&
					!pions[p.x-1][p.y].isMort()) {
				dessinePion(g, new Point(p.x-1, p.y));
			}
			if(p.x+1<nbColonne)
				if(!pions[p.x+1][p.y].isSelectionne() && 
					pions[p.x+1][p.y].getCouleur().equals(c) &&
					!pions[p.x+1][p.y].isMort())
				dessinePion(g, new Point(p.x+1, p.y));
		}
		else if (pions[p.x][p.y].isSelectionne()) {
			if(p.x+1<nbColonne) {
				if(pions[p.x+1][p.y].isSelectionne() &&
						pions[p.x+1][p.y].getCouleur().equals(c)) {
					effacePion(g, p);
					tasserVertical(g);
				}
			}
			if(p.x-1>=0) {
				if(pions[p.x-1][p.y].isSelectionne() &&
						pions[p.x-1][p.y].getCouleur().equals(c)) {
					effacePion(g, p);
					tasserVertical(g);
				}
			}
			if(p.y+1<nbLigne) {
				if(pions[p.x][p.y+1].isSelectionne() &&
						pions[p.x][p.y+1].getCouleur().equals(c)) {
					effacePion(g, p);
					tasserVertical(g);
				}
			}
			if(p.y-1>=0) {
				if(pions[p.x][p.y-1].isSelectionne() &&
						pions[p.x][p.y-1].getCouleur().equals(c)) {
					effacePion(g, p);
					tasserVertical(g);
				}
			}
			tasserHorizontal(g);
		}
	}

	/**
	 * Vérifie si le pions[p.X][p.Y] est seul ou pas.
	 * @param p Point p permettant de retouver le pion a dessiner.
	 * @return vrai(true) si pions[p.X][p.Y] a au moins un voisin.
	 */
	public boolean pionNonSeul(Point p) {
		boolean b = false;
		int x = (int)p.getX();
		int y = (int)p.getY();
		if(x+1<nbColonne && !b) {
			if(getPion(x, y).getCouleur().equals(getPion(x+1, y).getCouleur())
					&& !getPion(x+1, y).isMort())
					 b = true;
		}
		if(x-1>=0 && !b) {
			if(getPion(x, y).getCouleur().equals(getPion(x-1, y).getCouleur())
					&& !getPion(x-1, y).isMort()) {
				b = true;
			}
		}
		if(y+1<nbLigne && !b) {
			if(getPion(x, y).getCouleur().equals(getPion(x, y+1).getCouleur())
					&& !getPion(x, y+1).isMort()) {
				b = true;
			}
		}
		if(y-1>=0 && !b) {
			if(getPion(x, y).getCouleur().equals(getPion(x, y-1).getCouleur())
					&& !getPion(x, y-1).isMort()) {
				b = true;
			}
		}
		return b;
	}
	
}//end class


