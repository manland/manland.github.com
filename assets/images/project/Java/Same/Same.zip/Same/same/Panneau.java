package same;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Gère la grille de pions et les clickes qui y sont faits.
 * @author Romain Maneschi
 */
public class Panneau extends JPanel implements java.awt.event.MouseListener {
	
	//Attributs
	/**
	 * Permet la sérialisation.
	 */
	private static final long serialVersionUID = -3986547390388201857L;
	/**
	 * Référence à la {@link #grille} de pion
	 */
	Grille grille;
	/**
	 * Taille d'un côté d'un pion. Permet de travailler sur les dimensions du panneau et de la fenêtre plsu facilement.
	 */
	private static int taillePion;
	/**
	 * Référence à la StatuBar de la fenêtre, essentiellement pour la mettre à jour.
	 */
	private StatuBar statuBar;
	/**
	 * Référence au fichierScore de la fenêtre, essentiellement pour le mettre à jour.
	 */
	private FichierScore fichierScore;
	/**
	 * Le score de la partie en cours.
	 */
	private int score;
	
	//Constructeur
	/**
	 * Créer un panneau contenant une {@link #grille} et initialise la statuBar
	 * @param statuBar {@link #statuBar}
	 * @param fichierScore {@link #fichierScore}
	 * @see #statuBar
	 * @see #fichierScore
	 */
	public Panneau (StatuBar statuBar, FichierScore fichierScore) {
		this.statuBar = statuBar;
		this.fichierScore = fichierScore;
		grille = new Grille();
		taillePion = grille.getCotePion();
		setSize(taillePion*grille.getNbColonne()+taillePion*2, taillePion*grille.getNbLigne()+taillePion*2);
		setPreferredSize(new Dimension(taillePion*grille.getNbColonne(), taillePion*grille.getNbLigne()));
		score = 0;
		statuBar.setScore(0);
		statuBar.setNbJetons(grille.getNbVivant());
		statuBar.setScoreSelection(0);
		addMouseListener(this);
	}
	
	//getters & setters
	/**
	 * @return La grille correspondante au panneau
	 */
	public Grille getGrille() {
		return grille;
	}
	/**
	 * Permet de changer de grille
	 * @param grille La nouvelle grille du panneau.
	 */
	public void setGrille(Grille grille) {
		this.grille = grille;
		grille.dessine(getGraphics());
	}
	
	//méthodes publiques
	/**
	 * Méthode héritée de Component, permettant de dessiner le Component sur g.
	 * @param g Graphique sur lequel la grille est peinte.
	 */
	public void paintComponent(Graphics g) {
        super.paintComponent(g);
        grille.dessine(g);
        g.dispose();
    }
	
	/**
	 * Renvoie la coordonnée de la case en fonction des coordonées du Graphique
	 * @param x Coordonnée x du click.
	 * @param y Coordonée y du click.
	 * @return Le Point p correspondant à pions[p.X][p.Y] 
	 */
	public static Point quelleCase(int x, int y) {
		return  new Point((int)x/taillePion, (int)y/taillePion);
	}
	
	/**
	 * Renvoie la coordonnée de la case en fonction de la ligne et de la colonne
	 * @param col Première coordonnée de la grille pions.
	 * @param lig Deuxième coordonée de la grille pions.
	 * @return Le Point p correspondant au coordonnées de la case dans le graphique.
	 */
	public static Point quelPoint(int col, int lig) {
		return new Point(col*taillePion, lig*taillePion);
	}
	
	/**
	 * Méthode héritée de java.awt.event.MouseListener.
	 * Si la case sur laquelle on click est sélectionnée alors on la supprime et on tasse la grille. Sinon on sélectionne la case et ces voisines. Enfin s'il y a une case de sélectionnée mais qu'on click sur une autre case alors on redessine la grille sans aucune sélection et on sélectionne la case clickée.
	 * @param e {@link #processMouseEvent(MouseEvent)}
	 */
	public void mousePressed(MouseEvent e) {
		Point p  = quelleCase(e.getX(), e.getY());
		if(grille.pionNonSeul(p)) {
			//s'il y a un point selectionne et qu'on click sur une autre case
			if(grille.getSelectionne() && !grille.getPion((int)p.getX(), (int)p.getY()).isSelectionne()) {
				for(int i=0; i<grille.getNbColonne(); i++) {
					for(int h=0; h<grille.getNbLigne(); h++) {
						grille.getPion(i, h).setSelectionne(false);
					}
				}
				grille.dessine(getGraphics());
				grille.dessinePion(getGraphics() , p);
			}
			//si il n'y a aucun point selectionne
			else if(!grille.getSelectionne()) {
				grille.dessinePion(getGraphics() , p);
				grille.setSelectionne(true);
			}
			//si on click sur un point selectionne
			else {
				grille.dessinePion(getGraphics() , p);
				grille.setSelectionne(false);
				verifierFinPartie();
			}
			mettreAJourStatuBar();
		}
		
	}
	
	/**
	 * Recréer une nouvelle grille, la dessine et met à jour les points.
	 * @see #grille
	 * @see Grille#dessine(Graphics)
	 */
	public void nouveauJeux() {
		grille = new Grille();
		grille.dessine(getGraphics());
		score = 0;
		mettreAJourStatuBar();
	}

	/**
	 * Méthode héritée de java.awt.event.MouseListener.
	 * Non implentée ici.
	 * @param e {@link #processMouseEvent(MouseEvent)}
	 */
	public void mouseClicked(MouseEvent e) {
		
	}

	/**
	 * Méthode héritée de java.awt.event.MouseListener.
	 * Non implentée ici.
	 * @param e {@link #processMouseEvent(MouseEvent)}
	 */
	public void mouseEntered(MouseEvent e) {

	}

	/**
	 * Méthode héritée de java.awt.event.MouseListener.
	 * Non implentée ici.
	 * @param e {@link #processMouseEvent(MouseEvent)}
	 */
	public void mouseExited(MouseEvent e) {
		
	}

	/**
	 * Méthode héritée de java.awt.event.MouseListener.
	 * Non implentée ici.
	 * @param e {@link #processMouseEvent(MouseEvent)}
	 */
	public void mouseReleased(MouseEvent e) {
		
	}
	
	/**
	 * Met à jour la StatuBar.
	 */
	public void mettreAJourStatuBar() {
		if(grille.getSelectionne()) {
			statuBar.setNbJetons(grille.getNbVivant());
			statuBar.setScoreSelection(grille.getScoreSelection());
		}
		else {
			score = grille.getScore();
			statuBar.setScore(grille.getScore());
			statuBar.setNbJetons(grille.getNbVivant());
			statuBar.setScoreSelection(0);
		}
	}
	
	//méthodes privées
	/**
	 * Parcours toute la grille et s'il n'existe plus aucun pion seul alors la partie est terminée. Vérifie enssuite si tous les pions sont morts pour ajouter ou retirer des points. Enfin propose à l'utilisateur de rentrer dans le top 10 (s'il en fait partie) et de recommencer la partie.
	 * @see Grille#pionNonSeul(Point)
	 * @see FichierScore
	 */
	private void verifierFinPartie() {
		boolean finPartie = true;
		int i = 0;
		int h = 0;
		while(i<grille.getNbColonne() && finPartie) {
			while(h<grille.getNbLigne() && finPartie) {
				if(!grille.getPion(i, h).isMort()) {
					if(grille.pionNonSeul(new Point(i, h))) {
						finPartie = false;
					}
				}
				h++;
			}
			h = 0;
			i++;
		}

		if(finPartie) {
			boolean toutfini = true;
			i = 0;
			h = 0;
			int count = 0;
			while(i<grille.getNbColonne()) {
				while(h<grille.getNbLigne()) {
					if(!grille.getPion(i, h).isMort()) {
						toutfini = false;
						count++;
					}
					h++;
				}
				h = 0;
				i++;
			}
			if(toutfini)
				score = score + 1000;
			else
				score = score - count;
			statuBar.setScore(score);
			statuBar.setNbJetons(0);
			statuBar.setScoreSelection(0);
			if(fichierScore.compare(score)) {
				String pseudo;
				try {
				pseudo = new String(JOptionPane.showInputDialog(null, "Bravo ! Vous avez fini la partie avec un score de "+score+" points.\nVous faites partie du top 10.\nVeuillez entrer votre pseudo : ", "Pseudo", JOptionPane.INFORMATION_MESSAGE));
				}
				catch(NullPointerException e) {
					pseudo = "Inconnu";
				}
	
				fichierScore.compareEtAjoute(score, pseudo);
				nouveauJeux();
			}
			else if(JOptionPane.showConfirmDialog(null,"Bravo ! Vous avez fini la partie avec un score de "+score+" points.\n Voulez-vous recommencer ?","Partie Fini",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE)==0)
					nouveauJeux();
		}
	}
}
