package same;

import java.io.IOException;

import javax.swing.SwingUtilities;

/**
 * Permet de lancer l'application en créant une Fenetre dans le thread de Swing.
 * 
 * @author Romain Maneschi
 */
public class Application {
	public static void main(String[] args) throws IOException {
		SwingUtilities.invokeLater(new Runnable()
		{
			/**
			 * lance le thread de Swing.
			 */
			public void run() {
				new Fenetre();
			}
		}
		);
	}
}
