package same;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;

/**
 * Gère toute l'apparence comprenant un menu, une toolBar, une statuBar, et un Panneau.
 * @author Romain Maneschi
 */
public class Fenetre extends JFrame {

	//Attributs
	/**
	 * Permet la sérialisation.
	 */
	private static final long serialVersionUID = -4392639534730082113L;
	/**
	 * Référence au Panneau.
	 */
	private Panneau panneau;
	/**
	 * Référence à la statuBar.
	 */
	private StatuBar statuBar;
	/**
	 * Référence au fichierScore.
	 */
	private FichierScore fichierScore;
	/**
	 * Référence à la boite à outils.
	 */
	private JToolBar bar;
	/**
	 * Référence au scrollPanneau qui permet d'ajouter des scrollBars au {@link #panneau} si besoins.
	 */
	private JScrollPane scrollPanneau;
	
	//Constructeur
	/**
	 * Créer une nouvelle fenêtre, y ajoute un layout et dispose un panneau, un menu, une toolBar et un panneau affichant les tops scores.
	 */
	public Fenetre() {
		super();
		statuBar = new StatuBar();
		fichierScore = new FichierScore();
		panneau = new Panneau(statuBar, fichierScore);
		scrollPanneau = new JScrollPane(panneau, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED , JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

		buildToolBar();
		build();
		buildMenu();
				
		add(scrollPanneau, BorderLayout.CENTER);
		add(statuBar, BorderLayout.SOUTH);
		add(fichierScore, BorderLayout.EAST);

		setVisible(true);
		scrollPanneau.setVisible(true);
	}
	
	//Méthodes Privées
	/**
	 * Donne à la fenêtre un nom, une taille, la place et permet de la détruire.
	 */
	private void build(){
		setTitle("Same");
		setSize(panneau.getWidth()+fichierScore.getWidth(), panneau.getHeight()+statuBar.getHeight()+bar.getHeight());
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 * Créer les menus.
	 */
	private void buildMenu() {
		JMenuBar menuBarre = new JMenuBar();
		setJMenuBar(menuBarre);
		
		JMenu fichier = new JMenu("Fichier");
		menuBarre.add(fichier);
		
		JMenuItem item = new JMenuItem("Nouveau Jeu");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_N);
	    item.addActionListener(new ActionNewJeu());
	    fichier.add(item);
	    
	    item = new JMenuItem("Quitter");
	    item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_Q);
	    item.addActionListener(new ActionQuitter());
		fichier.add(item);
		
		JMenu jeux = new JMenu("Jeux");
		menuBarre.add(jeux);
		
		item = new JMenuItem("Sauvegarder");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_S);
	    item.addActionListener(new ActionEnregistrer());
	    jeux.add(item);
	    
	    item = new JMenuItem("Restaurer");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_R);
	    item.addActionListener(new ActionRestaurer());
	    jeux.add(item);
	    
	    JMenu score = new JMenu("Score");
		menuBarre.add(score);
		
		item = new JMenuItem("Afficher/Cacher les scores");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_H);
	    item.addActionListener(new ActionAfficherCacherScore());
	    score.add(item);
	    
	    JMenu aide = new JMenu("Aide");
		menuBarre.add(aide);
		
		item = new JMenuItem("Aide");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_I);
	    item.addActionListener(new ActionAide());
	    aide.add(item);
	    
		item = new JMenuItem("A Propos De...");
		item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,InputEvent.CTRL_MASK));
	    item.setMnemonic(KeyEvent.VK_A);
	    item.addActionListener(new ActionAbout());
	    aide.add(item);
	}
	
	/**
	 * Créer une boite à outil.
	 */
	private void buildToolBar() {
		bar = new JToolBar("Faites votre choix");

		bar.add(new ActionNewJeu());
		bar.add(new ActionQuitter());
		bar.addSeparator();
		bar.add(new ActionEnregistrer());
		bar.add(new ActionRestaurer());
		bar.addSeparator();
		bar.add(new ActionAfficherCacherScore());
		bar.addSeparator();
		bar.add(new ActionAide());
		
		bar.setSize(0,50);
		
		getContentPane().add(bar, BorderLayout.NORTH); 
	}
	
	//sous classes privées
	/**
	 * Lance une nouvelle partie.
	 */
	private class ActionNewJeu extends AbstractAction implements ActionListener {

		/**
		 * Permet la sérialisation.
		 */
		private static final long serialVersionUID = -6248809911160887905L;
		
		/**
		 * Créer un nouvelle action qui permet de lancer une nouvelle partie.
		 * @see Panneau#nouveauJeux()
		 */
		public ActionNewJeu() {
			ImageIcon imageIcon = new ImageIcon("new.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "Nouveau jeu");
		} 

		public void actionPerformed(ActionEvent arg0) {
			if(JOptionPane.showConfirmDialog(null,"Voulez-vous vraiment recommencer ?","Recommencer",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE)==0)
				panneau.nouveauJeux();
		}
	}
	/**
	 *Ferme le programme.
	 */
	 private class ActionQuitter extends AbstractAction  implements ActionListener {

		/**
		 * Permet la sérialisation.
		 */
		private static final long serialVersionUID = 1855753151943287668L;
		
		/**
		 * Créer un nouvelle action permettant de quitter le programme.
		 * @see System#exit(int)
		 */
		public ActionQuitter() {
			ImageIcon imageIcon = new ImageIcon("exit.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "Quitter");
		} 

		public void actionPerformed(ActionEvent arg0) {
			if(JOptionPane.showConfirmDialog(null,"Voulez-vous vraiment quitter ?","Quitter",JOptionPane.OK_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE)==0)
				System.exit(0);
		}
	}
	/**
	 * Enregistre une partie en cours
	 */
	 private class ActionEnregistrer extends AbstractAction implements ActionListener {

		 /**
		  * Permet la sérialisation.
		  * @see ActionRestaurer
		  */
		private static final long serialVersionUID = 9213926741292175685L;
		
		/**
		 * Enregistre une partie en cours en la sérialisant.
		 * @see ActionRestaurer
		 */
		public ActionEnregistrer() {
			ImageIcon imageIcon = new ImageIcon("enregistrer.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "Enregistrer jeu");
		} 

		public void actionPerformed(ActionEvent arg0) {
			String fichier;
			try {
			fichier = new String(JOptionPane.showInputDialog(null, "Entrez le nom de la partie à enregistrer :", "Enregistrer", JOptionPane.INFORMATION_MESSAGE));
			}
			catch(NullPointerException e) {
				fichier = "";
			}

			if(!fichier.equals("")){
				try {
					FileOutputStream fos = new FileOutputStream(fichier+".same");
					ObjectOutputStream oos= new ObjectOutputStream(fos);
					try {
						oos.writeObject(panneau.getGrille()); 
						oos.flush();
					} 
					finally {
						try {
							oos.close();
						} 
						finally {
							fos.close();
						}
					}
				} 
				catch(IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
	}
	 /** 
	  * Restaure une partie sauvegardée.
	  */
	private class ActionRestaurer extends AbstractAction implements ActionListener {

		 /**
		  * Permet la sérialisation.
		  */
		private static final long serialVersionUID = -7933995313645631784L;
		
		/**
		 * Restaure une partie déjà sauvegarder en la désérialisant.
		 */
		public ActionRestaurer() {
			ImageIcon imageIcon = new ImageIcon("restaurer.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "Restaurer jeu");
		} 

		public void actionPerformed(ActionEvent arg0) {
			String fichier;
			try {
			fichier = new String(JOptionPane.showInputDialog(null, "Entrez le nom de la partie à restaurer :", "Restaurer", JOptionPane.INFORMATION_MESSAGE));
			}
			catch(NullPointerException e) {
				fichier = "";
			}

			if(!fichier.equals("")){
				Grille p = null;
				try {
					FileInputStream fis = new FileInputStream(fichier+".same");
					ObjectInputStream ois= new ObjectInputStream(fis);
					try {	
						p = (Grille) ois.readObject(); 
					} 
					finally {
						try {
							ois.close();
						} 
						finally {
							fis.close();
						}
					}
				} 
				catch(IOException ioe) {
					ioe.printStackTrace();
				} 
				catch(ClassNotFoundException cnfe) {
					cnfe.printStackTrace();
				}
				panneau.setGrille(p);
				panneau.mettreAJourStatuBar();
			}
		}
	}
	 /**
	  * Affiche A Propos de Same
	  */
	private class ActionAbout extends AbstractAction  implements ActionListener {
		
		/**
		 * Permet la sérialisation.
		 */
		private static final long serialVersionUID = -7962734636839308957L;

		/**
		 * Affiche un descriptif sur l'auteur et le but de Same
		 */
		public ActionAbout() {
			ImageIcon imageIcon = new ImageIcon("about.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "A Propos De...");
		} 

		public void actionPerformed(ActionEvent arg0) {
			JOptionPane.showMessageDialog(null,"Ce petit jeux a été programmer\ndans le but d'un tp noté, pour l'UE\nJava du semestre 5 de licence\ninformatique.\n\nDéveloppeur : Romain Maneschi","A Propos De...",JOptionPane.CLOSED_OPTION, new ImageIcon("about.png"));	
		}
	}
	/**
	 * Affiche ou cache les scores
	 */
	private class ActionAfficherCacherScore extends AbstractAction  implements ActionListener {
		/**
		 * Permet la sérialisation.
		 */
		private static final long serialVersionUID = -5353173917215291980L;

		/**
		 * Si les scores sont affichés, l'action les cachent sinon ils les affichent
		 */
		public ActionAfficherCacherScore() {
			ImageIcon imageIcon = new ImageIcon("scores.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "Afficher/Cacher Scores");
		} 

		public void actionPerformed(ActionEvent arg0) {
			if(fichierScore.isVisible())
				fichierScore.setVisible(false);
			else
				fichierScore.setVisible(true);
		}
	}
	/**
	 * Affiche une courte aide sur l'utilisation de Same
	 */
	private class ActionAide extends AbstractAction  implements ActionListener {
		/**
		 * Permet la sérialisation.
		 */
		private static final long serialVersionUID = -5353173917215291980L;
		
		/**
		 * Affiche une courte aide sur l'utilisation de Same
		 */
		public ActionAide() {
			ImageIcon imageIcon = new ImageIcon("about.png");
			putValue(Action.SMALL_ICON, imageIcon);
			putValue(Action.SHORT_DESCRIPTION, "Comment jouer ?");
		} 

		public void actionPerformed(ActionEvent arg0) {
			String s = "SAME<br />Est un jeu ludique où il suffit de clicker sur\nune case pour la sélectionner et de reclicker\nsur une des cases sélectionnées pour la faire\ndisparaitre.\nPlus le groupe de cases détruit est important\nplus il permet d'empocher des points.\nSi vous finissez toute la grille vous empocherez\n1000 points suplémentaires.\n\nBON JEUX !";
			JOptionPane.showMessageDialog(null, s, "Aide",JOptionPane.CLOSED_OPTION, new ImageIcon("about.png"));
		}
	}
}
