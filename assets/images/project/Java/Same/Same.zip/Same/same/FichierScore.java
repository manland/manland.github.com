package same;

import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JLabel;
import javax.swing.JPanel;

/************************************************************
 * Gère l'apparence, l'écriture et la lecture des scores.
 * @author Romain Maneschi
 */

public class FichierScore extends JPanel {

	//Attributs
	/**
	 * Permet la sérialisation.
	 */
	private static final long serialVersionUID = 5685646442728613877L;
	/**
	 * Tableau des scores.
	 * @see #tabPseudo
	 * @see #label
	 */
	private int tabScore[];
	/**
	 * Tableau des pseudos correspondant au score de {@link #tabScore}.
	 * @see #tabScore
	 * @see #label
	 */
	private String tabPseudo[];
	/**
	 * Tableau de JLabel pour l'affichage graphique.
	 * @see #tabScore
	 * @see #tabPseudo
	 */
	private JLabel label[];
	/**
	 * Nombre de scores à sauvegarder
	 */
	private final static int nbScores = 10;
	
	//Constructeur
	public FichierScore() {
		tabScore = new int[nbScores];
		tabPseudo = new String[nbScores];
		label = new JLabel[nbScores];
		for(int i=0; i<nbScores; i++) {
    		tabScore[i] = -1;
    		tabPseudo[i] = null;
    	}
		build();
		setSize(label[0].getWidth()+80,label[0].getHeight()*10);
	}
	
	//Méthodes Privées
	/**
	 * Donne à la fenêtre une taille, un layout et la rend visible puis éssaie de {@link #lire()} les données dans le fichier texte, initialise les tableaux et ajoutes les labels.
	 * @see #lire()
	 */
	private void build() {
		setVisible(true);
		setLayout(new GridLayout(nbScores, 1));
		try {
			lire();
		}
		catch(IOException e){}
		for(int i=nbScores-1; i>=0; i--) {
			if(tabScore[i] == -1 && i==0) {
				label[i] = new JLabel("Aucune partie terminée.");
				add(label[i], i, 0);
			}
			else if(tabScore[i] == -1) {
				label[i] = new JLabel(" ");
				add(label[i], i, 0);
			}
			else {
				label[i] = new JLabel(""+tabScore[i]+" "+tabPseudo[i]);
				add(label[i], i, 0);
			}
		}
	}
	
	/**
	 * Met a jours les tableaux et les labels en appelant {@link #lire()}.
	 * @see #lire()
	 */
	private void mettreAJour() {
		try {
			lire();
		}
		catch(IOException e){}
		for(int i=nbScores-1; i>=0; i--) {
			if(tabScore[i] != -1)
				label[i].setText(""+tabScore[i]+" "+tabPseudo[i]);
		}
	}

	/**
	 * Permet de #lire() les scores dans le fichier texte. Si le fichier n'existe pas il initialise {@link #tabScore} à -1 et {@link #tabPseudo} à null.
	 * @see #ecrire()
	 * @see #tabScore
	 * @see #tabPseudo
	 * @see IOException
	 * @throws IOException
	 */
	private void lire() throws IOException {
		BufferedReader lecteurAvecBuffer = null;
	    String ligne;

	    try {
	    	lecteurAvecBuffer = new BufferedReader(new FileReader("scores.txt"));
	    	int i=0;
		    while ((ligne = lecteurAvecBuffer.readLine()) != null) {
		    	if(!ligne.equals("-1null")) {
			    	String score = ligne.substring(0,4);
			    	tabScore[i] = Integer.parseInt(score);
			    	tabPseudo[i] = ligne.substring(4,ligne.length());
			    	i++;
		    	}
		    }
		    lecteurAvecBuffer.close();
	    }
	    catch(FileNotFoundException exc) {
	    	for(int i=0; i<nbScores; i++) {
	    		tabScore[i] = -1;
	    		tabPseudo[i] = null;
	    	}
	    }
	}
	
	/**
	 * Ecrit les scores dans le fichier texte.
	 * @see #lire()
	 * @see #tabScore
	 * @see #tabPseudo
	 * @throws IOException
	 */
	private void ecrire() throws IOException {
		PrintWriter ecrivain =  new PrintWriter(new BufferedWriter(new FileWriter("scores.txt")));
	    for(int i=0; i<nbScores; i++) {
	    	if(tabScore[i]<10 && tabScore[i]!=-1)
	    		ecrivain.println("000"+tabScore[i]+tabPseudo[i]);
	    	else if(tabScore[i]<100 && tabScore[i]!=-1)
	    		ecrivain.println("00"+tabScore[i]+tabPseudo[i]);
	    	else if(tabScore[i]<1000 && tabScore[i]!=-1)
	    		ecrivain.println("0"+tabScore[i]+tabPseudo[i]);
	    	else
	    		ecrivain.println(""+tabScore[i]+tabPseudo[i]);
	    }
	    ecrivain.close();
	    mettreAJour();
	}
	
	//Méthodes Publiques
	/**
	 * Dit si le score en cours peu entrer dans le top score. 
	 * @param points Le nombre de points à comparer.
	 * @return vrai(true) si les points permettent d'entrer dans le top score, faux(false) sinon.
	 */
	public boolean compare(int points) {
		boolean res = false;
		int i=0;
		while(i<nbScores && !res) {
			if(tabScore[i]<points) {
				res = true;
			}
			i++;
		}
		return res;
	}
	
	/**
	 * Vérifie si le score en cours peu entrer dans le top score et l'ajoute. 
	 * @param points Le nombre de points à comparer et à ajouter.
	 * @param pseudo Le pseudo du joueur à ajouter.
	 */
	public void compareEtAjoute(int points, String pseudo) {
		boolean res = false;
		int i=0;
		while(i<nbScores && !res) {
			if(tabScore[i]<points) {
				res = true;
				int temp[];
				String tempP[];
				temp = new int[nbScores];
				tempP = new String[nbScores];
				for(int h=0; h<nbScores; h++) {
					temp[h] = tabScore[h];
					tempP[h] = tabPseudo[h];
				}
				tabScore[i] = points;
				tabPseudo[i] = pseudo;
				for(int h=i+1; h<nbScores; h++) {
					tabScore[h] = temp[h-1];
					tabPseudo[h] = tempP[h-1];
				}
			}
			i++;
		}
		
		if(res) {
			try {
				ecrire();
			}
			catch(IOException e) {}
		}
	}
}
