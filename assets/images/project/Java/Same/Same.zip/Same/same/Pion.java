package same;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.io.Serializable;

public class Pion extends Component implements Serializable {

	//attributs
	/**
	 * Permet la sérialisation.
	 */
	private static final long serialVersionUID = 1315447270513253702L;
	/**
	 * vrai(true) si le pion est sélectionné.
	 */
	private boolean selectionne;
	/**
	 * vrai(true) si le pion est mort : on ne le voit plus à l'écran.
	 */
	private boolean mort;
	/**
	 * Couleur du pion.
	 */
	private Color couleur;
	/**
	 * Image du pion. 
	 * Non implenté par manque de temps.
	 */
	private Image image;
	/**
	 * vrai(true) si on utilise des images à la place des couleurs.
	 */
	private boolean utiliseImage;
	/**
	 * Le cote d'un pion.
	 */
	private static final int cote = 30;
	/**
	 * La couleur de fond du graphique.
	 */
	private static final Color couleurFond = new Color(255, 255, 255);
	/**
	 * La couleure de fond des cases sélectionnées.
	 */
	private static final Color couleurSelectionnee = new Color(0, 0, 0);
	
	//constructeur
	/**
	 * Créer un pion avec la couleur c
	 * @param c Couleur du pion
	 * @see Color
	 */
	public Pion(Color c) {
		selectionne = false;
		mort = false;
		couleur = c;
		image = null;
		utiliseImage = false;
	}
	/**
	 * Créer un pion avec l'image i et la couleure c. La couleure est conservée pour des raisons de commoditées pour la recherche de voisin.
	 * @param i Image du pion
	 * @param c Couleur du pion
	 */
	public Pion(Image i, Color c) {
		selectionne = false;
		mort = false;
		couleur = null;
		image = i;
		couleur = c;
		utiliseImage = true;
	}
	
	//getters & setters
	/**
	 * @return vrai(true) si le pion est sélectionné
	 */
	public boolean isSelectionne() {
		return selectionne;
	}
	/**
	 * @param selectionne permet de spécifier au pion qu'il est sélectionné
	 */
	public void setSelectionne(boolean selectionne) {
		this.selectionne = selectionne;
	}
	/**
	 * @return La couleur du pion.
	 * @see Color
	 */
	public Color getCouleur() {
		return couleur;
	}
	/**
	 * @return vrai(true) si le pion est mort donc invisible donc détruit.
	 */
	public boolean isMort() {
		return mort;
	}
	/**
	 * @param mort permet de spécifier au pion qu'il est mort.
	 */
	public void setMort(boolean mort) {
		this.mort = mort;
	}
	/**
	 * @return La taille d'un des côté du pion.
	 */
	public int getCote() {
		return cote;
	}
	
	//méthodes
	/**
	 * Dessine le pion sur le graphique aux bonnes coordonnées.
	 * @param lig coordonnée x du pion à dessiner.
	 * @param col coordonnée y du pion à dessiner.
	 * @param g Le graphique sur lequel sont les pions.
	 */	
	public void dessine (int lig, int col, Graphics g) {
		if(selectionne && !mort && !utiliseImage) {
			g.setColor(couleurSelectionnee);
			g.fillRect(lig, col, cote, cote);
			g.setColor(couleur);
			g.fillOval(lig, col, cote, cote);
		}
		else if(!selectionne && !mort && !utiliseImage) {
			g.setColor(couleurFond);
			g.fillRect(lig, col, cote, cote);
			g.setColor(couleur);
			g.fillOval(lig, col, cote, cote);
		}
		else if(selectionne && !mort && utiliseImage) {
			g.setColor(couleurSelectionnee);
			g.fillRect(lig, col, cote, cote);
			g.drawImage(image, lig, col, cote, cote, this);
		}
		else if(!selectionne && !mort && utiliseImage) {
			g.setColor(couleurFond);
			g.fillRect(lig, col, cote, cote);
			g.drawImage(image, lig, col, cote, cote, this);
		}
		else {
			g.setColor(couleurFond);
			g.fillRect(lig, col, cote, cote);
		}
	}
}
