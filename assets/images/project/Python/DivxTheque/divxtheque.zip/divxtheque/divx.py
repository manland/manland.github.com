#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import os,re,sys,urllib,string,pygtk,gtk,gobject,time,thread,threading,codecs,pango
pygtk.require('2.0')


class variables():
	def __init__(self):
		#première fenêtre
		self.Color_fenetre_generale1 = 0
		self.Color_fenetre_generale2 = 40000
		self.Color_fenetre_generale3 = 65000

		#fenêtre de résultat des recherches
		self.Color_notebook1 = 0
		self.Color_notebook2 = 40000
		self.Color_notebook3 = 65000

		self.titre_justification = gtk.JUSTIFY_CENTER

		self.Color_titre1 = 65000
		self.Color_titre2 = 65000
		self.Color_titre3 = 65000

		self.Color_fond_titre1 = 0
		self.Color_fond_titre2 = 40000
		self.Color_fond_titre3 = 65000

		self.size_titre = 20

		self.notebook_font = None

		self.style_fenetre_film = gtk.POS_TOP

		###uniquement pour stats
		self.Color_soustitre1 = 65000
		self.Color_soustitre2 = 65000
		self.Color_soustitre3 = 65000

		self.Color_fond_soustitre1 = 0
		self.Color_fond_soustitre2 = 40000
		self.Color_fond_soustitre3 = 65000

		self.size_soustitre = 20

		self.Color_texte1 = 65000
		self.Color_texte2 = 65000
		self.Color_texte3 = 65000

		self.Color_fond_texte1 = 0
		self.Color_fond_texte2 = 40000
		self.Color_fond_texte3 = 65000

		self.size_texte = 10

		###pour toutes les pages des films
		self.Color_genre1 = 65000
		self.Color_genre2 = 65000
		self.Color_genre3 = 65000

		self.Color_fond_genre1 = 0
		self.Color_fond_genre2 = 40000
		self.Color_fond_genre3 = 65000

		self.size_genre = 10
		self.justification_genre = gtk.JUSTIFY_LEFT

		self.Color_datedesortie1 = 65000
		self.Color_datedesortie2 = 65000
		self.Color_datedesortie3 = 65000

		self.Color_fond_datedesortie1 = 0
		self.Color_fond_datedesortie2 = 40000
		self.Color_fond_datedesortie3 = 65000

		self.size_datedesortie = 10
		self.justification_datedesortie = gtk.JUSTIFY_LEFT

		self.Color_realisateur1 = 65000
		self.Color_realisateur2 = 65000
		self.Color_realisateur3 = 65000

		self.Color_fond_realisateur1 = 0
		self.Color_fond_realisateur2 = 40000
		self.Color_fond_realisateur3 = 65000

		self.size_realisateur = 10
		self.justification_realisateur = gtk.JUSTIFY_LEFT

		self.Color_nationnalite1 = 65000
		self.Color_nationnalite2 = 65000
		self.Color_nationnalite3 = 65000

		self.Color_fond_nationnalite1 = 0
		self.Color_fond_nationnalite2 = 40000
		self.Color_fond_nationnalite3 = 65000

		self.size_nationnalite = 10
		self.justification_nationnalite = gtk.JUSTIFY_LEFT

		self.Color_repertoire1 = 65000
		self.Color_repertoire2 = 65000
		self.Color_repertoire3 = 65000

		self.Color_fond_repertoire1 = 0
		self.Color_fond_repertoire2 = 40000
		self.Color_fond_repertoire3 = 65000

		self.size_repertoire = 10
		self.justification_repertoire = gtk.JUSTIFY_LEFT

		self.Color_taille1 = 65000
		self.Color_taille2 = 65000
		self.Color_taille3 = 65000

		self.Color_fond_taille1 = 0
		self.Color_fond_taille2 = 40000
		self.Color_fond_taille3 = 65000

		self.size_taille = 10
		self.justification_taille = gtk.JUSTIFY_LEFT

		self.Color_reference1 = 65000
		self.Color_reference2 = 65000
		self.Color_reference3 = 65000

		self.Color_fond_reference1 = 0
		self.Color_fond_reference2 = 40000
		self.Color_fond_reference3 = 65000

		self.size_reference = 10
		self.justification_reference = gtk.JUSTIFY_RIGHT

		self.Color_synopsis1 = 65000
		self.Color_synopsis2 = 65000
		self.Color_synopsis3 = 65000

		self.Color_fond_synopsis1 = 0
		self.Color_fond_synopsis2 = 40000
		self.Color_fond_synopsis3 = 65000

		self.size_synopsis = 10
		self.justification_synopsis = gtk.JUSTIFY_LEFT

		#fenêtre des options
		self.Color_fenetre_options1 = 0
		self.Color_fenetre_options2 = 40000
		self.Color_fenetre_options3 = 65000

		self.style_fenetre_options = gtk.POS_LEFT

		#fenêtre des ajouts de films
		self.Color_fenetre_ajout1 = 0
		self.Color_fenetre_ajout2 = 40000
		self.Color_fenetre_ajout3 = 65000

		self.extension = 'Mauvaise extension -> '
		self.enregistre = 'Déjà enregistré -> '
		self.ajouter = 'Ajouter -> '
		

########################################################################################################################
#Classe de l'interface en GTK et principale
########################################################################################################################
#Améliorations
#
########################################################################################################################
class skin():
	def __init__(self):		
		self.fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)#gtk.WINDOW_POPUP
		self.fenetre.connect("destroy", gtk.main_quit)
		self.fenetre.set_border_width(0)

		self.fenetre.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_fenetre_generale1,variables().Color_fenetre_generale2,variables().Color_fenetre_generale3))

		HBox = gtk.HBox(False, 2)
		self.frame_menu = gtk.Frame()
		self.frame_menu.set_label("Menu")
		self.frame_menu.set_label_align(0.5, 0.5)
		self.frame_menu.set_shadow_type(gtk.SHADOW_NONE)

		self.frame_page = gtk.Frame()
		self.frame_page.set_shadow_type(gtk.SHADOW_NONE)
		HBox.pack_start(self.frame_menu, False,False,False)
		HBox.pack_start(self.frame_page, False,False,False)
		self.fenetre.add(HBox)
	
		self.menu()
		self.page()
		HBox.show()
		self.frame_menu.show()
		self.frame_page.show()
		self.fenetre.show()
	
	def aproposde(self, widget, donnees=None):
		aproposde_fenetre = gtk.Dialog("A propos...",self.fenetre, gtk.DIALOG_MODAL,None)
		aproposde_fenetre.connect("destroy", lambda x:aproposde_fenetre.destroy())
		text = gtk.Label('A propos de M@Ndivx...\nLogiciel créé par m@n\nVersion 1')
		aproposde_fenetre.vbox.pack_start(text,True,False,True)
		bouton_ok = gtk.Button()
		hboite = options().joli_boutton("Ok",gtk.STOCK_OK)
		bouton_ok.add(hboite)
		aproposde_fenetre.action_area.pack_start(bouton_ok,True,False,True)
		bouton_ok.connect("clicked", lambda x:aproposde_fenetre.destroy())
		aproposde_fenetre.show_all()

	def menu(self):
		VBox_menu = gtk.VBox(False, 0)
		self.frame_menu.add(VBox_menu)
		##Frame_ajouter + Bouton
		frame_ajouter = gtk.Frame()
		frame_ajouter.set_label("Ajouter")
		VBox_menu.pack_start(frame_ajouter, False,False,True)
		VBox_menu_ajouter = gtk.VBox(False, 0)
		frame_ajouter.add(VBox_menu_ajouter)
		bouton_ajouter_1film = gtk.Button('Film')
		bouton_ajouter_1film.connect("button_press_event", self.ajouter_1film)
		VBox_menu_ajouter.pack_start(bouton_ajouter_1film, True,False,True)
		bouton_ajouter_1rep = gtk.Button('Répertoire')
		bouton_ajouter_1rep.connect("button_press_event", self.ajouter_1rep)
		VBox_menu_ajouter.pack_start(bouton_ajouter_1rep, True,False,True)
		##Frame_rechercher + Bouton
		frame_rechercher = gtk.Frame()
		frame_rechercher.set_label("Recherche")
		VBox_menu.pack_start(frame_rechercher, False,False,True)
		VBox_menu_rechercher = gtk.VBox(False, 0)
		frame_rechercher.add(VBox_menu_rechercher)
		bouton_recherche_simple = gtk.Button("Simple")
		bouton_recherche_simple.connect("button_press_event", self.recherche_simple)
		VBox_menu_rechercher.pack_start(bouton_recherche_simple, True,False,True)
		bouton_rechercher_complexe = gtk.Button('Complexe')
		bouton_rechercher_complexe.connect("button_press_event", self.recherche_complexe, rechercher(None,None).dico_generale)
		VBox_menu_rechercher.pack_start(bouton_rechercher_complexe, True,False,True)
		##Frame_option + Bouton
		frame_option = gtk.Frame()
		frame_option.set_label("Options")
		VBox_menu.pack_start(frame_option, False,False,True)
		VBox_menu_option = gtk.VBox(False, 0)
		frame_option.add(VBox_menu_option)
		bouton_parametre = gtk.Button('Paramètres')
		bouton_parametre.connect("button_press_event", options().fenetre)##
		VBox_menu_option.pack_start(bouton_parametre, True,False,True)
		bouton_path = gtk.Button('Doubles')
		bouton_path.connect("button_press_event", lambda x, y:organiser())##
		VBox_menu_option.pack_start(bouton_path, True,False,True)
		##Frame_quitter + Bouton
		frame_quitter = gtk.Frame()
		frame_quitter.set_label("Quitter")
		VBox_menu.pack_start(frame_quitter, False,False,True)
		VBox_menu_quitter = gtk.VBox(False, 0)
		frame_quitter.add(VBox_menu_quitter)
		bouton_quitter = gtk.Button('Quitter')
		bouton_quitter.connect("button_press_event", gtk.main_quit)
		VBox_menu_quitter.pack_start(bouton_quitter, True,False,True)
		bouton_apropos = gtk.Button('A Propos')
		bouton_apropos.connect("button_press_event", self.aproposde)
		VBox_menu_quitter.pack_start(bouton_apropos, True,False,True)

		VBox_menu.show_all()

	def page(self):
		VBox_afficher = gtk.VBox(False, 0)
		self.frame_page.add(VBox_afficher)
		VBox_afficher.show()

		titre = gtk.Label('Statistique :\nNombre de films : \nDernier ajouter (indiquer date dans bd)\nMeilleur note (indique note bd)\n...')
		titre.set_justify(gtk.JUSTIFY_LEFT)
		VBox_afficher.pack_start(titre,False,False,True)
		titre.show()

	def ajouter_1film(self, widget, donnees=None):
		self.selectfichier = gtk.FileSelection('Choisissez un film')
		self.selectfichier.connect("destroy", lambda x:self.selectfichier.destroy())
		self.selectfichier.cancel_button.connect("clicked", lambda x:self.selectfichier.destroy())	
		self.selectfichier.ok_button.connect("clicked", lambda x:self.selectfichier.hide())	
		self.selectfichier.ok_button.connect_after("clicked", self.ok_fichier_1film)
		self.selectfichier.show()

	def ok_fichier_1film(self, widget):
		divx1 = self.selectfichier.get_filename()
		divx(divx1,0)
		self.selectfichier.destroy()

	def ajouter_1rep(self, widget, donnees=None):
		self.selectfichier = gtk.FileSelection('Choisissez un répertoire')
		self.selectfichier.connect("destroy", lambda x:self.selectfichier.destroy())
		self.selectfichier.cancel_button.connect("clicked", lambda x:self.selectfichier.destroy())	
		self.selectfichier.ok_button.connect("clicked", lambda x:self.selectfichier.hide())	
		self.selectfichier.ok_button.connect_after("clicked", self.ok_fichier_1rep)
		self.selectfichier.show()

	def ok_fichier_1rep(self, widget):
		divx1 = self.selectfichier.get_filename()
		divx(divx1,1)
		self.selectfichier.destroy()

	def recherche_simple(self, widget, donnees=None):
		dialog = gtk.Dialog("Recherche",self.fenetre, gtk.DIALOG_NO_SEPARATOR,None)
		dialog.connect("destroy", lambda x:dialog.destroy())
		self.entry = gtk.Entry(0)
		self.entry.set_text("Entrez votre recherche")
		self.entry.select_region(0, len(self.entry.get_text()))
		dialog.vbox.pack_start(self.entry,True,False,True)

		bouton_cancel = gtk.Button('Annuler')
		dialog.action_area.pack_start(bouton_cancel,True,False,True)
		bouton_cancel.connect("clicked", lambda x:dialog.destroy())

		bouton_ok = gtk.Button('Ok')
		dialog.action_area.pack_start(bouton_ok,True,False,True)
		bouton_ok.connect("clicked", lambda x:dialog.hide())
		bouton_ok.connect_after("clicked", self.recherche_simple2)

		dialog.show_all()

	def recherche_simple2(self, widget):
		texte = self.entry.get_text()
		widget.destroy()
		rechercher(texte,0)

	def recherche_complexe_intermediaire(self,combobox,type_recherche,dialog):
		model = combobox.get_model()
		choix = combobox.get_active_iter()
		choix = model.get_value(choix, 0)
		dialog.destroy()
		self.recherche_complexe(None,None,rechercher(None,None).complexe(choix,type_recherche))
		

	def recherche_complexe(self, widget, event, dico):
		liste_titre = []
		liste_genre = []
		liste_realisateur = []
		liste_nationnalite = []
		liste_annee = []
		for film in dico:
			if (dico[film][0]!='0'):
				liste_titre.append(dico[film][0])
			if (dico[film][4]!='0'):
				liste_genre.append(dico[film][4])
			if (dico[film][2]!='0'):
				liste_realisateur.append(dico[film][2])
			if (dico[film][3]!='0'):
				liste_nationnalite.append(dico[film][3])
			if (dico[film][1][-4:]!='0'):
				if (dico[film][1][-4]=='1' or dico[film][1][-4]=='2'):
					liste_annee.append(dico[film][1][-4:])

		liste_titre = list(set(liste_titre))
		liste_titre.sort()
		liste_genre = list(set(liste_genre))
		liste_genre.sort()
		liste_realisateur = list(set(liste_realisateur))
		liste_realisateur.sort()
		liste_nationnalite = list(set(liste_nationnalite))
		liste_nationnalite.sort()
		liste_annee = list(set(liste_annee))
		liste_annee.sort()

		dialog = gtk.Dialog("Recherche",self.fenetre, gtk.DIALOG_NO_SEPARATOR,None)
		dialog.connect("destroy", lambda x:dialog.destroy())

		titre = gtk.Label('Titre : ')
		dialog.vbox.pack_start(titre,True,False,True)
		self.entry_titre = gtk.combo_box_entry_new_text()
		for film in liste_titre:
			self.entry_titre.append_text(film)
		if(len(liste_titre)==1):
			self.entry_titre.set_active(0)
		self.entry_titre.connect('changed', self.recherche_complexe_intermediaire,'titre',dialog)
		dialog.vbox.pack_start(self.entry_titre,True,False,True)

		genre = gtk.Label('Genre : ')
		dialog.vbox.pack_start(genre,True,False,True)
		self.entry_genre = gtk.combo_box_entry_new_text()
		for genre in liste_genre:
			self.entry_genre.append_text(genre)
		if(len(liste_genre)==1):
			self.entry_genre.set_active(0)
		self.entry_genre.connect('changed', self.recherche_complexe_intermediaire,'genre',dialog)
		dialog.vbox.pack_start(self.entry_genre,True,False,True)

		realisateur = gtk.Label('Réalisateur : ')
		dialog.vbox.pack_start(realisateur,True,False,True)
		self.entry_realisateur = gtk.combo_box_entry_new_text()
		for realisateur in liste_realisateur:
			self.entry_realisateur.append_text(realisateur)
		if(len(liste_realisateur)==1):
			self.entry_realisateur.set_active(0)
		self.entry_realisateur.connect('changed', self.recherche_complexe_intermediaire,'realisateur',dialog)
		dialog.vbox.pack_start(self.entry_realisateur,True,False,True)

		annee = gtk.Label('Année : ')
		dialog.vbox.pack_start(annee,True,False,True)
		self.entry_annee = gtk.combo_box_entry_new_text()
		for annee in liste_annee:
			self.entry_annee.append_text(annee)
		if(len(liste_annee)==1):
			self.entry_annee.set_active(0)
		self.entry_annee.connect('changed', self.recherche_complexe_intermediaire,'datedesortie',dialog)
		dialog.vbox.pack_start(self.entry_annee,True,False,True)

		nationnalite = gtk.Label('Nationnalité : ')
		dialog.vbox.pack_start(nationnalite,True,False,True)
		self.entry_nationnalite = gtk.combo_box_entry_new_text()
		for nationnalite in liste_nationnalite:
			self.entry_nationnalite.append_text(nationnalite)
		if(len(liste_nationnalite)==1):
			self.entry_nationnalite.set_active(0)
		self.entry_nationnalite.connect('changed', self.recherche_complexe_intermediaire,'nationnalite',dialog)
		dialog.vbox.pack_start(self.entry_nationnalite,True,False,True)

		bouton_cancel = gtk.Button('Annuler')
		dialog.action_area.pack_start(bouton_cancel,True,False,True)
		bouton_cancel.connect("clicked", lambda x:dialog.destroy())

		bouton_ok = gtk.Button('Ok')
		dialog.action_area.pack_start(bouton_ok,True,False,True)
		bouton_ok.connect("clicked", lambda x:dialog.hide())
		bouton_ok.connect_after("clicked", self.recherche_complexe2, dico)

		dialog.show_all()

	def recherche_complexe2(self, widget, dico):
		liste_a_afficher = []
		for film in dico:
			liste_a_afficher.append(dico[film])
		rechercher(None,None).afficher(liste_a_afficher)

	def destroy(self, widget):
		gtk.main_quit()


########################################################################################################################
#Classe permettant, à partir d'un dictionnaire de rechercher une valeure clé du dico première valeure, valeure tableau 
#	contenant les valeures suivantes et les affichage dans un NoteBook
#La méthode recuperer_info permet à partir d'un tuple d'id de renvoyer un tuple de tuple contenant les infos des films
########################################################################################################################
#Appelé par : rechercher('recherche',dans)
#	si dans=0 -> recherche la 'recherche' dans tout
#	sinon dans=type -> recherche la 'recherche' dans 'dans'
#Renvoie : rien, affiche un NoteBook contenant les résultats de la recherche
########################################################################################################################
#Améliorations :
#	chercher dans le dico plutôt que la bd_divx
#	type de recherche : dichotomique ???
########################################################################################################################
class rechercher(skin):
	def __init__(self,recherche,dans):
		self.bd = 'bd_divx'
		nb_motif = 22
		self.creation_dico_generale(nb_motif)
		if (dans==0):
			a = self.simple(recherche)
			a = self.recuperer_info(a)
			self.afficher(a)
		elif(dans):
			a = self.complexe(recherche,dans)
			a = self.recuperer_info(a)
			self.afficher(a)

	def simple(self,recherche):
		ligneS = open(self.bd,'r')
		i = 0
		dico_trouver = {}
		for ligne in ligneS.readlines():
			resultat = re.search('\b'+recherche+'\b',ligne)
			if resultat:
				dico_trouver[''+ligne[4:11]+''] = 5
			else:
				resultat = re.search(''+recherche+'',ligne)
				if resultat:
					dico_trouver[''+ligne[4:11]+''] = 4
				else:
					resultat = re.search(''+string.capwords(recherche)+'',ligne)
					if resultat:
						dico_trouver[''+ligne[4:11]+''] = 3
					else:
						resultat = re.search(''+string.lower(recherche)+'',ligne)
						if resultat:
							dico_trouver[''+ligne[4:11]+''] = 2
						else:
							resultat = re.search(''+string.upper(recherche)+'',ligne)
							if resultat:
								dico_trouver[''+ligne[4:11]+''] = 2
							else:
								resultat = re.search(''+string.swapcase(recherche)+'',ligne)
								if resultat:
									dico_trouver[''+ligne[4:11]+''] = 1
		ligneS.close()
		return dico_trouver

	def complexe(self,recherche,dans):
		if(recherche == None or dans == None):
			recherche = 'nawak'
			dans = 'nawak'
		ligneS = open(self.bd,'r')
		i = 0
		dico_trouver = {}
		for ligne in ligneS.readlines():
			resultat = re.search(""+dans+"::[^"+recherche+"]*"+recherche+"",ligne)
			if resultat:
				dico_trouver[''+ligne[4:11]+''] = self.dico_generale[''+ligne[4:11]+'']
		ligneS.close()
		return dico_trouver
		
	def recuperer_info(self,dico):
		info = []
		for film in dico:
			if (dico[film]==5):
				info.append(self.dico_generale[film])
		for film in dico:
			if (dico[film]==4):
				info.append(self.dico_generale[film])
		for film in dico:
			if (dico[film]==3):
				info.append(self.dico_generale[film])
		for film in dico:
			if (dico[film]==2):
				info.append(self.dico_generale[film])
		for film in dico:
			if (dico[film]==1):
				info.append(self.dico_generale[film])
		return info

	def afficher(self,dico):
		fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)#gtk.WINDOW_POPUP
		fenetre.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_notebook1,variables().Color_notebook2,variables().Color_notebook3))
		fenetre.set_default_size(600, 300)
		fenetre.connect("destroy", lambda x:fenetre.destroy())
		fenetre.set_border_width(0)
		notebook = gtk.Notebook()
		notebook.set_tab_pos(variables().style_fenetre_film)

		fd = gtk.ScrolledWindow()
		fd.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
		textview = gtk.TextView()
		textview.set_wrap_mode(gtk.WRAP_WORD)
		textview.set_cursor_visible(False)
		textview.set_editable(False)
		buffertexte = textview.get_buffer()

		balise_titre = buffertexte.create_tag(None, size_points=variables().size_titre, background_gdk=gtk.gdk.Color(variables().Color_fond_titre1,variables().Color_fond_titre2,variables().Color_fond_titre3), foreground_gdk=gtk.gdk.Color(variables().Color_titre1,variables().Color_titre2,variables().Color_titre3), editable=False, justification=variables().titre_justification, font=variables().notebook_font)
		balise_sous_titre = buffertexte.create_tag(None, size_points=variables().size_soustitre, background_gdk=gtk.gdk.Color(variables().Color_fond_soustitre1,variables().Color_fond_soustitre2,variables().Color_fond_soustitre3), foreground_gdk=gtk.gdk.Color(variables().Color_soustitre1,variables().Color_soustitre2,variables().Color_soustitre3), editable=False, font=variables().notebook_font)
		balise_film = buffertexte.create_tag(None, size_points=variables().size_texte, background_gdk=gtk.gdk.Color(variables().Color_fond_texte1,variables().Color_fond_texte2,variables().Color_fond_texte3), foreground_gdk=gtk.gdk.Color(variables().Color_texte1,variables().Color_texte2,variables().Color_texte3), editable=False, font=variables().notebook_font)
		balise_genre = balise_film

		buffertexte.set_text('Statistiques\n')
		debut_titre = buffertexte.get_iter_at_line(0)
		fin_titre = buffertexte.get_iter_at_line(1)
		buffertexte.apply_tag(balise_titre, debut_titre, fin_titre)

		buffertexte.insert(fin_titre, 'Film ('+str(len(dico))+')\n')
		debut_sous_titre = buffertexte.get_iter_at_line(1)
		fin_sous_titre = buffertexte.get_iter_at_line(2)
		buffertexte.apply_tag(balise_sous_titre, debut_sous_titre, fin_sous_titre)

		film = ''
		for f in dico:
			film = film + f[0] + '\n'
		buffertexte.insert(fin_titre, ''+film+'')
		debut_film = buffertexte.get_iter_at_line(2)
		fin_film = buffertexte.get_iter_at_line(len(dico)+2)
		buffertexte.apply_tag(balise_film, debut_film, fin_film)

		liste_genre = []
		for g in dico:
			liste_genre.insert(-1,g[4])
		liste_genre = list(set(liste_genre))
		liste_genre.sort()
		genre = ''
		for g in liste_genre:
			genre = genre + g + '\n'

		buffertexte.insert(fin_film, '\nGenre ('+str(len(liste_genre))+')\n')
		debut_sous_titre = buffertexte.get_iter_at_line(3+len(dico))
		fin_sous_titre = buffertexte.get_iter_at_line(4+len(dico))
		buffertexte.apply_tag(balise_sous_titre, debut_sous_titre, fin_sous_titre)

		buffertexte.insert(fin_sous_titre, ''+genre+'')
		debut_genre = buffertexte.get_iter_at_line(4+len(dico))
		fin_genre = buffertexte.get_iter_at_line(5+len(dico)+len(liste_genre))
		buffertexte.apply_tag(balise_genre, debut_genre, fin_genre)

		fd.add(textview)
		titre = gtk.Label('StatS')
		notebook.append_page(fd, titre)

		if (len(dico)>5):
			notebook.set_scrollable(True)
		for film in dico:
			titre = film[0]
			datedesortie = '\nDate de Sortie : ' + film[1]
			realisateur = '\nRéalisateur : ' + film[2]
			nationnalite = '\nNationnalité : ' + film[3]
			genre = '\nGenre : ' + film[4]
			duree = '\nDurée : ' + film[5]
			repertoire = '\nRépertoire : ' + film[6]
			taille = '\nTaille : ' + film[7]
			reference = '\nMerci à : ' + film[8]
			synopsis = '\nSynopsis :\n' + film[9]

			fd = gtk.ScrolledWindow()
			fd.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
			textview = gtk.TextView()
			textview.set_wrap_mode(gtk.WRAP_WORD)
			buffertexte = textview.get_buffer()

			balise_titre = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_titre1,variables().Color_fond_titre2,variables().Color_fond_titre3), foreground_gdk=gtk.gdk.Color(variables().Color_titre1,variables().Color_titre2,variables().Color_titre3), size_points=variables().size_titre, editable=False, justification=variables().titre_justification, font=variables().notebook_font)
			balise_genre = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_genre1,variables().Color_fond_genre2,variables().Color_fond_genre3), foreground_gdk=gtk.gdk.Color(variables().Color_genre1,variables().Color_genre2,variables().Color_genre3), size_points=variables().size_genre, editable=False, justification=variables().justification_genre, font=variables().notebook_font)
			balise_datedesortie = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_datedesortie1,variables().Color_fond_datedesortie2,variables().Color_fond_datedesortie3), foreground_gdk=gtk.gdk.Color(variables().Color_datedesortie1,variables().Color_datedesortie2,variables().Color_datedesortie3), size_points=variables().size_datedesortie, editable=False, justification=variables().justification_datedesortie, font=variables().notebook_font)
			balise_realisateur = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_realisateur1,variables().Color_fond_realisateur2,variables().Color_fond_realisateur3), foreground_gdk=gtk.gdk.Color(variables().Color_realisateur1,variables().Color_realisateur2,variables().Color_realisateur3), size_points=variables().size_realisateur, editable=False, justification=variables().justification_realisateur, font=variables().notebook_font)
			balise_nationnalite = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_nationnalite1,variables().Color_fond_nationnalite2,variables().Color_fond_nationnalite3), foreground_gdk=gtk.gdk.Color(variables().Color_nationnalite1,variables().Color_nationnalite2,variables().Color_nationnalite3), size_points=variables().size_nationnalite, editable=False, justification=variables().justification_nationnalite, font=variables().notebook_font)
			balise_repertoire = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_repertoire1,variables().Color_fond_repertoire2,variables().Color_fond_repertoire3), foreground_gdk=gtk.gdk.Color(variables().Color_repertoire1,variables().Color_repertoire2,variables().Color_repertoire3), size_points=variables().size_repertoire, editable=False, justification=variables().justification_repertoire, font=variables().notebook_font)
			balise_taille = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_taille1,variables().Color_fond_taille2,variables().Color_fond_taille3), foreground_gdk=gtk.gdk.Color(variables().Color_taille1,variables().Color_taille2,variables().Color_taille3), size_points=variables().size_taille, editable=False, justification=variables().justification_taille, font=variables().notebook_font)
			balise_reference = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_reference1,variables().Color_fond_reference2,variables().Color_fond_reference3), foreground_gdk=gtk.gdk.Color(variables().Color_reference1,variables().Color_reference2,variables().Color_reference3), size_points=variables().size_reference, editable=False, justification=variables().justification_reference, font=variables().notebook_font)
			balise_synopsis = buffertexte.create_tag(None, background_gdk=gtk.gdk.Color(variables().Color_fond_synopsis1,variables().Color_fond_synopsis2,variables().Color_fond_synopsis3), foreground_gdk=gtk.gdk.Color(variables().Color_synopsis1,variables().Color_synopsis2,variables().Color_synopsis3), size_points=variables().size_synopsis, editable=False, justification=variables().justification_synopsis, font=variables().notebook_font)

			buffertexte.set_text(titre)
			nb_caract_titre = buffertexte.get_char_count()
			debut_titre = buffertexte.get_start_iter()
			fin_titre = buffertexte.get_iter_at_offset(nb_caract_titre)
			buffertexte.apply_tag(balise_titre, debut_titre, fin_titre)

			buffertexte.insert(fin_titre, datedesortie)
			nb_caract_datedesortie = buffertexte.get_char_count() + nb_caract_titre
			debut_datedesortie = buffertexte.get_iter_at_line(2)
			fin_datedesortie = buffertexte.get_iter_at_offset(nb_caract_datedesortie)
			buffertexte.apply_tag(balise_datedesortie, debut_datedesortie, fin_datedesortie)

			buffertexte.insert(fin_datedesortie, realisateur)
			nb_caract_realisateur = buffertexte.get_char_count() + nb_caract_datedesortie
			debut_realisateur = buffertexte.get_iter_at_line(3)
			fin_realisateur = buffertexte.get_iter_at_offset(nb_caract_realisateur)
			buffertexte.apply_tag(balise_realisateur, debut_realisateur, fin_realisateur)

			buffertexte.insert(fin_realisateur, nationnalite)
			nb_caract_nationnalite = buffertexte.get_char_count() + nb_caract_realisateur	
			debut_nationnalite = buffertexte.get_iter_at_line(4)
			fin_nationnalite = buffertexte.get_iter_at_offset(nb_caract_nationnalite)
			buffertexte.apply_tag(balise_nationnalite, debut_nationnalite, fin_nationnalite)

			buffertexte.insert(fin_realisateur, genre)
			nb_caract_genre = buffertexte.get_char_count() + nb_caract_nationnalite
			debut_genre = buffertexte.get_iter_at_line(5)
			fin_genre = buffertexte.get_iter_at_offset(nb_caract_genre)
			buffertexte.apply_tag(balise_genre, debut_genre, fin_genre)

			buffertexte.insert(fin_realisateur, repertoire)
			nb_caract_repertoire = buffertexte.get_char_count() + nb_caract_genre
			debut_repertoire = buffertexte.get_iter_at_line(6)
			fin_repertoire = buffertexte.get_iter_at_offset(nb_caract_repertoire)
			buffertexte.apply_tag(balise_repertoire, debut_repertoire, fin_repertoire)

			buffertexte.insert(fin_realisateur, taille)
			nb_caract_taille = buffertexte.get_char_count() + nb_caract_repertoire
			debut_taille = buffertexte.get_iter_at_line(7)
			fin_taille =buffertexte.get_iter_at_offset(nb_caract_taille)
			buffertexte.apply_tag(balise_taille, debut_taille, fin_taille)

			buffertexte.insert(fin_realisateur, reference)
			nb_caract_reference = buffertexte.get_char_count() + nb_caract_taille
			debut_reference = buffertexte.get_iter_at_line(8)
			fin_reference = buffertexte.get_iter_at_offset(nb_caract_reference)
			buffertexte.apply_tag(balise_reference, debut_reference, fin_reference)

			buffertexte.insert(fin_realisateur, synopsis)
			nb_caract_synopsis = buffertexte.get_char_count() + nb_caract_reference
			debut_synopsis = buffertexte.get_iter_at_line(8)
			fin_synopsis = buffertexte.get_iter_at_offset(nb_caract_synopsis)
			buffertexte.apply_tag(balise_synopsis, debut_synopsis, fin_synopsis)

			vboite = gtk.VBox(False,0)
			vboite.pack_start(textview, True, True, 0)

			bouton_1er = gtk.Button('<<')
			bouton_1er.connect("button_press_event", lambda e,w:notebook.set_current_page(0))
			bouton_prev = gtk.Button('<')
			bouton_prev.connect("button_press_event", lambda e,w:notebook.prev_page())
			bouton_suiv = gtk.Button('>')
			bouton_suiv.connect("button_press_event", lambda e,w:notebook.next_page())
			bouton_der = gtk.Button('>>')
			bouton_der.connect("button_press_event", lambda e,w:notebook.set_current_page(len(dico)))

			hboite = gtk.HBox(True,0)
			hboite.pack_start(bouton_1er, True, True, 0)
			hboite.pack_start(bouton_prev, True, True, 0)
			hboite.pack_start(bouton_suiv, True, True, 0)
			hboite.pack_start(bouton_der, True, True, 0)

			vboite.pack_start(hboite, False, False, 0)

			fd.add_with_viewport(vboite)

			titre = gtk.Label(''+titre+'')
			notebook.append_page(fd, titre)
		fenetre.add(notebook)
		fenetre.show_all()	

	def destroy(self, widget):
		gtk.main_quit()
		
	def creation_dico_generale(self,nb_motif):
		ligneS = open(self.bd,'r')
		self.dico_generale = {}
		for ligne in ligneS.readlines():
			liste_temp = []
			resultat = re.search('([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::([^::]+)::(.+)',ligne)
			if resultat:
				i=4
				while(i<=nb_motif):
					liste_temp.append(resultat.group(i))
					i = i + 2
				self.dico_generale[resultat.group(2)]=liste_temp
		ligneS.close()
		self.dico_generale


########################################################################################################################
#Classe permettant, à partir d'un répertoir, de prendre tous les fichiers et d'aller chercher sur allocine des détails
#détails : titre,datedesortie,realisateur,nationnalite,genre,duree,synopsis,référence
########################################################################################################################
#Appelé par : divx('répertoire',type_ajout)
#	si type_ajout=0 -> un seul film
#	si type_ajout=1 -> par répertoire
#Renvoie : rien, modifie le fichier texte bd_divx en y inscrivant les détails en UTF8
########################################################################################################################
#Améliorations :
#	commencer les recherches séquentielles sur les films qu'à partir d'une certaine ligne = pas trop de risque ?
#	ajouter durée et image
#	vérifier l'extension du fichier
########################################################################################################################
class divx(skin):
	def __init__(self,repertoire,type_ajout):
		self.bd_divx = 'bd_divx'
		self.bd_extensions = 'bd_extensions'
		self.stop = True
		dico = rechercher(None,None).dico_generale
		self.liste_titre = []
		for film in dico:
			if (dico[film][0]!='0'):
				self.liste_titre.append(dico[film][0])
		extensionS = open(self.bd_extensions,'r')
		self.liste_extensions = []
		for extension in extensionS.readlines():
			self.liste_extensions.append(extension)
		extensionS.close()
		if (type_ajout==1):
			self.tableau_nomsfilms = os.listdir(''+repertoire+'')
			self.taille_tableau_nomsfilms = len(self.tableau_nomsfilms)
			self.affichage(repertoire)
		elif (type_ajout==0):
			self.tableau_nomsfilms = [0]
			liste_nomfilm=string.split(repertoire,'/')
			self.tableau_nomsfilms[0] = liste_nomfilm[-1]
			self.taille_tableau_nomsfilms = 1
			taille_nom_film = len(liste_nomfilm[-1])
			taille_total = len(repertoire)
			taille_repertoire = taille_total - taille_nom_film
			repertoire = repertoire[:taille_repertoire-1]
			self.affichage(repertoire)
		
	def affichage(self,repertoire):
		fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)
		fenetre.set_title("Recherche en cours...")
		fenetre.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_fenetre_ajout1,variables().Color_fenetre_ajout2,variables().Color_fenetre_ajout3))
		fenetre.set_default_size(600, 300)
		fenetre.connect("destroy", lambda x:fenetre.destroy())

		text_film_fait = gtk.TextView()
		text_film_fait.set_editable(False)
		text_film_fait.set_cursor_visible(False)
		text_film_fait.set_wrap_mode(gtk.WRAP_WORD)
		self.buffer_text_film_fait = text_film_fait.get_buffer()
		self.buffer_text_film_fait.set_text("...")
			
		text_film_passe = gtk.TextView()
		text_film_passe.set_editable(False)
		text_film_passe.set_cursor_visible(False)
		text_film_passe.set_wrap_mode(gtk.WRAP_WORD)
		self.buffer_text_film_passe = text_film_passe.get_buffer()
		self.buffer_text_film_passe.set_text("...")

		fenetre_vert = gtk.VBox(False,0)
		fenetre_hori = gtk.HBox(True,5)

		frame_film_fait = gtk.Frame('Films Ajoutés')
		sw_film_fait = gtk.ScrolledWindow()
		sw_film_fait.add_with_viewport(text_film_fait)
		frame_film_fait.add(sw_film_fait)
		fenetre_hori.pack_start(frame_film_fait,True,True,0)

		frame_film_passe = gtk.Frame('Films Passés')
		sw_film_passe = gtk.ScrolledWindow()
		sw_film_passe.add_with_viewport(text_film_passe)
		frame_film_passe.add(sw_film_passe)
		fenetre_hori.pack_start(frame_film_passe,True,True,0)

		fenetre_vert.pack_start(fenetre_hori,True,True,0)

		vboite_dessous = gtk.VBox(False,0)
		self.barreprogress = gtk.ProgressBar(adjustment=None)
		self.barreprogress.set_orientation(gtk.PROGRESS_LEFT_TO_RIGHT)
		vboite_dessous.pack_start(self.barreprogress, False, False, 0)
		boutton_stopper = gtk.Button('Stopper')
		boutton_stopper.connect("button_press_event", lambda e,w,i:self.stop_thread(i),False)
		vboite_dessous.pack_start(boutton_stopper, False, True, 0)

		fenetre_vert.pack_start(vboite_dessous,False,False,0)

		fenetre.add(fenetre_vert)
		fenetre.show_all()

		thread.start_new_thread(self.ajouter_divx_informatiquement,(repertoire,0))
		self.barreprogress.set_text('Fini')

	def stop_thread(self,boole):
		self.stop = boole

	def info_film(self,reson,film):
		gtk.gdk.threads_enter()
		nb_ligne_fait = self.buffer_text_film_fait.get_line_count()
		marque_fait = self.buffer_text_film_fait.get_iter_at_line(nb_ligne_fait)
		nb_ligne_passe = self.buffer_text_film_passe.get_line_count()
		marque_passe = self.buffer_text_film_passe.get_iter_at_line(nb_ligne_passe)

		if(reson=="extension"):
			self.buffer_text_film_passe.insert(marque_passe, variables().extension+film+'\n')
		elif(reson=="deja"):
			self.buffer_text_film_passe.insert(marque_passe, variables().enregistre+film+'\n')
		else:
			self.buffer_text_film_fait.insert(marque_fait, variables().ajouter+film+'\n')
		gtk.gdk.threads_leave()
		time.sleep(0.1)
		return True

	def fraction(self,num_film):
		gtk.gdk.threads_enter()
		self.barreprogress.set_fraction(float(num_film)/self.taille_tableau_nomsfilms)
		self.barreprogress.set_text(''+str(num_film)+'/'+str(self.taille_tableau_nomsfilms)+'')
		gtk.gdk.threads_leave()
		time.sleep(0.1)
		return True

	def est_fait(self,titre2):
		resultat = False
		for titre in self.liste_titre:
			if(''+titre+'' == ''+titre2+''):
				resultat = True
		return resultat

	def bonne_extension(self,extension):
		resultat = False
		extension = string.lower(extension)
		extension = extension + '\n'
		for ext in self.liste_extensions:
			if(''+ext+'' == ''+extension+''):
				resultat = True
		return resultat

	def ajouter_divx_informatiquement(self,repertoire,num_film):
		if(self.taille_tableau_nomsfilms>1):
			while(not(self.fraction(num_film+1))):
				1
		taille_film = str(os.stat(repertoire+'/'+self.tableau_nomsfilms[num_film]).st_size)
		liste_nomfilm=string.split(self.tableau_nomsfilms[num_film])
		titre = self.tableau_nomsfilms[num_film]
		count_mot = len(liste_nomfilm)
		remplace = re.search('([^.]+).(.+)',liste_nomfilm[count_mot - 1])
		if remplace :
			extension = remplace.group(2)
			del liste_nomfilm[count_mot - 1]
			liste_nomfilm.append(remplace.group(1))
		else:
			extension = 0
		titresansextension = string.join(liste_nomfilm)
		titresansextension = string.capwords(titresansextension)
		if(not(self.bonne_extension(extension)) and self.stop and num_film+1<self.taille_tableau_nomsfilms):
			while(not(self.info_film("extension",titre))):
				1
			self.ajouter_divx_informatiquement(repertoire,num_film+1)
		elif(not(self.bonne_extension(extension)) and self.stop and num_film+1==self.taille_tableau_nomsfilms):
			while(not(self.info_film("extension",titre))):
				1
		elif(self.est_fait(titresansextension) and self.stop and num_film+1<self.taille_tableau_nomsfilms):
			while(not(self.info_film("deja",titresansextension))):
				1
			self.ajouter_divx_informatiquement(repertoire,num_film+1)
		elif(self.est_fait(titresansextension) and self.stop and num_film+1==self.taille_tableau_nomsfilms):
			while(not(self.info_film("deja",titresansextension))):
				1
		elif(self.stop and not(self.est_fait(titresansextension)) and self.bonne_extension(extension)):
			recherche=""+liste_nomfilm[0]+""
			j = 1
			while (j<count_mot) :
				recherche = ""+recherche+"+"+liste_nomfilm[j]+""
				j = j + 1
			page = urllib.urlopen('http://www.allocine.fr/recherche/?motcle='+recherche+'&rub=1')
			strpage=page.readlines()
			strpage_count_ligne = len(strpage)
			h = 0
			while (h<strpage_count_ligne) :
				resultat = re.search('film/fichefilm_gen_cfilm=([0-9]+)[^A-Z]+'+liste_nomfilm[0]+'',strpage[h])
				if resultat :
					h = strpage_count_ligne
					page2 = urllib.urlopen('http://www.allocine.fr/film/fichefilm_gen_cfilm='+resultat.group(1)+'.html')
					strpage2=page2.readlines()
					strpage_count_ligne2 = len(strpage2)
					k = 0
					datedesortie='0'
					realisateur='0'
					nationnalite='0'
					genre='0'
					duree='0'
					synopsis='0'
					while (k<strpage_count_ligne2) :
						resultat2 = re.search('Date\sde\ssortie\s:\s[^>]+>([^<]+)',strpage2[k])
						if resultat2 :#date de sortie
							datedesortie=resultat2.group(1)
							datedesortie=datedesortie.decode('iso-8859-1').encode('UTF_8')
					
						resultat3 = re.search('Réalisé\spar\s[^>]+>([^<]+)',strpage2[k])
						if resultat3 :#réalisateur
							realisateur=resultat3.group(1)
							realisateur=realisateur.decode('iso-8859-1').encode('UTF_8')
					
						resultat4 = re.search('Plus\.\.\.[^A-Z]+Film\s([^\.]+)',strpage2[k])
						if resultat4 :#Nationalité
							nationnalite=resultat4.group(1)
							nationnalite=nationnalite.decode('iso-8859-1').encode('UTF_8')
					
						resultat5 = re.search('Genre\s:\s[^>]+>([^<]+)',strpage2[k])
						if resultat5 :#Genre
							genre=resultat5.group(1)
							genre=genre.decode('iso-8859-1').encode('UTF_8')
							
						resultat6 = re.search('Durée\s:\s(........)',strpage2[k])
						if resultat6 :#Durée le seul a pas marcher ??
							duree=resultat6.group(1)
							duree=duree.decode('iso-8859-1').encode('UTF_8')
							
						resultat7 = re.search('Synopsis',strpage2[k])
						if resultat7 :#Synopsis
							resultat8 = re.search('^[^A-Z]+(.*)[^.]{18}$',strpage2[k+4])
							if (resultat8 and (resultat8.group(1) != '')):#Synopsis
								synopsis=resultat8.group(1)
								synopsis=synopsis.decode('iso-8859-1').encode('UTF_8')

						k = k + 1
					self.ecriture_bd(titresansextension,titre,datedesortie,realisateur,nationnalite,genre,duree,synopsis,taille_film,repertoire,num_film)
					if(self.stop and num_film+1 < self.taille_tableau_nomsfilms):
						self.ajouter_divx_informatiquement(repertoire,num_film+1)
				elif(not(resultat) and h+1==strpage_count_ligne):
					self.ecriture_bd(titresansextension,titre,'0','0','0','0','0','0',taille_film,repertoire,num_film)
					h = strpage_count_ligne
					if(self.stop and num_film+1 < self.taille_tableau_nomsfilms):
						self.ajouter_divx_informatiquement(repertoire,num_film+1)
				else :
					h = h + 1

	def recuperer_id(self):
		bd_divx = open(self.bd_divx,'r') 
		id_num = bd_divx.readlines()
		id_num = id_num[-1][4:11]
		bd_divx.close()
		if (id_num == ''):
			id_num = 0
		id_num = int(id_num) + 1
		while (len(str(id_num)) < 7):
			id_num = '0' + str(id_num)
		return str(id_num)
		
	def ecriture_bd(self,titresansextension,titre,datedesortie,realisateur,nationnalite,genre,duree,synopsis,taille_film,repertoire,num_film):
		id_num = self.recuperer_id()
		bd_divx = open(self.bd_divx,'a')
		bd_divx.write('id::'+id_num+'::titre::'+titresansextension+'::datedesortie::'+datedesortie+'::realisateur::'+realisateur+'::nationnalite::'+nationnalite+'::genre::'+genre+'::duree::'+duree+'::repertoire::'+repertoire+'/'+titre+'::taille::'+taille_film+'::reference::www.allocine.fr::synopsis::'+synopsis+'\n')
		bd_divx.close()
		while(not(self.info_film(id_num,titresansextension))):
			1

	def destroy(self, widget):
		gtk.main_quit()


########################################################################################################################
#Classe qui réorganise la bd :
#	- cherche, demande et enlève les doubles
########################################################################################################################
#Appelé par : organiser()
#Renvoie : rien, affiche les films redondant, demande et supprime ceux-ci
########################################################################################################################
#Améliorations :
#	- rechercher les synopsis contenant un : et les enlever
#	- chercher les id qui se suivent pas et réorganiser la suite
########################################################################################################################
class organiser(skin):
	def __init__(self):
		self.stop = True
		self.liste_double = []
		if(self.recopier_bd()):
			self.affiche_barreprogress()
		
	def affiche_barreprogress(self):
		self.dialog = gtk.Dialog('Réorganisation : En cours...', None, gtk.DIALOG_NO_SEPARATOR, None)
		self.barreprogress = gtk.ProgressBar(adjustment=None)
		self.barreprogress.set_orientation(gtk.PROGRESS_LEFT_TO_RIGHT)
		self.dialog.vbox.pack_start(self.barreprogress, False, False, 0)
		bouton_stopper = gtk.Button('Stopper')
		bouton_stopper.connect("button_press_event", lambda e,w,i:self.stopper(i),False)
		self.dialog.action_area.pack_start(bouton_stopper, True, True, 0)
		self.dialog.show_all()
		thread.start_new_thread(self.trouver_double, ())

	def ini_afficher_double(self):
		self.dialog.hide()
		if(len(self.liste_double) > 0):
			liste_a_afficher = []
			for id_film in self.liste_double:
				dico = {}
				dico[''+id_film+''] = 5
				infos = rechercher(None,None).recuperer_info(dico)
				infos.insert(0,id_film)
				liste_a_afficher.append(infos)
			self.afficher_double(liste_a_afficher)
		else:
			dialog = gtk.Dialog('Réorganisation : Finie', None, gtk.DIALOG_NO_SEPARATOR, None)
			txt = gtk.Label('Aucun double trouvé')
			dialog.vbox.pack_start(txt, False, False, 0)
			bouton_quitter = gtk.Button('Quitter')
			bouton_quitter.connect("button_press_event", lambda e,w:dialog.destroy())
			dialog.action_area.pack_start(bouton_quitter, True, True, 0)
			dialog.show_all()

	def affiche_bouton_ok(self):
		boutton_ok = gtk.Button('Suivant')
		boutton_ok.connect("button_press_event",lambda e,w:self.ini_afficher_double())
		self.dialog.action_area.pack_start(boutton_ok, True, True, 0)
		boutton_ok.show_now()

	def fraction(self,num_film):
		gtk.gdk.threads_enter()
		self.barreprogress.set_fraction(float(num_film)/len(rechercher(None,None).dico_generale))
		self.barreprogress.set_text(''+str(num_film)+'/'+str(len(rechercher(None,None).dico_generale))+'')
		if(not(self.stop) or (num_film == len(rechercher(None,None).dico_generale))):
			self.affiche_bouton_ok()
		gtk.gdk.threads_leave()
		time.sleep(0.1)
		return True

	def stopper(self,boole):
		self.stop = boole

	def recopier_bd(self):
		bd = rechercher(None,None).bd
		bd_divx = open(bd,'r')
		bd_divx_old = open(bd+'_old','w')
		for film in bd_divx.readlines():
			bd_divx_old.write(film)
		bd_divx.close()
		bd_divx_old.close()
		return True

	def trouver_double(self):
		liste_film = []
		liste_double = []
		num_film = 0
		for t in rechercher(None,None).dico_generale:
			if(self.stop):
				num_film = num_film + 1
				while(not(self.fraction(num_film))):
					1
				titre = rechercher(None,None).dico_generale[t][0]
				if not(self.est_deja(titre,liste_film)):
					liste_film.insert(0,titre)
				else:
					liste_double.insert(0,t)
			else:
				self.affiche_bouton_ok()
				break
		self.liste_double = liste_double

	def est_deja(self,titre,liste_film):
		if(filter(lambda e: e==titre, liste_film)):
			return True
		else:
			return False

	def enleve_redondant(self):
		bd = rechercher(None,None).bd
		bd_divx = open(bd,'w')
		bd_divx_old = open(bd+'_old','r')
		for film in bd_divx_old.readlines():
			if (not(filter(lambda e: e==film[4:11], self.liste_double))):
				bd_divx.write(film)
		bd_divx.close()
		bd_divx_old.close()
		self.fenetre.destroy()

	def enleve_cocher(self,film):
		if (filter(lambda e: e==film, self.liste_double)):
			i = 0
			for f in self.liste_double:
				if (f == film):
					del self.liste_double[i]
				i = i + 1
		else:
			self.liste_double.append(film)

	def afficher_double(self,dico):
		self.fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)#gtk.WINDOW_POPUP
		self.fenetre.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_notebook1,variables().Color_notebook2,variables().Color_notebook3))
		self.fenetre.set_default_size(600, 300)
		self.fenetre.connect("destroy", lambda x:self.fenetre.destroy())
		self.fenetre.set_border_width(0)
		
		notebook = gtk.Notebook()
		notebook.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_notebook1,variables().Color_notebook2,variables().Color_notebook3))

		fd = gtk.ScrolledWindow()
		fd.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
		fd.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_notebook1,variables().Color_notebook2,variables().Color_notebook3))
		
		boite_v = gtk.VBox(False, 0)
		titre_del = gtk.Label('Film à supprimer ('+str(len(dico))+') :\n')
		boite_v.pack_start(titre_del, False, False, 0)
		i = 1
		for film in dico:
			boite_h = gtk.HBox(False, 10)
			bouton_voir = gtk.Button('Voir')
			bouton_voir.connect("button_press_event", lambda e,w,i:notebook.set_current_page(i),i)
			boite_h.pack_start(bouton_voir, False, False, 0)
			bouton = gtk.CheckButton(film[1][0])
			bouton.set_active(True)
			bouton.connect("toggled", lambda w,i:self.enleve_cocher(i), film[0])
			boite_h.pack_start(bouton, False, False, 0)
			boite_v.pack_start(boite_h, False, False, 0)
			i = i + 1
		bouton_ok = gtk.Button('Supprimer')
		bouton_ok.connect("button_press_event", lambda e,w:self.enleve_redondant())
		boite_v.pack_start(bouton_ok, False, False, 0)

		fd.add_with_viewport(boite_v)
		titre = gtk.Label('StatS')
		notebook.append_page(fd, titre)

		if (len(dico)>5):
			notebook.set_scrollable(True)
		for film in dico:
			titre = film[1][0]
			datedesortie = '\nDate de Sortie : ' + film[1][1]
			realisateur = '\nRéalisateur : ' + film[1][2]
			nationnalite = '\nNationnalité : ' + film[1][3]
			genre = '\nGenre : ' + film[1][4]
			duree = '\nDurée : ' + film[1][5]
			repertoire = '\nRépertoire : ' + film[1][6]
			taille = '\nTaille : ' + film[1][7]
			reference = '\nMerci à : ' + film[1][8]
			synopsis = '\nSynopsis :\n' + film[1][9]

			fd = gtk.ScrolledWindow()
			fd.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
			textview = gtk.TextView()
			textview.set_wrap_mode(gtk.WRAP_WORD)
			buffertexte = textview.get_buffer()
			
			balise_titre = buffertexte.create_tag(None, background="blue", foreground="white", size_points=20, editable=False, justification=gtk.JUSTIFY_CENTER)
			buffertexte.set_text(titre)
			nb_caract_titre = buffertexte.get_char_count()
			debut_titre = buffertexte.get_start_iter()
			fin_titre = buffertexte.get_iter_at_offset(nb_caract_titre)
			buffertexte.apply_tag(balise_titre, debut_titre, fin_titre)

			balise_datedesortie = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_titre, datedesortie)
			nb_caract_datedesortie = buffertexte.get_char_count() + nb_caract_titre
			debut_datedesortie = buffertexte.get_iter_at_line(2)
			fin_datedesortie = buffertexte.get_iter_at_offset(nb_caract_datedesortie)
			buffertexte.apply_tag(balise_datedesortie, debut_datedesortie, fin_datedesortie)

			balise_realisateur = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_datedesortie, realisateur)
			nb_caract_realisateur = buffertexte.get_char_count() + nb_caract_datedesortie
			debut_realisateur = buffertexte.get_iter_at_line(3)
			fin_realisateur = buffertexte.get_iter_at_offset(nb_caract_realisateur)
			buffertexte.apply_tag(balise_realisateur, debut_realisateur, fin_realisateur)

			balise_nationnalite = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_realisateur, nationnalite)
			nb_caract_nationnalite = buffertexte.get_char_count() + nb_caract_realisateur	
			debut_nationnalite = buffertexte.get_iter_at_line(4)
			fin_nationnalite = buffertexte.get_iter_at_offset(nb_caract_nationnalite)
			buffertexte.apply_tag(balise_nationnalite, debut_nationnalite, fin_nationnalite)

			balise_genre = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_realisateur, genre)
			nb_caract_genre = buffertexte.get_char_count() + nb_caract_nationnalite
			debut_genre = buffertexte.get_iter_at_line(5)
			fin_genre = buffertexte.get_iter_at_offset(nb_caract_genre)
			buffertexte.apply_tag(balise_genre, debut_genre, fin_genre)

			balise_repertoire = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_realisateur, repertoire)
			nb_caract_repertoire = buffertexte.get_char_count() + nb_caract_genre
			debut_repertoire = buffertexte.get_iter_at_line(6)
			fin_repertoire = buffertexte.get_iter_at_offset(nb_caract_repertoire)
			buffertexte.apply_tag(balise_repertoire, debut_repertoire, fin_repertoire)

			balise_taille = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_realisateur, taille)
			nb_caract_taille = buffertexte.get_char_count() + nb_caract_repertoire
			debut_taille = buffertexte.get_iter_at_line(7)
			fin_taille =buffertexte.get_iter_at_offset(nb_caract_taille)
			buffertexte.apply_tag(balise_taille, debut_taille, fin_taille)

			balise_reference = buffertexte.create_tag(None, size_points=10, editable=False, background="red", foreground="white", justification=gtk.JUSTIFY_RIGHT)
			buffertexte.insert(fin_realisateur, reference)
			nb_caract_reference = buffertexte.get_char_count() + nb_caract_taille
			debut_reference = buffertexte.get_iter_at_line(8)
			fin_reference = buffertexte.get_iter_at_offset(nb_caract_reference)
			buffertexte.apply_tag(balise_reference, debut_reference, fin_reference)

			balise_synopsis = buffertexte.create_tag(None, size_points=10, editable=False)
			buffertexte.insert(fin_realisateur, synopsis)
			nb_caract_synopsis = buffertexte.get_char_count() + nb_caract_reference
			debut_synopsis = buffertexte.get_iter_at_line(9)
			fin_synopsis = buffertexte.get_iter_at_offset(nb_caract_synopsis)
			buffertexte.apply_tag(balise_synopsis, debut_synopsis, fin_synopsis)


			vboite = gtk.VBox(False,0)
			vboite.pack_start(textview, True, True, 0)

			bouton_1er = gtk.Button('<<')
			bouton_1er.connect("button_press_event", lambda e,w:notebook.set_current_page(0))
			bouton_prev = gtk.Button('<')
			bouton_prev.connect("button_press_event", lambda e,w:notebook.prev_page())
			bouton_suiv = gtk.Button('>')
			bouton_suiv.connect("button_press_event", lambda e,w:notebook.next_page())
			bouton_der = gtk.Button('>>')
			bouton_der.connect("button_press_event", lambda e,w:notebook.set_current_page(len(dico)))

			hboite = gtk.HBox(True,0)
			hboite.pack_start(bouton_1er, True, True, 0)
			hboite.pack_start(bouton_prev, True, True, 0)
			hboite.pack_start(bouton_suiv, True, True, 0)
			hboite.pack_start(bouton_der, True, True, 0)

			vboite.pack_start(hboite, False, False, 0)

			fd.add_with_viewport(vboite)

			titre = gtk.Label(''+titre+'')
			notebook.append_page(fd, titre)
		notebook.set_show_border(False)
		self.fenetre.add(notebook)
		self.fenetre.show_all()	

	def destroy(self, widget):
		gtk.main_quit()


########################################################################################################################
##Classe qui permet de définir les options :
#	- couleure générale
#	- extension à prendre
#	- répertoires à surveiller
#	- couleur des textview
########################################################################################################################
#
########################################################################################################################
#Améliorations :
#	- langue
#	- mise à jour
#	- raccourcis
########################################################################################################################
class options(skin):
	def __init__(self):
		pass

	def joli_boutton(self,titre,stock_id):
		hboite = gtk.HBox(False,0)
		hboite.set_border_width(2)
		etiquette = gtk.Label(titre)
		image = gtk.Image()
		image.set_from_stock(stock_id, gtk.ICON_SIZE_LARGE_TOOLBAR)
		hboite.pack_start(image, False, False, 3)
		hboite.pack_start(etiquette, False, False, 3)
		hboite.show_all()
		return hboite

	def fenetre(self,event,widget):
		self.fenetre = gtk.Window(gtk.WINDOW_TOPLEVEL)#gtk.WINDOW_POPUP
		self.fenetre.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_fenetre_options1,variables().Color_fenetre_options2,variables().Color_fenetre_options3))
		self.fenetre.set_default_size(600, 300)
		self.fenetre.connect("destroy", lambda x:self.fenetre.destroy())
		self.fenetre.set_border_width(0)
		
		notebook = gtk.Notebook()
		notebook.modify_bg(gtk.STATE_NORMAL,gtk.gdk.Color(variables().Color_fenetre_options1,variables().Color_fenetre_options2,variables().Color_fenetre_options3))
		notebook.set_tab_pos(variables().style_fenetre_options) 
		notebook.set_scrollable(False) 

		bouton_skin = gtk.Button()
		hboite_skin = self.joli_boutton("Skin",gtk.STOCK_SELECT_COLOR)
		bouton_skin.add(hboite_skin)
		bouton_skin.connect('clicked',lambda e:notebook.set_current_page(0))
		page_skin = self.faire_page_skin(None,None)
		notebook.append_page(page_skin, bouton_skin)

		bouton_systeme = gtk.Button()
		hboite_systeme = self.joli_boutton("Système",gtk.STOCK_EXECUTE)
		bouton_systeme.add(hboite_systeme)
		bouton_systeme.connect('clicked',lambda e:notebook.set_current_page(1))
		page_systeme = self.faire_page_systeme()
		notebook.append_page(page_systeme, bouton_systeme)

		bouton_internet = gtk.Button()
		hboite_internet = self.joli_boutton("Internet",gtk.STOCK_REFRESH)
		bouton_internet.add(hboite_internet)
		bouton_internet.connect('clicked',lambda e:notebook.set_current_page(2))
		page_internet = self.faire_page_internet()
		notebook.append_page(page_internet, bouton_internet)

		bouton_quitter = gtk.Button()
		hboite_quitter = self.joli_boutton("Quitter",gtk.STOCK_QUIT)
		bouton_quitter.add(hboite_quitter)
		bouton_quitter.connect('clicked',lambda e:self.fenetre.destroy())
		page_quitter = gtk.Label('Quitter')
		notebook.append_page(page_quitter, bouton_quitter)


		self.fenetre.add(notebook)
		self.fenetre.show_all()

	def faire_page_skin(self,frame_haut,ancien):
		if(ancien!=None):
			ancien.destroy()
		if(frame_haut==None):
			frame_haut = gtk.Frame()
		vboite_generale = gtk.VBox(False, 10)
		frame_haut.set_label("Skin")
		hboite_dessous = gtk.HBox(True,10)
		txt = gtk.Label("Choisissez l'une de ces catégories...")
		vboite_generale.pack_start(txt,True,True,10)
		bouton_creer_son_skin = gtk.Button()
		bouton_creer_son_skin.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Vous permet de créer\nlibrement une interface graphique\nà votre logiciel préféré ^^")
		bouton_creer_son_skin.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		bouton_creer_son_skin.connect('clicked',lambda d,frame,ancien:self.faire_page_skin_createur(frame,ancien),frame_haut,vboite_generale)
		hboite = self.joli_boutton("Créateur de Skin",gtk.STOCK_CONVERT)
		bouton_creer_son_skin.add(hboite)
		hboite_dessous.pack_start(bouton_creer_son_skin,False,False,0)
		bouton_changer_son_skin = gtk.Button()
		bouton_changer_son_skin.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Sélectionnez parmis une  liste\nl'interface graphique qui vous\ncorrespond au mieu^^")
		bouton_changer_son_skin.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("Changer de Skin",gtk.STOCK_JUMP_TO)
		bouton_changer_son_skin.add(hboite)
		hboite_dessous.pack_start(bouton_changer_son_skin,False,False,0)

		bouton_envoyer_bd = gtk.Button()
		bouton_envoyer_bd.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"!! Attention !!\nCe processus réorganise entièrement\nvotre base de donnée.\nPeu être très très long...")
		bouton_envoyer_bd.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("Envoyer votre BD",gtk.STOCK_GO_UP)
		bouton_envoyer_bd.add(hboite)
		hboite_dessous.pack_start(bouton_envoyer_bd,False,False,0)
		vboite_generale.pack_start(hboite_dessous,False,False,0)

		frame_haut.add(vboite_generale)
		frame_haut.show_all()
		return frame_haut

	def faire_page_skin_createur(self,frame,ancien):
		ancien.destroy()
		frame.set_label("Créateur de Skin")

		vboite_generale = gtk.VBox(False, 10)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Titre du skin : ")
		hboite.pack_start(titre,False,False,0)
		titre_entry = gtk.Entry()
		hboite.pack_start(titre_entry,True,True,0)
		vboite_generale.pack_start(hboite,False,False,0)

		frame_generale = gtk.Frame('Fenêtre Générale')
		vboite_options = gtk.VBox(False, 10)
		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure de la fenêtre : ")
		hboite.pack_start(titre,False,False,0)
		couleure_generale = gtk.ColorButton(gtk.gdk.Color(variables().Color_fenetre_generale1,variables().Color_fenetre_generale2,variables().Color_fenetre_generale3))
		couleure_generale.set_use_alpha(True)
		hboite.pack_start(couleure_generale,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)
		frame_generale.add(vboite_options)
		vboite_generale.pack_start(frame_generale,False,False,0)

		frame_notebook = gtk.Frame('Présentation des Films')
		vboite_options = gtk.VBox(False, 10)
		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Onglets : ")
		hboite.pack_start(titre,False,False,0)
		notebook_entry = gtk.combo_box_entry_new_text()
		notebook_entry.append_text("au dessus")
		notebook_entry.append_text("au dessous")
		notebook_entry.append_text("à droite")
		notebook_entry.append_text("à gauche")
		notebook_entry.set_active(0)
		hboite.pack_start(notebook_entry,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Justification du titre : ")
		hboite.pack_start(titre,False,False,0)
		notebook_justification = gtk.combo_box_entry_new_text()
		notebook_justification.append_text("au centre")
		notebook_justification.append_text("à droite")
		notebook_justification.append_text("à gauche")
		notebook_justification.set_active(0)
		hboite.pack_start(notebook_justification,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure de la fenêtre : ")
		hboite.pack_start(titre,False,False,0)
		couleure_notebook = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_notebook1,variables().Color_notebook2,variables().Color_notebook3))
		couleure_notebook.set_use_alpha(True)
		hboite.pack_start(couleure_notebook,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure du titre : ")
		hboite.pack_start(titre,False,False,0)
		couleure_titre = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_titre1,variables().Color_titre2,variables().Color_titre3))
		couleure_titre.set_use_alpha(True)
		hboite.pack_start(couleure_titre,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure du fond du titre : ")
		hboite.pack_start(titre,False,False,0)
		couleure_fond_titre = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_fond_titre1,variables().Color_fond_titre2,variables().Color_fond_titre3))
		couleure_fond_titre.set_use_alpha(True)
		hboite.pack_start(couleure_fond_titre,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Police du titre : ")
		hboite.pack_start(titre,False,False,0)
		font_titre = gtk.FontButton()
		hboite.pack_start(font_titre,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure des textes : ")
		hboite.pack_start(titre,False,False,0)
		couleure_textes = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_texte1,variables().Color_texte2,variables().Color_texte3))
		couleure_textes.set_use_alpha(True)
		hboite.pack_start(couleure_textes,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure de l'arrière plan des textes : ")
		hboite.pack_start(titre,False,False,0)
		couleure_fond_textes = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_fond_texte1,variables().Color_fond_texte2,variables().Color_fond_texte3))
		couleure_fond_textes.set_use_alpha(True)
		hboite.pack_start(couleure_fond_textes,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Police des textes : ")
		hboite.pack_start(titre,False,False,0)
		font_textes = gtk.FontButton()
		hboite.pack_start(font_textes,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		frame_notebook.add(vboite_options)

		vboite_generale.pack_start(frame_notebook,True,True,0)

		frame_Options = gtk.Frame('Options')

		vboite_options = gtk.VBox(False, 10)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Onglets : ")
		hboite.pack_start(titre,False,False,0)
		Options_entry = gtk.combo_box_entry_new_text()
		Options_entry.set_active(2)
		Options_entry.append_text("au dessus")
		Options_entry.append_text("au dessous")
		Options_entry.append_text("à droite")
		Options_entry.append_text("à gauche")
		Options_entry.set_active(0)
		hboite.pack_start(Options_entry,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure de la fenêtre : ")
		hboite.pack_start(titre,False,False,0)
		couleure_Options = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_fenetre_options1,variables().Color_fenetre_options2,variables().Color_fenetre_options3))
		couleure_Options.set_use_alpha(True)
		hboite.pack_start(couleure_Options,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)
		
		frame_Options.add(vboite_options)

		vboite_generale.pack_start(frame_Options,True,True,5)

		frame_ajout = gtk.Frame('Ajout des films')

		vboite_options = gtk.VBox(False, 10)

		hboite = gtk.HBox(False,0)
		titre = gtk.Label("Couleure de la fenêtre : ")
		hboite.pack_start(titre,False,False,0)
		couleure_ajout = gtk.ColorButton(color=gtk.gdk.Color(variables().Color_fenetre_ajout1,variables().Color_fenetre_ajout2,variables().Color_fenetre_ajout3))
		couleure_ajout.set_use_alpha(True)
		hboite.pack_start(couleure_ajout,True,True,0)
		vboite_options.pack_start(hboite,False,False,0)
		
		frame_ajout.add(vboite_options)

		vboite_generale.pack_start(frame_ajout,True,True,5)

		hboite_bouttons = gtk.HBox(True,0)
		bouton_ok = gtk.Button()
		hboite = self.joli_boutton("Enregistrer",gtk.STOCK_SAVE)
		bouton_ok.add(hboite)

		infos = []###toutes les possibilités
		infos.insert(0,titre_entry)
		infos.insert(1,couleure_generale)
		infos.insert(2,notebook_entry)
		infos.insert(3,notebook_justification)
		infos.insert(4,couleure_notebook)
		infos.insert(5,couleure_titre)
		infos.insert(6,couleure_fond_titre)
		infos.insert(7,font_titre)
		infos.insert(8,couleure_textes)
		infos.insert(9,couleure_fond_textes)
		infos.insert(10,Options_entry)
		infos.insert(11,couleure_Options)
		infos.insert(12,couleure_ajout)

		bouton_ok.connect('clicked',lambda e:self.enregistrer_skin(infos))
		bouton_ok.connect_after('clicked',lambda e:self.faire_page_skin(frame,vboite_generale))
		hboite_bouttons.pack_start(bouton_ok,False,False,0)
		bouton_annuler = gtk.Button()
		hboite = self.joli_boutton("Annuler",gtk.STOCK_UNDO)
		bouton_annuler.add(hboite)
		bouton_annuler.connect('clicked',lambda e:self.faire_page_skin(frame,vboite_generale))
		hboite_bouttons.pack_start(bouton_annuler,False,False,0)
		
		vboite_generale.pack_start(hboite_bouttons,False,False,0)

		frame.add(vboite_generale)
		frame.show_all()
		return frame


	def enregistrer_skin(self,infos):
		titre_entry = infos[0]#
		couleure_generale = infos[1]
		notebook_entry = infos[2]#
		notebook_justification = infos[3]#
		couleure_fenetre_presentation = infos[4]
		couleure_titre = infos[5]
		couleure_fond_titre = infos[6]
		police_titre = infos[7]
		couleure_textes = infos[8]
		couleure_fond_textes = infos[9]
		Options_entry = infos[10]
		couleure_Options = infos[11]
		couleure_ajout = infos[12]

		titre_skin = titre_entry.get_text()
		couleure_generale = couleure_generale.get_color().to_string()#A voir pour couleure

		if(notebook_entry.get_active()==0):
			onglet_presentation = "top"#gtk.POS_TOP
		elif(notebook_entry.get_active()==1):
			onglet_presentation = "bottom"#gtk.POS_BOTTOM
		elif(notebook_entry.get_active()==2):
			onglet_presentation = "right"#gtk.POS_RIGHT
		elif(notebook_entry.get_active()==3):
			onglet_presentation = "left"#gtk.POS_LEFT
		if(notebook_justification.get_active()==0):
			justification_titre = "center"#gtk.JUSTIFY_CENTER
		elif(notebook_justification.get_active()==1):
			justification_titre = "right"#gtk.JUSTIFY_RIGHT
		elif(notebook_justification.get_active()==2):
			justification_titre = "left"#gtk.JUSTIFY_LEFT

		couleure_fenetre_presentation = 0#A voir pour couleure
		couleure_titre = 0#A voir pour couleure
		couleure_fd_titre = 0#A voir pour couleure
		police_titre = 0#A voir pour police+size
		taille_titre = 0#A voir pour police+size
		couleure_texte = 0#A voir pour couleure
		couleure_fd_texte = 0#A voir pour couleure
		police_texte = 0#A voir pour police+size
		taille_texte = 0#A voir pour police+size
#############################################

	def faire_page_systeme(self):
		frame_haut = gtk.Frame('Système')
		vboite_generale = gtk.VBox(False, 10)
		hboite_dessous = gtk.HBox(True,10)
		txt = gtk.Label("Choisissez l'une de ces catégories...")
		vboite_generale.pack_start(txt,True,True,10)
		bouton_repertoire_a_surveiller = gtk.Button()
		bouton_repertoire_a_surveiller.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Enregistrez-y les répertoires\nqui doivent être régulièrement\ninspectés pour ne plus avoir à\ns'en souciez^^")
		bouton_repertoire_a_surveiller.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("Path",gtk.STOCK_SAVE_AS)
		bouton_repertoire_a_surveiller.add(hboite)
		hboite_dessous.pack_start(bouton_repertoire_a_surveiller,False,False,0)

		bouton_organisez_bd = gtk.Button()
		bouton_organisez_bd.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"!! Attention !!\nCe processus réorganise entièrement\nvotre base de donnée.\nPeu être très très long...")
		bouton_organisez_bd.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("RéOrganiser votre BD",gtk.STOCK_UNDELETE)
		bouton_organisez_bd.add(hboite)
		hboite_dessous.pack_start(bouton_organisez_bd,False,False,0)

		bouton_log = gtk.Button()
		bouton_log.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Vous permet de définir\ndifférents paramètres pour\nles logs. Mais aussi\nde les inspecter et envoyer^^")
		bouton_log.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("Log",gtk.STOCK_ZOOM_IN)
		bouton_log.add(hboite)
		hboite_dessous.pack_start(bouton_log,False,False,0)
		vboite_generale.pack_start(hboite_dessous,False,False,0)

		frame_haut.add(vboite_generale)
		frame_haut.show_all()
		return frame_haut

	def faire_page_internet(self):
		frame_haut = gtk.Frame('Internet')
		vboite_generale = gtk.VBox(False, 10)
		hboite_dessous = gtk.HBox(True,10)
		txt = gtk.Label("Choisissez l'une de ces catégories...")
		vboite_generale.pack_start(txt,True,True,10)
		bouton_mise_a_jour = gtk.Button()
		bouton_mise_a_jour.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Vérifiez qu'il n'y est pas\nde version plus récente car\nvous ne bénéficierez pas\ndes dernières options.")
		bouton_mise_a_jour.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("Mise à jour",gtk.STOCK_SAVE_AS)
		bouton_mise_a_jour.add(hboite)
		hboite_dessous.pack_start(bouton_mise_a_jour,False,False,0)

		bouton_envoyer_synopsis = gtk.Button()
		bouton_envoyer_synopsis.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Si vous avez vous-même rempli\nune fiche non disponible sur\nallociné.fr\nmerci de partager.")
		bouton_envoyer_synopsis.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("Envoyer mes synopsis",gtk.STOCK_UNDELETE)
		bouton_envoyer_synopsis.add(hboite)
		hboite_dessous.pack_start(bouton_envoyer_synopsis,False,False,0)

		bouton_news = gtk.Button()
		bouton_news.connect('enter',lambda d,w,t:self.refresh(w,t),txt,"Paramètrez les news que je\nvous envoie de temps en temps...")
		bouton_news.connect('leave',lambda d,w,t:self.refresh(w,t),txt,"Choisissez l'une de ces catégories...")
		hboite = self.joli_boutton("News",gtk.STOCK_ZOOM_IN)
		bouton_news.add(hboite)
		hboite_dessous.pack_start(bouton_news,False,False,0)
		vboite_generale.pack_start(hboite_dessous,False,False,0)

		frame_haut.add(vboite_generale)
		frame_haut.show_all()
		return frame_haut

	def refresh(self,widget,txt):
		widget.set_text(""+txt+"")
		widget.show_now()










########################################################################################################################
########################################################################################################################
#Lancement du programme
########################################################################################################################
########################################################################################################################
if __name__ == "__main__":#démare le programme
	app = skin()
	gtk.gdk.threads_init()
	gtk.main()
	#app.iconbitmap('icone.ico')
